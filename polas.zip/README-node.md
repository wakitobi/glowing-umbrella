# Linux Node.js controller

The control plane, dashboard, telemetry, and optional Ollama analysis now run in Node.js. The existing `redis.so` mining engine remains a Python extension, so `miner_bridge.py` is the smallest possible compatibility layer.

Requirements:

- Linux x86-64
- Node.js 18 or newer
- Python 3 matching the ABI used to build `redis.so`
- Existing `.env` file beside these scripts

Start:

```bash
cd /path/to/xmrig
npm start
```

Dashboard: read the randomly selected `127.0.0.1:PORT` URL from startup output. Set `DASHBOARD_PORT` to a value from `10000` through `65000` when a fixed port is required.

Optional local-LLM telemetry analysis:

```bash
OLLAMA_URL=http://127.0.0.1:11434 \
OLLAMA_MODEL=qwen2.5:1.5b \
npm start
```

If Python is installed under another command:

```bash
PYTHON=/usr/bin/python3.11 npm start
```

Tests do not connect to the pool:

```bash
npm test
python3 -m py_compile miner_bridge.py
```

Security and labeling:

- Pool credentials remain only in `.env`.
- Telemetry logs do not contain the URL, user, or password.
- The dashboard and Ollama prompt explicitly identify the workload as cryptocurrency mining.
