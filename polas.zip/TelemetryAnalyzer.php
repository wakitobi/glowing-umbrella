<?php
declare(strict_types=1);

final class TelemetryAnalyzer
{
    private string $logPath;
    private float $interval;
    private string $ollamaUrl;
    private string $ollamaModel;
    /** @var array<int, array<string, int|float|string>> */
    private array $history = [];
    private string $lastAnalysis = 'Waiting for mining telemetry.';
    private float $lastAnalysisAt = 0.0;

    public function __construct(
        string $logPath = 'telemetry.jsonl',
        float $interval = 60.0,
        string $ollamaUrl = '',
        string $ollamaModel = ''
    ) {
        $this->logPath = $logPath;
        $this->interval = max(5.0, $interval);
        $this->ollamaUrl = rtrim($ollamaUrl, '/');
        $this->ollamaModel = $ollamaModel;
        $this->loadHistory();
    }

    private function loadHistory(): void
    {
        if (!is_file($this->logPath)) {
            return;
        }
        $lines = @file($this->logPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($lines === false) {
            return;
        }
        foreach (array_slice($lines, -120) as $line) {
            $row = json_decode($line, true);
            if (is_array($row) && $this->validSnapshot($row)) {
                $this->history[] = $row;
            }
        }
    }

    /** @param array<string, mixed> $row */
    private function validSnapshot(array $row): bool
    {
        return isset($row['timestamp'], $row['status'], $row['job'], $row['shares'], $row['hashrate'])
            && is_numeric($row['timestamp']) && is_numeric($row['shares']) && is_numeric($row['hashrate']);
    }

    /** @param array<string, mixed> $state
     *  @return array<string, int|float|string>
     */
    public function record(array $state): array
    {
        $snapshot = [
            'timestamp' => microtime(true),
            'status' => substr((string)($state['status'] ?? 'unknown'), 0, 64),
            'job' => substr((string)($state['job'] ?? '-'), 0, 128),
            'shares' => max(0, (int)($state['shares'] ?? 0)),
            'hashrate' => max(0.0, (float)($state['hashrate'] ?? 0.0)),
        ];
        $this->history[] = $snapshot;
        $this->history = array_slice($this->history, -120);
        $directory = dirname($this->logPath);
        if ($directory !== '.' && !is_dir($directory)) {
            mkdir($directory, 0770, true);
        }
        file_put_contents(
            $this->logPath,
            json_encode($snapshot, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR) . PHP_EOL,
            FILE_APPEND | LOCK_EX
        );
        if ($snapshot['timestamp'] - $this->lastAnalysisAt >= $this->interval) {
            $this->lastAnalysis = $this->analyze();
            $this->lastAnalysisAt = (float)$snapshot['timestamp'];
        }
        return $snapshot;
    }

    /** @return array<string, int|float|string> */
    public function metrics(): array
    {
        if ($this->history === []) {
            return ['samples' => 0, 'hashrate' => 0.0, 'trend_pct' => 0.0, 'shares' => 0];
        }
        $rates = [];
        foreach ($this->history as $item) {
            if ((float)$item['hashrate'] > 0) {
                $rates[] = (float)$item['hashrate'];
            }
        }
        $midpoint = max(1, intdiv(count($rates), 2));
        $oldRates = array_slice($rates, 0, $midpoint);
        $newRates = array_slice($rates, $midpoint);
        if ($newRates === []) {
            $newRates = $oldRates;
        }
        $average = static fn(array $values): float => $values === [] ? 0.0 : array_sum($values) / count($values);
        $old = $average($oldRates);
        $new = $average($newRates);
        $latest = $this->history[array_key_last($this->history)];
        return [
            'samples' => count($this->history),
            'hashrate' => round((float)$latest['hashrate'], 2),
            'average_hashrate' => round($average($rates), 2),
            'trend_pct' => round($old > 0 ? (($new - $old) / $old) * 100 : 0.0, 2),
            'shares' => (int)$latest['shares'],
            'status' => (string)$latest['status'],
        ];
    }

    public function lastAnalysis(): string
    {
        return $this->lastAnalysis;
    }

    public function analyze(): string
    {
        $metrics = $this->metrics();
        if ($this->ollamaUrl !== '' && $this->ollamaModel !== '') {
            $result = $this->ollamaAnalysis($metrics);
            if ($result !== null) {
                return $result;
            }
        }
        return $this->ruleAnalysis($metrics);
    }

    /** @param array<string, int|float|string> $metrics */
    private function ruleAnalysis(array $metrics): string
    {
        if ((int)$metrics['samples'] === 0) {
            return 'Waiting for mining telemetry.';
        }
        if ((float)$metrics['hashrate'] <= 0) {
            return 'Mining is not producing hashrate; check the pool connection and worker state.';
        }
        $trend = (float)$metrics['trend_pct'];
        if ($trend <= -15) {
            return sprintf('Hashrate is falling (%.1f%% trend); check CPU contention and thermal throttling.', $trend);
        }
        if ($trend >= 15) {
            return sprintf('Hashrate is improving (%.1f%% trend); keep the current configuration while collecting more samples.', $trend);
        }
        return sprintf('Mining is stable at %.2f H/s with %d submitted shares.', (float)$metrics['hashrate'], (int)$metrics['shares']);
    }

    /** @param array<string, int|float|string> $metrics */
    private function ollamaAnalysis(array $metrics): ?string
    {
        $payload = json_encode([
            'model' => $this->ollamaModel,
            'stream' => false,
            'prompt' => 'You analyze explicitly labeled cryptocurrency-mining telemetry. Give one concise operational observation. Never claim this is LLM inference. Metrics: ' . json_encode($metrics, JSON_UNESCAPED_SLASHES),
        ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        $context = stream_context_create(['http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\n",
            'content' => $payload,
            'timeout' => 10,
            'ignore_errors' => true,
        ]]);
        $body = @file_get_contents($this->ollamaUrl . '/api/generate', false, $context);
        if ($body === false) {
            return null;
        }
        $decoded = json_decode($body, true);
        $text = is_array($decoded) ? trim((string)($decoded['response'] ?? '')) : '';
        return $text === '' ? null : substr($text, 0, 500);
    }
}
