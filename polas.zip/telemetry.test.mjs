import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { TelemetryAnalyzer } from "./telemetry.mjs";

test("records sanitized mining metrics", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "miner-telemetry-"));
  const logPath = path.join(directory, "telemetry.jsonl");
  const analyzer = new TelemetryAnalyzer({ logPath, interval: 5_000 });
  await analyzer.record({ status: "hashrate", job: "a", shares: 2, hashrate: 100, password: "secret" });
  await analyzer.record({ status: "hashrate", job: "b", shares: 3, hashrate: 110, url: "private" });
  assert.deepEqual(analyzer.metrics(), {
    samples: 2,
    hashrate: 110,
    average_hashrate: 105,
    trend_pct: 10,
    shares: 3,
    status: "hashrate",
    last_event: analyzer.metrics().last_event,
    stale: false,
  });
  const text = fs.readFileSync(logPath, "utf8");
  assert.equal(text.includes("secret"), false);
  assert.equal(text.includes("private"), false);
  fs.rmSync(directory, { recursive: true, force: true });
});

test("reports zero hashrate", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "miner-telemetry-"));
  const analyzer = new TelemetryAnalyzer({ logPath: path.join(directory, "telemetry.jsonl") });
  await analyzer.record({ status: "connected", shares: 0, hashrate: 0 });
  assert.match(await analyzer.analyze(), /not producing hashrate/);
  fs.rmSync(directory, { recursive: true, force: true });
});

test("loads valid rows, ignores malformed rows, and bounds history", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "miner-telemetry-"));
  const logPath = path.join(directory, "telemetry.jsonl");
  fs.writeFileSync(logPath, [
    JSON.stringify({ timestamp: 1, status: "hashrate", job: "a", shares: 1, hashrate: 90 }),
    "not-json",
    JSON.stringify({ timestamp: 2, password: "must-not-load" }),
  ].join("\n"));
  const analyzer = new TelemetryAnalyzer({ logPath, historyLimit: 2 });
  assert.equal(analyzer.history().length, 1);
  assert.equal(analyzer.history()[0].job, "a");
  await analyzer.record({ status: "hashrate", job: "b", shares: 2, hashrate: 100 });
  await analyzer.record({ status: "hashrate", job: "c", shares: 3, hashrate: 110 });
  assert.equal(analyzer.history().length, 2);
  assert.equal(analyzer.metrics().hashrate, 110);
  assert.equal(JSON.stringify(analyzer.history()).includes("must-not-load"), false);
  fs.rmSync(directory, { recursive: true, force: true });
});

test("reports stale telemetry", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "miner-telemetry-"));
  const analyzer = new TelemetryAnalyzer({ logPath: path.join(directory, "telemetry.jsonl"), staleAfter: 1 });
  await analyzer.record({ status: "hashrate", job: "a", shares: 1, hashrate: 100 });
  await new Promise((resolve) => setTimeout(resolve, 5));
  assert.equal(analyzer.metrics().stale, true);
  fs.rmSync(directory, { recursive: true, force: true });
});
