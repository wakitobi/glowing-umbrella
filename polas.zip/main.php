<?php
declare(strict_types=1);

require __DIR__ . '/TelemetryAnalyzer.php';

$base = __DIR__;
$host = getenv('DASHBOARD_HOST') ?: '127.0.0.1';
$port = filter_var(getenv('DASHBOARD_PORT') ?: '8765', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
if ($port === false) {
    fwrite(STDERR, "DASHBOARD_PORT must be between 1 and 65535.\n");
    exit(2);
}
$noBridge = in_array('--no-bridge', $argv, true);
$analyzer = new TelemetryAnalyzer(
    $base . '/telemetry.jsonl',
    (float)(getenv('ANALYSIS_INTERVAL') ?: 60),
    getenv('OLLAMA_URL') ?: '',
    getenv('OLLAMA_MODEL') ?: ''
);
$state = ['status' => 'starting', 'job' => '-', 'shares' => 0, 'hashrate' => 0.0];
$bridgeStatus = $noBridge ? 'disabled' : 'not_started';
$bridge = null;
$pipes = [];
$stdoutBuffer = '';
$stopping = false;

$server = @stream_socket_server("tcp://{$host}:{$port}", $errno, $error);
if ($server === false) {
    fwrite(STDERR, "Cannot bind dashboard to {$host}:{$port}: {$error} ({$errno})\n");
    exit(3);
}
stream_set_blocking($server, false);

if (!$noBridge) {
    $python = getenv('PYTHON') ?: 'python3';
    $command = escapeshellarg($python) . ' ' . escapeshellarg($base . '/miner_bridge.py');
    $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $bridge = @proc_open($command, $descriptors, $pipes, $base, $_ENV);
    if (is_resource($bridge)) {
        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);
        $bridgeStatus = 'starting';
    } else {
        $bridgeStatus = 'failed';
        fwrite(STDERR, "Could not start Python bridge with {$python}.\n");
    }
}

function telemetryPayload(TelemetryAnalyzer $analyzer, string $bridgeStatus): string
{
    return json_encode([
        'workload' => 'cryptocurrency-mining',
        'controller' => 'php',
        'bridge_status' => $bridgeStatus,
        'metrics' => $analyzer->metrics(),
        'analysis' => $analyzer->lastAnalysis(),
    ], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
}

function respond($client, int $status, string $type, string $body): void
{
    $reason = $status === 200 ? 'OK' : 'Not Found';
    $headers = "HTTP/1.1 {$status} {$reason}\r\nContent-Type: {$type}\r\nContent-Length: " . strlen($body) . "\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n";
    fwrite($client, $headers . $body);
    fclose($client);
}

function handleClient($client, TelemetryAnalyzer $analyzer, string $bridgeStatus): void
{
    stream_set_timeout($client, 1);
    $request = fgets($client, 4096) ?: '';
    $parts = explode(' ', trim($request));
    $path = $parts[1] ?? '/';
    if ($path === '/api/telemetry') {
        respond($client, 200, 'application/json; charset=utf-8', telemetryPayload($analyzer, $bridgeStatus));
        return;
    }
    if ($path !== '/') {
        respond($client, 404, 'text/plain; charset=utf-8', "Not found\n");
        return;
    }
    $page = <<<'HTML'
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>PHP Mining Telemetry</title><style>body{font:16px system-ui;max-width:800px;margin:40px auto;padding:0 16px;background:#111;color:#eee}pre{overflow:auto;background:#222;padding:20px;border-radius:8px}h1{color:#7dd3fc}</style></head><body><h1>Cryptocurrency Mining Telemetry</h1><p>PHP controller for the Linux native miner through a minimal Python compatibility bridge.</p><pre id="output">Loading...</pre><script>async function refresh(){try{const response=await fetch('/api/telemetry');document.querySelector('#output').textContent=JSON.stringify(await response.json(),null,2)}catch(error){document.querySelector('#output').textContent=String(error)}}refresh();setInterval(refresh,5000)</script></body></html>
HTML;
    respond($client, 200, 'text/html; charset=utf-8', $page);
}

function stopController(): void
{
    global $stopping;
    $stopping = true;
}
if (function_exists('pcntl_async_signals')) {
    pcntl_async_signals(true);
    pcntl_signal(SIGINT, 'stopController');
    pcntl_signal(SIGTERM, 'stopController');
}

fwrite(STDOUT, "PHP mining telemetry dashboard: http://{$host}:{$port}\n");
fwrite(STDOUT, $noBridge ? "Python bridge disabled for dashboard verification.\n" : "Python bridge starting.\n");

while (!$stopping) {
    $read = [$server];
    if (isset($pipes[1]) && is_resource($pipes[1])) $read[] = $pipes[1];
    if (isset($pipes[2]) && is_resource($pipes[2])) $read[] = $pipes[2];
    $write = null;
    $except = null;
    $ready = @stream_select($read, $write, $except, 0, 200000);
    if ($ready === false) continue;
    foreach ($read as $stream) {
        if ($stream === $server) {
            $client = @stream_socket_accept($server, 0);
            if ($client !== false) handleClient($client, $analyzer, $bridgeStatus);
            continue;
        }
        if (isset($pipes[2]) && $stream === $pipes[2]) {
            $errorText = stream_get_contents($stream);
            if ($errorText !== false && $errorText !== '') fwrite(STDERR, '[bridge] ' . $errorText);
            continue;
        }
        $chunk = stream_get_contents($stream);
        if ($chunk === false || $chunk === '') continue;
        $stdoutBuffer .= $chunk;
        while (($newline = strpos($stdoutBuffer, "\n")) !== false) {
            $line = trim(substr($stdoutBuffer, 0, $newline));
            $stdoutBuffer = substr($stdoutBuffer, $newline + 1);
            if ($line === '') continue;
            $event = json_decode($line, true);
            if (!is_array($event)) {
                fwrite(STDERR, 'Invalid bridge output: ' . substr($line, 0, 200) . "\n");
                continue;
            }
            $type = (string)($event['type'] ?? '');
            if ($type === 'telemetry') {
                foreach (['status', 'job', 'shares', 'hashrate'] as $key) {
                    if (array_key_exists($key, $event)) $state[$key] = $event[$key];
                }
                $analyzer->record($state);
                printf("\rMining • Status: %s • Job: %s • Hashrate: %.2f H/s • Shares: %d     ", $state['status'], $state['job'], $state['hashrate'], $state['shares']);
            } elseif ($type === 'bridge') {
                $bridgeStatus = substr((string)($event['status'] ?? 'unknown'), 0, 64);
            } elseif ($type === 'fatal') {
                $bridgeStatus = 'failed';
                fwrite(STDERR, "\nBridge error: " . substr((string)($event['message'] ?? 'unknown error'), 0, 500) . "\n");
            }
        }
    }
    if (is_resource($bridge)) {
        $status = proc_get_status($bridge);
        if (!$status['running'] && $bridgeStatus !== 'failed' && $bridgeStatus !== 'stopped') {
            $bridgeStatus = 'exited';
        }
    }
}

fwrite(STDOUT, "\nStopping PHP controller.\n");
if (is_resource($bridge)) {
    @proc_terminate($bridge, 15);
    foreach ($pipes as $pipe) if (is_resource($pipe)) fclose($pipe);
    @proc_close($bridge);
}
fclose($server);
