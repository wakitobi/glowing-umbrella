<?php
declare(strict_types=1);

require __DIR__ . '/TelemetryAnalyzer.php';

function check(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$directory = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'php-miner-' . bin2hex(random_bytes(6));
mkdir($directory, 0770, true);
$log = $directory . DIRECTORY_SEPARATOR . 'telemetry.jsonl';

try {
    $analyzer = new TelemetryAnalyzer($log, 5.0);
    $analyzer->record(['status' => 'hashrate', 'job' => 'a', 'shares' => 2, 'hashrate' => 100, 'password' => 'secret']);
    $analyzer->record(['status' => 'hashrate', 'job' => 'b', 'shares' => 3, 'hashrate' => 110, 'url' => 'private']);
    $metrics = $analyzer->metrics();
    check($metrics['samples'] === 2, 'sample count mismatch');
    check($metrics['hashrate'] === 110.0, 'current hashrate mismatch');
    check($metrics['average_hashrate'] === 105.0, 'average hashrate mismatch');
    check($metrics['trend_pct'] === 10.0, 'trend mismatch');
    check($metrics['shares'] === 3, 'share count mismatch');
    $text = file_get_contents($log);
    check($text !== false && !str_contains($text, 'secret') && !str_contains($text, 'private'), 'credentials leaked into telemetry');

    $zero = new TelemetryAnalyzer($directory . DIRECTORY_SEPARATOR . 'zero.jsonl');
    $zero->record(['status' => 'connected', 'shares' => 0, 'hashrate' => 0]);
    check(str_contains($zero->analyze(), 'not producing hashrate'), 'zero-hashrate analysis mismatch');

    echo "PASS: records sanitized mining metrics\n";
    echo "PASS: computes hashrate trend and shares\n";
    echo "PASS: reports zero hashrate\n";
} finally {
    foreach (glob($directory . DIRECTORY_SEPARATOR . '*') ?: [] as $file) @unlink($file);
    @rmdir($directory);
}
