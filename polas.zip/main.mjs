#!/usr/bin/env node
import { spawn } from "node:child_process";
import http from "node:http";
import readline from "node:readline";
import fs from "node:fs";
import { loadConfig } from "./config.mjs";
import { TelemetryAnalyzer } from "./telemetry.mjs";

let config;
try { config = loadConfig(); } catch (error) { console.error(`Configuration error: ${error.message}`); process.exit(2); }

const analyzer = new TelemetryAnalyzer({
  logPath: config.telemetryPath,
  interval: config.analysisIntervalMs,
  staleAfter: config.staleAfterMs,
  historyLimit: config.historyLimit,
  logMaxBytes: config.logMaxBytes,
  ollamaUrl: config.ollamaUrl,
  ollamaModel: config.ollamaModel,
});
const state = { status: "starting", job: "-", shares: 0, hashrate: 0 };
const runtime = { bridge: null, bridgeStatus: config.engineEnabled ? "not_started" : "disabled", starts: 0, restarts: 0, lastExit: null, stopping: false, desiredRunning: config.engineEnabled, restartTimer: null };

function payload() {
  return { workload: "cryptocurrency-mining", controller: "node", version: config.version, hostname: config.hostname, engine_enabled: config.engineEnabled, bridge_status: runtime.bridgeStatus, runtime: { starts: runtime.starts, restarts: runtime.restarts, last_exit: runtime.lastExit }, metrics: analyzer.metrics(), analysis: analyzer.lastAnalysisText };
}
function json(response, status, value) {
  const body = JSON.stringify(value);
  response.writeHead(status, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "content-length": Buffer.byteLength(body) });
  response.end(body);
}
function serveFile(response, name, type) {
  const file = `${config.publicDir}/${name}`;
  const body = fs.readFileSync(file);
  response.writeHead(200, { "content-type": type, "cache-control": "no-cache", "content-length": body.length });
  response.end(body);
}
function updateState(event) {
  state.status = String(event.status ?? state.status).slice(0, 64);
  state.job = String(event.job ?? state.job).slice(0, 128);
  state.shares = Math.max(0, Number(event.shares) || 0);
  state.hashrate = Math.max(0, Number(event.hashrate) || 0);
}
function scheduleRestart() {
  if (runtime.stopping || !runtime.desiredRunning || !config.engineEnabled || runtime.restarts >= config.restartLimit) return;
  const delay = Math.min(config.restartBaseMs * (2 ** Math.min(runtime.restarts, 6)), 120_000);
  runtime.restartTimer = setTimeout(() => { runtime.restartTimer = null; startBridge(); }, delay);
  console.error(`Bridge restart scheduled in ${Math.round(delay / 1000)}s.`);
}
function startBridge() {
  if (runtime.stopping || !config.engineEnabled || runtime.bridge) return false;
  runtime.desiredRunning = true;
  runtime.starts += 1;
  runtime.bridgeStatus = "starting";
  const child = spawn(config.python, [config.bridgePath], { cwd: config.rootDir, env: process.env, stdio: ["ignore", "pipe", "pipe"] });
  runtime.bridge = child;
  const lines = readline.createInterface({ input: child.stdout });
  lines.on("line", async (line) => {
    let event;
    try { event = JSON.parse(line); } catch { console.error(`Invalid bridge output: ${line.slice(0, 200)}`); return; }
    if (event.type === "telemetry") { updateState(event); await analyzer.record(state); }
    else if (event.type === "bridge") runtime.bridgeStatus = String(event.status || "unknown").slice(0, 64);
    else if (event.type === "fatal") { runtime.bridgeStatus = "failed"; console.error(`Bridge error: ${String(event.message || "unknown error").slice(0, 500)}`); }
  });
  child.stderr.on("data", (chunk) => process.stderr.write(`[bridge] ${chunk}`));
  child.on("error", (error) => { runtime.bridgeStatus = "failed"; console.error(`Could not start ${config.python}: ${error.message}`); });
  child.on("exit", (code, signal) => {
    runtime.bridge = null;
    runtime.lastExit = { code, signal, at: new Date().toISOString() };
    runtime.bridgeStatus = runtime.stopping ? "stopped" : "exited";
    if (!runtime.stopping && runtime.desiredRunning) { runtime.restarts += 1; scheduleRestart(); }
  });
  return true;
}
function stopBridge() {
  runtime.desiredRunning = false;
  if (runtime.restartTimer) clearTimeout(runtime.restartTimer);
  if (!runtime.bridge) return;
  runtime.bridgeStatus = "stopping";
  runtime.bridge.kill("SIGTERM");
  setTimeout(() => { if (runtime.bridge && !runtime.bridge.killed) runtime.bridge.kill("SIGKILL"); }, 5_000).unref();
}
function requestHandler(request, response) {
  const url = new URL(request.url, `http://${config.host}:${config.port}`);
  if (request.method !== "GET" && request.method !== "POST") return json(response, 405, { error: "method_not_allowed" });
  if (request.method === "GET" && url.pathname === "/api/health") return json(response, 200, { ok: true, ...payload() });
  if (request.method === "GET" && url.pathname === "/api/telemetry") return json(response, 200, payload());
  if (request.method === "GET" && url.pathname === "/api/history") return json(response, 200, { items: analyzer.history() });
  if (request.method === "GET" && url.pathname === "/api/config") return json(response, 200, { host: config.host, port: config.port, engine_enabled: config.engineEnabled, python: config.python, analysis_interval_s: config.analysisIntervalMs / 1000, stale_after_s: config.staleAfterMs / 1000, version: config.version });
  if (request.method === "POST" && url.pathname === "/api/engine/start") {
    if (!config.engineEnabled) return json(response, 409, { error: "engine_disabled", bridge_status: runtime.bridgeStatus });
    return json(response, 200, { started: startBridge(), bridge_status: runtime.bridgeStatus });
  }
  if (request.method === "POST" && url.pathname === "/api/engine/stop") { stopBridge(); return json(response, 200, { stopped: true, bridge_status: runtime.bridgeStatus }); }
  if (request.method === "GET" && url.pathname === "/") return serveFile(response, "index.html", "text/html; charset=utf-8");
  if (request.method === "GET" && url.pathname === "/app.css") return serveFile(response, "app.css", "text/css; charset=utf-8");
  if (request.method === "GET" && url.pathname === "/app.js") return serveFile(response, "app.js", "text/javascript; charset=utf-8");
  return json(response, 404, { error: "not_found" });
}

const server = http.createServer(requestHandler);
server.listen(config.port, config.host, () => {
  console.log(`Node mining operations dashboard: http://${config.host}:${config.port}`);
  console.log(`Engine: ${config.engineEnabled ? "enabled" : "disabled"} | Python: ${config.python} | Version: ${config.version}`);
  if (config.engineEnabled) startBridge();
});
function shutdown(signal) {
  if (runtime.stopping) return;
  runtime.stopping = true;
  console.log(`Received ${signal}; stopping controller.`);
  stopBridge();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 8_000).unref();
}
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
