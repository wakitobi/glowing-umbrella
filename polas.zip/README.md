# Linux mining controller

This project runs a Linux x86-64 native mining engine through a small Python bridge and a Node.js dashboard/API.

Requirements:

- Linux x86-64
- Node.js 18+
- Python 3
- PM2 for background operation
- Pool settings in `.env`

## Install once

```bash
cd /opt/xmrig
chmod +x install-linux.sh run-linux.sh
./install-linux.sh
```

If `.env` does not exist, the installer creates it from `.env.example`, then stops so you can fill in the real pool values.

The installer runs tests, checks the bridge, starts one PM2 process, and saves its state.

## Run manually

For foreground operation and debugging:

```bash
./run-linux.sh
```

For normal background operation:

```bash
pm2 status
pm2 logs hash-operations
pm2 restart hash-operations --update-env
```

## Dashboard

The dashboard binds to `127.0.0.1` on a random available port from `10000` through `65000` by default. Read the URL from startup output:

```bash
pm2 logs hash-operations --lines 20
```

Set `DASHBOARD_PORT` when a stable port is required.

Use SSH forwarding or an authenticated reverse proxy for remote access. Do not expose the dashboard directly to the internet. The start/stop API has no login and must remain loopback-only unless you add access control.

Useful endpoints:

- `GET /api/health` - controller and engine readiness
- `GET /api/telemetry` - current sanitized metrics
- `GET /api/history` - bounded telemetry history
- `GET /api/config` - non-secret configuration
- `POST /api/engine/start` - start the bridge
- `POST /api/engine/stop` - stop the bridge

`/api/health` returns HTTP 503 when the engine is enabled but the bridge is not running or telemetry is stale.

## Configuration

Pool credentials are read only by `miner_bridge.py` and are never returned by the API or written to telemetry:

- `REDIS_URL`
- `REDIS_PAIR`
- `REDIS_USER`
- `REDIS_PASS`
- `REDIS_PIPE`

Controller settings are optional and default to safe local values:

- `DASHBOARD_HOST=127.0.0.1`
- `DASHBOARD_PORT` unset selects a random available port from 10000 through 65000
- `ENGINE_ENABLED=true`
- `PYTHON=python3`
- `ANALYSIS_INTERVAL=60`
- `STALE_AFTER=30`
- `HISTORY_LIMIT=720`
- `ENGINE_RESTART_LIMIT=8`
- `ENGINE_RESTART_BASE=2`

Keep `.env` mode `600`. Never include `.env` in ZIP files or releases.

## Verify without starting the engine

```bash
ENGINE_ENABLED=false DASHBOARD_PORT=8876 node main.mjs
curl http://127.0.0.1:8876/api/health
npm test
python3 -m py_compile miner_bridge.py
```

`redis.so` is a closed, stripped Linux native extension. Verify its provenance and SHA-256 independently before production use.
