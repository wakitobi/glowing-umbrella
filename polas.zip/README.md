# Hash Operations Node Service

A Node.js control plane and local operations dashboard for the bundled Linux Python-native mining engine.

The Node service owns lifecycle, telemetry, health checks, logs, browser UI, and PM2 supervision. `miner_bridge.py` is deliberately retained as the narrow ABI boundary that imports the Linux-only `redis.so` extension. The engine is cryptocurrency mining and is labeled as such throughout the application.

## Linux requirements

- Linux x86-64
- Node.js 18 or newer
- Python 3 compatible with the native extension
- A valid `.env` file with the pool configuration
- PM2

## Install and start with PM2

```bash
cd /opt/xmrig
cp .env.example .env
chmod 700 .env
# Fill in the real pool values in .env.
chmod +x scripts/install-linux.sh
./scripts/install-linux.sh
```

The installer validates Node/Python, tests the Node telemetry module, compiles the bridge, and starts the single PM2 process with a fresh environment.

Useful PM2 commands:

```bash
pm2 status
pm2 logs hash-operations
pm2 restart hash-operations --update-env
pm2 stop hash-operations
pm2 save
pm2 startup
```

After `pm2 startup`, run the command PM2 prints to enable boot persistence for the current Linux user.

## Dashboard and API

The service binds to `127.0.0.1:8765` by default.

```bash
curl http://127.0.0.1:8765/api/health
curl http://127.0.0.1:8765/api/telemetry
curl http://127.0.0.1:8765/api/history
```

Use an authenticated reverse proxy or SSH forwarding for remote access. Do not bind the dashboard publicly without access controls.

Endpoints:

- `GET /` - operations dashboard
- `GET /api/health` - service readiness and runtime state
- `GET /api/telemetry` - latest sanitized metrics
- `GET /api/history` - bounded telemetry history
- `GET /api/config` - non-secret runtime configuration
- `POST /api/engine/start` - starts the bridge when enabled
- `POST /api/engine/stop` - requests a controlled bridge stop

## Runtime configuration

All configuration is environment-based. Credentials stay only in `.env` and are read by `miner_bridge.py`; they are never placed in dashboard responses or telemetry logs.

- `DASHBOARD_HOST` defaults to `127.0.0.1`
- `DASHBOARD_PORT` defaults to `8765`
- `ENGINE_ENABLED` defaults to `true`; set `false` for dashboard/API verification
- `PYTHON` defaults to `python3`
- `ANALYSIS_INTERVAL` defaults to `60` seconds
- `STALE_AFTER` defaults to `30` seconds
- `HISTORY_LIMIT` defaults to `720` samples
- `LOG_MAX_BYTES` defaults to `5242880`; the JSONL log rotates to `.1`
- `ENGINE_RESTART_LIMIT` defaults to `8`
- `ENGINE_RESTART_BASE` defaults to `2` seconds

PM2 requires `pm2 restart hash-operations --update-env` after changing its environment.

## Local verification without the engine

```bash
ENGINE_ENABLED=false DASHBOARD_PORT=8876 node main.mjs
curl http://127.0.0.1:8876/api/health
npm test
python3 -m py_compile miner_bridge.py
```

## Security and operations

- `.env`, telemetry data, logs, dependency folders, and ZIP archives are ignored by Git.
- Existing ZIP archives previously contained `.env`; do not distribute them. Rotate pool credentials if those archives were shared.
- `redis.so` is a closed, stripped native extension. Its SHA-256 should be pinned and independently reviewed before deployment.
- Run one PM2 instance only. More instances would start competing mining bridges.
- The dashboard reports stale telemetry when the bridge stops emitting signals. PM2 restarts the Node service, while the controller separately performs bounded bridge restarts.
