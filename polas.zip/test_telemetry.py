import json
import tempfile
import unittest
from pathlib import Path

from telemetry import TelemetryAnalyzer


class TelemetryAnalyzerTests(unittest.TestCase):
    def test_records_metrics_and_writes_jsonl(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "telemetry.jsonl"
            analyzer = TelemetryAnalyzer(path, interval=5)
            analyzer.record({"status": "hashrate", "job": "a", "shares": 2, "hashrate": 100})
            analyzer.record({"status": "hashrate", "job": "b", "shares": 3, "hashrate": 110})
            metrics = analyzer.metrics()
            self.assertEqual(metrics["samples"], 2)
            self.assertEqual(metrics["hashrate"], 110.0)
            self.assertEqual(metrics["shares"], 3)
            rows = [json.loads(line) for line in path.read_text().splitlines()]
            self.assertEqual(len(rows), 2)
            self.assertNotIn("password", rows[0])
            self.assertNotIn("url", rows[0])

    def test_rule_analyzer_reports_zero_hashrate(self):
        with tempfile.TemporaryDirectory() as directory:
            analyzer = TelemetryAnalyzer(Path(directory) / "telemetry.jsonl")
            analyzer.record({"status": "connected", "job": "a", "shares": 0, "hashrate": 0})
            self.assertIn("not producing hashrate", analyzer.analyze())


if __name__ == "__main__":
    unittest.main()
