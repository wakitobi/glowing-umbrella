import fs from "node:fs";
import path from "node:path";

function validSnapshot(row) {
  return row && Number.isFinite(Number(row.timestamp))
    && typeof row.status === "string" && typeof row.job === "string"
    && Number.isFinite(Number(row.shares)) && Number.isFinite(Number(row.hashrate));
}

export class TelemetryAnalyzer {
  constructor({
    logPath = "telemetry.jsonl",
    interval = 60_000,
    staleAfter = 30_000,
    historyLimit = 720,
    logMaxBytes = 5 * 1024 * 1024,
    ollamaUrl = "",
    ollamaModel = "",
  } = {}) {
    this.logPath = path.resolve(logPath);
    this.interval = Math.max(5_000, Number(interval));
    this.staleAfter = Math.max(1, Number(staleAfter));
    this.historyLimit = Math.max(2, Number(historyLimit));
    this.logMaxBytes = Math.max(1024, Number(logMaxBytes));
    this.ollamaUrl = String(ollamaUrl).replace(/\/$/, "");
    this.ollamaModel = String(ollamaModel);
    this._history = [];
    this.lastAnalysis = "Waiting for mining telemetry.";
    this.lastAnalysisAt = 0;
    this.loadHistory();
  }

  loadHistory() {
    try {
      const lines = fs.readFileSync(this.logPath, "utf8").split(/\r?\n/).filter(Boolean).slice(-this.historyLimit);
      this._history = lines.map((line) => JSON.parse(line)).filter(validSnapshot).slice(-this.historyLimit);
    } catch {
      this._history = [];
    }
  }

  history() {
    return this._history.map((item) => ({ ...item }));
  }

  snapshot(state) {
    return {
      timestamp: Date.now() / 1000,
      status: String(state.status ?? "unknown").slice(0, 64),
      job: String(state.job ?? "-").slice(0, 128),
      shares: Math.max(0, Number.parseInt(state.shares ?? 0, 10) || 0),
      hashrate: Math.max(0, Number(state.hashrate) || 0),
    };
  }

  async record(state) {
    const snapshot = this.snapshot(state);
    this._history.push(snapshot);
    this._history = this._history.slice(-this.historyLimit);
    fs.mkdirSync(path.dirname(this.logPath), { recursive: true });
    this.rotateIfNeeded();
    fs.appendFileSync(this.logPath, `${JSON.stringify(snapshot)}\n`, "utf8");
    if (Date.now() - this.lastAnalysisAt >= this.interval) {
      this.lastAnalysis = await this.analyze();
      this.lastAnalysisAt = Date.now();
    }
    return snapshot;
  }

  rotateIfNeeded() {
    try {
      if (fs.statSync(this.logPath).size >= this.logMaxBytes) {
        const rotated = `${this.logPath}.1`;
        try { fs.rmSync(rotated, { force: true }); } catch {}
        fs.renameSync(this.logPath, rotated);
      }
    } catch {}
  }

  metrics() {
    if (!this._history.length) return { samples: 0, hashrate: 0, trend_pct: 0, shares: 0, stale: true };
    const rates = this._history.map((item) => item.hashrate).filter((rate) => rate > 0);
    const midpoint = Math.max(1, Math.floor(rates.length / 2));
    const average = (items) => items.length ? items.reduce((a, b) => a + b, 0) / items.length : 0;
    const oldRate = average(rates.slice(0, midpoint));
    const newRate = average(rates.slice(midpoint).length ? rates.slice(midpoint) : rates.slice(0, midpoint));
    const latest = this._history.at(-1);
    return {
      samples: this._history.length,
      hashrate: Number(latest.hashrate.toFixed(2)),
      average_hashrate: Number(average(rates).toFixed(2)),
      trend_pct: Number((oldRate ? ((newRate - oldRate) / oldRate) * 100 : 0).toFixed(2)),
      shares: latest.shares,
      status: latest.status,
      last_event: latest.timestamp,
      stale: Date.now() - latest.timestamp * 1000 > this.staleAfter,
    };
  }

  ruleAnalysis(metrics) {
    if (!metrics.samples) return "Waiting for mining telemetry.";
    if (metrics.stale) return "Telemetry is stale; the mining bridge may be disconnected.";
    if (metrics.hashrate <= 0) return "Mining is not producing hashrate; check the pool connection and worker state.";
    if (metrics.trend_pct <= -15) return `Hashrate is falling (${metrics.trend_pct.toFixed(1)}% trend); check CPU contention and thermal throttling.`;
    if (metrics.trend_pct >= 15) return `Hashrate is improving (${metrics.trend_pct.toFixed(1)}% trend); keep the current configuration while collecting more samples.`;
    return `Mining is stable at ${metrics.hashrate.toFixed(2)} H/s with ${metrics.shares} submitted shares.`;
  }

  async analyze() {
    const metrics = this.metrics();
    if (this.ollamaUrl && this.ollamaModel) {
      try {
        const response = await fetch(`${this.ollamaUrl}/api/generate`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ model: this.ollamaModel, stream: false, prompt: `Analyze explicitly labeled cryptocurrency-mining telemetry. Give one concise operational observation. Metrics: ${JSON.stringify(metrics)}` }),
          signal: AbortSignal.timeout(10_000),
        });
        if (response.ok) {
          const text = String((await response.json()).response ?? "").trim().slice(0, 500);
          if (text) return text;
        }
      } catch {}
    }
    return this.ruleAnalysis(metrics);
  }

  get lastAnalysisText() { return this.lastAnalysis; }
}
