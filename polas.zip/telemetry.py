"""Mining telemetry collection and optional local-LLM analysis.

The workload remains explicitly identified as cryptocurrency mining.  If Ollama is
available, telemetry summaries can be sent to a local model; otherwise a deterministic
rule-based analyzer is used.  Credentials and pool URLs are never included.
"""

from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Snapshot:
    timestamp: float
    status: str
    job: str
    shares: int
    hashrate: float


class TelemetryAnalyzer:
    def __init__(
        self,
        log_path: str | Path = "telemetry.jsonl",
        interval: float = 60.0,
        ollama_url: str | None = None,
        ollama_model: str | None = None,
    ) -> None:
        self.log_path = Path(log_path)
        self.interval = max(5.0, float(interval))
        self.ollama_url = (ollama_url or os.getenv("OLLAMA_URL", "")).rstrip("/")
        self.ollama_model = ollama_model or os.getenv("OLLAMA_MODEL", "")
        self.history: deque[Snapshot] = deque(maxlen=120)
        self.last_analysis = "Waiting for mining telemetry."
        self._last_analysis_at = 0.0
        self._lock = threading.Lock()
        self._load_history()

    def _load_history(self) -> None:
        if not self.log_path.exists():
            return
        try:
            lines = self.log_path.read_text(encoding="utf-8", errors="replace").splitlines()[-120:]
            for line in lines:
                data = json.loads(line)
                self.history.append(Snapshot(**data))
        except (OSError, ValueError, TypeError):
            self.history.clear()

    def record(self, state: dict[str, Any]) -> Snapshot:
        snapshot = Snapshot(
            timestamp=time.time(),
            status=str(state.get("status", "unknown")),
            job=str(state.get("job", "-"))[:128],
            shares=max(0, int(state.get("shares", 0))),
            hashrate=max(0.0, float(state.get("hashrate", 0.0))),
        )
        with self._lock:
            self.history.append(snapshot)
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(asdict(snapshot), separators=(",", ":")) + "\n")
            if snapshot.timestamp - self._last_analysis_at >= self.interval:
                self.last_analysis = self.analyze()
                self._last_analysis_at = snapshot.timestamp
        return snapshot

    def metrics(self) -> dict[str, Any]:
        items = list(self.history)
        if not items:
            return {"samples": 0, "hashrate": 0.0, "trend_pct": 0.0, "shares": 0}
        rates = [item.hashrate for item in items if item.hashrate > 0]
        current = items[-1].hashrate
        midpoint = max(1, len(rates) // 2)
        old = sum(rates[:midpoint]) / len(rates[:midpoint]) if rates else 0.0
        new_rates = rates[midpoint:] or rates[:midpoint]
        new = sum(new_rates) / len(new_rates) if new_rates else 0.0
        trend = ((new - old) / old * 100.0) if old else 0.0
        return {
            "samples": len(items),
            "hashrate": round(current, 2),
            "average_hashrate": round(sum(rates) / len(rates), 2) if rates else 0.0,
            "trend_pct": round(trend, 2),
            "shares": items[-1].shares,
            "status": items[-1].status,
        }

    def analyze(self) -> str:
        metrics = self.metrics()
        if self.ollama_url and self.ollama_model:
            result = self._ollama_analysis(metrics)
            if result:
                return result
        return self._rule_analysis(metrics)

    def _rule_analysis(self, metrics: dict[str, Any]) -> str:
        if metrics["samples"] == 0:
            return "Waiting for mining telemetry."
        if metrics["hashrate"] <= 0:
            return "Mining is not producing hashrate; check the pool connection and worker state."
        trend = metrics["trend_pct"]
        if trend <= -15:
            return f"Hashrate is falling ({trend:.1f}% trend); check CPU contention and thermal throttling."
        if trend >= 15:
            return f"Hashrate is improving ({trend:.1f}% trend); keep the current configuration while collecting more samples."
        return f"Mining is stable at {metrics['hashrate']:.2f} H/s with {metrics['shares']} submitted shares."

    def _ollama_analysis(self, metrics: dict[str, Any]) -> str | None:
        prompt = (
            "You analyze explicitly labeled cryptocurrency-mining telemetry. "
            "Give one concise operational observation. Never claim this is LLM inference. "
            f"Metrics: {json.dumps(metrics, separators=(',', ':'))}"
        )
        payload = json.dumps(
            {"model": self.ollama_model, "prompt": prompt, "stream": False}
        ).encode("utf-8")
        request = urllib.request.Request(
            f"{self.ollama_url}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                body = json.loads(response.read().decode("utf-8"))
            text = str(body.get("response", "")).strip()
            return text[:500] or None
        except (OSError, ValueError, urllib.error.URLError):
            return None
