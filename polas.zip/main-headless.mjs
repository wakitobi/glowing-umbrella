#!/usr/bin/env node
import { spawn } from "node:child_process";
import readline from "node:readline";
import os from "node:os";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Config from env
const config = {
  python: process.env.PYTHON || "python3",
  engineEnabled: process.env.ENGINE_ENABLED !== "false",
  telemetryPath: process.env.TELEMETRY_PATH || path.join(__dirname, "data", "telemetry.jsonl"),
  staleAfterMs: Number(process.env.STALE_AFTER || "30") * 1000,
  historyLimit: Number(process.env.HISTORY_LIMIT || "720"),
  logMaxBytes: Number(process.env.LOG_MAX_MAX_BYTES || "5242880"),
};

const state = { status: "starting", job: "-", shares: 0, hashrate: 0, lastUpdate: 0 };
const runtime = { bridge: null, starts: 0, restarts: 0 };

function log(msg) {
  console.log(`[${new Date().toISOString()}] ${msg}`);
}

function recordTelemetry(snapshot) {
  try {
    fs.mkdirSync(path.dirname(config.telemetryPath), { recursive: true });
    fs.appendFileSync(config.telemetryPath, JSON.stringify(snapshot) + "\n", "utf8");
  } catch (e) {
    console.error(`Failed to write telemetry: ${e.message}`);
  }
}

function updateState(event) {
  state.status = event.status ?? state.status;
  state.job = event.job ?? state.job;
  state.shares = Math.max(0, Number(event.shares) || 0);
  state.hashrate = Math.max(0, Number(event.hashrate) || 0);
  state.lastUpdate = Date.now();

  const snapshot = {
    timestamp: Date.now() / 1000,
    status: state.status,
    job: state.job,
    shares: state.shares,
    hashrate: state.hashrate,
  };

  recordTelemetry(snapshot);
  log(`STATUS=${state.status} JOB=${state.job} HASH=${state.hashrate} H/s SHARES=${state.shares}`);
}

function startBridge() {
  if (!config.engineEnabled) {
    log("Engine disabled via ENGINE_ENABLED=false");
    return;
  }

  runtime.starts++;
  const bridgePath = path.join(__dirname, "miner_bridge.py");
  runtime.bridge = spawn(config.python, [bridgePath], {
    cwd: __dirname,
    env: process.env,
    stdio: ["ignore", "pipe", "pipe"]
  });

  const lines = readline.createInterface({ input: runtime.bridge.stdout });
  lines.on("line", (line) => {
    try {
      const event = JSON.parse(line);
      if (event.type === "telemetry") updateState(event);
      else if (event.type === "bridge") log(`BRIDGE: ${event.status}`);
      else if (event.type === "fatal") log(`FATAL: ${event.message}`);
    } catch (e) {
      console.error(`Invalid JSON: ${line.slice(0, 100)}`);
    }
  });

  runtime.bridge.stderr.on("data", (chunk) => process.stderr.write(`[bridge] ${chunk}`));
  runtime.bridge.on("exit", (code, signal) => {
    log(`Bridge exited code=${code} signal=${signal}`);
    runtime.bridge = null;
    if (runtime.restarts < 8 && config.engineEnabled) {
      runtime.restarts++;
      log(`Restarting bridge in 5s (attempt ${runtime.restarts})`);
      setTimeout(startBridge, 5000);
    }
  });

  log(`Bridge started (pid=${runtime.bridge.pid})`);
}

function checkStale() {
  if (state.lastUpdate && Date.now() - state.lastUpdate > config.staleAfterMs) {
    log("WARN: Telemetry stale");
  }
}

function shutdown(signal) {
  log(`Received ${signal}, stopping...`);
  if (runtime.bridge) runtime.bridge.kill("SIGTERM");
  setTimeout(() => process.exit(0), 3000);
  setTimeout(() => process.exit(1), 8000).unref();
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));

log(`XMRig Headless Controller | Engine=${config.engineEnabled ? "enabled" : "disabled"}`);
setInterval(checkStale, 10000);
startBridge();
