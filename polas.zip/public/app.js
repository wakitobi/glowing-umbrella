const $ = (id) => document.getElementById(id);
let telemetry = null;
let history = [];
let busy = false;

function timeAgo(timestamp) {
  if (!timestamp) return "Never";
  const seconds = Math.max(0, Math.round(Date.now() / 1000 - timestamp));
  if (seconds < 5) return "Now";
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}
function fixed(value, decimals = 2) { return Number(value || 0).toFixed(decimals); }
function setStatus(text, kind = "") {
  $("liveStatus").className = `status ${kind}`;
  $("liveStatus").innerHTML = `<i></i> ${text}`;
}
function render(data) {
  telemetry = data;
  const m = data.metrics;
  $("hashrate").innerHTML = `${fixed(m.hashrate)} <small>H/s</small>`;
  $("shares").textContent = m.shares ?? 0;
  $("average").textContent = `${fixed(m.average_hashrate)} H/s`;
  $("trend").textContent = `${Number(m.trend_pct || 0) > 0 ? "+" : ""}${fixed(m.trend_pct)}%`;
  $("trend").style.color = m.trend_pct < -15 ? "var(--red)" : m.trend_pct > 15 ? "var(--green)" : "";
  $("lastEvent").textContent = timeAgo(m.last_event);
  $("freshness").textContent = m.stale ? "Telemetry stale" : "Signal current";
  $("analysis").textContent = data.analysis;
  $("bridgeStatus").textContent = data.bridge_status.replaceAll("_", " ");
  $("workerStatus").textContent = m.status || data.bridge_status;
  $("hostname").textContent = data.hostname;
  $("controller").textContent = `${data.controller} ${data.version}`;
  $("restarts").textContent = data.runtime.restarts;
  $("samples").textContent = m.samples;
  $("job").textContent = history.at(-1)?.job || "-";
  const running = ["running", "starting"].includes(data.bridge_status);
  $("engineButton").textContent = running ? "Stop engine" : "Start engine";
  $("engineButton").dataset.action = running ? "stop" : "start";
  $("engineButton").disabled = busy || !data.engine_enabled;
  setStatus(m.stale ? "Service online, telemetry stale" : "Live", m.stale ? "" : "online");
  $("updated").textContent = `Updated ${new Date().toLocaleTimeString()}`;
}
function renderTable() {
  const rows = history.slice(-8).reverse();
  $("events").innerHTML = rows.length ? rows.map((item) => `<tr><td>${new Date(item.timestamp * 1000).toLocaleTimeString()}</td><td>${escapeHtml(item.status)}</td><td title="${escapeHtml(item.job)}">${escapeHtml(item.job)}</td><td>${fixed(item.hashrate)} H/s</td><td>${item.shares}</td></tr>`).join("") : '<tr><td colspan="5">No telemetry available</td></tr>';
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}
function drawChart() {
  const canvas = $("chart");
  const box = canvas.getBoundingClientRect();
  const scale = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, Math.floor(box.width * scale));
  canvas.height = Math.max(1, Math.floor(box.height * scale));
  const ctx = canvas.getContext("2d");
  ctx.scale(scale, scale);
  const width = box.width, height = box.height, pad = 18;
  const points = history.slice(-90);
  $("emptyChart").style.display = points.length ? "none" : "grid";
  ctx.strokeStyle = "#2a3034"; ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) { const y = pad + (height - pad * 2) * i / 4; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke(); }
  if (!points.length) return;
  const max = Math.max(1, ...points.map((p) => p.hashrate)) * 1.1;
  const coordinates = points.map((point, index) => ({ x: points.length === 1 ? width / 2 : pad + index * (width - pad * 2) / (points.length - 1), y: height - pad - point.hashrate / max * (height - pad * 2) }));
  const gradient = ctx.createLinearGradient(0, 0, 0, height); gradient.addColorStop(0, "rgba(66,217,208,.25)"); gradient.addColorStop(1, "rgba(66,217,208,0)");
  ctx.beginPath(); ctx.moveTo(coordinates[0].x, height - pad); coordinates.forEach((p) => ctx.lineTo(p.x, p.y)); ctx.lineTo(coordinates.at(-1).x, height - pad); ctx.closePath(); ctx.fillStyle = gradient; ctx.fill();
  ctx.beginPath(); coordinates.forEach((p, i) => i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)); ctx.strokeStyle = "#42d9d0"; ctx.lineWidth = 2; ctx.stroke();
}
async function refresh() {
  try {
    const [telemetryResponse, historyResponse] = await Promise.all([fetch("/api/telemetry"), fetch("/api/history")]);
    if (!telemetryResponse.ok || !historyResponse.ok) throw new Error("API unavailable");
    history = (await historyResponse.json()).items;
    render(await telemetryResponse.json()); renderTable(); drawChart();
  } catch (error) { setStatus(error.message, "error"); }
}
$("refresh").addEventListener("click", refresh);
$("engineButton").addEventListener("click", async () => {
  busy = true; $("engineButton").disabled = true;
  try { await fetch(`/api/engine/${$("engineButton").dataset.action}`, { method: "POST" }); await refresh(); }
  finally { busy = false; if (telemetry) render(telemetry); }
});
window.addEventListener("resize", drawChart);
refresh(); setInterval(refresh, 5000);
