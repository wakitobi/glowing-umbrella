# Linux PHP controller

The project control plane, local dashboard, telemetry persistence, and optional Ollama analysis now run in PHP. The existing `redis.so` engine remains behind `miner_bridge.py` because it exports the Python-only entry point `PyInit_redis`; it cannot be loaded directly by PHP.

Architecture:

```text
PHP 8.1+ controller/dashboard
  -> NDJSON over stdio
Python compatibility bridge
  -> redis.so native Linux mining engine
```

Requirements:

- Linux x86-64
- PHP 8.1 or newer with `proc_open`, sockets/streams, and optional `pcntl`
- Python matching the ABI used to build `redis.so`
- Existing `.env` beside the scripts

Ubuntu installation:

```bash
sudo apt update
sudo apt install -y php-cli python3
cd /path/to/xmrig
php test_php.php
python3 -m py_compile miner_bridge.py
php main.php
```

Dashboard: `http://127.0.0.1:8765`

Use a specific Python interpreter when required:

```bash
PYTHON=/usr/bin/python3.11 php main.php
```

Optional local Ollama telemetry analysis:

```bash
OLLAMA_URL=http://127.0.0.1:11434 OLLAMA_MODEL=qwen2.5:1.5b php main.php
```

Safe dashboard-only verification, which does not start the bridge or connect to a pool:

```bash
DASHBOARD_PORT=8876 php main.php --no-bridge
curl http://127.0.0.1:8876/api/telemetry
```

Tests do not connect to the pool:

```bash
php test_php.php
php -l main.php
php -l TelemetryAnalyzer.php
python3 -m py_compile miner_bridge.py
```

Security:

- Pool credentials stay in `.env` and are consumed only by `miner_bridge.py`.
- PHP telemetry stores only timestamp, status, job, share count, and hashrate.
- Dashboard output explicitly identifies the workload as cryptocurrency mining.
- Do not publish `uva.zip` or `bush.zip`; both currently contain an `.env` file.
