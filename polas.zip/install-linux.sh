#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

command -v node >/dev/null || { echo "Node.js 18+ is required." >&2; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required for the native bridge." >&2; exit 1; }
node_major="$(node -p 'process.versions.node.split(".")[0]')"
[ "$node_major" -ge 18 ] || { echo "Node.js 18+ is required." >&2; exit 1; }
[ "$(uname -s)" = "Linux" ] || { echo "The bundled native engine requires Linux." >&2; exit 1; }
[ -f redis.so ] || { echo "redis.so is missing." >&2; exit 1; }
[ -f .env ] || { echo ".env is missing. Create it from .env.example." >&2; exit 1; }

npm install --omit=dev
npm install --global pm2
npm test
python3 -m py_compile miner_bridge.py
mkdir -p data logs
chmod 700 .env
pm2 startOrReload ecosystem.config.mjs --update-env
pm2 save

echo "Service ready. Check: pm2 status && curl http://127.0.0.1:8765/api/health"
echo "Enable boot startup with the command printed by: pm2 startup"
