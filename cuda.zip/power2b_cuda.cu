/*
 * power2b_cuda.cu — CUDA power2b (MBC yespower N=2048 r=32) host driver + hasher.
 *
 * Pipeline per hash (matches MicroBitcoin 3.2 src/crypto/yespower/yespower.c):
 *   init_hash = blake2b_256(header)                       [CPU]
 *   B[0:128]  = pbkdf2_blake2b(init_hash, pers, c=1, 128) [CPU]  (rest zero)
 *   init_hash = B[0:32]                                   [CPU]
 *   B         = smix(B)                                   [GPU kernel]
 *   out       = hmac_blake2b(key=B[-64:], msg=init_hash)  [CPU]
 *
 * Modes:
 *   power2b_cuda verify              -> hash rplant vector, compare to known digest
 *   power2b_cuda bench [batch] [it]  -> full-hash H/s over `it` kernel launches
 *
 * Build: nvcc -O3 -arch=sm_75 power2b_cuda.cu -o power2b_cuda
 *   (sm_75 = Tesla T4 / Turing. Use -arch=sm_XX to match your card.)
 */
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <vector>
#include <chrono>
#include <cuda_runtime.h>
#include "power2b_kernel.cuh"

/* ============================================================ *
 *  CPU blake2b-256 + hmac + pbkdf2 (port of blake2b_mbc.c)     *
 * ============================================================ */
typedef struct { uint8_t b[128]; uint64_t h[8]; uint64_t t[2]; size_t c; size_t outlen; } bctx;

#define ROTR64(x,y) (((x) >> (y)) ^ ((x) << (64 - (y))))
#define B2B_GET64(p) ( \
    ((uint64_t)((uint8_t*)(p))[0])       ^ (((uint64_t)((uint8_t*)(p))[1]) << 8)  ^ \
    (((uint64_t)((uint8_t*)(p))[2]) << 16) ^ (((uint64_t)((uint8_t*)(p))[3]) << 24) ^ \
    (((uint64_t)((uint8_t*)(p))[4]) << 32) ^ (((uint64_t)((uint8_t*)(p))[5]) << 40) ^ \
    (((uint64_t)((uint8_t*)(p))[6]) << 48) ^ (((uint64_t)((uint8_t*)(p))[7]) << 56))
#define B2B_G(a,b,c,d,x,y) { \
    v[a]=v[a]+v[b]+x; v[d]=ROTR64(v[d]^v[a],32); v[c]=v[c]+v[d]; v[b]=ROTR64(v[b]^v[c],24); \
    v[a]=v[a]+v[b]+y; v[d]=ROTR64(v[d]^v[a],16); v[c]=v[c]+v[d]; v[b]=ROTR64(v[b]^v[c],63); }

static const uint64_t b2b_iv[8] = {
    0x6A09E667F3BCC908ULL,0xBB67AE8584CAA73BULL,0x3C6EF372FE94F82BULL,0xA54FF53A5F1D36F1ULL,
    0x510E527FADE682D1ULL,0x9B05688C2B3E6C1FULL,0x1F83D9ABFB41BD6BULL,0x5BE0CD19137E2179ULL };

static void b2b_compress(bctx *ctx, int last) {
    const uint8_t sigma[12][16] = {
        {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},{14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3},
        {11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4},{7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8},
        {9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13},{2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9},
        {12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11},{13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10},
        {6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5},{10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0},
        {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},{14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3} };
    int i; uint64_t v[16], m[16];
    for (i=0;i<8;i++){ v[i]=ctx->h[i]; v[i+8]=b2b_iv[i]; }
    v[12]^=ctx->t[0]; v[13]^=ctx->t[1];
    if (last) v[14]=~v[14];
    for (i=0;i<16;i++) m[i]=B2B_GET64(&ctx->b[8*i]);
    for (i=0;i<12;i++){
        B2B_G(0,4,8,12,m[sigma[i][0]],m[sigma[i][1]]);
        B2B_G(1,5,9,13,m[sigma[i][2]],m[sigma[i][3]]);
        B2B_G(2,6,10,14,m[sigma[i][4]],m[sigma[i][5]]);
        B2B_G(3,7,11,15,m[sigma[i][6]],m[sigma[i][7]]);
        B2B_G(0,5,10,15,m[sigma[i][8]],m[sigma[i][9]]);
        B2B_G(1,6,11,12,m[sigma[i][10]],m[sigma[i][11]]);
        B2B_G(2,7,8,13,m[sigma[i][12]],m[sigma[i][13]]);
        B2B_G(3,4,9,14,m[sigma[i][14]],m[sigma[i][15]]);
    }
    for (i=0;i<8;i++) ctx->h[i]^=v[i]^v[i+8];
}
static int b2b_init(bctx *ctx, size_t outlen, const void *key, size_t keylen) {
    size_t i;
    if (outlen==0||outlen>64||keylen>64) return -1;
    for (i=0;i<8;i++) ctx->h[i]=b2b_iv[i];
    ctx->h[0]^=0x01010000 ^ (keylen<<8) ^ outlen;
    ctx->t[0]=ctx->t[1]=0; ctx->c=0; ctx->outlen=outlen;
    for (i=keylen;i<128;i++) ctx->b[i]=0;
    if (keylen>0){ /* not used here */ }
    return 0;
}
static void b2b_update(bctx *ctx, const void *in, size_t inlen) {
    size_t i;
    for (i=0;i<inlen;i++){
        if (ctx->c==128){ ctx->t[0]+=ctx->c; if(ctx->t[0]<ctx->c) ctx->t[1]++; b2b_compress(ctx,0); ctx->c=0; }
        ctx->b[ctx->c++]=((const uint8_t*)in)[i];
    }
}
static void b2b_final(bctx *ctx, void *out) {
    size_t i;
    ctx->t[0]+=ctx->c; if(ctx->t[0]<ctx->c) ctx->t[1]++;
    while (ctx->c<128) ctx->b[ctx->c++]=0;
    b2b_compress(ctx,1);
    for (i=0;i<ctx->outlen;i++) ((uint8_t*)out)[i]=(ctx->h[i>>3]>>(8*(i&7)))&0xFF;
}
static void blake2b_hash(void *out, const void *in, size_t inlen) {
    bctx c; b2b_init(&c,32,NULL,0); b2b_update(&c,in,inlen); b2b_final(&c,out);
}
/* HMAC-BLAKE2b-256 */
static void hmac_blake2b(uint8_t out[32], const uint8_t *key, size_t keylen,
                         const uint8_t *msg, size_t msglen) {
    uint8_t k[64], ipad[64], opad[64], ih[32], kh[32];
    if (keylen>64){ blake2b_hash(kh,key,keylen); key=kh; keylen=32; }
    memset(k,0,64); memcpy(k,key,keylen);
    for (int i=0;i<64;i++){ ipad[i]=k[i]^0x36; opad[i]=k[i]^0x5c; }
    /* inner = blake2b(ipad || msg) */
    bctx c; b2b_init(&c,32,NULL,0); b2b_update(&c,ipad,64); b2b_update(&c,msg,msglen); b2b_final(&c,ih);
    /* out = blake2b(opad || inner) */
    b2b_init(&c,32,NULL,0); b2b_update(&c,opad,64); b2b_update(&c,ih,32); b2b_final(&c,out);
}
/* PBKDF2-HMAC-BLAKE2b, c=1 */
static void pbkdf2_blake2b_c1(const uint8_t *passwd, size_t plen,
                              const uint8_t *salt, size_t slen,
                              uint8_t *buf, size_t dklen) {
    size_t done=0; uint32_t i=1;
    while (done<dklen){
        uint8_t ivec[4]={(uint8_t)(i>>24),(uint8_t)(i>>16),(uint8_t)(i>>8),(uint8_t)i};
        uint8_t msg[128]; memcpy(msg,salt,slen); memcpy(msg+slen,ivec,4);
        uint8_t T[32]; hmac_blake2b(T,passwd,plen,msg,slen+4);
        size_t clen = dklen-done; if (clen>32) clen=32;
        memcpy(buf+done,T,clen); done+=clen; i++;
    }
}

static const char *PERS = "Now I am become Death, the destroyer of worlds"; /* len 46 */
#define B_WORDS 1024   /* 4096 bytes */

/* wrap: header(80B) -> B[1024 words] (pre-smix), init_hash[32] */
static void wrap_header(const uint8_t header[80], uint32_t B[B_WORDS], uint8_t init_hash[32]) {
    uint8_t ih[32]; blake2b_hash(ih, header, 80);
    uint8_t Bbytes[4096]; memset(Bbytes,0,4096);
    pbkdf2_blake2b_c1(ih,32,(const uint8_t*)PERS,46,Bbytes,128);
    memcpy(init_hash, Bbytes, 32);      /* init_hash = B[:32] BEFORE smix */
    memcpy(B, Bbytes, 4096);
}
/* finish: out = hmac_blake2b(key=B[-64:], msg=init_hash) */
static void finish_hash(const uint32_t B[B_WORDS], const uint8_t init_hash[32], uint8_t out[32]) {
    const uint8_t *Bb=(const uint8_t*)B;
    hmac_blake2b(out, Bb+4096-64, 64, init_hash, 32);
}

/* ============================================================ *
 *  CUDA glue                                                   *
 * ============================================================ */
#define CK(x) do{ cudaError_t e=(x); if(e!=cudaSuccess){ \
    fprintf(stderr,"CUDA err %s:%d: %s\n",__FILE__,__LINE__,cudaGetErrorString(e)); exit(3);} }while(0)

static const size_t V_WORDS = (size_t)N_CONST * SL;   /* 2M words = 8 MiB */
static const size_t S_WORDS = 3ULL * Ssegment;        /* 24576 words = 96 KiB */

struct GpuSmix {
    int batch;
    uint32_t *dB=nullptr, *dV=nullptr, *dS=nullptr;
    GpuSmix(int b): batch(b) {
        CK(cudaMalloc(&dB, (size_t)batch*B_WORDS*4));
        CK(cudaMalloc(&dV, (size_t)batch*V_WORDS*4));
        CK(cudaMalloc(&dS, (size_t)batch*S_WORDS*4));
    }
    ~GpuSmix(){ if(dB)cudaFree(dB); if(dV)cudaFree(dV); if(dS)cudaFree(dS); }
    /* in/out: batch*B_WORDS uint32 */
    void run(uint32_t *hostB, int n) {
        CK(cudaMemcpy(dB, hostB, (size_t)n*B_WORDS*4, cudaMemcpyHostToDevice));
        int tpb=64, blocks=(n+tpb-1)/tpb;
        yespower_smix<<<blocks,tpb>>>(dB,dV,dS,(u32)n);
        CK(cudaGetLastError());
        CK(cudaDeviceSynchronize());
        CK(cudaMemcpy(hostB, dB, (size_t)n*B_WORDS*4, cudaMemcpyDeviceToHost));
    }
};

static void hex2bin(const char *hex, uint8_t *out, size_t n){
    for (size_t i=0;i<n;i++){ unsigned b; sscanf(hex+2*i,"%2x",&b); out[i]=(uint8_t)b; }
}
static std::string bin2hex(const uint8_t *b, size_t n){
    static const char *d="0123456789abcdef"; std::string s; s.resize(n*2);
    for (size_t i=0;i<n;i++){ s[2*i]=d[b[i]>>4]; s[2*i+1]=d[b[i]&15]; }
    return s;
}

/* rplant verified vector (from mbc-gpu-miner/main_gpu.py) */
static const char *VEC_HDR =
 "02000000b0ad0dda1d38a4ede0bd42f44dd5238d5c1d377de73eafe77e2abd16b8ac7e0"
 "143c4345eb9ad9135836f5c31b697f62429c1be08d55906ff407852adfba680a59"
 "53f1a530eb6101ba001cb6a";
static const char *VEC_HASH =
 "edc067dc5d32bf354297b77121dda0c3a98013ca5b6f825ffffee9c8c53208a9";

int main(int argc, char **argv){
    std::string cmd = argc>1 ? argv[1] : "verify";
    int dev=0; cudaDeviceProp p; CK(cudaGetDeviceProperties(&p,dev));
    fprintf(stderr,"GPU: %s  sm_%d%d  %zu MiB  %d SMs\n",
            p.name,p.major,p.minor,(size_t)(p.totalGlobalMem>>20),p.multiProcessorCount);

    if (cmd=="verify"){
        uint8_t hdr[80]; hex2bin(VEC_HDR,hdr,80);
        uint32_t B[B_WORDS]; uint8_t ih[32];
        wrap_header(hdr,B,ih);
        GpuSmix g(1);
        g.run(B,1);
        uint8_t out[32]; finish_hash(B,ih,out);
        std::string got=bin2hex(out,32);
        printf("vector got=%s\n",got.c_str());
        printf("vector exp=%s\n",VEC_HASH);
        printf("VERDICT: %s\n", got==VEC_HASH ? "PASS" : "FAIL");
        return got==VEC_HASH?0:1;
    }
    else if (cmd=="bench"){
        int batch = argc>2?atoi(argv[2]):256;
        int iters = argc>3?atoi(argv[3]):5;
        fprintf(stderr,"batch=%d iters=%d  (VRAM needed ~%.1f MiB)\n",
                batch,iters,(batch*(B_WORDS+V_WORDS+S_WORDS)*4.0)/(1024*1024));
        GpuSmix g(batch);
        /* prepare `batch` distinct pre-smix B buffers */
        std::vector<uint32_t> hostB((size_t)batch*B_WORDS);
        std::vector<uint8_t> ihs((size_t)batch*32);
        uint8_t hdr[80]; hex2bin(VEC_HDR,hdr,80);
        for (int i=0;i<batch;i++){
            hdr[76]=i; hdr[77]=i>>8; hdr[78]=i>>16; hdr[79]=i>>24;
            wrap_header(hdr,&hostB[(size_t)i*B_WORDS],&ihs[(size_t)i*32]);
        }
        std::vector<uint32_t> work = hostB;
        g.run(work.data(),batch);           /* warmup */
        auto t0=std::chrono::high_resolution_clock::now();
        long total=0;
        for (int it=0; it<iters; it++){ work=hostB; g.run(work.data(),batch); total+=batch; }
        auto t1=std::chrono::high_resolution_clock::now();
        double dt=std::chrono::duration<double>(t1-t0).count();
        printf("GPU power2b smix: %.1f H/s  (%ld hashes in %.2fs, batch=%d)\n",
               total/dt,total,dt,batch);
        return 0;
    }
    fprintf(stderr,"usage: %s verify | bench [batch] [iters]\n",argv[0]);
    return 2;
}
