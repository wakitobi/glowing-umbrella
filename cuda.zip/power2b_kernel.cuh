/*
 * power2b_kernel.cuh — CUDA port of the verified OpenCL smix kernel (YESPOWER_1.0,
 * MBC power2b: N=2048, r=32, blake2b wrapper handled host-side).
 *
 * 1:1 translation of projects/mbc-gpu-miner/smix.cl (verified against the rplant
 * test vector). __global -> plain device pointers, __kernel -> __global__,
 * get_global_id(0) -> blockIdx.x*blockDim.x+threadIdx.x.
 *
 * Per-thread global working set:
 *   V : N * SL words = 2048 * 1024 * 4 B = 8 MiB
 *   S : 3 * Ssegment  = 24576 words       = 96 KiB
 * Per-thread private: X[1024], B[1024], Xs[32] (~8.2 KiB -> local mem/spills).
 */
#ifndef POWER2B_KERNEL_CUH
#define POWER2B_KERNEL_CUH

#include <cstdint>

typedef uint32_t u32;
typedef uint64_t u64;

#define N_CONST     2048u
#define R_CONST     32u
#define SL          (32u * R_CONST)                          /* 1024 */
#define PWXsimple   2u
#define PWXgather   4u
#define PWXrounds   3u
#define PWXbytes    (PWXgather * PWXsimple * 8u)              /* 64 */
#define PWXwords    (PWXbytes / 4u)                           /* 16 */
#define SWidth      11u
#define Sbytes1     ((1u << SWidth) * PWXsimple * 8u)         /* 32768 */
#define Smask       (((1u << SWidth) - 1u) * PWXsimple * 8u)  /* 32752 */
#define Sbytes      (3u * Sbytes1)                            /* 98304 */
#define Sbytes_words (Sbytes / 4u)                            /* 24576 */
#define Ssegment    (Sbytes_words / 3u)                       /* 8192  */

#define ROTL(x,n) (((x)<<(n))|((x)>>(32-(n))))

typedef struct { u32 so, s1, s2, w; } sctx;

/* ==================== Salsa20/2 core ==================== */
__device__ static void salsa20_2(u32 *B) {
    u32 x[16];
    for (u32 i = 0; i < 16; i++) x[i * 5 % 16] = B[i];
    x[4] ^= ROTL(x[0]+x[12],7);  x[8] ^= ROTL(x[4]+x[0],9);
    x[12] ^= ROTL(x[8]+x[4],13); x[0] ^= ROTL(x[12]+x[8],18);
    x[9] ^= ROTL(x[5]+x[1],7);   x[13] ^= ROTL(x[9]+x[5],9);
    x[1] ^= ROTL(x[13]+x[9],13); x[5] ^= ROTL(x[1]+x[13],18);
    x[14] ^= ROTL(x[10]+x[6],7); x[2] ^= ROTL(x[14]+x[10],9);
    x[6] ^= ROTL(x[2]+x[14],13); x[10] ^= ROTL(x[6]+x[2],18);
    x[3] ^= ROTL(x[15]+x[11],7); x[7] ^= ROTL(x[3]+x[15],9);
    x[11] ^= ROTL(x[7]+x[3],13); x[15] ^= ROTL(x[11]+x[7],18);
    x[1] ^= ROTL(x[0]+x[3],7);   x[2] ^= ROTL(x[1]+x[0],9);
    x[3] ^= ROTL(x[2]+x[1],13);  x[0] ^= ROTL(x[3]+x[2],18);
    x[6] ^= ROTL(x[5]+x[4],7);   x[7] ^= ROTL(x[6]+x[5],9);
    x[4] ^= ROTL(x[7]+x[6],13);  x[5] ^= ROTL(x[4]+x[7],18);
    x[11] ^= ROTL(x[10]+x[9],7); x[8] ^= ROTL(x[11]+x[10],9);
    x[9] ^= ROTL(x[8]+x[11],13); x[10] ^= ROTL(x[9]+x[8],18);
    x[12] ^= ROTL(x[15]+x[14],7); x[13] ^= ROTL(x[12]+x[15],9);
    x[14] ^= ROTL(x[13]+x[12],13); x[15] ^= ROTL(x[14]+x[13],18);
    for (u32 i = 0; i < 16; i++) B[i] += x[i * 5 % 16];
}

/* ==================== pwxform with S evolution ====================
 * S_base is a device pointer; sc->so/s1/s2 are WORD offsets into it.
 * Each logical S entry is 2 words (matches the OpenCL (*)[2] cast). */
__device__ static void pwxform(u32 *X, u32 *S_base, sctx *sc) {
    u32 S0 = sc->so;
    u32 S1 = sc->s1;
    u32 w  = sc->w;
    u32 Sm = Smask;
    for (u32 i = 0; i < PWXrounds; i++) {
        for (u32 j = 0; j < PWXgather; j++) {
            u32 *Xj = X + j * 4;
            u32 xl = Xj[0], xh = Xj[1];
            u32 p0 = S0 + ((xl & Sm) / 8u) * 2u;   /* word offset of S0[idx] */
            u32 p1 = S1 + ((xh & Sm) / 8u) * 2u;
            for (u32 k = 0; k < PWXsimple; k++) {
                u64 s0v = ((u64)S_base[p0 + k*2 + 1] << 32) + (u64)S_base[p0 + k*2];
                u64 s1v = ((u64)S_base[p1 + k*2 + 1] << 32) + (u64)S_base[p1 + k*2];
                xl = Xj[k * 2]; xh = Xj[k * 2 + 1];
                u64 xv = (u64)xh * (u64)xl;
                xv += s0v; xv ^= s1v;
                Xj[k * 2] = (u32)xv; Xj[k * 2 + 1] = (u32)(xv >> 32);
            }
            if ((i == 0) || (j < PWXgather / 2)) {
                if (j & 1) {
                    for (u32 k = 0; k < PWXsimple; k++) {
                        S_base[S1 + w*2 + 0] = Xj[k * 2];
                        S_base[S1 + w*2 + 1] = Xj[k * 2 + 1];
                        w++;
                    }
                } else {
                    for (u32 k = 0; k < PWXsimple; k++) {
                        S_base[S0 + (w + k)*2 + 0] = Xj[k * 2];
                        S_base[S0 + (w + k)*2 + 1] = Xj[k * 2 + 1];
                    }
                }
            }
        }
    }
    /* Rotate S pointers: (S0,S1,S2) <- (S2,S0,S1) */
    u32 old_so = sc->so; sc->so = sc->s2; sc->s2 = sc->s1; sc->s1 = old_so;
    sc->w = w & ((1u << SWidth) * PWXsimple - 1u);
}

/* ==================== blockmix_pwxform ==================== */
__device__ static void blockmix_pwxform(u32 *B, u32 r, u32 *S_base, sctx *sc) {
    u32 r1 = 128u * r / PWXbytes;
    u32 Xt[PWXwords];
    for (u32 i = 0; i < PWXwords; i++) Xt[i] = B[(r1 - 1) * PWXwords + i];
    for (u32 i0 = 0; i0 < r1; i0++) {
        if (r1 > 1) { for (u32 k = 0; k < PWXwords; k++) Xt[k] ^= B[i0 * PWXwords + k]; }
        pwxform(Xt, S_base, sc);
        for (u32 k = 0; k < PWXwords; k++) B[i0 * PWXwords + k] = Xt[k];
    }
    u32 salsa_idx = (r1 - 1) * PWXbytes / 64u;
    salsa20_2(&B[salsa_idx * 16]);
}

/* ==================== blockmix_salsa (r=1) for S-init ==================== */
__device__ static void blockmix_salsa_r1(u32 *B) {
    u32 Xt[16];
    for (u32 i = 0; i < 16; i++) Xt[i] = B[16 + i];
    for (u32 i0 = 0; i0 < 2; i0++) {
        for (u32 k = 0; k < 16; k++) Xt[k] ^= B[i0 * 16 + k];
        salsa20_2(Xt);
        for (u32 k = 0; k < 16; k++) B[i0 * 16 + k] = Xt[k];
    }
}

/* S-box init: smix1 with r=1, V=S, blockmix_salsa */
__device__ static void sinit(u32 *X, u32 *S_base, u32 Nloop) {
    for (u32 i = 0; i < Nloop; i++) {
        for (u32 k = 0; k < 32; k++) S_base[i * 32 + k] = X[k];
        if (i > 1) {
            u32 intfy = X[16];
            u32 n = i; while (n & (n - 1)) n &= (n - 1);
            u32 j = (intfy & (n - 1)) + (i - n);
            for (u32 k = 0; k < 32; k++) X[k] ^= S_base[j * 32 + k];
        }
        blockmix_salsa_r1(X);
    }
}

/* ==================== main smix ==================== */
__device__ static void smix(u32 *X, u32 *B, u32 *V, u32 *S_base, sctx *sc,
                            u32 r, u32 N, u64 V_off) {
    /* X <- B (SIMD unshuffle) */
    for (u32 b = 0; b < 64; b++)
        for (u32 i = 0; i < 16; i++)
            X[b * 16 + i] = B[b * 16 + (i * 5 % 16)];

    /* Precompute k=1..r-1 (YESPOWER_1.0) */
    for (u32 k = 1; k < r; k++) {
        for (u32 i = 0; i < 32; i++) X[k * 32 + i] = X[(k - 1) * 32 + i];
        blockmix_pwxform(&X[k * 32], 1, S_base, sc);
    }

    /* smix1 */
    for (u32 i = 0; i < N; i++) {
        for (u32 k = 0; k < SL; k++) V[V_off + (u64)i * SL + k] = X[k];
        if (i > 1) {
            u32 intfy = X[(2 * r - 1) * 16];
            u32 n = i; while (n & (n - 1)) n &= (n - 1);
            u32 j = (intfy & (n - 1)) + (i - n);
            for (u32 k = 0; k < SL; k++) X[k] ^= V[V_off + (u64)j * SL + k];
        }
        blockmix_pwxform(X, r, S_base, sc);
    }

    /* B' <- X (SIMD shuffle) */
    for (u32 b = 0; b < 64; b++)
        for (u32 i = 0; i < 16; i++)
            B[b * 16 + (i * 5 % 16)] = X[b * 16 + i];

    /* smix2: X <- B */
    for (u32 b = 0; b < 64; b++)
        for (u32 i = 0; i < 16; i++)
            X[b * 16 + i] = B[b * 16 + (i * 5 % 16)];

    u32 Nloop_rw = (N + 2) / 3; Nloop_rw++; Nloop_rw &= ~1u;
    for (u32 i = 0; i < Nloop_rw; i++) {
        u32 j = X[(2 * r - 1) * 16] & (N - 1);
        for (u32 k = 0; k < SL; k++) X[k] ^= V[V_off + (u64)j * SL + k];
        for (u32 k = 0; k < SL; k++) V[V_off + (u64)j * SL + k] = X[k];
        blockmix_pwxform(X, r, S_base, sc);
    }

    for (u32 b = 0; b < 64; b++)
        for (u32 i = 0; i < 16; i++)
            B[b * 16 + (i * 5 % 16)] = X[b * 16 + i];
}

/* ==================== kernel ==================== */
extern "C" __global__ void yespower_smix(
    u32 *Bi_g,    /* [num*1024] in/out */
    u32 *V_g,     /* [num*N*SL]  scratch */
    u32 *S_g,     /* [num*3*Ssegment] scratch */
    u32 num)
{
    u32 gid = blockIdx.x * blockDim.x + threadIdx.x;
    if (gid >= num) return;

    u64 V_off = (u64)gid * N_CONST * SL;
    u32 *S_base = S_g + (u64)gid * 3u * Ssegment;

    sctx sc;
    sc.so = 0; sc.s1 = Ssegment; sc.s2 = 2 * Ssegment; sc.w = 0;

    u32 X[1024], B[1024], Xs[32];
    for (u32 k = 0; k < 1024; k++) B[k] = Bi_g[(u64)gid * 1024 + k];

    /* S-box init */
    for (u32 k = 0; k < 2; k++)
        for (u32 i = 0; i < 16; i++)
            Xs[k * 16 + i] = B[k * 16 + (i * 5 % 16)];

    u32 N_sinit = Sbytes / 128u;   /* 768 */
    sinit(Xs, S_base, N_sinit);

    for (u32 k = 0; k < 2; k++)
        for (u32 i = 0; i < 16; i++)
            B[k * 16 + (i * 5 % 16)] = Xs[k * 16 + i];

    /* reset S context after S-init */
    sc.so = 0; sc.s1 = Ssegment; sc.s2 = 2 * Ssegment; sc.w = 0;

    smix(X, B, V_g, S_base, &sc, R_CONST, N_CONST, V_off);

    for (u32 k = 0; k < 1024; k++) Bi_g[(u64)gid * 1024 + k] = B[k];
}

#endif /* POWER2B_KERNEL_CUH */
