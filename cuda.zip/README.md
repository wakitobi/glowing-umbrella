# mbc-cuda-miner — power2b (MBC yespower) CUDA hasher for Tesla T4

CUDA port of the verified OpenCL `smix` kernel for MicroBitcoin's power2b
(yespower 1.0, N=2048, r=32, blake2b wrapper, pers="Now I am become Death, the
destroyer of worlds"). Written to build and run on an NVIDIA Tesla T4 (Turing,
sm_75).

## Status / what is verified

- **Algorithm correctness: PROVEN offline.** `test/host_smix.c` is a CPU
  translation of the *exact* code in `power2b_kernel.cuh` (same smix, same
  pwxform/salsa, same blake2b wrapper). It reproduces the known rplant test
  vector byte-for-byte:
  ```
  header 02000000b0ad...b6a  ->  edc067dc5d32bf354297b77121dda0c3a98013ca5b6f825ffffee9c8c53208a9
  ```
  Run it yourself: `gcc -O2 test/host_smix.c -o test/host_smix && ./test/host_smix` → `VERDICT: PASS`.
- **CUDA build + live H/s: GATED on the T4.** This machine has no CUDA toolkit
  (no nvcc), so the `.cu` was not compiled here. Build it on the T4 with
  `build.sh` and it will self-verify against the same vector before benchmarking.

## Files

- `power2b_kernel.cuh` — the CUDA `__global__ yespower_smix` kernel + device
  helpers. 1:1 with the verified `smix.cl`. Per-thread: 8 MiB V + 96 KiB S in
  global memory, ~8 KiB private (X/B/Xs).
- `power2b_cuda.cu` — host driver: blake2b/pbkdf2/hmac wrapper (CPU), CUDA
  malloc/memcpy/launch glue, `verify` and `bench` modes.
- `build.sh` — nvcc build for a chosen arch (default sm_75 = T4), then verify + bench.
- `test/host_smix.c` — CPU proof of the algorithm (no GPU needed).
- `test/wraptest.c` — isolated crypto-wrapper cross-check vs the Python reference.

## Build & run on the T4

```bash
# 1. Ensure CUDA toolkit is installed (nvcc). On Ubuntu:
#      sudo apt-get install -y nvidia-cuda-toolkit
#    or NVIDIA's repo for a newer CUDA matching the driver.
# 2. Build for the T4 (Turing = sm_75):
bash build.sh sm_75
# build.sh will:
#   - nvcc -O3 -arch=sm_75 power2b_cuda.cu -o power2b_cuda
#   - ./power2b_cuda verify   (must print VERDICT: PASS)
#   - ./power2b_cuda bench 256 5
```

Manual:
```bash
nvcc -O3 -arch=sm_75 power2b_cuda.cu -o power2b_cuda
./power2b_cuda verify
./power2b_cuda bench 512 5          # H/s at batch=512, 5 launches
for b in 128 256 512 1024; do ./power2b_cuda bench $b 5; done   # find the sweet spot
```

## Expected hashrate (T4, honest)

power2b is memory-hard by design — the T4 is **bandwidth-bound, not
compute-bound**. Its 2560 CUDA cores sit mostly idle; the wall is the 320 GB/s
GDDR6 divided by ~32 MiB of scratchpad traffic per hash:

```
theoretical ceiling  ~9-10 KH/s   (320 GB/s / 32 MiB)  -- unreachable
realistic, tuned      ~4-6 KH/s   (40-60% of ceiling, helped by the 4 MB L2)
this naive kernel     ~1-3 KH/s   (one hash per thread, no shared-mem staging)
```

For reference the native CPU miner does ~257 H/s/core, so even 2-3 KH/s on the
T4 ≈ a 10-12 core CPU. It works; it is not "big" hashrate — no yespower miner is
on any GPU, that is the algorithm's whole point.

### Where the speed goes and how to push it higher
- This kernel keeps the 96 KiB S-box in **global** memory (per thread). On the
  T4 those gathers are served largely from the **4 MB L2**, which is why it's
  usable at all (vs a GT 610's raw-VRAM 4.8% efficiency).
- Biggest win available: stage the pwxform S-box in **shared memory**. Turing
  has 64 KiB shared/SM — the full 96 KiB won't fit, but the hot 32 KiB S0/S1
  working segments can, cutting the random-gather latency. That's the path from
  ~2 KH/s toward the ~5 KH/s tuned figure.
- Batch/occupancy: each hash needs ~8.1 MiB, so 16 GB caps you near ~1900
  concurrent, but occupancy peaks well before that — sweep `bench` to find it.

## Next step (pool mining, not just hashing)

`power2b_cuda` currently hashes + benchmarks. To actually mine you wire it to
the rplant Stratum-over-WebSocket flow (subscribe/authorize/notify/submit) —
reuse the header/target math and the Koyeb WS bridge from the CPU Rust miner
(`micro/rust-miner`) and feed candidate nonces through the kernel, verifying
hits against the target before submit. Say the word and I'll add the Stratum
loop.
