// wraptest.c — validate the CPU wrap()/finish() crypto against Python reference.
// Compile the crypto out of power2b_cuda.cu by #include with a stub, but simpler:
// we copy the same functions guarded so we can build with plain gcc (no CUDA).
#define WRAPTEST_ONLY 1
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

typedef struct { uint8_t b[128]; uint64_t h[8]; uint64_t t[2]; size_t c; size_t outlen; } bctx;
#define ROTR64(x,y) (((x) >> (y)) ^ ((x) << (64 - (y))))
#define B2B_GET64(p) ( \
    ((uint64_t)((uint8_t*)(p))[0])       ^ (((uint64_t)((uint8_t*)(p))[1]) << 8)  ^ \
    (((uint64_t)((uint8_t*)(p))[2]) << 16) ^ (((uint64_t)((uint8_t*)(p))[3]) << 24) ^ \
    (((uint64_t)((uint8_t*)(p))[4]) << 32) ^ (((uint64_t)((uint8_t*)(p))[5]) << 40) ^ \
    (((uint64_t)((uint8_t*)(p))[6]) << 48) ^ (((uint64_t)((uint8_t*)(p))[7]) << 56))
#define B2B_G(a,b,c,d,x,y) { \
    v[a]=v[a]+v[b]+x; v[d]=ROTR64(v[d]^v[a],32); v[c]=v[c]+v[d]; v[b]=ROTR64(v[b]^v[c],24); \
    v[a]=v[a]+v[b]+y; v[d]=ROTR64(v[d]^v[a],16); v[c]=v[c]+v[d]; v[b]=ROTR64(v[b]^v[c],63); }
static const uint64_t b2b_iv[8] = {
    0x6A09E667F3BCC908ULL,0xBB67AE8584CAA73BULL,0x3C6EF372FE94F82BULL,0xA54FF53A5F1D36F1ULL,
    0x510E527FADE682D1ULL,0x9B05688C2B3E6C1FULL,0x1F83D9ABFB41BD6BULL,0x5BE0CD19137E2179ULL };
static void b2b_compress(bctx *ctx, int last) {
    const uint8_t sigma[12][16] = {
        {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},{14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3},
        {11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4},{7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8},
        {9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13},{2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9},
        {12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11},{13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10},
        {6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5},{10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0},
        {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},{14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3} };
    int i; uint64_t v[16], m[16];
    for (i=0;i<8;i++){ v[i]=ctx->h[i]; v[i+8]=b2b_iv[i]; }
    v[12]^=ctx->t[0]; v[13]^=ctx->t[1];
    if (last) v[14]=~v[14];
    for (i=0;i<16;i++) m[i]=B2B_GET64(&ctx->b[8*i]);
    for (i=0;i<12;i++){
        B2B_G(0,4,8,12,m[sigma[i][0]],m[sigma[i][1]]);
        B2B_G(1,5,9,13,m[sigma[i][2]],m[sigma[i][3]]);
        B2B_G(2,6,10,14,m[sigma[i][4]],m[sigma[i][5]]);
        B2B_G(3,7,11,15,m[sigma[i][6]],m[sigma[i][7]]);
        B2B_G(0,5,10,15,m[sigma[i][8]],m[sigma[i][9]]);
        B2B_G(1,6,11,12,m[sigma[i][10]],m[sigma[i][11]]);
        B2B_G(2,7,8,13,m[sigma[i][12]],m[sigma[i][13]]);
        B2B_G(3,4,9,14,m[sigma[i][14]],m[sigma[i][15]]);
    }
    for (i=0;i<8;i++) ctx->h[i]^=v[i]^v[i+8];
}
static int b2b_init(bctx *ctx, size_t outlen, const void *key, size_t keylen) {
    size_t i; if (outlen==0||outlen>64||keylen>64) return -1;
    for (i=0;i<8;i++) ctx->h[i]=b2b_iv[i];
    ctx->h[0]^=0x01010000 ^ (keylen<<8) ^ outlen;
    ctx->t[0]=ctx->t[1]=0; ctx->c=0; ctx->outlen=outlen;
    for (i=keylen;i<128;i++) ctx->b[i]=0; return 0;
}
static void b2b_update(bctx *ctx, const void *in, size_t inlen) {
    size_t i; for (i=0;i<inlen;i++){
        if (ctx->c==128){ ctx->t[0]+=ctx->c; if(ctx->t[0]<ctx->c) ctx->t[1]++; b2b_compress(ctx,0); ctx->c=0; }
        ctx->b[ctx->c++]=((const uint8_t*)in)[i]; }
}
static void b2b_final(bctx *ctx, void *out) {
    size_t i; ctx->t[0]+=ctx->c; if(ctx->t[0]<ctx->c) ctx->t[1]++;
    while (ctx->c<128) ctx->b[ctx->c++]=0; b2b_compress(ctx,1);
    for (i=0;i<ctx->outlen;i++) ((uint8_t*)out)[i]=(ctx->h[i>>3]>>(8*(i&7)))&0xFF;
}
static void blake2b_hash(void *out, const void *in, size_t inlen) {
    bctx c; b2b_init(&c,32,NULL,0); b2b_update(&c,in,inlen); b2b_final(&c,out);
}
static void hmac_blake2b(uint8_t out[32], const uint8_t *key, size_t keylen,
                         const uint8_t *msg, size_t msglen) {
    uint8_t k[64], ipad[64], opad[64], ih[32], kh[32];
    if (keylen>64){ blake2b_hash(kh,key,keylen); key=kh; keylen=32; }
    memset(k,0,64); memcpy(k,key,keylen);
    for (int i=0;i<64;i++){ ipad[i]=k[i]^0x36; opad[i]=k[i]^0x5c; }
    bctx c; b2b_init(&c,32,NULL,0); b2b_update(&c,ipad,64); b2b_update(&c,msg,msglen); b2b_final(&c,ih);
    b2b_init(&c,32,NULL,0); b2b_update(&c,opad,64); b2b_update(&c,ih,32); b2b_final(&c,out);
}
static void pbkdf2_blake2b_c1(const uint8_t *passwd, size_t plen,
                              const uint8_t *salt, size_t slen,
                              uint8_t *buf, size_t dklen) {
    size_t done=0; uint32_t i=1;
    while (done<dklen){
        uint8_t ivec[4]={(uint8_t)(i>>24),(uint8_t)(i>>16),(uint8_t)(i>>8),(uint8_t)i};
        uint8_t msg[128]; memcpy(msg,salt,slen); memcpy(msg+slen,ivec,4);
        uint8_t T[32]; hmac_blake2b(T,passwd,plen,msg,slen+4);
        size_t clen = dklen-done; if (clen>32) clen=32;
        memcpy(buf+done,T,clen); done+=clen; i++;
    }
}
static const char *PERS = "Now I am become Death, the destroyer of worlds";
static void hex2bin(const char *hex, uint8_t *out, size_t n){
    for (size_t i=0;i<n;i++){ unsigned b; sscanf(hex+2*i,"%2x",&b); out[i]=(uint8_t)b; } }
static void ph(const char*l,const uint8_t*b,size_t n){ printf("%s",l); for(size_t i=0;i<n;i++)printf("%02x",b[i]); printf("\n"); }

static const char *VEC_HDR =
 "02000000b0ad0dda1d38a4ede0bd42f44dd5238d5c1d377de73eafe77e2abd16b8ac7e0"
 "143c4345eb9ad9135836f5c31b697f62429c1be08d55906ff407852adfba680a59"
 "53f1a530eb6101ba001cb6a";

int main(){
    uint8_t hdr[80]; hex2bin(VEC_HDR,hdr,80);
    uint8_t ih[32]; blake2b_hash(ih,hdr,80);
    ph("init_hash(header) = ",ih,32);
    uint8_t B[128]; pbkdf2_blake2b_c1(ih,32,(const uint8_t*)PERS,46,B,128);
    ph("B[:32] (init_hash pre-smix) = ",B,32);
    ph("B[96:128] = ",B+96,32);
    // finish with a fake smixed B: just hmac over the pbkdf2 B tail for cross-check shape
    uint8_t out[32]; hmac_blake2b(out,B+64,64,ih,32);
    ph("hmac(key=B[64:128],msg=init_hash) = ",out,32);
    return 0;
}
