// host_smix.c — full CPU power2b using host translation of the smix kernel +
// the reference blake2b crypto. Proves the algorithm/crypto WITHOUT a GPU.
// If this prints edc067...c53208a9 for the rplant vector, the smix logic (which
// the CUDA kernel mirrors 1:1) and the CPU wrapper are both correct.
//
// Build: gcc -O2 -I../ref host_smix.c ../ref/crypto/blake2b.c \
//            ../ref/crypto/yespower/yespower.c -o host_smix   (NO — we do our own smix)
// Actually self-contained: we include only blake2b for the wrapper and reimplement
// smix in host C (same code as power2b_kernel.cuh).
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

typedef uint32_t u32; typedef uint64_t u64;

/* ---------- blake2b crypto (matches ref, 64-byte HMAC pad) ---------- */
typedef struct { uint8_t b[128]; uint64_t h[8]; uint64_t t[2]; size_t c; size_t outlen; } bctx;
#define ROTR64(x,y) (((x) >> (y)) ^ ((x) << (64 - (y))))
#define B2B_GET64(p) ( \
    ((uint64_t)((uint8_t*)(p))[0])       ^ (((uint64_t)((uint8_t*)(p))[1]) << 8)  ^ \
    (((uint64_t)((uint8_t*)(p))[2]) << 16) ^ (((uint64_t)((uint8_t*)(p))[3]) << 24) ^ \
    (((uint64_t)((uint8_t*)(p))[4]) << 32) ^ (((uint64_t)((uint8_t*)(p))[5]) << 40) ^ \
    (((uint64_t)((uint8_t*)(p))[6]) << 48) ^ (((uint64_t)((uint8_t*)(p))[7]) << 56))
#define B2B_G(a,b,c,d,x,y) { \
    v[a]=v[a]+v[b]+x; v[d]=ROTR64(v[d]^v[a],32); v[c]=v[c]+v[d]; v[b]=ROTR64(v[b]^v[c],24); \
    v[a]=v[a]+v[b]+y; v[d]=ROTR64(v[d]^v[a],16); v[c]=v[c]+v[d]; v[b]=ROTR64(v[b]^v[c],63); }
static const uint64_t b2b_iv[8]={0x6A09E667F3BCC908ULL,0xBB67AE8584CAA73BULL,0x3C6EF372FE94F82BULL,
 0xA54FF53A5F1D36F1ULL,0x510E527FADE682D1ULL,0x9B05688C2B3E6C1FULL,0x1F83D9ABFB41BD6BULL,0x5BE0CD19137E2179ULL};
static void b2b_compress(bctx*ctx,int last){
    const uint8_t sigma[12][16]={{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},{14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3},
    {11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4},{7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8},
    {9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13},{2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9},
    {12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11},{13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10},
    {6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5},{10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0},
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},{14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3}};
    int i; uint64_t v[16],m[16];
    for(i=0;i<8;i++){v[i]=ctx->h[i];v[i+8]=b2b_iv[i];}
    v[12]^=ctx->t[0]; v[13]^=ctx->t[1]; if(last)v[14]=~v[14];
    for(i=0;i<16;i++)m[i]=B2B_GET64(&ctx->b[8*i]);
    for(i=0;i<12;i++){
        B2B_G(0,4,8,12,m[sigma[i][0]],m[sigma[i][1]]); B2B_G(1,5,9,13,m[sigma[i][2]],m[sigma[i][3]]);
        B2B_G(2,6,10,14,m[sigma[i][4]],m[sigma[i][5]]); B2B_G(3,7,11,15,m[sigma[i][6]],m[sigma[i][7]]);
        B2B_G(0,5,10,15,m[sigma[i][8]],m[sigma[i][9]]); B2B_G(1,6,11,12,m[sigma[i][10]],m[sigma[i][11]]);
        B2B_G(2,7,8,13,m[sigma[i][12]],m[sigma[i][13]]); B2B_G(3,4,9,14,m[sigma[i][14]],m[sigma[i][15]]); }
    for(i=0;i<8;i++)ctx->h[i]^=v[i]^v[i+8];
}
static int b2b_init(bctx*ctx,size_t outlen,size_t keylen){
    size_t i; if(outlen==0||outlen>64)return -1;
    for(i=0;i<8;i++)ctx->h[i]=b2b_iv[i];
    ctx->h[0]^=0x01010000 ^ (keylen<<8) ^ outlen;
    ctx->t[0]=ctx->t[1]=0; ctx->c=0; ctx->outlen=outlen;
    for(i=keylen;i<128;i++)ctx->b[i]=0; return 0;
}
static void b2b_update(bctx*ctx,const void*in,size_t inlen){
    size_t i; for(i=0;i<inlen;i++){ if(ctx->c==128){ctx->t[0]+=ctx->c; if(ctx->t[0]<ctx->c)ctx->t[1]++; b2b_compress(ctx,0); ctx->c=0;} ctx->b[ctx->c++]=((const uint8_t*)in)[i]; }
}
static void b2b_final(bctx*ctx,void*out){
    size_t i; ctx->t[0]+=ctx->c; if(ctx->t[0]<ctx->c)ctx->t[1]++;
    while(ctx->c<128)ctx->b[ctx->c++]=0; b2b_compress(ctx,1);
    for(i=0;i<ctx->outlen;i++)((uint8_t*)out)[i]=(ctx->h[i>>3]>>(8*(i&7)))&0xFF;
}
static void blake2b_hash(void*out,const void*in,size_t inlen){ bctx c; b2b_init(&c,32,0); b2b_update(&c,in,inlen); b2b_final(&c,out); }
/* HMAC with 64-byte pad, matching MBC crypto/blake2b.c hmac_blake2b_init */
static void hmac_blake2b(uint8_t out[32],const uint8_t*key,size_t keylen,const uint8_t*msg,size_t msglen){
    uint8_t pad[64], ih[32], kh[32];
    if(keylen>64){ blake2b_hash(kh,key,keylen); key=kh; keylen=32; }
    bctx inner,outer; b2b_init(&inner,32,0);
    memset(pad,0x36,64); for(size_t i=0;i<keylen;i++)pad[i]^=key[i];
    b2b_update(&inner,pad,64);
    b2b_init(&outer,32,0);
    memset(pad,0x5c,64); for(size_t i=0;i<keylen;i++)pad[i]^=key[i];
    b2b_update(&outer,pad,64);
    b2b_update(&inner,msg,msglen); b2b_final(&inner,ih);
    b2b_update(&outer,ih,32); b2b_final(&outer,out);
}
static void pbkdf2_c1(const uint8_t*passwd,size_t plen,const uint8_t*salt,size_t slen,uint8_t*buf,size_t dklen){
    size_t done=0; uint32_t i=1;
    while(done<dklen){
        uint8_t ivec[4]={(uint8_t)(i>>24),(uint8_t)(i>>16),(uint8_t)(i>>8),(uint8_t)i};
        uint8_t msg[128]; memcpy(msg,salt,slen); memcpy(msg+slen,ivec,4);
        uint8_t T[32]; hmac_blake2b(T,passwd,plen,msg,slen+4);
        size_t clen=dklen-done; if(clen>32)clen=32; memcpy(buf+done,T,clen); done+=clen; i++;
    }
}
static const char*PERS="Now I am become Death, the destroyer of worlds";

/* ---------- smix (host translation, identical to power2b_kernel.cuh) ---------- */
#define N_CONST 2048u
#define R_CONST 32u
#define SL (32u*R_CONST)
#define PWXsimple 2u
#define PWXgather 4u
#define PWXrounds 3u
#define PWXbytes (PWXgather*PWXsimple*8u)
#define PWXwords (PWXbytes/4u)
#define SWidth 11u
#define Sbytes1 ((1u<<SWidth)*PWXsimple*8u)
#define Smask (((1u<<SWidth)-1u)*PWXsimple*8u)
#define Sbytes (3u*Sbytes1)
#define Sbytes_words (Sbytes/4u)
#define Ssegment (Sbytes_words/3u)
#define ROTL(x,n) (((x)<<(n))|((x)>>(32-(n))))
typedef struct{u32 so,s1,s2,w;}sctx;

static void salsa20_2(u32*B){
    u32 x[16]; for(u32 i=0;i<16;i++)x[i*5%16]=B[i];
    x[4]^=ROTL(x[0]+x[12],7); x[8]^=ROTL(x[4]+x[0],9); x[12]^=ROTL(x[8]+x[4],13); x[0]^=ROTL(x[12]+x[8],18);
    x[9]^=ROTL(x[5]+x[1],7); x[13]^=ROTL(x[9]+x[5],9); x[1]^=ROTL(x[13]+x[9],13); x[5]^=ROTL(x[1]+x[13],18);
    x[14]^=ROTL(x[10]+x[6],7); x[2]^=ROTL(x[14]+x[10],9); x[6]^=ROTL(x[2]+x[14],13); x[10]^=ROTL(x[6]+x[2],18);
    x[3]^=ROTL(x[15]+x[11],7); x[7]^=ROTL(x[3]+x[15],9); x[11]^=ROTL(x[7]+x[3],13); x[15]^=ROTL(x[11]+x[7],18);
    x[1]^=ROTL(x[0]+x[3],7); x[2]^=ROTL(x[1]+x[0],9); x[3]^=ROTL(x[2]+x[1],13); x[0]^=ROTL(x[3]+x[2],18);
    x[6]^=ROTL(x[5]+x[4],7); x[7]^=ROTL(x[6]+x[5],9); x[4]^=ROTL(x[7]+x[6],13); x[5]^=ROTL(x[4]+x[7],18);
    x[11]^=ROTL(x[10]+x[9],7); x[8]^=ROTL(x[11]+x[10],9); x[9]^=ROTL(x[8]+x[11],13); x[10]^=ROTL(x[9]+x[8],18);
    x[12]^=ROTL(x[15]+x[14],7); x[13]^=ROTL(x[12]+x[15],9); x[14]^=ROTL(x[13]+x[12],13); x[15]^=ROTL(x[14]+x[13],18);
    for(u32 i=0;i<16;i++)B[i]+=x[i*5%16];
}
static void pwxform(u32*X,u32*S_base,sctx*sc){
    u32 S0=sc->so,S1=sc->s1,w=sc->w,Sm=Smask;
    for(u32 i=0;i<PWXrounds;i++)for(u32 j=0;j<PWXgather;j++){
        u32*Xj=X+j*4; u32 xl=Xj[0],xh=Xj[1];
        u32 p0=S0+((xl&Sm)/8u)*2u; u32 p1=S1+((xh&Sm)/8u)*2u;
        for(u32 k=0;k<PWXsimple;k++){
            u64 s0v=((u64)S_base[p0+k*2+1]<<32)+(u64)S_base[p0+k*2];
            u64 s1v=((u64)S_base[p1+k*2+1]<<32)+(u64)S_base[p1+k*2];
            xl=Xj[k*2]; xh=Xj[k*2+1]; u64 xv=(u64)xh*(u64)xl; xv+=s0v; xv^=s1v;
            Xj[k*2]=(u32)xv; Xj[k*2+1]=(u32)(xv>>32);
        }
        if((i==0)||(j<PWXgather/2)){
            if(j&1){ for(u32 k=0;k<PWXsimple;k++){ S_base[S1+w*2]=Xj[k*2]; S_base[S1+w*2+1]=Xj[k*2+1]; w++; } }
            else   { for(u32 k=0;k<PWXsimple;k++){ S_base[S0+(w+k)*2]=Xj[k*2]; S_base[S0+(w+k)*2+1]=Xj[k*2+1]; } }
        }
    }
    u32 old=sc->so; sc->so=sc->s2; sc->s2=sc->s1; sc->s1=old;
    sc->w=w&((1u<<SWidth)*PWXsimple-1u);
}
static void blockmix_pwxform(u32*B,u32 r,u32*S_base,sctx*sc){
    u32 r1=128u*r/PWXbytes; u32 Xt[PWXwords];
    for(u32 i=0;i<PWXwords;i++)Xt[i]=B[(r1-1)*PWXwords+i];
    for(u32 i0=0;i0<r1;i0++){
        if(r1>1)for(u32 k=0;k<PWXwords;k++)Xt[k]^=B[i0*PWXwords+k];
        pwxform(Xt,S_base,sc);
        for(u32 k=0;k<PWXwords;k++)B[i0*PWXwords+k]=Xt[k];
    }
    u32 si=(r1-1)*PWXbytes/64u; salsa20_2(&B[si*16]);
}
static void blockmix_salsa_r1(u32*B){
    u32 Xt[16]; for(u32 i=0;i<16;i++)Xt[i]=B[16+i];
    for(u32 i0=0;i0<2;i0++){ for(u32 k=0;k<16;k++)Xt[k]^=B[i0*16+k]; salsa20_2(Xt); for(u32 k=0;k<16;k++)B[i0*16+k]=Xt[k]; }
}
static void sinit(u32*X,u32*S_base,u32 Nloop){
    for(u32 i=0;i<Nloop;i++){
        for(u32 k=0;k<32;k++)S_base[i*32+k]=X[k];
        if(i>1){ u32 intfy=X[16]; u32 n=i; while(n&(n-1))n&=(n-1); u32 j=(intfy&(n-1))+(i-n);
            for(u32 k=0;k<32;k++)X[k]^=S_base[j*32+k]; }
        blockmix_salsa_r1(X);
    }
}
static void smix(u32*X,u32*B,u32*V,u32*S_base,sctx*sc,u32 r,u32 N){
    for(u32 b=0;b<64;b++)for(u32 i=0;i<16;i++)X[b*16+i]=B[b*16+(i*5%16)];
    for(u32 k=1;k<r;k++){ for(u32 i=0;i<32;i++)X[k*32+i]=X[(k-1)*32+i]; blockmix_pwxform(&X[k*32],1,S_base,sc); }
    for(u32 i=0;i<N;i++){
        for(u32 k=0;k<SL;k++)V[(u64)i*SL+k]=X[k];
        if(i>1){ u32 intfy=X[(2*r-1)*16]; u32 n=i; while(n&(n-1))n&=(n-1); u32 j=(intfy&(n-1))+(i-n);
            for(u32 k=0;k<SL;k++)X[k]^=V[(u64)j*SL+k]; }
        blockmix_pwxform(X,r,S_base,sc);
    }
    for(u32 b=0;b<64;b++)for(u32 i=0;i<16;i++)B[b*16+(i*5%16)]=X[b*16+i];
    for(u32 b=0;b<64;b++)for(u32 i=0;i<16;i++)X[b*16+i]=B[b*16+(i*5%16)];
    u32 Nrw=(N+2)/3; Nrw++; Nrw&=~1u;
    for(u32 i=0;i<Nrw;i++){
        u32 j=X[(2*r-1)*16]&(N-1);
        for(u32 k=0;k<SL;k++)X[k]^=V[(u64)j*SL+k];
        for(u32 k=0;k<SL;k++)V[(u64)j*SL+k]=X[k];
        blockmix_pwxform(X,r,S_base,sc);
    }
    for(u32 b=0;b<64;b++)for(u32 i=0;i<16;i++)B[b*16+(i*5%16)]=X[b*16+i];
}

static void hex2bin(const char*hex,uint8_t*out,size_t n){ for(size_t i=0;i<n;i++){unsigned b;sscanf(hex+2*i,"%2x",&b);out[i]=(uint8_t)b;} }

int main(){
    const char*VEC_HDR="02000000b0ad0dda1d38a4ede0bd42f44dd5238d5c1d377de73eafe77e2abd16b8ac7e0"
                       "143c4345eb9ad9135836f5c31b697f62429c1be08d55906ff407852adfba680a59"
                       "53f1a530eb6101ba001cb6a";
    const char*EXP="edc067dc5d32bf354297b77121dda0c3a98013ca5b6f825ffffee9c8c53208a9";
    uint8_t hdr[80]; hex2bin(VEC_HDR,hdr,80);

    uint8_t ih[32]; blake2b_hash(ih,hdr,80);
    uint8_t Bb[4096]; memset(Bb,0,4096);
    pbkdf2_c1(ih,32,(const uint8_t*)PERS,46,Bb,128);
    uint8_t init_hash[32]; memcpy(init_hash,Bb,32);

    u32*B=(u32*)Bb;
    u32*X=malloc(1024*4);
    u32*V=malloc((size_t)N_CONST*SL*4);
    u32*S=malloc(3ull*Ssegment*4);
    u32 Xs[32];
    for(u32 k=0;k<2;k++)for(u32 i=0;i<16;i++)Xs[k*16+i]=B[k*16+(i*5%16)];
    sctx sc={0,Ssegment,2*Ssegment,0};
    sinit(Xs,S,Sbytes/128u);
    for(u32 k=0;k<2;k++)for(u32 i=0;i<16;i++)B[k*16+(i*5%16)]=Xs[k*16+i];
    sc.so=0; sc.s1=Ssegment; sc.s2=2*Ssegment; sc.w=0;
    smix(X,B,V,S,&sc,R_CONST,N_CONST);

    uint8_t out[32]; hmac_blake2b(out,(uint8_t*)B+4096-64,64,init_hash,32);
    printf("got = "); for(int i=0;i<32;i++)printf("%02x",out[i]); printf("\n");
    printf("exp = %s\n",EXP);
    char got[65]; for(int i=0;i<32;i++)sprintf(got+2*i,"%02x",out[i]);
    printf("VERDICT: %s\n", strcmp(got,EXP)==0?"PASS":"FAIL");
    free(X);free(V);free(S);
    return strcmp(got,EXP)==0?0:1;
}
