#!/usr/bin/env bash
# build.sh — build the power2b CUDA miner on a T4 (or any CUDA box).
# Usage: bash build.sh [sm_arch]   e.g. bash build.sh sm_75   (T4 default)
set -euo pipefail
ARCH="${1:-sm_75}"   # Tesla T4 = Turing = sm_75

if ! command -v nvcc >/dev/null 2>&1; then
  echo "ERROR: nvcc not found. Install the CUDA toolkit:"
  echo "  Ubuntu: sudo apt-get install -y nvidia-cuda-toolkit   (or NVIDIA's .deb repo for a newer CUDA)"
  echo "  Then re-run: bash build.sh $ARCH"
  exit 1
fi

echo ">> nvcc: $(nvcc --version | tail -1)"
echo ">> building for -arch=$ARCH"

# -O3, target arch, allow the big per-thread local arrays.
nvcc -O3 -arch="$ARCH" \
     --ptxas-options=-v \
     power2b_cuda.cu -o power2b_cuda

echo ">> built ./power2b_cuda"
echo ">> verifying against the rplant test vector..."
./power2b_cuda verify
echo ">> quick benchmark (batch=256, 5 launches)..."
./power2b_cuda bench 256 5
echo
echo "Tune batch for your VRAM: each hash needs ~8.1 MiB (V+S+B)."
echo "T4 16 GB -> up to ~1900 concurrent, but occupancy peaks far lower."
echo "Sweep:  for b in 128 256 512 1024; do ./power2b_cuda bench \$b 5; done"
