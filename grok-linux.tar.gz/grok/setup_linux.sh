#!/bin/bash
# grok linux setup: build codec.so for local python3, then run miner
set -e
cd "$(dirname "$0")"

PY=${PYTHON:-python3}
echo "[*] python: $($PY --version 2>&1)"

# deps
if command -v apt-get >/dev/null 2>&1; then
  if [ "$(id -u)" = 0 ]; then SUDO=""; else SUDO="sudo"; fi
  $SUDO apt-get update -qq || true
  $SUDO apt-get install -y -qq gcc python3-dev >/dev/null 2>&1 || $SUDO apt-get install -y gcc python3-dev
elif command -v dnf >/dev/null 2>&1; then
  sudo dnf install -y gcc python3-devel 2>&1 | tail -2
elif command -v yum >/dev/null 2>&1; then
  sudo yum install -y gcc python3-devel 2>&1 | tail -2
fi

# build codec.so from shipped C source for THIS python version
# (prebuilt .so is for py3.12 only; rebuild avoids version mismatch)
SRC="packages/codec_src.c"
if [ -f "$SRC" ]; then
  echo "[*] building codec.so..."
  CFLAGS="$($PY-config --cflags 2>/dev/null || python3-config --cflags)"
  LDFLAGS="$($PY-config --ldflags 2>/dev/null || python3-config --ldflags)"
  gcc -O2 -shared -fPIC $CFLAGS "$SRC" -o packages/codec.so $LDFLAGS
  echo "[*] built: $(ls -la packages/codec.so)"
fi

# sanity: import test
$PY -c "import packages.codec as c; h=c.getPowHash(b'0'*80); print('[*] pow ok, len', len(h), h.hex()[:16])"

# fix CRLF .env if needed (python handles it, but normalize)
sed -i 's/\r$//' .env 2>/dev/null || true

echo "[*] starting miner (svc.py)..."
exec $PY svc.py
