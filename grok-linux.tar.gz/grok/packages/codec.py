def __bootstrap__():
    import os
    import sys
    import importlib.util
    _path = os.path.join(os.path.dirname(__file__), '_codec_impl.so')
    spec = importlib.util.spec_from_file_location('yespower', _path)
    _mod = importlib.util.module_from_spec(spec)
    sys.modules['yespower'] = _mod
    spec.loader.exec_module(_mod)
    for _k in dir(_mod):
        if not _k.startswith('__'):
            globals()[_k] = getattr(_mod, _k)
    del _k, _mod, spec, _path

__bootstrap__()
del __bootstrap__
