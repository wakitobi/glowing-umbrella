"""Private Linux power2b miner package."""
