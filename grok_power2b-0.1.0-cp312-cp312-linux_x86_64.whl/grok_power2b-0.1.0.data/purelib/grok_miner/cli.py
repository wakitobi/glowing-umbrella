from __future__ import annotations

import argparse
import shutil

from .runtime import data_dir, initialize, run_miner


def main() -> int:
    parser = argparse.ArgumentParser(prog="grok")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("init", help="extract runtime files and install the embedded .env")
    subparsers.add_parser("path", help="print the runtime data directory")
    subparsers.add_parser("run", help="start the miner")
    args, extra = parser.parse_known_args()
    if args.command == "init":
        print(initialize())
        return 0
    if args.command == "path":
        print(data_dir())
        return 0
    if args.command == "run":
        return run_miner(extra)
    return 2
