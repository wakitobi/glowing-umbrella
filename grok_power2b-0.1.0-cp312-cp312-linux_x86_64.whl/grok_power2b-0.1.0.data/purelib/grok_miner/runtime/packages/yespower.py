"""Load the bundled CPython 3.12 Linux extension without pkg_resources."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path

_extension = Path(__file__).with_name("yespower.so")
_spec = spec_from_file_location("yespower", _extension)
if _spec is None or _spec.loader is None:
    raise ImportError(f"cannot load {_extension}")
_module = module_from_spec(_spec)
_spec.loader.exec_module(_module)
getPowHash = _module.getPowHash
