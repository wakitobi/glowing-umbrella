//! power2b-miner: native Rust miner for MicroBitcoin (power2b / yespower
//! N=2048 r=32), speaking Stratum over the Koyeb WebSocket proxy — the same
//! pool path the browser/WASM miner used, but running the coin's own C
//! yespower directly across N native threads instead of inside Chrome.

mod config;
mod power2b;
mod stratum;
mod stratum_job;

use config::Config;
use crossbeam_channel::{bounded, Receiver, Sender};
use rand::Rng;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};
use stratum::{PoolEvent, StratumClient};
use stratum_job::{meets_target, target_from_diff, Job};

/// Shared mining state handed to worker threads.
struct Work {
    job: Job,
    extranonce1: String,
    extranonce2: String,
    target: [u8; 32],
    ntime: String,
    /// Bumped on every job/difficulty change; workers restart when it changes.
    epoch: u64,
}

/// A found share, sent from a worker back to the network thread for submit.
struct Share {
    job_id: String,
    extranonce2: String,
    ntime: String,
    nonce_hex: String,
}

fn main() {
    let mut env_path: Option<String> = None;
    let mut threads_override: Option<usize> = None;
    let args: Vec<String> = std::env::args().collect();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--env" => {
                i += 1;
                env_path = args.get(i).cloned();
            }
            "--threads" | "-t" => {
                i += 1;
                threads_override = args.get(i).and_then(|s| s.parse().ok());
            }
            "--help" | "-h" => {
                println!(
                    "power2b-miner [--env PATH] [--threads N]\n\
                     Reads pool config from .env (proxy/host/port/username/password/threads)."
                );
                return;
            }
            _ => {}
        }
        i += 1;
    }

    let mut cfg = match Config::load(env_path.as_deref()) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("config error: {e}");
            std::process::exit(1);
        }
    };
    if let Some(t) = threads_override {
        cfg.threads = t;
    }

    println!(
        "power2b-miner starting: pool {}:{} via proxy, worker={}, threads={}",
        if cfg.host.is_empty() { "?" } else { &cfg.host },
        if cfg.port.is_empty() { "?" } else { &cfg.port },
        cfg.username,
        cfg.threads
    );

    // Reconnect loop.
    loop {
        if let Err(e) = run_session(&cfg) {
            eprintln!("session ended: {e}; reconnecting in 5s");
            thread::sleep(Duration::from_secs(5));
        }
    }
}

fn run_session(cfg: &Config) -> Result<(), String> {
    let mut client = StratumClient::connect(&cfg.proxy)?;
    client.set_read_timeout(Some(Duration::from_millis(500)));
    println!("connected, subscribing…");
    client.subscribe()?;

    let (tx, rx) = std::sync::mpsc::channel::<PoolEvent>();
    let (share_tx, share_rx): (Sender<Share>, Receiver<Share>) = bounded(256);

    // Current work, shared with workers via a Mutex + epoch counter.
    let work: Arc<Mutex<Option<Work>>> = Arc::new(Mutex::new(None));
    let epoch = Arc::new(AtomicU64::new(0));
    let hashes = Arc::new(AtomicU64::new(0));
    let accepted = Arc::new(AtomicUsize::new(0));
    let rejected = Arc::new(AtomicUsize::new(0));

    // Spawn worker threads.
    let mut worker_handles = Vec::new();
    for wid in 0..cfg.threads {
        let work = Arc::clone(&work);
        let epoch = Arc::clone(&epoch);
        let hashes = Arc::clone(&hashes);
        let share_tx = share_tx.clone();
        worker_handles.push(thread::spawn(move || {
            worker_loop(wid, cfg_threads_hint(), work, epoch, hashes, share_tx);
        }));
    }
    drop(share_tx); // workers hold their own clones

    // Hashrate reporter.
    {
        let hashes = Arc::clone(&hashes);
        let accepted = Arc::clone(&accepted);
        let rejected = Arc::clone(&rejected);
        thread::spawn(move || {
            let mut last = Instant::now();
            let mut last_h = 0u64;
            loop {
                thread::sleep(Duration::from_secs(10));
                let now = Instant::now();
                let h = hashes.load(Ordering::Relaxed);
                let dt = now.duration_since(last).as_secs_f64();
                let hr = if dt > 0.0 {
                    (h - last_h) as f64 / dt
                } else {
                    0.0
                };
                println!(
                    "[stats] {:.1} H/s | accepted {} | rejected {}",
                    hr,
                    accepted.load(Ordering::Relaxed),
                    rejected.load(Ordering::Relaxed)
                );
                last = now;
                last_h = h;
            }
        });
    }

    // Network thread state.
    let mut extranonce1: Option<String> = None;
    let mut extranonce2_size: usize = 4;
    let mut difficulty: Option<f64> = None;
    let mut pending_job: Option<(Job, bool)> = None;
    let mut authorized = false;

    let user = cfg.username.clone();
    let pass = cfg.password.clone();

    loop {
        // 1) drain pool events into our state.
        client.pump(&tx)?;
        while let Ok(ev) = rx.try_recv() {
            match ev {
                PoolEvent::Subscribed {
                    extranonce1: en1,
                    extranonce2_size: sz,
                } => {
                    println!("subscribed: extranonce1={en1} en2_size={sz}");
                    extranonce1 = Some(en1);
                    extranonce2_size = sz;
                    client.authorize(&user, &pass)?;
                }
                PoolEvent::Authorized(ok) => {
                    println!("authorized: {ok}");
                    authorized = ok;
                    if !ok {
                        return Err("authorization rejected by pool".into());
                    }
                }
                PoolEvent::Difficulty(d) => {
                    println!("difficulty = {d}");
                    difficulty = Some(d);
                }
                PoolEvent::SetExtranonce(en1) => {
                    println!("set_extranonce1 = {en1}");
                    extranonce1 = Some(en1);
                }
                PoolEvent::NewJob { job, clean } => {
                    println!(
                        "new job {}{}",
                        job.job_id,
                        if clean { " (clean)" } else { "" }
                    );
                    pending_job = Some((job, clean));
                }
                PoolEvent::SubmitResult { accepted: ok, detail } => {
                    if ok {
                        accepted.fetch_add(1, Ordering::Relaxed);
                        println!("share ACCEPTED");
                    } else {
                        rejected.fetch_add(1, Ordering::Relaxed);
                        println!("share REJECTED: {detail}");
                    }
                }
            }
        }

        // 2) if we have everything needed and a fresh job, publish work.
        if authorized {
            if let (Some(en1), Some(diff), Some((job, _clean))) =
                (&extranonce1, difficulty, pending_job.take_if_ready())
            {
                let en2 = random_extranonce2(extranonce2_size);
                let target = target_from_diff(diff);
                let new_epoch = epoch.fetch_add(1, Ordering::SeqCst) + 1;
                let ntime = job.ntime.clone();
                {
                    let mut guard = work.lock().unwrap();
                    *guard = Some(Work {
                        job,
                        extranonce1: en1.clone(),
                        extranonce2: en2,
                        target,
                        ntime,
                        epoch: new_epoch,
                    });
                }
            }
        }

        // 3) submit any shares workers found.
        while let Ok(s) = share_rx.try_recv() {
            println!(
                "submitting share job={} nonce={} en2={}",
                s.job_id, s.nonce_hex, s.extranonce2
            );
            client.submit(&user, &s.job_id, &s.extranonce2, &s.ntime, &s.nonce_hex)?;
        }

        thread::sleep(Duration::from_millis(20));
    }
}

// Helper trait so we can "take the pending job only once, when set".
trait TakeIfReady {
    fn take_if_ready(&mut self) -> Option<(Job, bool)>;
}
impl TakeIfReady for Option<(Job, bool)> {
    fn take_if_ready(&mut self) -> Option<(Job, bool)> {
        self.take()
    }
}

fn cfg_threads_hint() -> usize {
    // Placeholder retained for symmetry; workers are per-thread stateless.
    0
}

fn random_extranonce2(size: usize) -> String {
    let mut rng = rand::thread_rng();
    let mut bytes = vec![0u8; size];
    rng.fill(&mut bytes[..]);
    hex::encode(bytes)
}

/// A single mining worker: pulls the current Work snapshot, sweeps a random
/// nonce range, and restarts whenever the epoch changes (new job/difficulty).
fn worker_loop(
    _wid: usize,
    _hint: usize,
    work: Arc<Mutex<Option<Work>>>,
    epoch: Arc<AtomicU64>,
    hashes: Arc<AtomicU64>,
    share_tx: Sender<Share>,
) {
    let mut rng = rand::thread_rng();
    loop {
        // snapshot current work
        let snapshot = {
            let guard = work.lock().unwrap();
            match &*guard {
                Some(w) => Some((
                    w.job.clone(),
                    w.extranonce1.clone(),
                    w.extranonce2.clone(),
                    w.target,
                    w.ntime.clone(),
                    w.epoch,
                )),
                None => None,
            }
        };

        let (job, en1, en2, target, ntime, my_epoch) = match snapshot {
            Some(s) => s,
            None => {
                thread::sleep(Duration::from_millis(100));
                continue;
            }
        };

        // random nonce start; sweep upward until the epoch changes.
        let mut nonce: u32 = rng.gen();
        let mut local_count: u64 = 0;
        loop {
            let header = job.build_header(&en1, &en2, nonce);
            let digest = power2b::power2b(&header);
            local_count += 1;

            if meets_target(&digest, &target) {
                let _ = share_tx.send(Share {
                    job_id: job.job_id.clone(),
                    extranonce2: en2.clone(),
                    ntime: ntime.clone(),
                    nonce_hex: format!("{nonce:08x}"),
                });
            }

            // periodically flush hash counter + check for a new epoch.
            if local_count & 0x3f == 0 {
                hashes.fetch_add(local_count, Ordering::Relaxed);
                local_count = 0;
                if epoch.load(Ordering::SeqCst) != my_epoch {
                    break;
                }
            }
            nonce = nonce.wrapping_add(1);
        }
    }
}
