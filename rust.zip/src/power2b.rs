//! power2b proof-of-work: yespower variant used by MicroBitcoin.
//! N=2048, r=32, pers="Now I am become Death, the destroyer of worlds".
//! Thin FFI over the coin's own C yespower_tls (thread-local storage,
//! MT-safe as long as the output buffer is thread-local).

use std::os::raw::{c_int, c_uchar};

#[repr(C)]
struct YespowerParams {
    n: u32,
    r: u32,
    pers: *const u8,
    perslen: usize,
}

#[repr(C)]
struct YespowerBinary {
    uc: [c_uchar; 32],
}

extern "C" {
    fn yespower_tls(
        src: *const u8,
        srclen: usize,
        params: *const YespowerParams,
        dst: *mut YespowerBinary,
    ) -> c_int;
}

const PERS: &[u8] = b"Now I am become Death, the destroyer of worlds";

/// Hash an 80-byte serialized block header, returning the 32-byte power2b
/// digest in the same byte order as the C hasher (out.uc[0..32]).
pub fn power2b(header: &[u8; 80]) -> [u8; 32] {
    let params = YespowerParams {
        n: 2048,
        r: 32,
        pers: PERS.as_ptr(),
        perslen: PERS.len(),
    };
    let mut out = YespowerBinary { uc: [0u8; 32] };
    let rc = unsafe { yespower_tls(header.as_ptr(), 80, &params, &mut out) };
    assert_eq!(rc, 0, "yespower_tls failed (rc={rc})");
    out.uc
}

#[cfg(test)]
mod tests {
    use super::*;

    // Ground-truth vector: pool.rplant.xyz job (from the worker's static test()).
    // header -> power2b digest, verified against the coin's standalone C hasher.
    #[test]
    fn known_vector() {
        let header_hex = "00000020960b97dda67bcd7f41cac011223e3149824a7055d0ea700a293cefb20a0a0000c1558f21a9c06e4864db4c09dfb99f396e6ca66732f59e8731bfd73d55fe84c124f50163f3fa0b1ecbaeaaaa";
        let bytes = hex::decode(header_hex).unwrap();
        let mut header = [0u8; 80];
        header.copy_from_slice(&bytes);
        let digest = power2b(&header);
        assert_eq!(
            hex::encode(digest),
            "2c955868692e569526a6079798f0fd90bdee80e272d01b2e07c9d362f2705c63"
        );
    }
}
