//! Stratum-over-WebSocket client for the Koyeb proxy (rplant-compatible).
//! Messages are newline-terminated JSON. Sequence:
//!   subscribe -> [sub_id, extranonce1, en2_size]
//!   authorize(user, pass) -> true
//!   set_difficulty / notify / set_extranonce (async pushes)
//!   submit [user, job_id, en2, ntime, nonce] -> true/false

use serde_json::{json, Value};
use std::io::{Read, Write};
use std::net::TcpStream;
use std::sync::mpsc::Sender;
use tungstenite::stream::MaybeTlsStream;
use tungstenite::{connect, Message, WebSocket};

use crate::stratum_job::Job;

/// Events surfaced from the pool to the mining coordinator.
#[derive(Debug, Clone)]
pub enum PoolEvent {
    Subscribed {
        extranonce1: String,
        extranonce2_size: usize,
    },
    Authorized(bool),
    Difficulty(f64),
    SetExtranonce(String),
    NewJob {
        job: Job,
        clean: bool,
    },
    SubmitResult {
        accepted: bool,
        detail: String,
    },
}

type Ws = WebSocket<MaybeTlsStream<TcpStream>>;

pub struct StratumClient {
    ws: Ws,
}

fn as_str(v: &Value) -> String {
    v.as_str().map(|s| s.to_string()).unwrap_or_default()
}

impl StratumClient {
    pub fn connect(proxy_url: &str) -> Result<Self, String> {
        let (ws, _resp) =
            connect(proxy_url).map_err(|e| format!("ws connect {proxy_url}: {e}"))?;
        // Non-blocking-ish reads are handled via the underlying stream; keep it
        // blocking here and drive reads on a dedicated thread in main.
        Ok(StratumClient { ws })
    }

    /// Set the underlying TCP read timeout so the read loop can poll periodically.
    pub fn set_read_timeout(&mut self, dur: Option<std::time::Duration>) {
        if let MaybeTlsStream::Plain(s) = self.ws.get_mut() {
            let _ = s.set_read_timeout(dur);
        } else if let MaybeTlsStream::NativeTls(t) = self.ws.get_mut() {
            let _ = t.get_mut().set_read_timeout(dur);
        }
    }

    fn send(&mut self, v: Value) -> Result<(), String> {
        let line = format!("{}\n", v);
        self.ws
            .send(Message::Text(line))
            .map_err(|e| format!("ws send: {e}"))
    }

    pub fn subscribe(&mut self) -> Result<(), String> {
        self.send(json!({
            "id": "mining.subscribe",
            "method": "mining.subscribe",
            "params": ["power2b-rs/1.0"]
        }))
    }

    pub fn authorize(&mut self, user: &str, pass: &str) -> Result<(), String> {
        self.send(json!({
            "id": "mining.authorize",
            "method": "mining.authorize",
            "params": [user, pass]
        }))
    }

    pub fn submit(
        &mut self,
        user: &str,
        job_id: &str,
        extranonce2: &str,
        ntime: &str,
        nonce_hex: &str,
    ) -> Result<(), String> {
        self.send(json!({
            "id": "mining.submit",
            "method": "mining.submit",
            "params": [user, job_id, extranonce2, ntime, nonce_hex]
        }))
    }

    /// Read one websocket frame and parse any Stratum messages it contains,
    /// emitting PoolEvents on `tx`. Returns Ok(true) if a frame was processed,
    /// Ok(false) on read timeout (no data), Err on fatal socket error.
    pub fn pump(&mut self, tx: &Sender<PoolEvent>) -> Result<bool, String> {
        match self.ws.read() {
            Ok(Message::Text(text)) => {
                for line in text.split('\n') {
                    let line = line.trim();
                    if line.is_empty() {
                        continue;
                    }
                    if let Ok(v) = serde_json::from_str::<Value>(line) {
                        handle_message(&v, tx);
                    }
                }
                Ok(true)
            }
            Ok(Message::Binary(_)) | Ok(Message::Ping(_)) | Ok(Message::Pong(_)) => Ok(true),
            Ok(Message::Close(_)) => Err("pool closed connection".into()),
            Ok(Message::Frame(_)) => Ok(true),
            Err(tungstenite::Error::Io(e))
                if e.kind() == std::io::ErrorKind::WouldBlock
                    || e.kind() == std::io::ErrorKind::TimedOut =>
            {
                Ok(false)
            }
            Err(e) => Err(format!("ws read: {e}")),
        }
    }
}

fn handle_message(m: &Value, tx: &Sender<PoolEvent>) {
    let method = m.get("method").and_then(|v| v.as_str());
    let id = m.get("id").and_then(|v| v.as_str());

    // Async server pushes (have a `method`).
    if let Some(method) = method {
        match method {
            "mining.set_difficulty" => {
                if let Some(d) = m
                    .get("params")
                    .and_then(|p| p.get(0))
                    .and_then(|v| v.as_f64())
                {
                    let _ = tx.send(PoolEvent::Difficulty(d));
                }
                return;
            }
            "mining.set_extranonce" => {
                if let Some(en1) = m
                    .get("params")
                    .and_then(|p| p.get(0))
                    .and_then(|v| v.as_str())
                {
                    let _ = tx.send(PoolEvent::SetExtranonce(en1.to_string()));
                }
                return;
            }
            "mining.notify" => {
                if let Some(p) = m.get("params").and_then(|v| v.as_array()) {
                    if p.len() >= 9 {
                        let branches = p[4]
                            .as_array()
                            .map(|a| a.iter().map(as_str).collect::<Vec<_>>())
                            .unwrap_or_default();
                        let job = Job {
                            job_id: as_str(&p[0]),
                            prevhash: as_str(&p[1]),
                            coinb1: as_str(&p[2]),
                            coinb2: as_str(&p[3]),
                            merkle_branch: branches,
                            version: as_str(&p[5]),
                            nbits: as_str(&p[6]),
                            ntime: as_str(&p[7]),
                        };
                        let clean = p[8].as_bool().unwrap_or(false);
                        let _ = tx.send(PoolEvent::NewJob { job, clean });
                    }
                }
                return;
            }
            _ => {}
        }
    }

    // Responses to our requests (matched by string id).
    match id {
        Some("mining.subscribe") => {
            if let Some(res) = m.get("result").and_then(|v| v.as_array()) {
                // result = [sub_details, extranonce1, extranonce2_size]
                let en1 = res.get(1).map(as_str).unwrap_or_default();
                let sz = res
                    .get(2)
                    .and_then(|v| v.as_u64())
                    .map(|n| n as usize)
                    .unwrap_or(4);
                let _ = tx.send(PoolEvent::Subscribed {
                    extranonce1: en1,
                    extranonce2_size: sz,
                });
            }
        }
        Some("mining.authorize") => {
            let ok = m.get("result").and_then(|v| v.as_bool()).unwrap_or(false);
            let _ = tx.send(PoolEvent::Authorized(ok));
        }
        Some("mining.submit") => {
            let ok = m.get("result").and_then(|v| v.as_bool()).unwrap_or(false);
            let detail = if ok {
                "ok".to_string()
            } else {
                m.get("error").map(|e| e.to_string()).unwrap_or_default()
            };
            let _ = tx.send(PoolEvent::SubmitResult {
                accepted: ok,
                detail,
            });
        }
        _ => {}
    }
}

// silence unused import warnings for platforms where TcpStream helpers differ
#[allow(unused_imports)]
use std::marker::PhantomData as _Unused;
#[allow(dead_code)]
fn _keep_io_traits(_r: &dyn Read, _w: &dyn Write) {}
