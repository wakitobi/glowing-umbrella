//! Pool configuration, loaded from a `.env` file (same keys the Python miner
//! and web miner use: proxy/host/port/username/password/threads/socks5_proxy).

use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone)]
pub struct Config {
    /// wss:// Koyeb proxy URL (base64-path encoded pool target).
    pub proxy: String,
    pub host: String,
    pub port: String,
    pub username: String,
    pub password: String,
    pub threads: usize,
}

fn parse_env(text: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') || !line.contains('=') {
            continue;
        }
        let (k, v) = line.split_once('=').unwrap();
        let mut v = v.trim().to_string();
        // strip surrounding quotes if present
        if (v.starts_with('"') && v.ends_with('"') && v.len() >= 2)
            || (v.starts_with('\'') && v.ends_with('\'') && v.len() >= 2)
        {
            v = v[1..v.len() - 1].to_string();
        }
        map.insert(k.trim().to_string(), v);
    }
    map
}

impl Config {
    /// Load from an explicit path, or search: ./.env, ../.env, then
    /// the packaged web-miner-linux/.env next to the binary.
    pub fn load(explicit: Option<&str>) -> Result<Self, String> {
        let candidates: Vec<String> = if let Some(p) = explicit {
            vec![p.to_string()]
        } else {
            vec![".env".into(), "../.env".into(), "../../.env".into()]
        };

        let mut found = None;
        for c in &candidates {
            if Path::new(c).is_file() {
                found = Some(c.clone());
                break;
            }
        }
        let path = found.ok_or_else(|| {
            format!(
                "no .env found (looked in: {}). Pass --env <path>.",
                candidates.join(", ")
            )
        })?;

        let text = fs::read_to_string(&path).map_err(|e| format!("read {path}: {e}"))?;
        let m = parse_env(&text);

        let get = |k: &str| m.get(k).cloned().unwrap_or_default();

        let proxy = get("proxy");
        if proxy.is_empty() {
            return Err(format!("`proxy` missing in {path}"));
        }
        let username = get("username");
        if username.is_empty() {
            return Err(format!("`username` missing in {path}"));
        }

        let threads = m
            .get("threads")
            .and_then(|s| s.parse::<usize>().ok())
            .filter(|&n| n > 0)
            .unwrap_or_else(num_cpus::get);

        Ok(Config {
            proxy,
            host: get("host"),
            port: get("port"),
            username,
            password: get("password"),
            threads,
        })
    }
}
