//! Stratum job -> 80-byte power2b header construction.
//! Mirrors the extracted worker's header builder exactly:
//!   merkle_root = sha256d(coinb1 + en1 + en2 + coinb2), folded over branches
//!   header = swap4(version) + swap32(prevhash) + merkle_root
//!            + swap4(ntime) + swap4(nbits) + swap4(nonce)
//! where swap4 reverses the 4 bytes of a LE32 word and swap32 byte-reverses
//! each 4-byte word of the 32-byte prevhash.

use sha2::{Digest, Sha256};

pub fn sha256d(data: &[u8]) -> [u8; 32] {
    let first = Sha256::digest(data);
    let second = Sha256::digest(first);
    let mut out = [0u8; 32];
    out.copy_from_slice(&second);
    out
}

/// Reverse the bytes of a 4-byte little-endian word given as an 8-char hex str.
fn swap4_hex(word_hex: &str) -> String {
    let mut b = hex::decode(word_hex).expect("swap4 hex");
    b.reverse();
    hex::encode(b)
}

/// Byte-reverse each 4-byte word of a 32-byte (64 hex char) value.
fn swap32_hex(hash_hex: &str) -> String {
    let bytes = hex::decode(hash_hex).expect("swap32 hex");
    assert_eq!(bytes.len(), 32);
    let mut out = Vec::with_capacity(32);
    for chunk in bytes.chunks(4) {
        let mut c = chunk.to_vec();
        c.reverse();
        out.extend_from_slice(&c);
    }
    hex::encode(out)
}

/// A mining job as delivered by `mining.notify`.
#[derive(Debug, Clone)]
pub struct Job {
    pub job_id: String,
    pub prevhash: String,
    pub coinb1: String,
    pub coinb2: String,
    pub merkle_branch: Vec<String>,
    pub version: String,
    pub nbits: String,
    pub ntime: String,
}

impl Job {
    /// Compute the merkle root (hex) for a given extranonce1/extranonce2.
    pub fn merkle_root(&self, extranonce1: &str, extranonce2: &str) -> String {
        let coinbase_hex = format!(
            "{}{}{}{}",
            self.coinb1, extranonce1, extranonce2, self.coinb2
        );
        let coinbase = hex::decode(&coinbase_hex).expect("coinbase hex");
        let mut root = sha256d(&coinbase);
        for branch in &self.merkle_branch {
            let br = hex::decode(branch).expect("branch hex");
            let mut cat = Vec::with_capacity(64);
            cat.extend_from_slice(&root);
            cat.extend_from_slice(&br);
            root = sha256d(&cat);
        }
        hex::encode(root)
    }

    /// Build the 80-byte serialized header for the given nonce (u32).
    pub fn build_header(&self, extranonce1: &str, extranonce2: &str, nonce: u32) -> [u8; 80] {
        let merkle = self.merkle_root(extranonce1, extranonce2);
        let nonce_hex = format!("{nonce:08x}");
        let header_hex = format!(
            "{}{}{}{}{}{}",
            swap4_hex(&self.version),
            swap32_hex(&self.prevhash),
            merkle,
            swap4_hex(&self.ntime),
            swap4_hex(&self.nbits),
            swap4_hex(&nonce_hex),
        );
        let bytes = hex::decode(&header_hex).expect("header hex");
        assert_eq!(bytes.len(), 80, "header must be 80 bytes");
        let mut h = [0u8; 80];
        h.copy_from_slice(&bytes);
        h
    }
}

/// power2b target: the pool validates against ~2^240 / D. The base value is
/// 0x0000FFFF followed by all-FF (32 bytes big-endian) divided by difficulty,
/// matching the extracted worker's `parseInt("0000FFFF...FF",16)/miningDiff`.
/// Returns the 256-bit target as big-endian bytes.
pub fn target_from_diff(diff: f64) -> [u8; 32] {
    let mut base = [0xffu8; 32];
    base[0] = 0x00;
    base[1] = 0x00;

    if diff <= 0.0 {
        return base;
    }

    // scaled denominator: round(diff * 2^32) so we compute base/diff exactly as
    // (base << 32) / scaled via byte-level long division.
    const SCALE: u128 = 1u128 << 32;
    let scaled = (diff * SCALE as f64).round() as u128;
    if scaled == 0 {
        return base;
    }

    // dividend = base followed by 4 zero bytes  (== base * 2^32), 36 bytes BE.
    let mut dividend = [0u8; 36];
    dividend[..32].copy_from_slice(&base);

    // long division: one output byte at a time.
    let mut quotient = [0u8; 36];
    let mut rem: u128 = 0;
    for i in 0..36 {
        let acc = (rem << 8) | dividend[i] as u128;
        quotient[i] = (acc / scaled) as u8; // < 256 since acc < scaled*256
        rem = acc % scaled;
    }

    // result = low 32 bytes of the 36-byte quotient (top 4 bytes are ~0).
    let mut out = [0u8; 32];
    out.copy_from_slice(&quotient[4..36]);
    out
}

/// Compare the power2b digest against the target. The pool numeric value is the
/// byte-reversed digest (little-endian number) compared <= target (big-endian).
pub fn meets_target(digest: &[u8; 32], target_be: &[u8; 32]) -> bool {
    let mut num_be = *digest;
    num_be.reverse();
    num_be.as_slice() <= target_be.as_slice()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rplant_header_matches_vector() {
        // pool.rplant.xyz test vector from the worker's static test().
        let job = Job {
            job_id: "e0ff".into(),
            prevhash: "dd970b967fcd7ba611c0ca4149313e2255704a820a70ead0b2ef3c2900000a0a".into(),
            coinb1: "01000000010000000000000000000000000000000000000000000000000000000000000000ffffffff4e03d93d1f0424f5016308fabe6d6d00000000000000000000000000000000000000000000000000000000000000000100000000000000".into(),
            coinb2: "0f706f6f6c2e72706c616e742e78797a00000000020000000000000000266a24aa21a9ed889e8ce0216f207f75106adee83fac289bce8fe957fb2cca2be15c990099875a601fe70e000000001976a914bb89477996b8a915f686a1ba7109987a7b7730c188ac00000000".into(),
            merkle_branch: vec!["cf00b937757b98d92f0eaea7c7c3139014b37266bee658cbcd60466822796328".into()],
            version: "20000000".into(),
            nbits: "1e0bfaf3".into(),
            ntime: "6301f524".into(),
        };
        let header = job.build_header("67ffed53", "00000000", 2863312587);
        let expected = "00000020960b97dda67bcd7f41cac011223e3149824a7055d0ea700a293cefb20a0a0000c1558f21a9c06e4864db4c09dfb99f396e6ca66732f59e8731bfd73d55fe84c124f50163f3fa0b1ecbaeaaaa";
        assert_eq!(hex::encode(header), expected);
    }

    #[test]
    fn target_scales_with_difficulty() {
        // Higher difficulty => smaller (harder) target.
        let t1 = target_from_diff(1.0);
        let t2 = target_from_diff(2.0);
        assert!(t2.as_slice() < t1.as_slice());
        // diff=1 leaves 0x0000FFFF.. essentially unchanged at the top.
        assert_eq!(t1[0], 0x00);
        assert_eq!(t1[1], 0x00);
    }
}
