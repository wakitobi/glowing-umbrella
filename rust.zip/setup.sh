#!/usr/bin/env bash
# Build + run the native Rust power2b miner on a Linux machine (VPS/container).
# Installs Rust and a C toolchain if missing, builds --release, then either runs
# in the foreground or installs a systemd service (--install-service).
#
# Usage:
#   bash setup.sh                    # build + run in foreground
#   bash setup.sh --threads 4        # override thread count
#   bash setup.sh --install-service  # build + install+start systemd unit
#   bash setup.sh --uninstall        # stop + remove systemd unit
set -uo pipefail
cd "$(dirname "$0")"
ROOT="$(pwd)"

THREADS=""
INSTALL_SERVICE=0
UNINSTALL=0
while [ $# -gt 0 ]; do
  case "$1" in
    --threads|-t) THREADS="$2"; shift 2;;
    --install-service) INSTALL_SERVICE=1; shift;;
    --uninstall) UNINSTALL=1; shift;;
    *) echo "unknown arg: $1" >&2; exit 2;;
  esac
done

SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

# ---- uninstall path ----
if [ "$UNINSTALL" -eq 1 ]; then
  $SUDO systemctl stop power2b-miner 2>/dev/null || true
  $SUDO systemctl disable power2b-miner 2>/dev/null || true
  $SUDO rm -f /etc/systemd/system/power2b-miner.service
  $SUDO systemctl daemon-reload 2>/dev/null || true
  echo "power2b-miner service removed."
  exit 0
fi

# ---- .env check ----
if [ ! -f "$ROOT/.env" ]; then
  echo "ERROR: no .env in $ROOT (needs proxy/username/password). Copy it here first." >&2
  exit 1
fi

# ---- C toolchain ----
echo "== checking C toolchain =="
if ! command -v cc >/dev/null 2>&1 && ! command -v gcc >/dev/null 2>&1; then
  echo "installing build tools…"
  if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update -y >/dev/null 2>&1 && $SUDO apt-get install -y build-essential pkg-config libssl-dev curl >/dev/null 2>&1
  elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf install -y gcc make pkgconf openssl-devel curl >/dev/null 2>&1
  elif command -v yum >/dev/null 2>&1; then
    $SUDO yum install -y gcc make pkgconfig openssl-devel curl >/dev/null 2>&1
  elif command -v pacman >/dev/null 2>&1; then
    $SUDO pacman -Sy --noconfirm base-devel openssl curl >/dev/null 2>&1
  elif command -v apk >/dev/null 2>&1; then
    $SUDO apk add --no-cache build-base openssl-dev curl >/dev/null 2>&1
  elif command -v zypper >/dev/null 2>&1; then
    $SUDO zypper -n install gcc make pkg-config libopenssl-devel curl >/dev/null 2>&1
  else
    echo "ERROR: no known package manager; install a C compiler + openssl-dev manually." >&2
    exit 1
  fi
fi
command -v cc >/dev/null 2>&1 || command -v gcc >/dev/null 2>&1 || { echo "ERROR: still no C compiler." >&2; exit 1; }
echo "cc: $(command -v cc || command -v gcc)"

# ---- Rust toolchain ----
echo "== checking Rust =="
export PATH="$HOME/.cargo/bin:$PATH"
if ! command -v cargo >/dev/null 2>&1; then
  echo "installing rustup (stable, minimal)…"
  curl -sSfL https://sh.rustup.rs | sh -s -- -y --default-toolchain stable --profile minimal
  export PATH="$HOME/.cargo/bin:$PATH"
fi
command -v cargo >/dev/null 2>&1 || { echo "ERROR: cargo not on PATH after install." >&2; exit 1; }
echo "cargo: $(cargo --version)"

# ---- build ----
echo "== building --release (first build compiles the C yespower too) =="
cargo build --release || { echo "ERROR: build failed." >&2; exit 1; }
BIN="$ROOT/target/release/power2b-miner"
[ -x "$BIN" ] || { echo "ERROR: binary not produced at $BIN" >&2; exit 1; }
echo "built: $BIN"

RUN_ARGS=""
[ -n "$THREADS" ] && RUN_ARGS="--threads $THREADS"

# ---- systemd install path ----
if [ "$INSTALL_SERVICE" -eq 1 ]; then
  RUN_USER="${SUDO_USER:-$(id -un)}"
  UNIT=/etc/systemd/system/power2b-miner.service
  echo "== installing systemd unit ($UNIT), user=$RUN_USER =="
  $SUDO tee "$UNIT" >/dev/null <<EOF
[Unit]
Description=power2b native Rust miner (MicroBitcoin)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$ROOT
ExecStart=$BIN --env $ROOT/.env $RUN_ARGS
Restart=always
RestartSec=5
Nice=10

[Install]
WantedBy=multi-user.target
EOF
  # protect creds
  chmod 600 "$ROOT/.env" 2>/dev/null || true
  $SUDO systemctl daemon-reload
  $SUDO systemctl enable power2b-miner >/dev/null 2>&1
  $SUDO systemctl restart power2b-miner
  sleep 3
  echo "== status =="
  $SUDO systemctl --no-pager --full status power2b-miner | head -15 || true
  echo
  echo "logs:   journalctl -u power2b-miner -f"
  echo "stop:   $SUDO systemctl stop power2b-miner"
  echo "remove: bash setup.sh --uninstall"
  exit 0
fi

# ---- foreground run ----
echo "== running in foreground (Ctrl-C to stop) =="
exec "$BIN" --env "$ROOT/.env" $RUN_ARGS
