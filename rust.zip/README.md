# power2b-miner (native Rust)

A native Rust port of the browser/WASM power2b miner in `../web-miner-linux`.
Same pool, same protocol, same PoW — but it runs the coin's own C `yespower`
(N=2048, r=32, pers="Now I am become Death, the destroyer of worlds") directly
across N native threads instead of inside headless Chrome. No browser, no WASM
tax, no Emscripten worker.

Measured: ~740-840 H/s on 4 threads vs ~257 H/s for 7 WASM workers in Chrome.

## Layout

    Cargo.toml         crate + deps (tungstenite, sha2, cc build)
    build.rs           compiles csrc/ C yespower+blake2b into a static lib
    csrc/crypto/       the coin's power2b C sources (yespower.c, blake2b.c, ...)
    src/power2b.rs     FFI over yespower_tls; power2b(header) -> 32-byte digest
    src/stratum_job.rs job -> 80-byte header (merkle + coinbase), target math
    src/stratum.rs     Stratum-over-WebSocket client (Koyeb proxy)
    src/config.rs      loads pool config from .env
    src/main.rs        thread pool + network loop + share submission

## Build

Needs the Rust toolchain and a C compiler (MinGW gcc on Windows, or gcc/clang
on Linux — `cc` crate auto-detects). This repo built with the GNU toolchain:

    rustup default stable-x86_64-pc-windows-gnu   # Windows/MinGW
    cargo build --release

Binary: `target/release/power2b-miner(.exe)`.

On Linux the same tree builds unchanged (`cargo build --release`); the C sources
use `-msse2` + the x86-64 inline-asm pwxform path, matching the coin's hasher.

## Run

Reads pool config from a `.env` file (same keys as the Python/web miner:
`proxy`, `host`, `port`, `username`, `password`, `threads`).

    ./power2b-miner --env ../web-miner-linux/.env --threads 4

Search order when `--env` is omitted: `./.env`, `../.env`, `../../.env`.
`--threads N` overrides the `.env` `threads` value (defaults to CPU core count).

## Verify

    cargo test --release

Two ground-truth checks (both pass):
- `power2b::known_vector` — hashes the pool.rplant.xyz test header and asserts
  the digest equals the coin's standalone C hasher output
  (`2c955868...f2705c63`).
- `rplant_header_matches_vector` — rebuilds the 80-byte header from the
  `mining.notify` fields and asserts it matches the worker's embedded vector.

Live proof (45s run against the pool): subscribed, authorized, difficulty 0.2,
share ACCEPTED, ~800 H/s on 4 threads.

## How it maps to the WASM version

| WASM miner (index.html + worker.js) | Rust miner |
|---|---|
| `new WebSocket(proxy)` + JSON lines | `tungstenite` in `stratum.rs` |
| Emscripten `cwm_power2B` in Web Worker | C `yespower_tls` via FFI in `power2b.rs` |
| header builder in worker (swap4/swap32) | `stratum_job.rs::build_header` |
| `parseInt("0000FFFF..")/miningDiff` target | `target_from_diff` (256-bit long division) |
| 1-3 rotating Web Workers | `--threads N` native OS threads |

## Linux deployment

The whole tree is portable Rust + C — it builds on any x86-64 Linux with a C
compiler. Use `setup.sh`, which installs Rust + build tools if missing, builds
`--release`, and can install a systemd service.

Ship it (from this Windows box a portable tarball is already built at
`../rust-miner.tar.gz`, source only — no `target/`, no `.env`):

    scp ../rust-miner.tar.gz user@host:~/
    scp ../web-miner-linux/.env user@host:~/    # your pool creds, sent separately

On the Linux machine:

    tar xzf rust-miner.tar.gz
    cp .env rust-miner/.env            # setup.sh requires .env beside it
    cd rust-miner

    bash setup.sh --threads 4          # build + run in foreground, or…
    bash setup.sh --install-service --threads 4   # build + systemd auto-start

`--install-service` writes `/etc/systemd/system/power2b-miner.service`
(Restart=always, Nice=10, runs as the invoking user, `.env` chmod 600), enables
and starts it. Manage it with:

    journalctl -u power2b-miner -f     # live logs
    sudo systemctl stop power2b-miner
    bash setup.sh --uninstall          # stop + remove the unit

First build compiles the C yespower too and takes ~1-2 min; subsequent runs are
instant. `setup.sh` auto-detects apt/dnf/yum/pacman/apk/zypper for deps.

## Notes

- `.env` holds live pool worker credentials — keep this folder private and never
  put it in the tarball (the shipped `rust-miner.tar.gz` deliberately omits it).
- The miner speaks only to the Koyeb `wss://` proxy in `.env`; no other egress.
- Reconnects automatically with a 5s backoff if the pool drops.
- Native miner on a real Linux box beats the headless-Chrome bundle in
  `../web-miner-linux` on both speed (~3x) and footprint (no browser) — this is
  meant to replace it there.
