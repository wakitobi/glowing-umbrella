// Compiles the MicroBitcoin power2b C sources (yespower N=2048 r=32 + blake2b)
// into a static lib linked into the Rust binary. Same source tree the node's
// standalone hasher uses; we only expose yespower_tls via FFI.
fn main() {
    let mut build = cc::Build::new();
    build
        .file("csrc/crypto/yespower/yespower.c")
        .file("csrc/crypto/blake2b.c")
        .include("csrc")
        .include("csrc/crypto")
        .opt_level(3);

    // x86-64 gets SSE2 + the inline-asm pwxform path (mirrors gcc -msse2 build).
    let target = std::env::var("TARGET").unwrap_or_default();
    if target.contains("x86_64") || target.contains("i686") {
        build.flag_if_supported("-msse2");
    }
    // Silence the informational #warning lines and modern-gcc strictness.
    build
        .flag_if_supported("-Wno-cpp")
        .flag_if_supported("-fcommon")
        .warnings(false);

    build.compile("power2b");

    println!("cargo:rerun-if-changed=csrc/crypto/yespower/yespower.c");
    println!("cargo:rerun-if-changed=csrc/crypto/blake2b.c");
    println!("cargo:rerun-if-changed=csrc/crypto/yespower/yespower.h");
}
