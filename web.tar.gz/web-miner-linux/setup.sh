#!/usr/bin/env bash
# Deploy + launch the power2b web miner on a Linux machine.
# Usage: bash setup.sh   (run as normal user; sudo is only used to install chromium if missing)
set -euo pipefail
cd "$(dirname "$0")"

PORT=${MINER_WEB_PORT:-8765}
CDP_PORT=${MINER_CDP_PORT:-9222}
WORKERS=${MINER_WORKERS:-7}
PROFILE="$HOME/.chrome-miner-profile"

# --- find a chrome/chromium binary ---
CHROME=""
for c in google-chrome google-chrome-stable chromium chromium-browser chrome; do
  if command -v "$c" >/dev/null 2>&1; then CHROME="$c"; break; fi
done
if [ -z "$CHROME" ]; then
  echo "No chrome/chromium found. Installing chromium..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update && sudo apt-get install -y chromium-browser
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y chromium
  elif command -v yum >/dev/null 2>&1; then
    sudo yum install -y chromium
  else
    echo "ERROR: no package manager matched. Install chromium manually." >&2
    exit 1
  fi
  for c in chromium-browser chromium; do
    if command -v "$c" >/dev/null 2>&1; then CHROME="$c"; break; fi
  done
fi
echo "Using browser: $CHROME"

# --- start the web server (if not already running) ---
if curl -s -o /dev/null "http://127.0.0.1:$PORT/"; then
  echo "Web server already running on :$PORT"
else
  nohup python3 web/server.py > server.log 2>&1 &
  echo $! > server.pid
  echo "Web server started (pid $(cat server.pid)) on http://127.0.0.1:$PORT/"
  for i in $(seq 1 20); do
    curl -s -o /dev/null "http://127.0.0.1:$PORT/" && break
    sleep 0.5
  done
fi

# --- start headless chrome mining the page ---
if curl -s -o /dev/null "http://127.0.0.1:$CDP_PORT/json"; then
  echo "Headless chrome already running (CDP :$CDP_PORT)"
else
  nohup "$CHROME" --headless=new --disable-gpu --no-sandbox \
    --remote-allow-origins=* --remote-debugging-port=$CDP_PORT \
    --user-data-dir="$PROFILE" --window-size=1280,900 \
    "http://127.0.0.1:$PORT/" > chrome.log 2>&1 &
  echo $! > chrome.pid
  echo "Headless chrome started (pid $(cat chrome.pid)), mining now."
  echo "  web UI:  http://127.0.0.1:$PORT/   (open in any browser to watch)"
  echo "  CDP:     http://127.0.0.1:$CDP_PORT/json"
fi
