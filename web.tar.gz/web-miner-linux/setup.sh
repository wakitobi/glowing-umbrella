#!/usr/bin/env bash
# Deploy + launch the power2b web miner on a Linux machine (containers/VPS friendly).
# Usage: bash setup.sh   (normal user or root; sudo auto-detected)
set -uo pipefail
cd "$(dirname "$0")"

PORT=${MINER_WEB_PORT:-8765}
CDP_PORT=${MINER_CDP_PORT:-9222}
PROFILE="$HOME/.chrome-miner-profile"

SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

echo "== checking python3 =="
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install it first, e.g.:  sudo apt install -y python3" >&2
  exit 1
fi
echo "python3: $(python3 --version 2>&1)"

# --- find a REAL chrome/chromium binary (reject Ubuntu snap stubs) ---
# Snap stubs are shell scripts; real chrome/chromium are ELF executables.
find_chrome() {
  for c in google-chrome google-chrome-stable chromium chromium-browser chrome; do
    if command -v "$c" >/dev/null 2>&1; then
      local path
      path="$(command -v "$c")"
      if [ -f "$path" ] && head -c 4 "$path" 2>/dev/null | grep -q ELF; then
        CHROME="$c"
        echo "browser: $CHROME ($("$CHROME" --version 2>&1 | head -1))"
        return 0
      fi
      echo "note: $c is a wrapper script (snap stub?), ignoring"
    fi
  done
  return 1
}

CHROME=""
if ! find_chrome; then
  echo "== no real chrome/chromium found; installing google-chrome-stable =="
  if command -v wget >/dev/null 2>&1; then
    wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O /tmp/gchrome.deb
  elif command -v curl >/dev/null 2>&1; then
    curl -sL https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -o /tmp/gchrome.deb
  else
    echo "ERROR: neither wget nor curl available." >&2
    exit 1
  fi
  $SUDO apt-get update >/dev/null 2>&1 || true
  if $SUDO apt-get install -y /tmp/gchrome.deb >/tmp/gchrome-install.log 2>&1; then
    rm -f /tmp/gchrome.deb
  else
    echo "google-chrome deb install failed, trying apt chromium..."
    tail -5 /tmp/gchrome-install.log
    $SUDO apt-get install -y chromium >/dev/null 2>&1 || true
    rm -f /tmp/gchrome.deb
  fi
  if ! find_chrome; then
    echo "== trying playwright chromium (container-friendly) =="
    if command -v npx >/dev/null 2>&1; then
      npx --yes playwright@latest install chromium --with-deps >/tmp/playwright-install.log 2>&1 || true
      PW_CHROME="$(ls "$HOME"/.cache/ms-playwright/chromium-*/chrome-linux/chrome 2>/dev/null | head -1)"
      if [ -n "$PW_CHROME" ] && [ -x "$PW_CHROME" ]; then
        CHROME="$PW_CHROME"
        echo "browser: playwright chromium ($("$CHROME" --version 2>&1))"
      fi
    fi
  fi
fi

if [ -z "$CHROME" ]; then
  echo "ERROR: could not install a browser. Install chromium/google-chrome manually." >&2
  exit 1
fi

# --- start the web server ---
if curl -s -o /dev/null "http://127.0.0.1:$PORT/"; then
  echo "web server already running on :$PORT"
else
  nohup python3 web/server.py > server.log 2>&1 &
  echo $! > server.pid
  ok=""
  for i in $(seq 1 20); do
    if curl -s -o /dev/null "http://127.0.0.1:$PORT/"; then ok=1; break; fi
    sleep 0.5
  done
  if [ -z "$ok" ]; then
    echo "ERROR: web server did not come up on :$PORT. server.log:" >&2
    cat server.log >&2
    exit 1
  fi
  echo "web server started (pid $(cat server.pid)): http://127.0.0.1:$PORT/"
fi

echo "config: $(curl -s http://127.0.0.1:$PORT/config.json | head -c 200)"

# --- start headless chrome ---
if curl -s -o /dev/null "http://127.0.0.1:$CDP_PORT/json"; then
  echo "headless chrome already running (CDP :$CDP_PORT)"
  exit 0
fi

FLAGS="--disable-gpu --no-sandbox --disable-dev-shm-usage --no-first-run --disable-extensions --disable-background-networking --mute-audio --remote-allow-origins=* --remote-debugging-port=$CDP_PORT --user-data-dir=$PROFILE --window-size=1280,900"

start_chrome() {
  nohup "$CHROME" "$1" $FLAGS "http://127.0.0.1:$PORT/" > chrome.log 2>&1 &
  echo $! > chrome.pid
  ok=""
  for i in $(seq 1 24); do
    if curl -s -o /dev/null "http://127.0.0.1:$CDP_PORT/json"; then ok=1; break; fi
    if ! kill -0 "$(cat chrome.pid)" 2>/dev/null; then break; fi
    sleep 0.5
  done
  [ -n "$ok" ]
}

if start_chrome "--headless=new"; then
  echo "headless chrome started (pid $(cat chrome.pid)), mining now."
elif start_chrome "--headless"; then
  echo "headless chrome started with legacy --headless (pid $(cat chrome.pid)), mining now."
else
  echo "ERROR: headless chrome failed to start. chrome.log:" >&2
  cat chrome.log >&2
  exit 1
fi

echo
echo "  web UI: http://127.0.0.1:$PORT/   (open in any browser to watch stats)"
echo "  CDP:    http://127.0.0.1:$CDP_PORT/json"
echo "  log:    tail -f chrome.log ; tail -f server.log"