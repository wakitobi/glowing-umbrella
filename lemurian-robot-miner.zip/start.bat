@echo off
REM Start the WebSocket bridge in background
echo Starting WebSocket bridge...
start /B python ws_bridge.py
timeout /t 2 >nul

REM Read config from .env
for /f "tokens=1,2 delims==" %%a in (.env) do (
    if "%%a"=="username" set WALLET=%%b
    if "%%a"=="threads" set THREADS=%%b
)

REM Start mining
echo Starting lemurian-robot miner...
cpuminer.exe -a power2b -o stratum+tcp://127.0.0.1:3334 -u %WALLET% -p x -t %THREADS%
