"""
pearlhash/cuda_miner.py — CUDA-accelerated PearlHash tile scanner.

Uses a CuPy RawKernel that:
  1. Takes the pre-computed jackpot tensor (R, C, 16) already on GPU
  2. Runs blake3 on all R*C tiles in parallel (one CUDA thread per tile)
  3. Checks each hash against the target
  4. Returns the first winning (ri, ci) or (-1, -1)

Blake3 is reimplemented in CUDA C (the 4-round compression function,
single-chunk path only — our message is always 64 bytes = exactly 1 chunk).

This eliminates the Python-side tile scan loop entirely.
"""

from __future__ import annotations

import struct
import numpy as np

# ---------------------------------------------------------------------------
# BLAKE3 CUDA implementation (single chunk, 64-byte message, keyed)
# ---------------------------------------------------------------------------

BLAKE3_CUDA_SRC = r"""
// No system headers — NVRTC doesn't have them. Use builtin CUDA types.
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned char      uint8_t;

// Blake3 constants
#define CHUNK_START   1u
#define CHUNK_END     2u
#define ROOT          8u
#define KEYED_HASH    16u

__device__ __forceinline__ uint32_t rotr32(uint32_t x, int n) {
    return (x >> n) | (x << (32 - n));
}

__device__ void g(uint32_t* state, int a, int b, int c, int d,
                  uint32_t mx, uint32_t my) {
    state[a] += state[b] + mx;
    state[d]  = rotr32(state[d] ^ state[a], 16);
    state[c] += state[d];
    state[b]  = rotr32(state[b] ^ state[c], 12);
    state[a] += state[b] + my;
    state[d]  = rotr32(state[d] ^ state[a], 8);
    state[c] += state[d];
    state[b]  = rotr32(state[b] ^ state[c], 7);
}

__device__ void round_fn(uint32_t* state, const uint32_t* msg, int round) {
    // permutation schedule (same as reference)
    const uint8_t SIGMA[7][16] = {
        {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
        {2,6,3,10,7,0,4,13,1,11,12,5,9,14,15,8},
        {3,4,10,12,13,2,7,14,6,5,9,0,11,15,8,1},
        {10,7,12,9,14,3,13,15,4,0,11,2,5,8,1,6},
        {12,13,9,11,15,10,14,8,7,2,5,3,0,1,6,4},
        {14,15,11,5,8,12,6,1,13,3,0,10,2,4,9,7},
        {15,8,5,4,1,14,10,3,6,12,2,7,13,11,9,0},
    };
    const uint8_t* s = SIGMA[round % 7];
    g(state, 0, 4, 8,  12, msg[s[0]],  msg[s[1]]);
    g(state, 1, 5, 9,  13, msg[s[2]],  msg[s[3]]);
    g(state, 2, 6, 10, 14, msg[s[4]],  msg[s[5]]);
    g(state, 3, 7, 11, 15, msg[s[6]],  msg[s[7]]);
    g(state, 0, 5, 10, 15, msg[s[8]],  msg[s[9]]);
    g(state, 1, 6, 11, 12, msg[s[10]], msg[s[11]]);
    g(state, 2, 7, 8,  13, msg[s[12]], msg[s[13]]);
    g(state, 3, 4, 9,  14, msg[s[14]], msg[s[15]]);
}

// Compute blake3(msg64, key=key32) -> out32 (32 bytes / 8 uint32)
// Single chunk, keyed, flags = CHUNK_START | CHUNK_END | ROOT | KEYED_HASH
__device__ void blake3_keyed_64(
    const uint32_t* key,   // 8 x uint32
    const uint32_t* msg,   // 16 x uint32 (64 bytes LE)
    uint32_t* out          // 8 x uint32
) {
    static const uint32_t IV[8] = {
        0x6A09E667u, 0xBB67AE85u, 0x3C6EF372u, 0xA54FF53Au,
        0x510E527Fu, 0x9B05688Cu, 0x1F83D9ABu, 0x5BE0CD19u,
    };
    uint32_t flags = CHUNK_START | CHUNK_END | ROOT | KEYED_HASH;
    uint32_t state[16];
    // init: key words as chaining value, then IV, then counter/len/flags
    for (int i = 0; i < 8; i++) state[i]     = key[i];
    for (int i = 0; i < 4; i++) state[8 + i] = IV[i];
    state[12] = 0;      // counter lo
    state[13] = 0;      // counter hi
    state[14] = 64;     // block length
    state[15] = flags;

    for (int r = 0; r < 7; r++) round_fn(state, msg, r);

    // output: XOR first and second half
    for (int i = 0; i < 8; i++) out[i] = state[i] ^ state[8 + i];
}

// ---------------------------------------------------------------------------
// Main kernel: one thread per tile, checks blake3(jackpot[ri,ci], key=sigma)
// <= target (little-endian uint256 comparison).
//
// jackpot: (R * C * 16) uint32, row-major  [ri * C * 16 + ci * 16 + word]
// sigma:   8 x uint32 (32 bytes of a_seed, interpreted LE)
// target:  8 x uint32 (32 bytes, LE uint256)
// hit_ri, hit_ci: output (int32), initialised to -1 by caller
// ---------------------------------------------------------------------------
extern "C" __global__ void scan_tiles(
    const uint32_t* __restrict__ jackpot,   // (R, C, 16) uint32
    const uint32_t* __restrict__ sigma,     // 8 uint32  (blake3 key)
    const uint32_t* __restrict__ target,    // 8 uint32  (LE uint256)
    int R, int C,
    int* __restrict__ hit_encoded           // output: ri*C+ci of first hit, or INT_MAX
) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= R * C) return;

    const uint32_t* msg = jackpot + tid * 16;  // 16 uint32 = 64 bytes

    uint32_t hash_out[8];
    blake3_keyed_64(sigma, msg, hash_out);

    // Little-endian uint256 compare: hash <= target
    // Compare word by word from most-significant (index 7) down
    bool le = true;
    for (int i = 7; i >= 0; i--) {
        if (hash_out[i] < target[i]) { le = true;  break; }
        if (hash_out[i] > target[i]) { le = false; break; }
    }
    if (le) {
        atomicMin(hit_encoded, tid);
    }
}
"""

# ---------------------------------------------------------------------------
# Python wrapper
# ---------------------------------------------------------------------------

_cupy_available = None
_kernel = None


def _ensure_kernel():
    global _cupy_available, _kernel
    if _cupy_available is not None:
        return _cupy_available
    try:
        import cupy as cp
        _kernel = cp.RawKernel(BLAKE3_CUDA_SRC, "scan_tiles",
                               options=("--std=c++14",))
        _cupy_available = True
        print("[cuda_miner] CUDA blake3 kernel compiled OK — GPU tile scan active")
    except Exception as e:
        _cupy_available = False
        print(f"[cuda_miner] CuPy kernel compile failed ({e.__class__.__name__}: {e}); using CPU fallback")
    return _cupy_available


def scan_tiles_gpu(jackpot_np: np.ndarray, a_seed: bytes, target: int):
    """
    Scan all tiles for a hash hit entirely on the GPU.

    jackpot_np: (R, C, 16) uint32 numpy array
    a_seed:     32-byte blake3 key
    target:     int (little-endian uint256)

    Returns (ri, ci) of the first winning tile, or None if no hit.
    Returns False if CuPy unavailable (caller uses CPU fallback).
    """
    if not _ensure_kernel():
        return False  # signal: use CPU fallback

    import cupy as cp

    R, C, _ = jackpot_np.shape
    n_tiles = R * C

    # Upload jackpot to GPU (flattened)
    jackpot_gpu = cp.asarray(jackpot_np.reshape(-1), dtype=cp.uint32)

    # sigma: 32 bytes of a_seed as 8 x uint32 LE
    sigma_np = np.frombuffer(a_seed, dtype=np.uint32)  # 8 words
    sigma_gpu = cp.asarray(sigma_np, dtype=cp.uint32)

    # target: 256-bit LE as 8 x uint32
    target_bytes = target.to_bytes(32, "little")
    target_np = np.frombuffer(target_bytes, dtype=np.uint32)
    target_gpu = cp.asarray(target_np, dtype=cp.uint32)

    # Output: single int, initialised to INT_MAX (no hit)
    INT_MAX = np.int32(2**31 - 1)
    hit_encoded = cp.full((1,), INT_MAX, dtype=cp.int32)

    threads = 256
    blocks = (n_tiles + threads - 1) // threads

    _kernel((blocks,), (threads,), (
        jackpot_gpu, sigma_gpu, target_gpu,
        np.int32(R), np.int32(C),
        hit_encoded,
    ))
    cp.cuda.stream.get_current_stream().synchronize()

    encoded = int(hit_encoded[0])
    if encoded == int(INT_MAX):
        return None  # no hit
    ri = encoded // C
    ci = encoded % C
    return ri, ci
