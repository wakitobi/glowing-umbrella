@echo off
REM start-miner.bat — run the PHP power2b miner on Windows (double-click or from cmd).
setlocal
set HERE=%~dp0
set PHP=php
set INI=%HERE%php.ini
set THREADS=%1
if "%THREADS%"=="" set THREADS=4
"%PHP%" -c "%INI%" -d output_buffering=0 "%HERE%run.php" %THREADS%
endlocal
