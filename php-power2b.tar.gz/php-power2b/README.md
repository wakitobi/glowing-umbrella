# php-power2b — pure-PHP MBC (power2b) CPU miner

A working CPU miner for MicroBitcoin (power2b = yespower N=2048 r=32, MBC
personalization) written in PHP. The Stratum client, header/merkle/target math,
and mining loop are all PHP. The one thing PHP can't do fast enough on its own —
the yespower hash — is done through FFI into a tiny C shared library
(`power2b.dll`) compiled from the coin's own hashing source. This is the correct
design: reusing the consensus C code means zero risk of a hashing mismatch, and
the test vector proves it byte-for-byte.

## Verified
- `test_vector.php`  — power2b hash matches the rplant ground-truth vector (PASS)
- `verify_build.php` — header build + merkle root reproduce the exact 80-byte
  consensus header, and the hash matches (HEADER PASS / HASH PASS)
- Live: connects to the pool, subscribes/authorizes, mines, and **shares are
  ACCEPTED** by na.rplant.xyz (via the Koyeb WebSocket proxy).
- Speed: ~115-150 H/s per PHP process (single core). PHP+FFI is ~2x slower than
  native cpuminer (~257 H/s/core) because of per-call FFI marshalling overhead,
  but it produces real, accepted shares. Run one process per core with `run.php`.

## Files
- `power2b.dll`     — yespower(power2b) compiled from `crypto/` (exposes `yespower_tls`)
- `power2b.php`     — FFI wrapper: `Power2b::hash($header80)` / `hashHex($hex)`
- `wsclient.php`    — minimal RFC6455 WebSocket client over a PHP TLS stream
- `miner.php`       — one connection + one mining thread (the actual miner)
- `run.php`         — launches N `miner.php` processes (one per core) + auto-restart
- `start-miner.bat` — Windows launcher
- `php.ini`         — enables ffi, sockets, openssl, gmp; sets extension_dir
- `.env`            — pool config (proxy, username, password, threads) — copied from ../mbc
- `test_vector.php`, `verify_build.php`, `bench.php` — checks/benchmark
- `crypto/`         — C source for the hasher (yespower.c, blake2b.c, headers)

## Requirements
- PHP 8.x with FFI, sockets, openssl, gmp extensions (all shipped as DLLs with
  the winget PHP build; `php.ini` here enables them).
- The prebuilt `power2b.dll`. To rebuild (needs MinGW gcc, x86_64):
  ```
  gcc -O3 -msse2 -fcommon -shared -o power2b.dll -I. -Icrypto \
      crypto/yespower/yespower.c crypto/blake2b.c -Wl,--export-all-symbols
  ```

## Run
```
# verify first
php -c php.ini test_vector.php
php -c php.ini verify_build.php

# single core
php -c php.ini -d output_buffering=0 miner.php 0

# all cores (reads threads= from .env)
php -c php.ini -d output_buffering=0 run.php 7
# or on Windows: double-click start-miner.bat  (or: start-miner.bat 7)
```

## Run on another Linux machine
The C hasher is portable; only the compiled library differs (`power2b.dll` on
Windows, `power2b.so` on Linux). `power2b.php` auto-picks the right one, and
`setup.sh` builds the `.so` from the bundled `crypto/` source. So you ship the
source tree, not the binary.

```
# 1. copy the folder to the box (scp / git / rsync). The Windows .dll is not needed.
scp php-power2b.tar.gz user@box:~/          # tarball excludes the .dll + logs
ssh user@box 'tar xzf php-power2b.tar.gz && cd php-power2b && bash setup.sh'
```

`setup.sh` will:
1. install `php-cli`, `php-ffi`, `php-gmp` (+ `php-sockets`/`php-openssl` where
   packaged separately) and `gcc` across apt / dnf / yum / pacman / apk / zypper;
2. compile `power2b.so` from `crypto/` (`-O3 -fPIC -shared`, `-msse2` on x86);
3. write a Linux `php.ini` pointing at the distro's `extension_dir`;
4. verify the hash + header against the rplant ground-truth vector (aborts if it
   fails — never mines with a broken hasher);
5. start `run.php` on all cores (or the `.env` `threads` count).

Sub-commands:
```
bash setup.sh --build        # install + build + verify only, don't mine
bash setup.sh --run 8        # skip build, run 8 processes
```

Auto-start on boot + restart on crash (systemd):
```
sudo bash install-service.sh 8      # installs php-power2b.service, starts it
journalctl -u php-power2b -f        # watch it mine
sudo bash install-service.sh --uninstall
```
The service runs as your user, `Restart=always`, `Nice=10`, and `chmod 600`s
`.env` (it holds the pool worker credentials).

Notes:
- On ARM boxes (Raspberry Pi, ARM VPS) `setup.sh` drops `-msse2` and lets gcc
  pick the arch — the C is portable, it just compiles slower per hash.
- Most distros compile FFI/GMP/sockets/openssl in or auto-load them via conf.d,
  so the generated `php.ini` only sets `extension_dir` + `ffi.enable=1` to avoid
  "module already loaded" warnings. If `php -m` shows FFI/gmp missing after
  install, add `extension=ffi` / `extension=gmp` to `php.ini`.

## Config (.env)
```
proxy=wss://<koyeb-host>/<base64 of "na.rplant.xyz:7022">
username=<MBC_address>.<worker>
password=x
threads=7
```
The `proxy` is the Koyeb WebSocket relay; the base64 path segment decodes to the
real Stratum host:port. Stratum messages are newline-terminated JSON text frames
(the client appends the `\n` — the pool silently drops frames without it).

## How it works
1. `wsclient.php` opens `wss://` (TLS stream + RFC6455 handshake, client-masked
   frames).
2. `mining.subscribe` → `[subs, extranonce1, en2size]`; `mining.authorize` → true.
3. `mining.set_difficulty` → target = `0x0000ffff...ff * 2^32 / (diff*2^32)`
   (256-bit division via GMP), a 32-byte big-endian target.
4. `mining.notify` → build header:
   `LE32(version) + swap4(prevhash) + merkleRoot + LE32(ntime) + LE32(nbits) + LE32(nonce)`
   where `merkleRoot = sha256d(coinb1+en1+en2+coinb2)` folded over the branches.
5. Sweep nonces, `Power2b::hash(header)`, compare `reverse(hash) < target`.
6. On a hit: `mining.submit [user, job_id, en2, ntime, nonce]`.

Each `run.php` child uses a random extranonce2, so parallel processes search
disjoint space without coordination.

## Notes
- PHP CLI is single-process/single-core, so N cores = N processes (`run.php`),
  not threads. That's why the miner is structured as one-connection-per-process.
- `.env` holds the pool worker credentials — it mines to the address in it. Fine
  for your own machines; don't hand the folder to strangers.
