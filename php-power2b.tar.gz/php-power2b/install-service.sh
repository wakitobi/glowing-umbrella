#!/usr/bin/env bash
# install-service.sh — install the PHP power2b miner as a systemd service
# (auto-start on boot, restart on crash). Run from the miner dir on the target box.
#   sudo bash install-service.sh [threads]
#   sudo bash install-service.sh --uninstall
set -euo pipefail
cd "$(dirname "$0")"
DIR="$(pwd)"
SVC="php-power2b"
UNIT="/etc/systemd/system/${SVC}.service"

[ "$(id -u)" -eq 0 ] || { echo "run as root (sudo)"; exit 1; }

if [ "${1:-}" = "--uninstall" ]; then
  systemctl stop "$SVC" 2>/dev/null || true
  systemctl disable "$SVC" 2>/dev/null || true
  rm -f "$UNIT"; systemctl daemon-reload
  echo "uninstalled $SVC"; exit 0
fi

THREADS="${1:-$(php -r '$e=@parse_ini_file(".env")?:[];echo (int)($e["threads"]??4);')}"
PHP="$(command -v php)"
RUNUSER="${SUDO_USER:-root}"

# build if the .so isn't there yet
[ -f power2b.so ] || bash setup.sh --build

# lock down .env (holds pool creds)
[ -f .env ] && chmod 600 .env || true

cat > "$UNIT" <<UNITEOF
[Unit]
Description=PHP power2b (MBC) CPU miner
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${RUNUSER}
WorkingDirectory=${DIR}
ExecStart=${PHP} -c ${DIR}/php.ini -d output_buffering=0 ${DIR}/run.php ${THREADS}
Restart=always
RestartSec=5
Nice=10

[Install]
WantedBy=multi-user.target
UNITEOF

systemctl daemon-reload
systemctl enable "$SVC"
systemctl restart "$SVC"
echo "installed + started $SVC ($THREADS threads)"
echo "logs: journalctl -u $SVC -f"
