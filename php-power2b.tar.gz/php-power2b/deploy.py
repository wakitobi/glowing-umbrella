import paramiko, sys, time
from scp import SCPClient

HOST, PORT, USER, PWD = "172.235.53.54", 22, "root", "ThC0faazTq!PCY!F"
LOCAL_TAR = r"C:\Users\User\projects\php-power2b.tar.gz"

def run(c, cmd, timeout=600, quiet=False):
    stdin, out, err = c.exec_command(cmd, get_pty=True, timeout=timeout)
    buf = []
    for line in iter(out.readline, ""):
        buf.append(line)
        if not quiet:
            sys.stdout.write(line); sys.stdout.flush()
    rc = out.channel.recv_exit_status()
    return rc, "".join(buf)

c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
print(f"[deploy] connecting {USER}@{HOST}:{PORT}")
c.connect(HOST, PORT, USER, PWD, timeout=30)

print("[deploy] OS:")
run(c, "cat /etc/os-release | grep -E '^(PRETTY_NAME|VERSION)=' ; nproc")

print("[deploy] uploading bundle")
with SCPClient(c.get_transport()) as scp:
    scp.put(LOCAL_TAR, "/root/php-power2b.tar.gz")

print("[deploy] extract + setup --build")
rc, _ = run(c, "cd /root && rm -rf php-power2b && tar xzf php-power2b.tar.gz && "
               "cd php-power2b && bash setup.sh --build 2>&1")
print(f"[deploy] setup --build rc={rc}")
c.close()
sys.exit(0 if rc == 0 else 1)
