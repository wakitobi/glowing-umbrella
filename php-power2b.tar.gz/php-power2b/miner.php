<?php
// miner.php — single-connection, single-thread power2b (MBC) CPU miner.
// Connects to the Koyeb Stratum-over-WebSocket proxy, subscribes/authorizes,
// then mines: hash a batch of nonces, poll the socket for new jobs, submit shares.
//
// For multiple threads, launch N copies (run.php). Each process opens its own
// pool connection and uses a random extranonce2, so their search spaces don't
// overlap. PHP CLI is one process = one core, so N processes = N cores.
//
// Usage: php -c php.ini miner.php [worker-label]

require __DIR__ . '/power2b.php';
require __DIR__ . '/wsclient.php';

$env   = parse_ini_file(__DIR__ . '/.env') ?: [];
$proxy = $env['proxy']    ?? '';
$user  = $env['username'] ?? '';
$pass  = $env['password'] ?? 'x';
$label = $argv[1] ?? '0';
if ($proxy === '' || $user === '') { fwrite(STDERR, "missing proxy/username in .env\n"); exit(1); }

function logln(string $s): void {
    global $label;
    echo '[' . date('H:i:s') . "][w$label] $s\n";
    @ob_flush(); @flush();
}

// ---- byte-order + target helpers ----------------------------------------
function swap4(string $bin): string {
    $o = ''; for ($i = 0; $i < strlen($bin); $i += 4) $o .= strrev(substr($bin, $i, 4)); return $o;
}
function d_sha256(string $b): string { return hash('sha256', hash('sha256', $b, true), true); }

function targetFromDiff(float $diff): string {
    $baseHex = '0000ffff' . str_repeat('ff', 28);
    $base = gmp_init($baseHex, 16);
    $scaleStr = bcmul(sprintf('%.8f', $diff), '4294967296', 0);
    $scale = gmp_init($scaleStr === '' ? '1' : $scaleStr);
    if (gmp_cmp($scale, 0) <= 0) $scale = gmp_init(1);
    $t = gmp_div_q(gmp_mul($base, gmp_init('4294967296')), $scale);
    $hex = str_pad(gmp_strval($t, 16), 64, '0', STR_PAD_LEFT);
    return hex2bin(substr($hex, -64));
}
function meetsTarget(string $hash32, string $targetBE): bool {
    return strcmp(strrev($hash32), $targetBE) < 0;
}

// ---- connect + handshake -------------------------------------------------
$p = new Power2b();
logln("connecting to pool");
$ws = new WsClient($proxy, 30.0);
$reqId = 1;
$ws->sendText(json_encode(['id' => $reqId++, 'method' => 'mining.subscribe', 'params' => ['php-power2b/1.0']]));
usleep(200000);
$ws->sendText(json_encode(['id' => $reqId++, 'method' => 'mining.authorize', 'params' => [$user, $pass]]));
$ws->setTimeout(1);

$en1 = null; $en2size = 4; $diff = 0.2; $target = null;
$job = null; $merkleRoot = null; $en2hex = null; $nonce = 0;
$authorized = false;
$accepted = 0; $rejected = 0; $submitPending = [];
$hashCount = 0; $lastRate = microtime(true);

function drainSocket(): void {
    global $ws, $en1, $en2size, $diff, $target, $job, $merkleRoot, $en2hex, $nonce,
           $authorized, $accepted, $rejected, $submitPending, $p, $reqId, $user;

    $msg = $ws->receive();
    if ($msg === null) return;
    foreach (explode("\n", trim($msg)) as $line) {
        if ($line === '') continue;
        $j = json_decode($line, true);
        if (!is_array($j)) continue;

        if (isset($j['method'])) {
            switch ($j['method']) {
                case 'mining.set_difficulty':
                    $diff = (float)$j['params'][0];
                    $target = targetFromDiff($diff);
                    logln("difficulty => $diff");
                    break;
                case 'mining.set_extranonce':
                    $en1 = $j['params'][0];
                    $en2size = (int)($j['params'][1] ?? $en2size);
                    logln("set_extranonce => en1=$en1");
                    break;
                case 'mining.notify':
                    $pp = $j['params'];
                    $job = [
                        'job_id' => $pp[0], 'prevhash' => $pp[1], 'coinb1' => $pp[2],
                        'coinb2' => $pp[3], 'merkle_branch' => $pp[4], 'version' => $pp[5],
                        'nbits' => $pp[6], 'ntime' => $pp[7], 'clean' => $pp[8] ?? false,
                    ];
                    startJob();
                    break;
            }
        } elseif (array_key_exists('result', $j)) {
            $id = $j['id'] ?? null;
            if ($id !== null && isset($submitPending[$id])) {
                if ($j['result'] === true) { $accepted++; logln("share ACCEPTED (a=$accepted r=$rejected)"); }
                else { $rejected++; logln("share REJECTED " . json_encode($j['error']) . " (a=$accepted r=$rejected)"); }
                unset($submitPending[$id]);
            } elseif (is_array($j['result']) && $en1 === null) {
                $res = $j['result'];
                $en1 = $res[1] ?? null;
                $en2size = (int)($res[2] ?? 4);
                logln("subscribed: en1=$en1 en2size=$en2size");
                if ($job) startJob();
            } elseif ($j['result'] === true && !$authorized) {
                $authorized = true;
                logln("authorized OK");
            }
        }
    }
}

/** (Re)compute merkle root + reset nonce sweep for the current job. */
function startJob(): void {
    global $job, $en1, $en2size, $merkleRoot, $en2hex, $nonce, $target, $diff;
    if ($job === null || $en1 === null) return;
    if ($target === null) $target = targetFromDiff($diff);
    // random extranonce2 so parallel processes don't collide
    $en2hex = bin2hex(random_bytes($en2size));
    $coinbaseHex = $job['coinb1'] . $en1 . $en2hex . $job['coinb2'];
    $m = d_sha256(hex2bin($coinbaseHex));
    foreach ($job['merkle_branch'] as $b) $m = d_sha256($m . hex2bin($b));
    $merkleRoot = $m;
    $nonce = 0;
    logln("job {$job['job_id']} clean=" . ($job['clean'] ? 1 : 0) . " en2=$en2hex");
}

// prebuild the static header prefix per job to avoid rebuilding it each hash
function mineBatch(int $batch): void {
    global $job, $merkleRoot, $nonce, $target, $p, $ws, $reqId, $user,
           $submitPending, $hashCount;
    if ($job === null || $merkleRoot === null || $target === null) { usleep(10000); return; }

    $version = pack('V', hexdec($job['version']));
    $prev    = swap4(hex2bin($job['prevhash']));
    $ntime   = pack('V', hexdec($job['ntime']));
    $nbits   = pack('V', hexdec($job['nbits']));
    $prefix  = $version . $prev . $merkleRoot . $ntime . $nbits; // 76 bytes

    for ($k = 0; $k < $batch; $k++) {
        $header = $prefix . pack('V', $nonce);
        $h = $p->hash($header);
        if (meetsTarget($h, $target)) {
            $sid = $reqId++;
            $submitPending[$sid] = true;
            $nonceHex = str_pad(dechex($nonce), 8, '0', STR_PAD_LEFT);
            $ws->sendText(json_encode([
                'id' => $sid, 'method' => 'mining.submit',
                'params' => [$user, $job['job_id'], $GLOBALS['en2hex'], $job['ntime'], $nonceHex],
            ]));
            logln("FOUND share job={$job['job_id']} nonce=$nonceHex, submitting");
        }
        $nonce = ($nonce + 1) & 0xffffffff;
        $hashCount++;
        if ($nonce === 0) break; // exhausted (won't happen in practice before new job)
    }
}

logln("mining loop started");
while (true) {
    drainSocket();
    mineBatch(256);

    $now = microtime(true);
    if ($now - $lastRate >= 15.0) {
        $rate = $hashCount / ($now - $lastRate);
        logln(sprintf("~%.1f H/s | a=%d r=%d", $rate, $accepted, $rejected));
        $hashCount = 0; $lastRate = $now;
    }
}
