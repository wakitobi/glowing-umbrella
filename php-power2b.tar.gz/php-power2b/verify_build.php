<?php
// verify_build.php — prove buildHeader + merkle reproduce the rplant ground-truth header,
// then prove the hash matches, then sanity-check targetFromDiff.
require __DIR__ . '/power2b.php';

function swap4(string $bin): string { $o=''; for($i=0;$i<strlen($bin);$i+=4)$o.=strrev(substr($bin,$i,4)); return $o; }
function d_sha256(string $b): string { return hash('sha256', hash('sha256',$b,true), true); }

$job = [
  'prevhash' => 'da0dadb0eda4381df442bde08d23d54d7d371d5ce7af3ee716bd2a7e017eacb8',
  'coinb1'   => '01000000010000000000000000000000000000000000000000000000000000000000000000ffffffff2a03700a08062f503253482f04953f1a5308',
  'coinb2'   => '102f776166666c65706f6f6c2e636f6d2f0000000001d07e582a010000001976a9145d8f33b0a7c94c878d572c40cbff22a49268467d88ac00000000',
  'merkle_branch' => [
    '50a4a386ab344d40d29a833b6e40ea27dab6e5a79a2f8648d3bc0d1aa65ecd3f',
    '7952ecc836fb104f41b2cb06608eeeaa6d1ca2fe4391708fb13bb10ccf8da179',
    '9400ec6453aac577fb6807f11219b4243a3e50ca6d1c727e6d05663211960c94',
    'c11a630fa9332ab51d886a47509b5cbace844316f4fc52b493359b305fd489ae',
    '85891e7c5773f234d647f1d5fca7fbcabb59b261322d16c0ae486ccf5143383d',
    'faa26bbc17f99659f64136bea29b3fc8d772b339c52707d5f2ccfe1195317f43',
  ],
  'version' => '2', 'nbits' => '1b10b60e', 'ntime' => '531a3f95',
];
$en1 = '60021014'; $en2hex = '00000000'; $nonce = 1791689120;

$coinbaseHex = $job['coinb1'].$en1.$en2hex.$job['coinb2'];
$merkle = d_sha256(hex2bin($coinbaseHex));
foreach ($job['merkle_branch'] as $b) $merkle = d_sha256($merkle.hex2bin($b));

$version = pack('V', hexdec($job['version']));
$prev    = swap4(hex2bin($job['prevhash']));
$ntime   = pack('V', hexdec($job['ntime']));
$nbits   = pack('V', hexdec($job['nbits']));
$non     = pack('V', $nonce);
$header  = $version.$prev.$merkle.$ntime.$nbits.$non;

$expectedHeader = '02000000b0ad0dda1d38a4ede0bd42f44dd5238d5c1d377de73eafe77e2abd16b8ac7e0143c4345eb9ad9135836f5c31b697f62429c1be08d55906ff407852adfba680a5953f1a530eb6101ba001cb6a';
$expectedHash   = 'edc067dc5d32bf354297b77121dda0c3a98013ca5b6f825ffffee9c8c53208a9';

echo "built header : ".bin2hex($header)."\n";
echo "expect header: $expectedHeader\n";
$hdrOk = bin2hex($header) === $expectedHeader;
echo "HEADER ".($hdrOk?"PASS":"FAIL")."\n\n";

$p = new Power2b();
$got = bin2hex($p->hash($header));
echo "hash got  : $got\n";
echo "hash exp  : $expectedHash\n";
$hashOk = $got === $expectedHash;
echo "HASH ".($hashOk?"PASS":"FAIL")."\n\n";

// target sanity
function targetFromDiff(float $diff): string {
    $baseHex='0000ffff'.str_repeat('ff',28);
    $base=gmp_init($baseHex,16);
    $scale=gmp_init(bcmul(sprintf('%.8f',$diff),'4294967296',0));
    if(gmp_cmp($scale,0)<=0)$scale=gmp_init(1);
    $t=gmp_div_q(gmp_mul($base,gmp_init('4294967296')),$scale);
    $hex=str_pad(gmp_strval($t,16),64,'0',STR_PAD_LEFT);
    return hex2bin(substr($hex,-64));
}
echo "target@diff=1   : ".bin2hex(targetFromDiff(1.0))."\n";
echo "target@diff=0.2 : ".bin2hex(targetFromDiff(0.2))."\n";

exit(($hdrOk && $hashOk) ? 0 : 1);
