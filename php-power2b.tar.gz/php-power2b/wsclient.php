<?php
// wsclient.php — minimal RFC 6455 WebSocket client over a PHP TLS stream.
// Enough for Stratum-over-WebSocket: text frames, client masking, ping/pong.

final class WsClient
{
    /** @var resource */
    private $sock;
    private string $buf = '';

    public function __construct(string $url, float $timeout = 30.0)
    {
        $parts = parse_url($url);
        if ($parts === false || !isset($parts['scheme'], $parts['host'])) {
            throw new \RuntimeException("bad ws url: $url");
        }
        $secure = ($parts['scheme'] === 'wss');
        $host   = $parts['host'];
        $port   = $parts['port'] ?? ($secure ? 443 : 80);
        $path   = ($parts['path'] ?? '/') . (isset($parts['query']) ? '?' . $parts['query'] : '');

        $transport = $secure ? 'ssl' : 'tcp';
        $ctx = stream_context_create([
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true, 'peer_name' => $host],
        ]);
        $remote = "$transport://$host:$port";
        $errno = 0; $errstr = '';
        $sock = @stream_socket_client($remote, $errno, $errstr, $timeout,
            STREAM_CLIENT_CONNECT, $ctx);
        if (!$sock) {
            throw new \RuntimeException("connect failed to $remote: [$errno] $errstr");
        }
        stream_set_timeout($sock, (int)$timeout);
        $this->sock = $sock;

        // --- Handshake ---
        $key = base64_encode(random_bytes(16));
        $req = "GET $path HTTP/1.1\r\n"
             . "Host: $host\r\n"
             . "Upgrade: websocket\r\n"
             . "Connection: Upgrade\r\n"
             . "Sec-WebSocket-Key: $key\r\n"
             . "Sec-WebSocket-Version: 13\r\n"
             . "Origin: https://$host\r\n"
             . "\r\n";
        fwrite($this->sock, $req);

        // Read response headers up to \r\n\r\n
        $resp = '';
        while (!str_contains($resp, "\r\n\r\n")) {
            $chunk = fread($this->sock, 1);
            if ($chunk === '' || $chunk === false) {
                throw new \RuntimeException("handshake read failed; got: $resp");
            }
            $resp .= $chunk;
        }
        if (!preg_match('#^HTTP/1\.1 101#', $resp)) {
            throw new \RuntimeException("ws upgrade rejected:\n" . explode("\r\n", $resp)[0]);
        }
        $expect = base64_encode(sha1($key . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true));
        if (!preg_match('/Sec-WebSocket-Accept:\s*(.+)\r\n/i', $resp, $m) || trim($m[1]) !== $expect) {
            throw new \RuntimeException("ws accept mismatch");
        }
    }

    /** Send a text frame (masked, as required for clients). Appends the
     *  Stratum newline terminator so the pool parses the JSON line. */
    public function sendText(string $payload): void
    {
        if ($payload === '' || $payload[strlen($payload) - 1] !== "\n") {
            $payload .= "\n";
        }
        $this->sendFrame(0x1, $payload);
    }

    private function sendFrame(int $opcode, string $payload): void
    {
        $fin = 0x80;
        $b1  = $fin | $opcode;
        $len = strlen($payload);
        $frame = chr($b1);
        $maskBit = 0x80; // client frames MUST be masked
        if ($len < 126) {
            $frame .= chr($maskBit | $len);
        } elseif ($len < 65536) {
            $frame .= chr($maskBit | 126) . pack('n', $len);
        } else {
            $frame .= chr($maskBit | 127) . pack('J', $len);
        }
        $mask = random_bytes(4);
        $frame .= $mask;
        $masked = $payload ^ str_repeat($mask, intdiv($len, 4) + 1);
        $frame .= substr($masked, 0, $len);
        fwrite($this->sock, $frame);
    }

    /**
     * Read one application text message. Returns null on timeout (no data).
     * Handles fragmentation, ping/pong, close internally.
     */
    public function receive(): ?string
    {
        $message = '';
        $msgOpcode = null;
        while (true) {
            $hdr = $this->readN(2, true);
            if ($hdr === null) return null; // timeout, no frame started
            $b0 = ord($hdr[0]); $b1 = ord($hdr[1]);
            $fin = ($b0 & 0x80) !== 0;
            $opcode = $b0 & 0x0f;
            $masked = ($b1 & 0x80) !== 0;
            $len = $b1 & 0x7f;
            if ($len === 126) {
                $len = unpack('n', $this->readN(2))[1];
            } elseif ($len === 127) {
                $len = unpack('J', $this->readN(8))[1];
            }
            $maskKey = $masked ? $this->readN(4) : '';
            $payload = $len > 0 ? $this->readN($len) : '';
            if ($masked && $len > 0) {
                $payload ^= str_repeat($maskKey, intdiv($len, 4) + 1);
                $payload = substr($payload, 0, $len);
            }
            switch ($opcode) {
                case 0x0: // continuation
                    $message .= $payload; break;
                case 0x1: // text
                case 0x2: // binary
                    $msgOpcode = $opcode; $message .= $payload; break;
                case 0x8: // close
                    throw new \RuntimeException("ws closed by peer");
                case 0x9: // ping -> pong
                    $this->sendFrame(0xA, $payload); continue 2;
                case 0xA: // pong
                    continue 2;
            }
            if ($fin) return $message;
        }
    }

    /** Read exactly $n bytes. If $allowTimeout and nothing arrives, return null. */
    private function readN(int $n, bool $allowTimeout = false): ?string
    {
        while (strlen($this->buf) < $n) {
            $chunk = fread($this->sock, $n - strlen($this->buf));
            if ($chunk === '' || $chunk === false) {
                $meta = stream_get_meta_data($this->sock);
                if ($meta['timed_out']) {
                    if ($allowTimeout && $this->buf === '') return null;
                    // partial frame in progress: keep waiting
                    if ($this->buf === '' && !$allowTimeout) continue;
                    continue;
                }
                throw new \RuntimeException("ws read EOF");
            }
            $this->buf .= $chunk;
        }
        $out = substr($this->buf, 0, $n);
        $this->buf = substr($this->buf, $n);
        return $out;
    }

    public function setTimeout(int $seconds): void
    {
        stream_set_timeout($this->sock, $seconds);
    }

    public function close(): void
    {
        if (is_resource($this->sock)) {
            @fwrite($this->sock, chr(0x88) . chr(0x80) . random_bytes(4));
            @fclose($this->sock);
        }
    }
}
