<?php
// run.php — launch N miner processes (one per CPU core) and relay their output.
// Usage: php -c php.ini run.php [threads]   (defaults to .env `threads`, else 4)

$env = parse_ini_file(__DIR__ . '/.env') ?: [];
$threads = (int)($argv[1] ?? ($env['threads'] ?? 4));
if ($threads < 1) $threads = 1;

$php = PHP_BINARY;
$ini = php_ini_loaded_file() ?: '';
$miner = __DIR__ . '/miner.php';
$nulldev = (stripos(PHP_OS, 'WIN') === 0) ? 'NUL' : '/dev/null';

echo "starting $threads power2b miner process(es)\n";
$procs = [];
for ($i = 0; $i < $threads; $i++) {
    $cmd = escapeshellarg($php);
    if ($ini) $cmd .= ' -c ' . escapeshellarg($ini);
    $cmd .= ' -d output_buffering=0 ' . escapeshellarg($miner) . ' ' . $i;
    $p = proc_open($cmd, [0 => ['file', $nulldev, 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
    if (!is_resource($p)) { fwrite(STDERR, "failed to start miner $i\n"); continue; }
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);
    $procs[$i] = ['proc' => $p, 'out' => $pipes[1], 'err' => $pipes[2]];
}

// relay child stdout/stderr to our stdout until killed
while (true) {
    foreach ($procs as $i => $c) {
        foreach (['out', 'err'] as $ch) {
            $line = fgets($c[$ch]);
            while ($line !== false && $line !== '') {
                echo str_replace("\0", '', $line);
                $line = fgets($c[$ch]);
            }
        }
        $st = proc_get_status($c['proc']);
        if (!$st['running']) {
            echo "[run] miner $i exited (code {$st['exitcode']}), restarting\n";
            $cmd = escapeshellarg(PHP_BINARY);
            if ($ini) $cmd .= ' -c ' . escapeshellarg($ini);
            $cmd .= ' -d output_buffering=0 ' . escapeshellarg($miner) . ' ' . $i;
            $np = proc_open($cmd, [0 => ['file', $nulldev, 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $npipes);
            if (is_resource($np)) {
                stream_set_blocking($npipes[1], false);
                stream_set_blocking($npipes[2], false);
                $procs[$i] = ['proc' => $np, 'out' => $npipes[1], 'err' => $npipes[2]];
            }
        }
    }
    usleep(200000);
}
