<?php
// power2b.php — FFI wrapper around power2b.dll (yespower N=2048 r=32, MBC pers).
// Exposes Power2b::hash(string $header80) : string (32 raw bytes, hasher output order).

final class Power2b
{
    private \FFI $ffi;
    private \FFI\CData $params;   // yespower_params_t
    private string $pers = "Now I am become Death, the destroyer of worlds"; // 46 bytes

    public function __construct(?string $dllPath = null)
    {
        if ($dllPath === null) {
            // pick the platform-native shared library
            $lib = (stripos(PHP_OS, 'WIN') === 0) ? 'power2b.dll' : 'power2b.so';
            $dllPath = __DIR__ . DIRECTORY_SEPARATOR . $lib;
        }
        if (!is_file($dllPath)) {
            throw new \RuntimeException("power2b shared library not found at $dllPath");
        }
        // Minimal cdef mirroring yespower.h (only what we call).
        $this->ffi = \FFI::cdef(<<<CDEF
            typedef struct { uint32_t N, r; const uint8_t *pers; size_t perslen; } yespower_params_t;
            typedef struct { unsigned char uc[32]; } yespower_binary_t;
            int yespower_tls(const uint8_t *src, size_t srclen,
                             const yespower_params_t *params, yespower_binary_t *dst);
        CDEF, $dllPath);

        // Build a persistent params struct. Keep the pers buffer alive as a property.
        $this->params = $this->ffi->new('yespower_params_t');
        $this->params->N = 2048;
        $this->params->r = 32;
        $this->persBuf = $this->ffi->new('uint8_t[' . strlen($this->pers) . ']', false);
        \FFI::memcpy($this->persBuf, $this->pers, strlen($this->pers));
        $this->params->pers = $this->ffi->cast('uint8_t *', \FFI::addr($this->persBuf));
        $this->params->perslen = strlen($this->pers);
    }

    private \FFI\CData $persBuf;

    /** Hash an 80-byte header. Returns 32 raw bytes in hasher output order. */
    public function hash(string $header): string
    {
        if (strlen($header) !== 80) {
            throw new \InvalidArgumentException('header must be exactly 80 bytes, got ' . strlen($header));
        }
        $src = $this->ffi->new('uint8_t[80]', false);
        \FFI::memcpy($src, $header, 80);
        $out = $this->ffi->new('yespower_binary_t');
        $rc = $this->ffi->yespower_tls(
            $this->ffi->cast('uint8_t *', \FFI::addr($src)),
            80,
            \FFI::addr($this->params),
            \FFI::addr($out)
        );
        \FFI::free($src);
        if ($rc !== 0) {
            throw new \RuntimeException("yespower_tls failed rc=$rc");
        }
        return \FFI::string($this->ffi->cast('char *', \FFI::addr($out->uc)), 32);
    }

    /** Convenience: hash a hex header string, return hex digest. */
    public function hashHex(string $headerHex): string
    {
        return bin2hex($this->hash(hex2bin($headerHex)));
    }
}
