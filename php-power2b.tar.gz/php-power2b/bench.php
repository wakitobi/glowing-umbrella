<?php
require __DIR__ . '/power2b.php';
$p = new Power2b();
$h = hex2bin('02000000b0ad0dda1d38a4ede0bd42f44dd5238d5c1d377de73eafe77e2abd16b8ac7e0143c4345eb9ad9135836f5c31b697f62429c1be08d55906ff407852adfba680a5953f1a530eb6101ba001cb6a');
$N = (int)($argv[1] ?? 300);
$t0 = microtime(true);
for ($i = 0; $i < $N; $i++) { $p->hash($h); }
$dt = microtime(true) - $t0;
printf("%d hashes in %.3fs => %.1f H/s (single thread)\n", $N, $dt, $N/$dt);
