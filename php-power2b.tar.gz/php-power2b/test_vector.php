<?php
require __DIR__ . '/power2b.php';

// Ground-truth rplant test vector (from web-miner worker.js static test()).
$header   = '02000000b0ad0dda1d38a4ede0bd42f44dd5238d5c1d377de73eafe77e2abd16b8ac7e0143c4345eb9ad9135836f5c31b697f62429c1be08d55906ff407852adfba680a5953f1a530eb6101ba001cb6a';
$expected = 'edc067dc5d32bf354297b77121dda0c3a98013ca5b6f825ffffee9c8c53208a9';

$p = new Power2b();
$got = $p->hashHex($header);

echo "header   : $header\n";
echo "expected : $expected\n";
echo "got      : $got\n";
if ($got === $expected) {
    echo "VERDICT  : PASS — power2b FFI matches consensus\n";
    exit(0);
}
echo "VERDICT  : FAIL\n";
exit(1);
