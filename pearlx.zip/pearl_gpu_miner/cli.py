"""Pearl GPU Miner CLI."""
import argparse
import logging
import sys

import torch


def main():
    parser = argparse.ArgumentParser(
        description="Pearl GPU Miner — mine PRL with your GPU",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  # Standalone benchmark (no gateway needed)
  pearl-mine --standalone --device cuda

  # Connect to gateway
  pearl-mine --host localhost --port 8337

  # Custom matrix dimensions (larger = more hashes per step)
  pearl-mine --standalone -m 8192 -n 8192 -k 4096
""",
    )

    parser.add_argument("--standalone", action="store_true",
                        help="Standalone mode — mine random matrices for benchmarking")
    parser.add_argument("--device", default="cuda",
                        help="PyTorch device (cuda, cuda:0, cpu)")
    parser.add_argument("-m", type=int, default=4096, help="Matrix rows (default: 4096)")
    parser.add_argument("-n", type=int, default=4096, help="Matrix cols (default: 4096)")
    parser.add_argument("-k", type=int, default=4096, help="Common dim (default: 4096)")
    parser.add_argument("--noise-rank", type=int, default=128, help="Noise rank (default: 128)")
    parser.add_argument("--noise-range", type=int, default=128, help="Noise range (default: 128)")
    parser.add_argument("--hash-tile-h", type=int, default=16, help="Hash tile height")
    parser.add_argument("--hash-tile-w", type=int, default=16, help="Hash tile width")

    # Gateway options
    parser.add_argument("--host", default="localhost", help="Gateway host")
    parser.add_argument("--port", type=int, default=8337, help="Gateway port")
    parser.add_argument("--transport", default="tcp", choices=["tcp", "uds"])
    parser.add_argument("--socket", default="/tmp/pearlgw.sock", help="UDS path")

    parser.add_argument("-v", "--verbose", action="store_true")

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    # Check CUDA
    if "cuda" in args.device and not torch.cuda.is_available():
        logging.error("CUDA not available! Use --device cpu for CPU-only (very slow).")
        sys.exit(1)

    if "cuda" in args.device:
        gpu = torch.cuda.get_device_properties(0)
        logging.info(f"GPU: {gpu.name}, {gpu.total_mem // (1024**2)} MB, SM {gpu.major}.{gpu.minor}")

    from .miner import MinerConfig, mine_standalone, mine_gateway

    cfg = MinerConfig(
        m=args.m,
        n=args.n,
        k=args.k,
        noise_rank=args.noise_rank,
        noise_range=args.noise_range,
        hash_tile_h=args.hash_tile_h,
        hash_tile_w=args.hash_tile_w,
        device=args.device,
        gateway_host=args.host,
        gateway_port=args.port,
        gateway_transport=args.transport,
        gateway_socket=args.socket,
        standalone=args.standalone,
    )

    try:
        if args.standalone:
            mine_standalone(cfg)
        else:
            mine_gateway(cfg)
    except KeyboardInterrupt:
        logging.info("Interrupted, stopping miner.")


if __name__ == "__main__":
    main()
