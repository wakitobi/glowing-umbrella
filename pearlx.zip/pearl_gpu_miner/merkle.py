"""
BLAKE3 Merkle tree for matrix commitment — pure Python implementation.

Each leaf is a row of the matrix, padded to the BLAKE3 chunk boundary (1024 bytes).
The tree is a standard binary Merkle tree built from keyed BLAKE3 hashes.
"""
import math

from blake3 import blake3

CHUNK_LEN = 1024  # blake3 chunk length


def pad_to_chunk(data: bytes) -> bytes:
    """Pad data to the next multiple of CHUNK_LEN."""
    remainder = len(data) % CHUNK_LEN
    if remainder == 0:
        return data
    return data + b"\x00" * (CHUNK_LEN - remainder)


def keyed_hash(data: bytes, key: bytes) -> bytes:
    return blake3(data, key=key).digest()


class MerkleTree:
    """Binary Merkle tree over matrix rows with BLAKE3 keyed hashes."""

    def __init__(self, matrix_bytes: bytes, rows: int, cols: int, key: bytes):
        """Build tree from flattened int8 matrix bytes.

        Args:
            matrix_bytes: raw int8 bytes, length = rows * cols
            rows: number of rows
            cols: bytes per row
            key: 32-byte BLAKE3 key
        """
        assert len(key) == 32
        self.key = key
        self.rows = rows
        self.cols = cols

        # Build leaf hashes — each leaf is one row, padded
        self.leaf_hashes: list[bytes] = []
        for r in range(rows):
            row_data = matrix_bytes[r * cols : (r + 1) * cols]
            padded = pad_to_chunk(row_data)
            self.leaf_hashes.append(keyed_hash(padded, key))

        # Pad to power of 2
        n = 1
        while n < len(self.leaf_hashes):
            n *= 2
        while len(self.leaf_hashes) < n:
            self.leaf_hashes.append(b"\x00" * 32)

        # Build tree bottom-up
        self._tree = list(self.leaf_hashes)
        level = list(self.leaf_hashes)
        self._levels = [level[:]]
        while len(level) > 1:
            new_level = []
            for i in range(0, len(level), 2):
                combined = level[i] + level[i + 1]
                new_level.append(keyed_hash(combined, key))
            level = new_level
            self._levels.append(level[:])

        self.root = level[0] if level else b"\x00" * 32

    def get_proof(self, leaf_indices: list[int]) -> list[bytes]:
        """Get a multi-leaf Merkle proof for the given leaf indices.

        Returns sibling hashes needed to reconstruct the root.
        This is a simplified proof — the actual Pearl implementation uses
        pearl_mining.MerkleTree which has a more sophisticated proof format.
        """
        # For now, return a flat list of sibling hashes for each leaf
        proofs = []
        for idx in leaf_indices:
            path = []
            current_idx = idx
            for level in self._levels[:-1]:
                sibling = current_idx ^ 1
                if sibling < len(level):
                    path.append(level[sibling])
                current_idx //= 2
            proofs.extend(path)
        return proofs
