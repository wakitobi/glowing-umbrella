"""Pearl GPU Miner — standalone Python GPU miner for the Pearl network."""
