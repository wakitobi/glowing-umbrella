"""
Deterministic noise generation for Pearl NoisyGEMM.

Generates noise matrices E_AL, E_AR, E_BL, E_BR from blake3 keyed hashes,
matching the reference miner-base implementation exactly.

E_AL (m x r):   uniform random matrix
E_AR (r x k):   permutation matrix (assign_columns=True)
E_BL (k x r):   permutation matrix (assign_columns=False)
E_BR (r x n):   uniform random matrix, transposed
"""
from math import ceil

import numpy as np
import torch
from blake3 import blake3


def _is_pow2(n: int) -> bool:
    return n != 0 and (n & (n - 1)) == 0


def _np_mul_hi_u32(a: np.uint32, b: np.uint32) -> np.uint32:
    """Multiply two uint32 and return the upper 32 bits."""
    prod64 = a.astype(np.uint64) * b.astype(np.uint64)
    return (prod64 >> np.uint64(32)).astype(np.uint32)


# blake3 digest size
DIGEST_SIZE = 32


class NoiseGenerator:
    """Generates deterministic noise matrices from blake3 keyed seeds.

    Matches reference: miner-base/src/miner_base/noise_generation.py
    """

    def __init__(self, noise_rank: int = 128, noise_range: int = 128):
        if not _is_pow2(noise_range):
            raise ValueError("noise_range must be a power of two")
        if not _is_pow2(noise_rank):
            raise ValueError("noise_rank must be a power of two")
        if noise_range > 128:
            raise ValueError("noise_range must fit in uint7")
        if noise_rank % DIGEST_SIZE != 0:
            raise ValueError(f"noise_rank must be divisible by {DIGEST_SIZE}")

        # noise_range is halved because of the 2-values-per-byte scheme
        idxs_per_col = 2
        _nr = noise_range // idxs_per_col
        self.noise_rank = noise_rank
        self.noise_range = noise_range
        self.zero_point = _nr // 2
        self.range_mask = _nr - 1
        self.rank_mask = noise_rank - 1

    # ─── public API ───

    def generate(
        self,
        key_A: bytes,
        key_B: bytes,
        A_rows: int,
        common_dim: int,
        B_cols: int,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return (E_AL, E_AR, E_BL, E_BR) — all int8 on CPU.

        key_A = commitment_hash.noise_seed_A (= pow_key)
        key_B = commitment_hash.noise_seed_B
        """
        if A_rows < self.noise_rank:
            raise ValueError(f"A_rows ({A_rows}) must be >= noise_rank ({self.noise_rank})")
        if common_dim < self.noise_rank:
            raise ValueError(f"common_dim ({common_dim}) must be >= noise_rank ({self.noise_rank})")
        if B_cols < self.noise_rank:
            raise ValueError(f"B_cols ({B_cols}) must be >= noise_rank ({self.noise_rank})")

        # Seeds are 32-byte domain-separated strings, zero-padded
        seed_A = (
            torch.frombuffer(bytearray(b"A_tensor" + b"\x00" * 24), dtype=torch.uint8)
            .numpy()
            .tobytes()
        )
        seed_B = (
            torch.frombuffer(bytearray(b"B_tensor" + b"\x00" * 24), dtype=torch.uint8)
            .numpy()
            .tobytes()
        )

        E_AL = self._gen_uniform(seed_A, key_A, A_rows)
        E_AR = self._gen_permutation(seed_A, key_A, self.noise_rank, common_dim, assign_columns=True)
        E_BL = self._gen_permutation(seed_B, key_B, common_dim, self.noise_rank, assign_columns=False)
        E_BR = self._gen_uniform(seed_B, key_B, B_cols).T
        return E_AL, E_AR, E_BL, E_BR

    # ─── private ───

    def _hash(self, index: int, seed: bytes, key: bytes, prepend_index: int) -> bytes:
        """Hash function matching reference __get_random_hash."""
        message_prepend = np.zeros(8, dtype=np.int32)
        message_prepend[prepend_index] = 1 + index
        message_bytes = message_prepend.tobytes() + seed
        return blake3(message_bytes, key=key).digest()

    def _gen_uniform(self, seed: bytes, key: bytes, rows: int) -> torch.Tensor:
        """Generate uniform random noise matrix (rows x noise_rank)."""
        cols = self.noise_rank
        assert len(seed) == 32 and len(key) == 32

        draws = int(ceil(rows * cols / DIGEST_SIZE))
        random_bytes = b"".join(self._hash(i, seed, key, 0) for i in range(draws))

        random_tensor = torch.frombuffer(bytearray(random_bytes), dtype=torch.uint8)[:rows * cols]
        noise = ((random_tensor & self.range_mask) - self.zero_point).to(torch.int8).view(rows, cols)
        return noise

    def _gen_permutation(
        self, seed: bytes, key: bytes, rows: int, cols: int, assign_columns: bool
    ) -> torch.Tensor:
        """Generate permutation noise matrix.

        Each row/column has exactly two non-zero entries: +1 and -1.
        """
        assert (rows == self.noise_rank) or (cols == self.noise_rank)
        assert len(seed) == 32 and len(key) == 32

        noise_matrix = torch.zeros(rows, cols, dtype=torch.int8)

        if assign_columns:
            required_lines = cols
            assert rows == self.noise_rank
        else:
            required_lines = rows
            assert cols == self.noise_rank

        bytes_per_line = 4
        draws = int(ceil(required_lines * bytes_per_line / DIGEST_SIZE))

        for i in range(draws):
            random_hash = self._hash(i, seed, key, 1)
            random_uint32_array = np.frombuffer(random_hash, dtype=np.uint32)

            for k in range(DIGEST_SIZE // bytes_per_line):
                random_uint32 = random_uint32_array[k]
                first_idx = int(random_uint32 & self.rank_mask)
                second_idx = int(
                    first_idx ^ (1 + _np_mul_hi_u32(np.uint32(self.noise_rank - 1), random_uint32))
                )

                permutation = torch.zeros(self.noise_rank, dtype=torch.int8)
                permutation[first_idx] = 1
                permutation[second_idx] = -1

                assignment_index = i * DIGEST_SIZE // bytes_per_line + k
                if assignment_index >= required_lines:
                    break
                if assign_columns:
                    noise_matrix[:, assignment_index] = permutation
                else:
                    noise_matrix[assignment_index, :] = permutation

        return noise_matrix
