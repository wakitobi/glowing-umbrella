"""
Inner hash and transcript logic — GPU-accelerated via PyTorch.

Pearl PoW:
1. Tile the GEMM output into hash_tile_h x hash_tile_w tiles
2. XOR-reduce each tile to a uint32 ("inner hash")
3. Accumulate inner hashes into a 64-byte Transcript (16 x uint32) via rotl-XOR
4. After all k-reductions, blake3(transcript, key=pow_key) and check <= target

This module does steps 1-3 on GPU using vectorised torch ops.
Step 4 (blake3 keyed hash) is done on CPU since it's just one hash per tile.
"""
import struct

import blake3 as _blake3
import numpy as np
import torch

# Transcript: 64 bytes = 16 x uint32 (matches blake3::MSG_BLOCK_SIZE_U32)
TRANSCRIPT_U32 = 16
HASH_ACCUMULATE_ROTATION = 13

# PoW bounds
POW_TARGET_HARDEST = 0
POW_TARGET_EASIEST = (1 << 256) - 1


def rotl32(x: np.uint32, n: int) -> np.uint32:
    """Rotate left a 32-bit unsigned integer by n bits."""
    val = int(x) & 0xFFFFFFFF
    return np.uint32(((val << n) & 0xFFFFFFFF) | (val >> (32 - n)))


# ---------------------------------------------------------------------------
# GPU inner hash: XOR-reduce each tile to one uint32
# ---------------------------------------------------------------------------

def xor_reduce_tiles_gpu(
    C_block: torch.Tensor,
    tile_h: int,
    tile_w: int,
) -> torch.Tensor:
    """XOR-reduce hash tiles on GPU.

    Args:
        C_block: int32 tensor of shape (H, W) — a single output tile
        tile_h, tile_w: hash tile dimensions

    Returns:
        Tensor of shape (num_tiles_h, num_tiles_w) with uint32 XOR reductions
        stored as int32 (bit-pattern preserved).
    """
    H, W = C_block.shape
    nh = H // tile_h
    nw = W // tile_w

    if nh == 0 or nw == 0:
        return torch.empty((0, 0), dtype=torch.int32, device=C_block.device)

    # Trim to full tiles only, reshape to (nh, tile_h, nw, tile_w)
    trimmed = C_block[:nh * tile_h, :nw * tile_w]
    tiles = trimmed.reshape(nh, tile_h, nw, tile_w).permute(0, 2, 1, 3)  # (nh, nw, tile_h, tile_w)
    flat = tiles.reshape(nh, nw, -1)  # (nh, nw, tile_h*tile_w)

    # XOR reduction along last axis — torch.bitwise_xor doesn't have a reduce,
    # so we iteratively halve.  For tile_h*tile_w = 256 this is 8 iterations.
    v = flat
    while v.shape[-1] > 1:
        half = v.shape[-1] // 2
        if v.shape[-1] % 2 == 1:
            # odd: peel off last element, XOR remainder
            last = v[..., -1:]
            v = torch.bitwise_xor(v[..., :half], v[..., half:2 * half])
            v = torch.bitwise_xor(v, last)
        else:
            v = torch.bitwise_xor(v[..., :half], v[..., half:])

    return v.squeeze(-1)  # (nh, nw) int32


# ---------------------------------------------------------------------------
# Transcript accumulation (CPU, per hash tile)
# ---------------------------------------------------------------------------

class Transcript:
    """64-byte transcript buffer for accumulating inner hash results."""

    __slots__ = ("data",)

    def __init__(self):
        self.data = [np.uint32(0)] * TRANSCRIPT_U32

    def rotl_xor_into(self, reduction_count: int, combined_hash: np.uint32):
        idx = reduction_count % TRANSCRIPT_U32
        self.data[idx] = rotl32(self.data[idx], HASH_ACCUMULATE_ROTATION) ^ combined_hash

    def to_bytes(self) -> bytes:
        return b"".join(struct.pack("<I", int(w)) for w in self.data)


def check_pow(transcript: Transcript, pow_key: bytes, pow_target: int) -> bool:
    """Check if blake3(transcript, key=pow_key) <= pow_target."""
    h = _blake3.blake3(transcript.to_bytes(), key=pow_key).digest()
    return int.from_bytes(h, "little") <= pow_target
