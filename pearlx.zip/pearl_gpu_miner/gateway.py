"""
JSON-RPC client for the Pearl gateway.

Connects to pearl-gateway via TCP or Unix domain socket,
fetches mining jobs, and submits proofs.
"""
import json
import socket
import base64
import logging
from dataclasses import dataclass, field
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class GatewayConfig:
    host: str = "localhost"
    port: int = 8337
    transport: str = "tcp"  # "tcp" or "uds"
    socket_path: str = "/tmp/pearlgw.sock"


@dataclass
class MiningJob:
    incomplete_header_bytes: bytes
    target: int
    cert_version: int

    @classmethod
    def from_dict(cls, d: dict) -> "MiningJob":
        return cls(
            incomplete_header_bytes=base64.b64decode(d["incomplete_header_bytes"]),
            target=d["target"],
            cert_version=d.get("cert_version", 1),
        )

    def to_dict(self) -> dict:
        return {
            "incomplete_header_bytes": base64.b64encode(self.incomplete_header_bytes).decode(),
            "target": self.target,
            "cert_version": self.cert_version,
        }


class GatewayClient:
    """Simple JSON-RPC client for the Pearl gateway."""

    def __init__(self, config: GatewayConfig):
        self.config = config
        self._sock: socket.socket | None = None
        self._reader = None
        self._writer = None
        self._req_id = 0

    def connect(self):
        if self.config.transport == "tcp":
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._sock.connect((self.config.host, self.config.port))
            log.info(f"Connected to gateway at {self.config.host}:{self.config.port}")
        else:
            self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self._sock.connect(self.config.socket_path)
            log.info(f"Connected to gateway at {self.config.socket_path}")
        self._reader = self._sock.makefile("r", encoding="utf-8")
        self._writer = self._sock.makefile("w", encoding="utf-8")

    def close(self):
        if self._reader:
            self._reader.close()
        if self._writer:
            self._writer.close()
        if self._sock:
            self._sock.close()
        self._sock = None

    def _call(self, method: str, params: Any = None) -> Any:
        self._req_id += 1
        req = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self._req_id,
            "params": params or {},
        }
        line = json.dumps(req) + "\n"
        self._writer.write(line)
        self._writer.flush()

        resp_line = self._reader.readline()
        if not resp_line:
            raise ConnectionError("Gateway disconnected")
        resp = json.loads(resp_line.strip())

        if "error" in resp:
            err = resp["error"]
            raise Exception(f"Gateway RPC error {err.get('code')}: {err.get('message')}")
        if resp.get("id") != self._req_id:
            raise Exception(f"ID mismatch: expected {self._req_id}, got {resp.get('id')}")
        return resp.get("result")

    def get_mining_info(self) -> MiningJob:
        result = self._call("getMiningInfo")
        return MiningJob.from_dict(result)

    def submit_proof(self, proof_b64: str, job: MiningJob):
        self._call("submitPlainProof", {
            "plain_proof": proof_b64,
            "mining_job": job.to_dict(),
        })
        log.info("Proof submitted to gateway")

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()
