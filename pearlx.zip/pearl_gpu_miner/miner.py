"""
Main mining loop for the Pearl GPU miner.

Two modes:
  1. Standalone (--standalone): generates random matrices, mines against easiest
     target. Useful for benchmarking hashrate.
  2. Gateway (default): connects to pearl-gateway, fetches work, mines, submits.
"""
import logging
import os
import time
from dataclasses import dataclass

import torch
from blake3 import blake3

from .gateway import GatewayClient, GatewayConfig, MiningJob
from .noisy_gemm import NoisyGemmEngine

log = logging.getLogger(__name__)


@dataclass
class MinerConfig:
    # Matrix dimensions
    m: int = 4096
    n: int = 4096
    k: int = 4096
    noise_rank: int = 128
    noise_range: int = 128
    hash_tile_h: int = 16
    hash_tile_w: int = 16
    device: str = "cuda"

    # Gateway
    gateway_host: str = "localhost"
    gateway_port: int = 8337
    gateway_transport: str = "tcp"
    gateway_socket: str = "/tmp/pearlgw.sock"

    # Mining
    standalone: bool = False


def _derive_pow_key(header_bytes: bytes, iteration: int) -> bytes:
    """Derive a pow_key for standalone mining (no real commitment)."""
    seed = header_bytes + iteration.to_bytes(8, "little")
    return blake3(seed).digest()


def _make_engine(cfg: MinerConfig) -> NoisyGemmEngine:
    return NoisyGemmEngine(
        noise_range=cfg.noise_range,
        noise_rank=cfg.noise_rank,
        hash_tile_h=cfg.hash_tile_h,
        hash_tile_w=cfg.hash_tile_w,
        device=cfg.device,
    )


def mine_standalone(cfg: MinerConfig):
    """Standalone mining loop — random matrices, benchmark hashrate."""
    log.info(
        f"Standalone mining: {cfg.m}x{cfg.k} @ {cfg.n} on {cfg.device} "
        f"(rank={cfg.noise_rank}, tile={cfg.hash_tile_h}x{cfg.hash_tile_w})"
    )

    engine = _make_engine(cfg)

    # Use easiest target for benchmarking
    pow_target = (1 << 256) - 1
    header = os.urandom(32)

    iteration = 0
    t0 = time.time()
    last_report = t0

    while True:
        pow_key = _derive_pow_key(header, iteration)
        found, info = engine.mine_random(cfg.m, cfg.n, cfg.k, pow_key, pow_target)

        iteration += 1
        now = time.time()

        if now - last_report >= 5.0:
            elapsed = now - t0
            rate = engine.total_hashes / elapsed
            log.info(
                f"[iter {iteration}] {engine.total_hashes:,} hashes in {elapsed:.1f}s "
                f"= {rate:,.0f} H/s | blocks={engine.blocks_found}"
            )
            last_report = now

        if found:
            log.info(f"Block found at iteration {iteration}! info={info}")


def mine_gateway(cfg: MinerConfig):
    """Gateway mining loop — fetch work from pearl-gateway, mine, submit."""
    gw_cfg = GatewayConfig(
        host=cfg.gateway_host,
        port=cfg.gateway_port,
        transport=cfg.gateway_transport,
        socket_path=cfg.gateway_socket,
    )

    engine = _make_engine(cfg)

    log.info(f"Connecting to gateway at {gw_cfg.host}:{gw_cfg.port} ...")

    reconnect_delay = 2

    while True:
        try:
            with GatewayClient(gw_cfg) as client:
                log.info("Connected to gateway")
                _mine_loop(engine, client, cfg)
        except ConnectionError as e:
            log.warning(f"Gateway connection lost: {e}. Reconnecting in {reconnect_delay}s...")
            time.sleep(reconnect_delay)
        except Exception as e:
            log.error(f"Mining error: {e}. Retrying in {reconnect_delay}s...")
            time.sleep(reconnect_delay)


def _mine_loop(engine: NoisyGemmEngine, client: GatewayClient, cfg: MinerConfig):
    """Inner mining loop once connected to gateway."""
    current_job: MiningJob | None = None
    iteration = 0
    t0 = time.time()
    last_report = t0

    while True:
        # Fetch work
        job = client.get_mining_info()

        if current_job is None or job.incomplete_header_bytes != current_job.incomplete_header_bytes:
            log.info(
                f"New work: target={job.target}, cert_v={job.cert_version}, "
                f"header={job.incomplete_header_bytes[:8].hex()}..."
            )
            current_job = job

        # Generate random data matrices within valid range
        data_range = 256 - cfg.noise_range
        lo = -(data_range // 2)
        hi = lo + data_range - 1
        A = torch.randint(lo, hi + 1, (cfg.m, cfg.k), dtype=torch.int8)
        B = torch.randint(lo, hi + 1, (cfg.k, cfg.n), dtype=torch.int8)

        # Mine with proper commitment hash
        # mining_config_bytes would come from MiningConfiguration.to_bytes() in the real impl
        # For now, use a placeholder (the gateway miner generates config from dimensions)
        mining_config_bytes = _make_mining_config_bytes(cfg)

        found, info = engine.mine_with_commitment(
            A, B,
            job.incomplete_header_bytes,
            mining_config_bytes,
            job.target,
        )

        iteration += 1
        now = time.time()

        if now - last_report >= 10.0:
            elapsed = now - t0
            rate = engine.total_hashes / elapsed
            log.info(
                f"[iter {iteration}] {rate:,.0f} H/s | blocks={engine.blocks_found}"
            )
            last_report = now

        if found:
            log.info(f"BLOCK FOUND at iter {iteration}!")
            log.info(f"  A_rows: {info['A_row_indices']}")
            log.info(f"  B_cols: {info['B_col_indices']}")
            # Note: full proof submission requires the pearl_mining Rust library
            # for PlainProof creation and verification. This miner does the PoW
            # discovery — proof submission is handled by the gateway stack.
            log.info(
                "Proof submission requires pearl_mining Rust lib. "
                "Use the full Pearl miner stack for block submission."
            )


def _make_mining_config_bytes(cfg: MinerConfig) -> bytes:
    """Create a placeholder mining config byte representation.

    In production, this comes from MiningConfiguration.to_bytes()
    via the pearl_mining Rust library. We create a deterministic
    placeholder so the commitment hash is at least internally consistent.
    """
    import struct
    # Pack: common_dim(u32) + rank(u32) + mma_type(u8) + rows_pattern + cols_pattern
    # This is a simplified version — the real format is defined in Rust
    return struct.pack(
        "<IIB",
        cfg.k,          # common_dim
        cfg.noise_rank, # rank
        0,              # mma_type (Int7xInt7ToInt32 = 0)
    )
