"""
Commitment hash derivation for Pearl mining.

Derives the pow_key and noise seeds from the block header and matrix Merkle roots.
This must exactly match the reference implementation in miner-base/commitment_hash.py.
"""
from blake3 import blake3

# V3 domain-separation salts
SEED_SALT_A = blake3(b"pearl/cert-v3/noise-seed/A").digest()
SEED_SALT_B = blake3(b"pearl/cert-v3/noise-seed/B").digest()

_BIND_PAD = b"\x00" * 28


def _bind_root(merkle_root: bytes, dim: int, salt: bytes) -> bytes:
    """V3 salted root binding — commits matrix dimensions into the seed."""
    return blake3(
        merkle_root + dim.to_bytes(4, "little") + _BIND_PAD,
        key=salt,
    ).digest()


def get_key(incomplete_header_bytes: bytes, mining_config_bytes: bytes) -> bytes:
    """Derive the BLAKE3 key from block header + mining config."""
    return blake3(incomplete_header_bytes + mining_config_bytes).digest()


def commitment_hash_from_roots(
    A_root: bytes,
    B_root: bytes,
    key: bytes,
    salted_dims: tuple[int, int] | None = None,
) -> tuple[bytes, bytes]:
    """Compute (noise_seed_A, noise_seed_B) from Merkle roots.

    Returns:
        (noise_seed_A, noise_seed_B) — both 32-byte keys.
        noise_seed_A is used as pow_key in the NoisyGEMM check.
    """
    if salted_dims is not None:
        m, n = salted_dims
        A_root = _bind_root(A_root, m, SEED_SALT_A)
        B_root = _bind_root(B_root, n, SEED_SALT_B)

    commitment_B = blake3(key + B_root).digest()
    commitment_A = blake3(commitment_B + A_root).digest()
    return commitment_A, commitment_B
