"""
GPU-accelerated NoisyGEMM engine for Pearl mining.

Optimized for NVIDIA T4 (sm75) — uses float16 tensor cores for the heavy
matmul and does XOR-reduce + transcript accumulation on GPU.

The T4 has 65 TFLOPS of FP16 tensor core throughput but no native int8 matmul
via torch._int_mm (requires sm80+). Strategy:
  - Cast int8 → float16 for the GEMM (lossless for values in [-64, 63])
  - Cast result back to int32 for XOR-reduce
  - All noise generation stays on CPU (small relative to 4096^2 GEMM)
"""
import struct

import numpy as np
import torch
from blake3 import blake3

from .commitment import commitment_hash_from_roots
from .inner_hash import (
    TRANSCRIPT_U32,
    HASH_ACCUMULATE_ROTATION,
    Transcript,
    check_pow,
    rotl32,
)
from .merkle import MerkleTree
from .noise import NoiseGenerator


def _xor_reduce_gpu(C_block: torch.Tensor, tile_h: int, tile_w: int) -> torch.Tensor:
    """XOR-reduce hash tiles entirely on GPU.

    Returns (nh, nw) int32 tensor of XOR-reduced hash values.
    """
    H, W = C_block.shape
    nh = H // tile_h
    nw = W // tile_w
    if nh == 0 or nw == 0:
        return torch.empty((0, 0), dtype=torch.int32, device=C_block.device)

    trimmed = C_block[:nh * tile_h, :nw * tile_w]
    tiles = trimmed.reshape(nh, tile_h, nw, tile_w).permute(0, 2, 1, 3)
    flat = tiles.reshape(nh, nw, -1)

    v = flat
    while v.shape[-1] > 1:
        half = v.shape[-1] // 2
        if v.shape[-1] % 2 == 1:
            last = v[..., -1:]
            v = torch.bitwise_xor(v[..., :half], v[..., half:2 * half])
            v = torch.bitwise_xor(v, last)
        else:
            v = torch.bitwise_xor(v[..., :half], v[..., half:])

    return v.squeeze(-1)


class NoisyGemmEngine:
    """GPU NoisyGEMM miner — optimized for T4 (sm75).

    Uses fp16 tensor cores for the main GEMM, int32 for accumulation,
    and GPU-side XOR reduction for inner hashes.
    """

    def __init__(
        self,
        noise_range: int = 128,
        noise_rank: int = 128,
        hash_tile_h: int = 16,
        hash_tile_w: int = 16,
        device: str = "cuda",
    ):
        self.noise_range = noise_range
        self.noise_rank = noise_rank
        self.hash_tile_h = hash_tile_h
        self.hash_tile_w = hash_tile_w
        self.device = torch.device(device)
        self.noise_gen = NoiseGenerator(noise_rank, noise_range)

        # Stats
        self.total_hashes = 0
        self.blocks_found = 0

        # Detect best matmul strategy
        self._use_fp16 = True
        if torch.cuda.is_available():
            cap = torch.cuda.get_device_capability(self.device)
            self._sm = cap[0] * 10 + cap[1]
            # sm75 (T4): fp16 tensor cores, no torch._int_mm
            # sm80+ (A100, etc.): can use torch._int_mm
            # sm90 (H100): native int8 tensor cores
            self._use_int_mm = self._sm >= 80
        else:
            self._sm = 0
            self._use_int_mm = False
            self._use_fp16 = False

    def _gpu_matmul(self, A: torch.Tensor, B: torch.Tensor) -> torch.Tensor:
        """Best available int8-like matmul for this GPU.

        Args:
            A: int8 (m, k) on device
            B: int8 (k, n) on device

        Returns:
            int32 (m, n) result of A @ B
        """
        if self._use_int_mm:
            # sm80+: native int8 matmul
            return torch._int_mm(A, B)
        elif self._use_fp16:
            # sm75 (T4): fp16 tensor cores — lossless for int7 values
            return torch.matmul(
                A.to(torch.float16), B.to(torch.float16)
            ).to(torch.int32)
        else:
            # CPU fallback
            return torch.matmul(A.to(torch.int32), B.to(torch.int32))

    def _tiled_matmul(
        self,
        A: torch.Tensor,
        B: torch.Tensor,
        pow_key: bytes,
        pow_target: int,
    ) -> tuple[torch.Tensor, bool, dict | None]:
        """Tiled matmul with PoW checking.

        Output tiles are noise_rank x noise_rank. Within each output tile,
        hash tiles (hash_tile_h x hash_tile_w) each have their own Transcript.
        After all k-reductions, check blake3(transcript, key=pow_key) <= target.
        """
        m, k = A.shape
        n = B.shape[1]
        r = self.noise_rank
        th, tw = self.hash_tile_h, self.hash_tile_w

        C = torch.zeros((m, n), dtype=torch.int32, device=self.device)
        found = False
        block_info = None

        for i in range(0, m, r):
            i_max = min(i + r, m)
            for j in range(0, n, r):
                j_max = min(j + r, n)
                block_h = i_max - i
                block_w = j_max - j

                nh = block_h // th
                nw = block_w // tw

                transcripts = [[Transcript() for _ in range(nw)] for _ in range(nh)]
                reduction_count = 0

                C_block = torch.zeros((block_h, block_w), dtype=torch.int32, device=self.device)

                for p in range(0, k, r):
                    p_max = min(p + r, k)
                    A_tile = A[i:i_max, p:p_max]
                    B_tile = B[p:p_max, j:j_max]
                    C_tile = self._gpu_matmul(A_tile, B_tile)
                    C_block += C_tile

                    is_full = (block_h >= th and block_w >= tw and (p_max - p) == r)
                    if is_full:
                        hashes = _xor_reduce_gpu(C_block, th, tw)
                        hashes_cpu = hashes.cpu().numpy().view(np.uint32)
                        self.total_hashes += hashes_cpu.size

                        for hi in range(nh):
                            for wi in range(nw):
                                transcripts[hi][wi].rotl_xor_into(
                                    reduction_count,
                                    np.uint32(hashes_cpu[hi, wi]),
                                )
                        reduction_count += 1

                if not found and nh > 0 and nw > 0:
                    for hi in range(nh):
                        for wi in range(nw):
                            if check_pow(transcripts[hi][wi], pow_key, pow_target):
                                found = True
                                self.blocks_found += 1
                                block_info = {
                                    "A_row_indices": list(range(i + hi * th, i + (hi + 1) * th)),
                                    "B_col_indices": list(range(j + wi * tw, j + (wi + 1) * tw)),
                                }
                                break
                        if found:
                            break

                C[i:i_max, j:j_max] = C_block

        return C, found, block_info

    def mine_step(
        self,
        A: torch.Tensor,
        B: torch.Tensor,
        pow_key: bytes,
        pow_target: int,
    ) -> tuple[torch.Tensor, bool, dict | None]:
        """Run one NoisyGEMM pass: noise, tiled matmul, PoW check, denoise."""
        assert A.dtype == torch.int8 and B.dtype == torch.int8
        m, k = A.shape
        n = B.shape[1]
        assert B.shape[0] == k

        key_A = pow_key
        key_B = pow_key

        E_AL, E_AR, E_BL, E_BR = self.noise_gen.generate(key_A, key_B, m, k, n)

        # Noise A
        E_A = torch.matmul(E_AL.to(torch.int32), E_AR.to(torch.int32)).to(torch.int8)
        A_noised = (A + E_A).to(torch.int8)
        A_E_BL = torch.matmul(A.to(torch.int32), E_BL.to(torch.int32))

        # Noise B
        E_B = torch.matmul(E_BL.to(torch.int32), E_BR.to(torch.int32)).to(torch.int8)
        B_noised = (B + E_B).to(torch.int8)
        EAR_BpEB = torch.matmul(E_AR.to(torch.int32), B_noised.to(torch.int32))

        # Move to GPU
        A_gpu = A_noised.to(self.device)
        B_gpu = B_noised.to(self.device)

        C_noised, found, block_info = self._tiled_matmul(A_gpu, B_gpu, pow_key, pow_target)

        # Denoise
        A_EB = torch.matmul(A_E_BL, E_BR.to(torch.int32))
        EA_BpEB = torch.matmul(E_AL.to(torch.int32), EAR_BpEB)
        C = C_noised.cpu() - A_EB - EA_BpEB

        return C, found, block_info

    def mine_with_commitment(
        self,
        A: torch.Tensor,
        B: torch.Tensor,
        incomplete_header_bytes: bytes,
        mining_config_bytes: bytes,
        pow_target: int,
    ) -> tuple[bool, dict | None]:
        """Mine with proper commitment hash derivation."""
        m, k = A.shape
        n = B.shape[1]

        key = blake3(incomplete_header_bytes + mining_config_bytes).digest()

        A_bytes = A.flatten().detach().cpu().numpy().tobytes()
        Bt = B.T.contiguous()
        Bt_bytes = Bt.flatten().detach().cpu().numpy().tobytes()

        A_tree = MerkleTree(A_bytes, m, k, key)
        Bt_tree = MerkleTree(Bt_bytes, n, k, key)

        noise_seed_A, noise_seed_B = commitment_hash_from_roots(
            A_tree.root, Bt_tree.root, key, salted_dims=(m, n)
        )

        E_AL, E_AR, E_BL, E_BR = self.noise_gen.generate(noise_seed_A, noise_seed_B, m, k, n)

        E_A = torch.matmul(E_AL.to(torch.int32), E_AR.to(torch.int32)).to(torch.int8)
        A_noised = (A + E_A).to(torch.int8)

        E_B = torch.matmul(E_BL.to(torch.int32), E_BR.to(torch.int32)).to(torch.int8)
        B_noised = (B + E_B).to(torch.int8)

        A_gpu = A_noised.to(self.device)
        B_gpu = B_noised.to(self.device)
        _, found, block_info = self._tiled_matmul(A_gpu, B_gpu, noise_seed_A, pow_target)

        if found and block_info is not None:
            block_info["A"] = A
            block_info["B_t"] = Bt
            block_info["A_tree"] = A_tree
            block_info["Bt_tree"] = Bt_tree
            block_info["noise_seed_A"] = noise_seed_A
            block_info["noise_seed_B"] = noise_seed_B
            block_info["key"] = key

        return found, block_info

    def mine_random(
        self,
        m: int,
        n: int,
        k: int,
        pow_key: bytes,
        pow_target: int,
    ) -> tuple[bool, dict | None]:
        """Mine with random int8 matrices (standalone / benchmark mode)."""
        data_range = 256 - self.noise_range
        lo = -(data_range // 2)
        hi = lo + data_range - 1

        A = torch.randint(lo, hi + 1, (m, k), dtype=torch.int8)
        B = torch.randint(lo, hi + 1, (k, n), dtype=torch.int8)

        _, found, info = self.mine_step(A, B, pow_key, pow_target)
        return found, info
