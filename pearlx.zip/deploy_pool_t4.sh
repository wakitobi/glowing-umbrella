#!/bin/bash
# Pearl GPU Pool Miner - T4 Linux Deployment
# Pool: pearl-us-ord.lproute.com:3360
# Wallet: prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t
set -e

POOL_HOST="pearl-us-ord.lproute.com"
POOL_PORT=3360
WALLET="prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t"
WORKER="t4gpu"
REPO="https://github.com/pearl-research-labs/pearl.git"
WORKDIR="$HOME/pearl-miner"

echo "============================================="
echo "  Pearl GPU Pool Miner — T4 Deployment"
echo "  Pool: ${POOL_HOST}:${POOL_PORT}"
echo "  Wallet: ${WALLET:0:20}..."
echo "============================================="

# ── 1. System deps ─────────────────────────────────────────
echo "[1/8] Installing system dependencies..."
apt-get update -qq && apt-get install -y -qq git curl build-essential pkg-config libssl-dev cmake 2>/dev/null || true

# ── 2. Rust toolchain ──────────────────────────────────────
if ! command -v rustup &>/dev/null; then
    echo "[2/8] Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
else
    echo "[2/8] Rust already installed"
    source "$HOME/.cargo/env" 2>/dev/null || true
fi
rustup default stable 2>/dev/null

# ── 3. uv ──────────────────────────────────────────────────
if ! command -v uv &>/dev/null; then
    echo "[3/8] Installing uv..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="$HOME/.local/bin:$PATH"
else
    echo "[3/8] uv already installed"
fi

# ── 4. Clone repo ──────────────────────────────────────────
if [ ! -d "$WORKDIR" ]; then
    echo "[4/8] Cloning Pearl repo..."
    git clone --depth 1 "$REPO" "$WORKDIR"
else
    echo "[4/8] Pearl repo already cloned"
    cd "$WORKDIR" && git pull --ff-only 2>/dev/null || true
fi
cd "$WORKDIR"

# ── 5. Python env + workspace sync ────────────────────────
echo "[5/8] Setting up Python 3.12 environment..."
uv python install 3.12 2>/dev/null || true
uv venv --python 3.12 .venv
source .venv/bin/activate

echo "[6/8] Installing workspace packages (this may take a while)..."
# Build py-pearl-mining (Rust → Python wheel via maturin)
uv pip install maturin
cd py-pearl-mining
maturin develop --release
cd ..

# Install workspace packages
uv pip install -e miner/miner-utils
uv pip install -e miner/pearl-gateway
uv pip install -e miner/miner-base
uv pip install blake3 numpy torch --index-url https://download.pytorch.org/whl/cu130 2>/dev/null || \
    uv pip install blake3 numpy torch

# ── 6. GPU check ───────────────────────────────────────────
echo "[7/8] Checking GPU..."
python -c "
import torch
if torch.cuda.is_available():
    gpu = torch.cuda.get_device_name(0)
    mem = torch.cuda.get_device_properties(0).total_mem / 1e9
    print(f'  GPU: {gpu} ({mem:.1f} GB)')
    print(f'  CUDA: {torch.version.cuda}')
    print(f'  Compute cap: {torch.cuda.get_device_capability()}')
else:
    print('  WARNING: No GPU detected! Mining will be very slow on CPU.')
"

# ── 7. Write pool miner script ─────────────────────────────
echo "[8/8] Writing pool miner..."
cat > pool_miner.py << 'MINER_EOF'
#!/usr/bin/env python3
"""
Pearl Pool Miner — connects directly to LuckyPool via JSON-RPC.

Architecture:
  pool:3360 ←→ [this miner] (getMiningInfo / submitPlainProof)

The pool speaks the same JSON-RPC protocol as pearl-gateway.
We do NoisyGEMM on GPU, build PlainProof via pearl_mining Rust lib, submit.
"""
import argparse
import base64
import json
import os
import random
import socket
import struct
import sys
import time
import traceback
from dataclasses import dataclass
from enum import IntEnum
from math import ceil
from typing import Any, Optional

import blake3 as blake3_mod
import numpy as np
import torch

# --- pearl_mining Rust bindings ---
from pearl_mining import (
    IncompleteBlockHeader,
    MatrixMerkleProof,
    MiningConfiguration,
    MMAType,
    MoEConfig,
    PeriodicPattern,
    PlainProof,
    check_cert_version_eligible,
    penalized_target_bound,
    verify_plain_proof_for_cert_version,
)

# =====================================================================
# Constants
# =====================================================================
NOISE_RANGE = 128
NOISE_RANK = 128
HASH_TILE_H = 16
HASH_TILE_W = 16
TRANSCRIPT_SIZE_U32 = 16
HASH_ACCUMULATE_ROTATION = 13
BLAKE3_DIGEST_SIZE = 32
BLAKE3_CHUNK_LEN = 1024

# Tile patterns from MinerSettings defaults
ROWS_PATTERN = [0, 8]
COLS_PATTERN = [
    0, 1, 8, 9, 16, 17, 24, 25, 32, 33, 40, 41, 48, 49, 56, 57,
    64, 65, 72, 73, 80, 81, 88, 89, 96, 97, 104, 105, 112, 113, 120, 121,
    128, 129, 136, 137, 144, 145, 152, 153, 160, 161, 168, 169, 176, 177, 184, 185,
    192, 193, 200, 201, 208, 209, 216, 217, 224, 225, 232, 233, 240, 241, 248, 249,
]

# V3 salt constants
SEED_SALT_A = blake3_mod.blake3(b"pearl/cert-v3/noise-seed/A").digest()
SEED_SALT_B = blake3_mod.blake3(b"pearl/cert-v3/noise-seed/B").digest()
_BIND_PAD = b"\x00" * 28


class CertVersion(IntEnum):
    ZK_DENSE = 1
    ZK_MOE = 2
    ZK_V3 = 3

    @property
    def uses_salted_seeds(self):
        return self >= CertVersion.ZK_V3


# =====================================================================
# JSON-RPC Client
# =====================================================================
class PoolClient:
    """JSON-RPC client for pool communication."""

    def __init__(self, host: str, port: int, timeout: float = 30.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self._sock: Optional[socket.socket] = None
        self._reader = None
        self._writer = None
        self._req_id = 0

    def connect(self):
        """Establish TCP connection to pool."""
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(self.timeout)
        self._sock.connect((self.host, self.port))
        self._reader = self._sock.makefile("r", encoding="utf-8")
        self._writer = self._sock.makefile("w", encoding="utf-8")
        print(f"  Connected to {self.host}:{self.port}")

    def close(self):
        if self._reader:
            self._reader.close()
        if self._writer:
            self._writer.close()
        if self._sock:
            self._sock.close()
        self._sock = None

    def call(self, method: str, params: Any = None) -> Any:
        """Make a JSON-RPC call."""
        self._req_id += 1
        request = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self._req_id,
            "params": params if params is not None else {},
        }
        msg = json.dumps(request) + "\n"
        self._writer.write(msg)
        self._writer.flush()

        line = self._reader.readline()
        if not line:
            raise ConnectionError("Pool closed connection")
        response = json.loads(line.strip())

        if "error" in response:
            err = response["error"]
            raise RuntimeError(f"Pool error {err.get('code')}: {err.get('message')}")

        if response.get("id") != self._req_id:
            raise RuntimeError(f"Response ID mismatch: expected {self._req_id}, got {response.get('id')}")

        return response.get("result")

    def get_mining_info(self):
        """Get current mining job from pool."""
        return self.call("getMiningInfo")

    def submit_plain_proof(self, plain_proof: PlainProof, mining_job_dict: dict):
        """Submit a PlainProof to the pool."""
        return self.call("submitPlainProof", {
            "plain_proof": plain_proof.to_base64(),
            "mining_job": mining_job_dict,
        })


# =====================================================================
# BLAKE3 Merkle Tree (matches MatrixMerkleTree in miner-base)
# =====================================================================
def pad_to_chunk_boundary(data: bytes) -> bytes:
    """Pad data to BLAKE3 chunk boundary (1024 bytes)."""
    remainder = len(data) % BLAKE3_CHUNK_LEN
    if remainder == 0:
        return data
    return data + b"\x00" * (BLAKE3_CHUNK_LEN - remainder)


class MatrixMerkleTree:
    """BLAKE3 Merkle tree over matrix rows."""

    def __init__(self, matrix: torch.Tensor, key: bytes):
        self.key = key
        self.matrix = matrix
        self.num_rows = matrix.shape[0]

        # Compute leaf hashes (one per row)
        self.leaves = []
        for i in range(self.num_rows):
            row_bytes = matrix[i].contiguous().numpy().tobytes()
            padded = pad_to_chunk_boundary(row_bytes)
            h = blake3_mod.blake3(padded, key=key).digest()
            self.leaves.append(h)

        # Build tree
        self._tree = self._build_tree(self.leaves)

    @property
    def root(self) -> bytes:
        if not self._tree:
            return b"\x00" * 32
        return self._tree[-1][0]

    def _build_tree(self, leaves: list) -> list:
        """Build complete binary Merkle tree."""
        if not leaves:
            return []

        # Pad to power of 2
        n = 1
        while n < len(leaves):
            n *= 2
        padded = leaves + [b"\x00" * 32] * (n - len(leaves))

        levels = [padded]
        current = padded
        while len(current) > 1:
            next_level = []
            for i in range(0, len(current), 2):
                combined = current[i] + current[i + 1]
                h = blake3_mod.blake3(combined, key=self.key).digest()
                next_level.append(h)
            levels.append(next_level)
            current = next_level
        return levels

    def get_proof(self, leaf_idx: int) -> list:
        """Get Merkle proof for a single leaf."""
        proof = []
        idx = leaf_idx
        for level in self._tree[:-1]:
            sibling = idx ^ 1
            if sibling < len(level):
                proof.append(level[sibling])
            else:
                proof.append(b"\x00" * 32)
            idx //= 2
        return proof

    def get_multileaf_proof(self, leaf_indices: list) -> bytes:
        """Get a multileaf Merkle proof (serialized as expected by pearl_mining)."""
        # For pearl_mining, the proof is the concatenation of sibling hashes
        # needed to verify all requested leaves.
        if not leaf_indices:
            return b""

        # Compute which siblings are needed
        needed_siblings = set()
        requested_set = set(leaf_indices)

        current_indices = set(leaf_indices)
        all_siblings = []

        for level_idx, level in enumerate(self._tree[:-1]):
            next_indices = set()
            for idx in sorted(current_indices):
                sibling = idx ^ 1
                if sibling not in current_indices:
                    needed_siblings.add((level_idx, sibling))
                    if sibling < len(level):
                        all_siblings.append(level[sibling])
                    else:
                        all_siblings.append(b"\x00" * 32)
                next_indices.add(idx // 2)
            current_indices = next_indices

        return b"".join(all_siblings)

    def leaf_indices_from_rows(self, row_indices: list) -> list:
        """Convert matrix row indices to leaf indices."""
        return list(row_indices)


# =====================================================================
# Noise Generation (matches noise_generation.py)
# =====================================================================
def np_mul_hi_u32(a: np.uint32, b: np.uint32):
    prod64 = a.astype(np.uint64) * b.astype(np.uint64)
    return (prod64 >> np.uint64(32)).astype(np.uint32)


class NoiseGenerator:
    def __init__(self, noise_rank=128, noise_range=128):
        self.noise_rank = noise_rank
        idxs_per_col = 2
        _noise_range = noise_range // idxs_per_col
        self.zero_point_translation = _noise_range // 2
        self.range_mask = _noise_range - 1
        self.rank_mask = noise_rank - 1

    def _get_random_hash(self, index, seed, key, prepend_index):
        message_prepend = np.zeros(8, dtype=np.int32)
        message_prepend[prepend_index] = 1 + index
        message_bytes = message_prepend.tobytes() + seed
        return blake3_mod.blake3(message_bytes, key=key).digest()

    def generate_noise_matrices(self, key_A, key_B, A_rows, common_dim, B_cols):
        seed_A = (torch.frombuffer(bytearray(b"A_tensor" + b"\x00" * 24), dtype=torch.uint8)
                  .numpy().tobytes())
        seed_B = (torch.frombuffer(bytearray(b"B_tensor" + b"\x00" * 24), dtype=torch.uint8)
                  .numpy().tobytes())

        A_L = self._generate_uniform_random_matrix(seed_A, key_A, A_rows)
        A_R = self._generate_permutation_matrix(seed_A, key_A, self.noise_rank, common_dim, True)
        B_L = self._generate_permutation_matrix(seed_B, key_B, common_dim, self.noise_rank, False)
        B_R = self._generate_uniform_random_matrix(seed_B, key_B, B_cols).T
        return A_L, A_R, B_L, B_R

    def _generate_uniform_random_matrix(self, seed, key, rows):
        cols = self.noise_rank
        draws = int(ceil(rows * cols / BLAKE3_DIGEST_SIZE))
        random_bytes = b"".join(self._get_random_hash(i, seed, key, 0) for i in range(draws))
        random_tensor = torch.frombuffer(bytearray(random_bytes), dtype=torch.uint8)[:rows * cols]
        return (((random_tensor & self.range_mask) - self.zero_point_translation)
                .to(torch.int8).view(rows, cols))

    def _generate_permutation_matrix(self, seed, key, rows, cols, assign_columns):
        noise_matrix = torch.zeros(rows, cols, dtype=torch.int8)
        required_lines = cols if assign_columns else rows
        bytes_per_lines = 4
        draws = int(ceil(required_lines * bytes_per_lines / BLAKE3_DIGEST_SIZE))

        for i in range(draws):
            random_hash = self._get_random_hash(i, seed, key, 1)
            random_uint32_array = np.frombuffer(random_hash, dtype=np.uint32)
            for k_idx in range(BLAKE3_DIGEST_SIZE // bytes_per_lines):
                random_uint32 = random_uint32_array[k_idx]
                first_idx = random_uint32 & self.rank_mask
                second_idx = first_idx ^ (
                    1 + np_mul_hi_u32(np.uint32(self.noise_rank - 1), random_uint32)
                )
                permutation = torch.zeros(self.noise_rank, dtype=torch.int8)
                permutation[first_idx] = 1
                permutation[second_idx] = -1
                assignment_index = i * BLAKE3_DIGEST_SIZE // bytes_per_lines + k_idx
                if assignment_index >= required_lines:
                    break
                if assign_columns:
                    noise_matrix[:, assignment_index] = permutation
                else:
                    noise_matrix[assignment_index, :] = permutation
        return noise_matrix


# =====================================================================
# Commitment Hash (matches commitment_hash.py)
# =====================================================================
def _bind_root(merkle_root: bytes, dim: int, salt: bytes) -> bytes:
    return blake3_mod.blake3(
        merkle_root + dim.to_bytes(4, "little") + _BIND_PAD, key=salt
    ).digest()


def get_commitment_hash(A, B_t, incomplete_header_bytes, mining_config, *, salted_dims=None):
    """Compute commitment hash from matrices."""
    key = blake3_mod.blake3(incomplete_header_bytes + mining_config.to_bytes()).digest()
    tree_A = MatrixMerkleTree(A, key)
    tree_B = MatrixMerkleTree(B_t, key)

    A_root = tree_A.root
    B_root = tree_B.root

    if salted_dims is not None:
        m, n = salted_dims
        A_root = _bind_root(A_root, m, SEED_SALT_A)
        B_root = _bind_root(B_root, n, SEED_SALT_B)

    commitment_B = blake3_mod.blake3(key + B_root).digest()
    commitment_A = blake3_mod.blake3(commitment_B + A_root).digest()
    return commitment_A, commitment_B, key


# =====================================================================
# Inner Hash (matches inner_hash.py)
# =====================================================================
def rotl32(x, n):
    x = np.uint32(x)
    return np.uint32((x << n) | (x >> (32 - n)))


def xor_reduce_tile(tile: torch.Tensor) -> np.uint32:
    """XOR-reduce a tile to a single uint32."""
    flat = tile.contiguous().to(torch.int32).numpy().flatten()
    # Convert to uint32 view
    flat_bytes = flat.tobytes()
    words = np.frombuffer(flat_bytes, dtype=np.uint32)
    result = np.uint32(0)
    for w in words:
        result ^= w
    return result


# =====================================================================
# NoisyGEMM Mining Engine
# =====================================================================
class GPUMiner:
    """NoisyGEMM miner with GPU acceleration for T4."""

    def __init__(self, m=4096, n=4096, k=4096, device="cuda"):
        self.m = m
        self.n = n
        self.k = k
        self.device = device
        self.noise_gen = NoiseGenerator(NOISE_RANK, NOISE_RANGE)
        self.nonces_tried = 0
        self.blocks_found = 0

    def _generate_signal_matrices(self, nonce: int):
        """Generate random int8 signal matrices A and B."""
        torch.manual_seed(nonce)
        data_range = 256 - NOISE_RANGE  # 128
        min_val = -data_range // 2      # -64
        max_val = min_val + data_range - 1  # 63

        A = torch.randint(min_val, max_val + 1, (self.m, self.k), dtype=torch.int8)
        B = torch.randint(min_val, max_val + 1, (self.k, self.n), dtype=torch.int8)
        return A, B

    def _get_mining_config(self):
        """Create MiningConfiguration matching the tile patterns."""
        rows_pattern = PeriodicPattern.from_list(ROWS_PATTERN)
        cols_pattern = PeriodicPattern.from_list(COLS_PATTERN)
        return MiningConfiguration(
            common_dim=self.k,
            rank=NOISE_RANK,
            mma_type=MMAType.Int7xInt7ToInt32,
            rows_pattern=rows_pattern,
            cols_pattern=cols_pattern,
        )

    def mine_one(self, incomplete_header_bytes: bytes, target: int, cert_version: int):
        """
        Mine a single nonce attempt.

        Returns (PlainProof, mining_config) on success, (None, None) on miss.
        """
        nonce = random.randint(0, 2**64 - 1)
        self.nonces_tried += 1

        mining_config = self._get_mining_config()

        # Determine salted_dims based on cert version
        cv = CertVersion(cert_version)
        salted_dims = (self.m, self.n) if cv.uses_salted_seeds else None

        # Generate signal matrices
        A, B = self._generate_signal_matrices(nonce)

        # Compute commitment hash
        B_t = B.T.contiguous()
        commitment_A, commitment_B, key = get_commitment_hash(
            A, B_t, incomplete_header_bytes, mining_config, salted_dims=salted_dims
        )

        # Generate noise
        E_AL, E_AR, E_BL, E_BR = self.noise_gen.generate_noise_matrices(
            commitment_A, commitment_B, self.m, self.k, self.n
        )

        # Compute noised matrices
        E_A = torch.matmul(E_AL.to(torch.int32), E_AR.to(torch.int32)).to(torch.int8)
        E_B = torch.matmul(E_BL.to(torch.int32), E_BR.to(torch.int32)).to(torch.int8)

        A_noised = (A + E_A).contiguous()
        B_noised = (B + E_B).contiguous()

        # Compute pow_key from commitment_A (noise_seed_A)
        pow_key = commitment_A

        # Adjust target for rank penalty
        adjusted_target = penalized_target_bound(target, mining_config)
        if adjusted_target is None:
            return None, None

        # GPU matmul: A_noised @ B_noised (the hot path)
        if self.device == "cuda" and torch.cuda.is_available():
            A_gpu = A_noised.to(torch.float16).to("cuda")
            B_gpu = B_noised.to(torch.float16).to("cuda")
            C_noised_gpu = torch.matmul(A_gpu, B_gpu)
            C_noised = C_noised_gpu.to(torch.int32).cpu()
            del A_gpu, B_gpu, C_noised_gpu
        else:
            C_noised = torch.matmul(A_noised.to(torch.int32), B_noised.to(torch.int32))

        # Check PoW: tiled inner hash → transcript → blake3 check
        found_block = False
        found_row = 0
        found_col = 0

        # Process tiles
        for tile_i in range(0, self.m - HASH_TILE_H + 1, NOISE_RANK):
            if found_block:
                break
            for tile_j in range(0, self.n - HASH_TILE_W + 1, NOISE_RANK):
                if found_block:
                    break

                # For each hash tile position within this matmul tile
                tile_h_end = min(tile_i + NOISE_RANK, self.m)
                tile_w_end = min(tile_j + NOISE_RANK, self.n)

                for hi in range((tile_h_end - tile_i) // HASH_TILE_H):
                    if found_block:
                        break
                    for wi in range((tile_w_end - tile_j) // HASH_TILE_W):
                        if found_block:
                            break

                        row_start = tile_i + hi * HASH_TILE_H
                        col_start = tile_j + wi * HASH_TILE_W

                        # Build transcript across k reductions
                        transcript = [np.uint32(0)] * TRANSCRIPT_SIZE_U32
                        for p in range(0, self.k, NOISE_RANK):
                            p_end = min(p + NOISE_RANK, self.k)
                            if p_end - p < NOISE_RANK:
                                continue  # skip partial k tiles

                            # Accumulate partial C for this k-tile
                            # The tile of C_noised at these coordinates already
                            # has the full accumulation, so we need the partial sums
                            # For the reference miner, each k-reduction accumulates
                            # and hashes the running sum. We need to replicate this.
                            partial_C = torch.matmul(
                                A_noised[row_start:row_start+HASH_TILE_H, p:p_end].to(torch.int32),
                                B_noised[p:p_end, col_start:col_start+HASH_TILE_W].to(torch.int32)
                            )

                            # XOR-reduce the tile
                            combined = xor_reduce_tile(partial_C)

                            # Accumulate into transcript
                            reduction_count = p // NOISE_RANK
                            idx = reduction_count % TRANSCRIPT_SIZE_U32
                            transcript[idx] = rotl32(transcript[idx], HASH_ACCUMULATE_ROTATION) ^ combined

                        # Check PoW
                        transcript_bytes = b"".join(
                            struct.pack("<I", int(w)) for w in transcript
                        )
                        hash_result = blake3_mod.blake3(transcript_bytes, key=pow_key).digest()
                        hash_int = int.from_bytes(hash_result, "little")

                        if hash_int <= adjusted_target:
                            found_block = True
                            found_row = row_start
                            found_col = col_start

        if not found_block:
            return None, None

        # Block found! Create PlainProof
        self.blocks_found += 1
        print(f"\n  *** BLOCK FOUND! nonce={nonce}, tile=({found_row},{found_col}) ***")

        A_row_indices = list(range(found_row, found_row + HASH_TILE_H))
        B_col_indices = list(range(found_col, found_col + HASH_TILE_W))

        # Build Merkle proofs
        A_tree = MatrixMerkleTree(A, key)
        B_tree = MatrixMerkleTree(B_t, key)

        a_leaf_indices = A_tree.leaf_indices_from_rows(A_row_indices)
        b_leaf_indices = B_tree.leaf_indices_from_rows(B_col_indices)

        a_proof_bytes = A_tree.get_multileaf_proof(a_leaf_indices)
        b_proof_bytes = B_tree.get_multileaf_proof(b_leaf_indices)

        a_merkle_proof = MatrixMerkleProof(proof=a_proof_bytes, row_indices=A_row_indices)
        b_merkle_proof = MatrixMerkleProof(proof=b_proof_bytes, row_indices=B_col_indices)

        plain_proof = PlainProof(
            m=self.m,
            n=self.n,
            k=self.k,
            noise_rank=NOISE_RANK,
            a_merkle_proof=a_merkle_proof,
            bt_merkle_proof=b_merkle_proof,
        )

        # Verify locally
        try:
            block_header = IncompleteBlockHeader.from_bytes(incomplete_header_bytes)
            check_cert_version_eligible(cert_version, plain_proof)
            is_valid, msg = verify_plain_proof_for_cert_version(
                cert_version, block_header, plain_proof
            )
            if is_valid:
                print(f"  Local verification: PASSED")
            else:
                print(f"  Local verification: FAILED - {msg}")
                return None, None
        except Exception as e:
            print(f"  Local verification error: {e} (submitting anyway)")

        return plain_proof, mining_config


# =====================================================================
# Main Mining Loop
# =====================================================================
def main():
    parser = argparse.ArgumentParser(description="Pearl GPU Pool Miner")
    parser.add_argument("--pool", default="pearl-us-ord.lproute.com:3360",
                        help="Pool address host:port")
    parser.add_argument("--wallet", required=True,
                        help="Pearl wallet address (prl1...)")
    parser.add_argument("--worker", default="t4gpu",
                        help="Worker name")
    parser.add_argument("--dims", default="4096",
                        help="Matrix dimensions M=N=K (default: 4096)")
    parser.add_argument("--device", default="cuda",
                        help="Device: cuda or cpu")
    parser.add_argument("--debug", action="store_true",
                        help="Enable debug output")
    args = parser.parse_args()

    host, port = args.pool.rsplit(":", 1)
    port = int(port)
    dim = int(args.dims)

    print(f"""
╔══════════════════════════════════════════════╗
║       Pearl GPU Pool Miner v1.0              ║
╠══════════════════════════════════════════════╣
║  Pool:   {host}:{port:<24}║
║  Wallet: {args.wallet[:20]}...    ║
║  Worker: {args.worker:<36}║
║  Dims:   {dim}x{dim}x{dim:<24}║
║  Device: {args.device:<36}║
╚══════════════════════════════════════════════╝
""")

    # Check GPU
    if args.device == "cuda":
        if torch.cuda.is_available():
            gpu = torch.cuda.get_device_name(0)
            print(f"  GPU: {gpu}")
        else:
            print("  WARNING: CUDA not available, falling back to CPU")
            args.device = "cpu"

    # Initialize miner
    miner = GPUMiner(m=dim, n=dim, k=dim, device=args.device)

    # Connect to pool
    client = PoolClient(host, port)
    reconnect_delay = 5

    while True:
        try:
            client.connect()
            reconnect_delay = 5
            print("  Requesting work from pool...")

            # Get initial mining job
            job_data = client.get_mining_info()
            incomplete_header = base64.b64decode(job_data["incomplete_header_bytes"])
            target = job_data["target"]
            cert_version = job_data.get("cert_version", 1)

            print(f"  Got job: target={target}, cert_v={cert_version}, header={len(incomplete_header)}B")

            start_time = time.time()
            last_job_check = time.time()
            last_status = time.time()

            while True:
                # Try mining
                proof, config = miner.mine_one(incomplete_header, target, cert_version)

                if proof is not None:
                    # Submit!
                    print("  Submitting proof to pool...")
                    try:
                        result = client.submit_plain_proof(proof, job_data)
                        print(f"  Submission result: {result}")
                    except Exception as e:
                        print(f"  Submission failed: {e}")

                # Periodic status
                now = time.time()
                if now - last_status >= 30:
                    elapsed = now - start_time
                    rate = miner.nonces_tried / elapsed if elapsed > 0 else 0
                    print(f"  [{time.strftime('%H:%M:%S')}] "
                          f"nonces={miner.nonces_tried}, "
                          f"rate={rate:.1f}/s, "
                          f"blocks={miner.blocks_found}")
                    last_status = now

                # Check for new work every 5 seconds
                if now - last_job_check >= 5:
                    try:
                        new_job = client.get_mining_info()
                        new_header = base64.b64decode(new_job["incomplete_header_bytes"])
                        if new_header != incomplete_header:
                            incomplete_header = new_header
                            target = new_job["target"]
                            cert_version = new_job.get("cert_version", 1)
                            job_data = new_job
                            print(f"  New job: target={target}, cert_v={cert_version}")
                    except Exception as e:
                        print(f"  Job refresh error: {e}")
                    last_job_check = now

        except KeyboardInterrupt:
            print("\n  Shutting down...")
            client.close()
            elapsed = time.time() - start_time if 'start_time' in dir() else 0
            print(f"  Total nonces: {miner.nonces_tried}")
            print(f"  Blocks found: {miner.blocks_found}")
            sys.exit(0)

        except Exception as e:
            print(f"  Connection error: {e}")
            if args.debug:
                traceback.print_exc()
            client.close()
            print(f"  Reconnecting in {reconnect_delay}s...")
            time.sleep(reconnect_delay)
            reconnect_delay = min(reconnect_delay * 2, 120)


if __name__ == "__main__":
    main()
MINER_EOF

echo ""
echo "============================================="
echo "  Deployment complete!"
echo "============================================="
echo ""
echo "  To start mining:"
echo "  cd $WORKDIR && source .venv/bin/activate"
echo "  python pool_miner.py --wallet $WALLET --worker $WORKER"
echo ""
echo "  Or use the Rust mine() function for faster mining:"
echo "  python fast_miner.py --wallet $WALLET --worker $WORKER"
echo ""
