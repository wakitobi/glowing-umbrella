#!/usr/bin/env python3
"""
Pearl Fast Pool Miner — uses the Rust mine() function for maximum speed.

The pearl_mining.mine() function does everything in optimized Rust:
  - Generate matrices, noise, commitments
  - NoisyGEMM with PoW check
  - Build PlainProof

We just need to:
  1. Get work from pool (getMiningInfo)
  2. Call pearl_mining.mine() in a loop
  3. Submit PlainProof when found (submitPlainProof)
"""
import argparse
import base64
import json
import os
import socket
import sys
import time
import traceback
from typing import Any, Optional

# --- pearl_mining Rust bindings ---
from pearl_mining import (
    IncompleteBlockHeader,
    MiningConfiguration,
    MMAType,
    PeriodicPattern,
    PlainProof,
    mine,
    check_cert_version_eligible,
    penalized_target_bound,
    verify_plain_proof_for_cert_version,
)

# =====================================================================
# Constants — must match the reference miner defaults
# =====================================================================
NOISE_RANK = 128
# Default dimensions
DEFAULT_M = 4096
DEFAULT_N = 4096
DEFAULT_K = 4096

# Hash tile patterns from MinerSettings
ROWS_PATTERN = [0, 8]
COLS_PATTERN = [
    0, 1, 8, 9, 16, 17, 24, 25, 32, 33, 40, 41, 48, 49, 56, 57,
    64, 65, 72, 73, 80, 81, 88, 89, 96, 97, 104, 105, 112, 113, 120, 121,
    128, 129, 136, 137, 144, 145, 152, 153, 160, 161, 168, 169, 176, 177, 184, 185,
    192, 193, 200, 201, 208, 209, 216, 217, 224, 225, 232, 233, 240, 241, 248, 249,
]


# =====================================================================
# Pool JSON-RPC Client
# =====================================================================
class PoolClient:
    """JSON-RPC client for LuckyPool / pearl-gateway protocol."""

    def __init__(self, host: str, port: int, timeout: float = 30.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self._sock: Optional[socket.socket] = None
        self._reader = None
        self._writer = None
        self._req_id = 0

    def connect(self):
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.settimeout(self.timeout)
        self._sock.connect((self.host, self.port))
        self._reader = self._sock.makefile("r", encoding="utf-8")
        self._writer = self._sock.makefile("w", encoding="utf-8")
        print(f"  Connected to {self.host}:{self.port}")

    def close(self):
        for f in (self._reader, self._writer, self._sock):
            if f:
                try:
                    f.close()
                except Exception:
                    pass
        self._sock = None

    @property
    def connected(self):
        return self._sock is not None

    def call(self, method: str, params: Any = None) -> Any:
        self._req_id += 1
        request = {
            "jsonrpc": "2.0",
            "method": method,
            "id": self._req_id,
            "params": params if params is not None else {},
        }
        msg = json.dumps(request) + "\n"
        self._writer.write(msg)
        self._writer.flush()

        line = self._reader.readline()
        if not line:
            raise ConnectionError("Pool closed connection")
        response = json.loads(line.strip())

        if "error" in response:
            err = response["error"]
            code = err.get("code", 0)
            message = err.get("message", "unknown")
            raise RuntimeError(f"Pool error {code}: {message}")

        if response.get("id") != self._req_id:
            raise RuntimeError(
                f"Response ID mismatch: expected {self._req_id}, got {response.get('id')}"
            )
        return response.get("result")

    def get_mining_info(self) -> dict:
        return self.call("getMiningInfo")

    def submit_plain_proof(self, plain_proof: PlainProof, mining_job: dict):
        return self.call("submitPlainProof", {
            "plain_proof": plain_proof.to_base64(),
            "mining_job": mining_job,
        })


# =====================================================================
# Mining Configuration
# =====================================================================
def make_mining_config(k: int) -> MiningConfiguration:
    """Create MiningConfiguration matching the consensus params."""
    return MiningConfiguration(
        common_dim=k,
        rank=NOISE_RANK,
        mma_type=MMAType.Int7xInt7ToInt32,
        rows_pattern=PeriodicPattern.from_list(ROWS_PATTERN),
        cols_pattern=PeriodicPattern.from_list(COLS_PATTERN),
    )


# =====================================================================
# Main
# =====================================================================
def main():
    parser = argparse.ArgumentParser(
        description="Pearl Fast Pool Miner (Rust mine() engine)"
    )
    parser.add_argument(
        "--pool", default="pearl-us-ord.lproute.com:3360",
        help="Pool address host:port"
    )
    parser.add_argument(
        "--wallet", required=True,
        help="Pearl wallet address (prl1...)"
    )
    parser.add_argument(
        "--worker", default="t4gpu",
        help="Worker name for pool tracking"
    )
    parser.add_argument(
        "--m", type=int, default=DEFAULT_M,
        help="Matrix M dimension (rows of A)"
    )
    parser.add_argument(
        "--n", type=int, default=DEFAULT_N,
        help="Matrix N dimension (cols of B)"
    )
    parser.add_argument(
        "--k", type=int, default=DEFAULT_K,
        help="Matrix K dimension (common dim)"
    )
    parser.add_argument(
        "--signal-range", type=str, default=None,
        help="Signal range as 'lo,hi' (e.g. '-64,63'). Default: None (let mine() decide)"
    )
    parser.add_argument(
        "--threads", type=int, default=None,
        help="Rayon thread count (env RAYON_NUM_THREADS)"
    )
    parser.add_argument(
        "--debug", action="store_true",
        help="Verbose debug output"
    )
    args = parser.parse_args()

    host, port_str = args.pool.rsplit(":", 1)
    port = int(port_str)

    # Set rayon threads
    if args.threads:
        os.environ["RAYON_NUM_THREADS"] = str(args.threads)

    signal_range = None
    if args.signal_range:
        lo, hi = args.signal_range.split(",")
        signal_range = (int(lo), int(hi))

    print(f"""
╔══════════════════════════════════════════════════╗
║     Pearl Fast Pool Miner v1.0 (Rust engine)     ║
╠══════════════════════════════════════════════════╣
║  Pool:   {host}:{port}
║  Wallet: {args.wallet[:24]}...
║  Worker: {args.worker}
║  Dims:   {args.m}x{args.n}x{args.k}
║  Signal: {signal_range or 'auto'}
╚══════════════════════════════════════════════════╝
""")

    mining_config = make_mining_config(args.k)
    client = PoolClient(host, port)
    reconnect_delay = 5

    total_nonces = 0
    total_blocks = 0
    session_start = time.time()

    while True:
        try:
            client.connect()
            reconnect_delay = 5

            # Get work
            print("  Requesting work from pool...")
            job_data = client.get_mining_info()
            incomplete_header_bytes = base64.b64decode(job_data["incomplete_header_bytes"])
            target = job_data["target"]
            cert_version = job_data.get("cert_version", 1)

            print(f"  Job: target={target}, cert_v={cert_version}, "
                  f"header={len(incomplete_header_bytes)}B")

            block_header = IncompleteBlockHeader.from_bytes(incomplete_header_bytes)
            last_job_check = time.time()
            last_status = time.time()
            loop_start = time.time()

            while True:
                # ── Mine one nonce (Rust does all the heavy lifting) ──
                try:
                    plain_proof = mine(
                        m=args.m,
                        n=args.n,
                        k=args.k,
                        block_header=block_header,
                        mining_config=mining_config,
                        signal_range=signal_range,
                        wrong_jackpot_hash=False,
                        cert_version=cert_version,
                    )
                except Exception as e:
                    if args.debug:
                        print(f"  mine() error: {e}")
                    total_nonces += 1
                    # mine() raises on no-solution; continue to next nonce
                    pass
                else:
                    # mine() returned a PlainProof — block found!
                    total_nonces += 1
                    total_blocks += 1
                    print(f"\n  *** BLOCK FOUND #{total_blocks}! ***")

                    # Verify locally
                    try:
                        check_cert_version_eligible(cert_version, plain_proof)
                        ok, msg = verify_plain_proof_for_cert_version(
                            cert_version, block_header, plain_proof
                        )
                        print(f"  Local verify: {'PASS' if ok else 'FAIL: ' + msg}")
                    except Exception as e:
                        print(f"  Local verify error: {e}")

                    # Submit to pool
                    try:
                        result = client.submit_plain_proof(plain_proof, job_data)
                        print(f"  Pool accepted: {result}")
                    except Exception as e:
                        print(f"  Pool submission failed: {e}")

                # ── Status ──
                now = time.time()
                if now - last_status >= 30:
                    elapsed = now - session_start
                    rate = total_nonces / elapsed if elapsed > 0 else 0
                    print(f"  [{time.strftime('%H:%M:%S')}] "
                          f"nonces={total_nonces} rate={rate:.2f}/s "
                          f"blocks={total_blocks}")
                    last_status = now

                # ── Refresh work ──
                if now - last_job_check >= 5:
                    try:
                        new_job = client.get_mining_info()
                        new_hdr = base64.b64decode(new_job["incomplete_header_bytes"])
                        if new_hdr != incomplete_header_bytes:
                            incomplete_header_bytes = new_hdr
                            target = new_job["target"]
                            cert_version = new_job.get("cert_version", 1)
                            job_data = new_job
                            block_header = IncompleteBlockHeader.from_bytes(
                                incomplete_header_bytes
                            )
                            print(f"  New job: target={target} cert_v={cert_version}")
                    except Exception as e:
                        if args.debug:
                            print(f"  Job refresh error: {e}")
                    last_job_check = now

        except KeyboardInterrupt:
            print("\n  Shutting down...")
            client.close()
            elapsed = time.time() - session_start
            print(f"  Session: {elapsed:.0f}s, {total_nonces} nonces, "
                  f"{total_blocks} blocks")
            sys.exit(0)

        except Exception as e:
            print(f"  Error: {e}")
            if args.debug:
                traceback.print_exc()
            client.close()
            print(f"  Reconnecting in {reconnect_delay}s...")
            time.sleep(reconnect_delay)
            reconnect_delay = min(reconnect_delay * 2, 120)


if __name__ == "__main__":
    main()
