#!/usr/bin/env python3
"""
Pearl GPU Miner — single-file T4-optimized standalone.
Copy this one file to any Linux box with a GPU and run:
  pip install blake3 torch && python pearl_miner_t4.py

NoisyGEMM PoW: generate random int8 matrices, inject deterministic noise,
run GPU GEMM, XOR-reduce output tiles, check blake3 hash against target.

GPU strategy auto-detection:
  sm75 (T4):   fp16 tensor cores (65 TFLOPS) — lossless for int7 values
  sm80 (A100): torch._int_mm (native int8 tensor cores)
  sm90 (H100): torch._int_mm (native int8 tensor cores)
  CPU:         int32 matmul fallback
"""
import os, sys, time, struct, logging, argparse, json, socket
from math import ceil

import numpy as np
import torch
from blake3 import blake3

log = logging.getLogger('pearl')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S',
)

# ══════════════════════════════════════════════════════════════════════════════
# Noise Generation — deterministic from blake3-keyed seeds
# ══════════════════════════════════════════════════════════════════════════════
DIGEST = 32

def _mul_hi_u32(a, b):
    return (np.uint64(a) * np.uint64(b) >> np.uint64(32)).astype(np.uint32)

class NoiseGen:
    def __init__(self, rank=128, nrange=128):
        self.rank = rank
        self.nrange = nrange
        _nr = nrange // 2
        self.zp = _nr // 2
        self.rmask = _nr - 1
        self.rkmask = rank - 1

    def _h(self, idx, seed, key, pi):
        mp = np.zeros(8, dtype=np.int32)
        mp[pi] = 1 + idx
        return blake3(mp.tobytes() + seed, key=key).digest()

    def _uniform(self, seed, key, rows):
        cols = self.rank
        draws = int(ceil(rows * cols / DIGEST))
        rb = b''.join(self._h(i, seed, key, 0) for i in range(draws))
        rt = torch.frombuffer(bytearray(rb), dtype=torch.uint8)[:rows * cols]
        return ((rt & self.rmask) - self.zp).to(torch.int8).view(rows, cols)

    def _perm(self, seed, key, rows, cols, assign_cols):
        noise = torch.zeros(rows, cols, dtype=torch.int8)
        req = cols if assign_cols else rows
        draws = int(ceil(req * 4 / DIGEST))
        for i in range(draws):
            rh = self._h(i, seed, key, 1)
            ru = np.frombuffer(rh, dtype=np.uint32)
            for k in range(DIGEST // 4):
                rv = ru[k]
                f = int(rv & self.rkmask)
                s = int(f ^ (1 + _mul_hi_u32(np.uint32(self.rank - 1), rv)))
                p = torch.zeros(self.rank, dtype=torch.int8)
                p[f] = 1; p[s] = -1
                ai = i * DIGEST // 4 + k
                if ai >= req: break
                if assign_cols: noise[:, ai] = p
                else: noise[ai, :] = p
        return noise

    def gen(self, kA, kB, m, k, n):
        sA = b'A_tensor' + b'\x00' * 24
        sB = b'B_tensor' + b'\x00' * 24
        return (
            self._uniform(sA, kA, m),
            self._perm(sA, kA, self.rank, k, True),
            self._perm(sB, kB, k, self.rank, False),
            self._uniform(sB, kB, n).T,
        )


# ══════════════════════════════════════════════════════════════════════════════
# Inner Hash / Transcript / PoW check
# ══════════════════════════════════════════════════════════════════════════════
T_U32 = 16
H_ROT = 13

def rotl32(x, n):
    v = int(x) & 0xFFFFFFFF
    return np.uint32(((v << n) & 0xFFFFFFFF) | (v >> (32 - n)))

class Transcript:
    __slots__ = ('d',)
    def __init__(self):
        self.d = [np.uint32(0)] * T_U32
    def acc(self, rc, ch):
        i = rc % T_U32
        self.d[i] = rotl32(self.d[i], H_ROT) ^ ch
    def to_bytes(self):
        return b''.join(struct.pack('<I', int(w)) for w in self.d)

def check_pow(t, key, target):
    h = blake3(t.to_bytes(), key=key).digest()
    return int.from_bytes(h, 'little') <= target

def xor_reduce(C, th, tw):
    H, W = C.shape
    nh, nw = H // th, W // tw
    if nh == 0 or nw == 0:
        return torch.empty((0, 0), dtype=torch.int32, device=C.device)
    t = C[:nh*th, :nw*tw].reshape(nh, th, nw, tw).permute(0, 2, 1, 3).reshape(nh, nw, -1)
    v = t
    while v.shape[-1] > 1:
        h = v.shape[-1] // 2
        if v.shape[-1] % 2 == 1:
            v = torch.bitwise_xor(torch.bitwise_xor(v[..., :h], v[..., h:2*h]), v[..., -1:])
        else:
            v = torch.bitwise_xor(v[..., :h], v[..., h:])
    return v.squeeze(-1)


# ══════════════════════════════════════════════════════════════════════════════
# NoisyGEMM Engine
# ══════════════════════════════════════════════════════════════════════════════
class Engine:
    def __init__(self, rank=128, nrange=128, th=16, tw=16, dev='cuda'):
        self.rank = rank
        self.nrange = nrange
        self.th = th
        self.tw = tw
        self.dev = torch.device(dev)
        self.ng = NoiseGen(rank, nrange)
        self.hashes = 0
        self.found = 0

        if torch.cuda.is_available():
            cap = torch.cuda.get_device_capability(self.dev)
            self.sm = cap[0] * 10 + cap[1]
            self.use_intmm = self.sm >= 80
        else:
            self.sm = 0
            self.use_intmm = False

    def _mm(self, A, B):
        if self.use_intmm:
            return torch._int_mm(A, B)
        elif torch.cuda.is_available():
            return torch.matmul(A.to(torch.float16), B.to(torch.float16)).to(torch.int32)
        else:
            return torch.matmul(A.to(torch.int32), B.to(torch.int32))

    def mine(self, m, n, k, pow_key, target):
        dr = 256 - self.nrange
        lo = -(dr // 2)
        A = torch.randint(lo, lo + dr, (m, k), dtype=torch.int8)
        B = torch.randint(lo, lo + dr, (k, n), dtype=torch.int8)

        E_AL, E_AR, E_BL, E_BR = self.ng.gen(pow_key, pow_key, m, k, n)
        EA = torch.matmul(E_AL.to(torch.int32), E_AR.to(torch.int32)).to(torch.int8)
        EB = torch.matmul(E_BL.to(torch.int32), E_BR.to(torch.int32)).to(torch.int8)
        An = (A + EA).to(torch.int8).to(self.dev)
        Bn = (B + EB).to(torch.int8).to(self.dev)

        r = self.rank
        th, tw = self.th, self.tw
        hit = False; info = None

        for i in range(0, m, r):
            im = min(i + r, m)
            for j in range(0, n, r):
                jm = min(j + r, n)
                bh, bw = im - i, jm - j
                nh, nw = bh // th, bw // tw
                ts = [[Transcript() for _ in range(nw)] for _ in range(nh)]
                rc = 0
                Cb = torch.zeros((bh, bw), dtype=torch.int32, device=self.dev)

                for p in range(0, k, r):
                    pm = min(p + r, k)
                    Cb += self._mm(An[i:im, p:pm], Bn[p:pm, j:jm])
                    if bh >= th and bw >= tw and (pm - p) == r:
                        hh = xor_reduce(Cb, th, tw).cpu().numpy().view(np.uint32)
                        self.hashes += hh.size
                        for hi in range(nh):
                            for wi in range(nw):
                                ts[hi][wi].acc(rc, np.uint32(hh[hi, wi]))
                        rc += 1

                if not hit and nh > 0 and nw > 0:
                    for hi in range(nh):
                        for wi in range(nw):
                            if check_pow(ts[hi][wi], pow_key, target):
                                hit = True
                                self.found += 1
                                info = {
                                    'A_rows': list(range(i + hi*th, i + (hi+1)*th)),
                                    'B_cols': list(range(j + wi*tw, j + (wi+1)*tw)),
                                }
                                break
                        if hit: break
        return hit, info


# ══════════════════════════════════════════════════════════════════════════════
# Gateway JSON-RPC client
# ══════════════════════════════════════════════════════════════════════════════
class GatewayClient:
    def __init__(self, host='localhost', port=8337):
        self.host = host
        self.port = port
        self.sock = None
        self._id = 0

    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))
        self.sock.settimeout(30)

    def close(self):
        if self.sock:
            self.sock.close()
            self.sock = None

    def _call(self, method, params=None):
        self._id += 1
        req = json.dumps({'jsonrpc': '2.0', 'method': method, 'params': params or {}, 'id': self._id})
        self.sock.sendall((req + '\n').encode())
        buf = b''
        while b'\n' not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError('Gateway closed connection')
            buf += chunk
        return json.loads(buf.split(b'\n')[0])

    def get_mining_info(self):
        resp = self._call('getMiningInfo')
        if 'error' in resp:
            raise RuntimeError(f"RPC error: {resp['error']}")
        return resp.get('result', resp)


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════
def main():
    p = argparse.ArgumentParser(description='Pearl GPU Miner — T4 optimized')
    p.add_argument('--standalone', action='store_true', help='Benchmark mode (no gateway)')
    p.add_argument('--device', default='cuda', help='PyTorch device')
    p.add_argument('-m', type=int, default=4096, help='Matrix rows')
    p.add_argument('-n', type=int, default=4096, help='Matrix cols')
    p.add_argument('-k', type=int, default=4096, help='Common dim')
    p.add_argument('--host', default='localhost', help='Gateway host')
    p.add_argument('--port', type=int, default=8337, help='Gateway port')
    args = p.parse_args()

    engine = Engine(dev=args.device)
    strat = 'int_mm' if engine.use_intmm else 'fp16' if torch.cuda.is_available() else 'int32'

    if torch.cuda.is_available():
        log.info(f'GPU: {torch.cuda.get_device_name()} | sm{engine.sm} | strategy: {strat}')
        log.info(f'VRAM: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB')
    else:
        log.info(f'CPU mode | strategy: {strat}')

    if args.standalone:
        log.info(f'Standalone mining: {args.m}x{args.k}@{args.n}')
        target = (1 << 256) - 1
        header = os.urandom(32)
        it = 0; t0 = time.time(); lr = t0

        while True:
            pk = blake3(header + it.to_bytes(8, 'little')).digest()
            hit, info = engine.mine(args.m, args.n, args.k, pk, target)
            it += 1
            now = time.time()
            if now - lr >= 5.0:
                el = now - t0
                log.info(f'[iter {it}] {engine.hashes:,} hashes in {el:.1f}s = {engine.hashes/el:,.0f} H/s | found={engine.found}')
                lr = now
    else:
        log.info(f'Gateway mode: {args.host}:{args.port}')
        while True:
            try:
                gw = GatewayClient(args.host, args.port)
                gw.connect()
                log.info('Connected to gateway')

                it = 0; t0 = time.time(); lr = t0
                while True:
                    job = gw.get_mining_info()
                    target = int(job.get('target', (1 << 256) - 1))
                    header_hex = job.get('incomplete_header_bytes', '')
                    header = bytes.fromhex(header_hex) if header_hex else os.urandom(32)

                    pk = blake3(header + it.to_bytes(8, 'little')).digest()
                    hit, info = engine.mine(args.m, args.n, args.k, pk, target)
                    it += 1
                    now = time.time()
                    if now - lr >= 10.0:
                        el = now - t0
                        log.info(f'[iter {it}] {engine.hashes/el:,.0f} H/s | found={engine.found}')
                        lr = now
                    if hit:
                        log.info(f'BLOCK FOUND iter {it}: {info}')
            except (ConnectionError, OSError) as e:
                log.warning(f'Gateway error: {e}. Reconnecting in 5s...')
                time.sleep(5)
            except KeyboardInterrupt:
                log.info('Stopped.')
                break

if __name__ == '__main__':
    main()
