#!/bin/bash
# deploy_t4.sh — deploy pearl-gpu-miner to a T4 Linux machine
# Usage: scp -r pearl-gpu-miner-py/ user@host:~ && ssh user@host 'bash ~/pearl-gpu-miner-py/deploy_t4.sh'
# Or:    bash deploy_t4.sh   (if already on the T4 box)
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "=== Pearl GPU Miner — T4 Deploy ==="

# Detect GPU
if ! command -v nvidia-smi &>/dev/null; then
    echo "ERROR: nvidia-smi not found. Install NVIDIA drivers first."
    exit 1
fi

echo "GPU detected:"
nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader

# Install Python deps
if command -v uv &>/dev/null; then
    echo "Using uv..."
    uv pip install --system torch numpy blake3
elif command -v pip3 &>/dev/null; then
    echo "Using pip3..."
    pip3 install torch numpy blake3
elif command -v pip &>/dev/null; then
    echo "Using pip..."
    pip install torch numpy blake3
else
    echo "ERROR: No pip/uv found. Install Python first."
    exit 1
fi

# Verify CUDA + run benchmark
python3 - "$SCRIPT_DIR" <<'PYEOF'
import sys, os, time
script_dir = sys.argv[1]

import torch
assert torch.cuda.is_available(), "CUDA not available!"
cap = torch.cuda.get_device_capability()
name = torch.cuda.get_device_name()
sm = cap[0] * 10 + cap[1]
print(f"  GPU: {name}")
print(f"  Compute capability: sm{sm}")
print(f"  CUDA version: {torch.version.cuda}")
print(f"  Memory: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB")
if sm >= 75:
    print("  Tensor cores: YES (fp16)")
else:
    print("  WARNING: No tensor cores, will use fallback matmul")

sys.path.insert(0, script_dir)
from pearl_gpu_miner.noisy_gemm import NoisyGemmEngine
from blake3 import blake3

engine = NoisyGemmEngine(device="cuda")
strategy = "int_mm (sm80+)" if engine._use_int_mm else "fp16 tensor cores" if engine._use_fp16 else "int32 fallback"
print(f"  Matmul strategy: {strategy}")

# Warmup
pow_key = blake3(b"warmup").digest()
engine.mine_random(256, 256, 256, pow_key, 0)

# Benchmark
print("  Benchmarking 4096x4096...")
t0 = time.time()
iters = 3
for i in range(iters):
    pow_key = blake3(f"bench_{i}".encode()).digest()
    engine.mine_random(4096, 4096, 4096, pow_key, 0)
elapsed = time.time() - t0
rate = engine.total_hashes / elapsed
print(f"  {iters} iters in {elapsed:.1f}s = {rate:,.0f} H/s (4096x4096)")
print()
print("Deploy OK. Run with:")
print(f"  cd {script_dir}")
print(f"  python3 -m pearl_gpu_miner.cli --standalone --device cuda")
print(f"  python3 -m pearl_gpu_miner.cli --host <gateway> --port 8337")
PYEOF
