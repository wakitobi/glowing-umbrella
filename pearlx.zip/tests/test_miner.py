"""Test the Pearl GPU miner core logic on CPU."""
import os
import sys
import time

import numpy as np
import torch
from blake3 import blake3

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pearl_gpu_miner.noise import NoiseGenerator
from pearl_gpu_miner.inner_hash import Transcript, check_pow, xor_reduce_tiles_gpu, rotl32
from pearl_gpu_miner.noisy_gemm import NoisyGemmEngine
from pearl_gpu_miner.merkle import MerkleTree
from pearl_gpu_miner.commitment import commitment_hash_from_roots


def test_noise_generation():
    """Test that noise generation is deterministic and in range."""
    print("=== test_noise_generation ===")
    ng = NoiseGenerator(noise_rank=128, noise_range=128)
    key_A = blake3(b"test_key_A").digest()
    key_B = blake3(b"test_key_B").digest()

    E_AL, E_AR, E_BL, E_BR = ng.generate(key_A, key_B, 256, 256, 256)

    # Check shapes
    assert E_AL.shape == (256, 128), f"E_AL shape: {E_AL.shape}"
    assert E_AR.shape == (128, 256), f"E_AR shape: {E_AR.shape}"
    assert E_BL.shape == (256, 128), f"E_BL shape: {E_BL.shape}"
    assert E_BR.shape == (128, 256), f"E_BR shape: {E_BR.shape}"

    # E_A = E_AL @ E_AR should be within noise range
    E_A = torch.matmul(E_AL.to(torch.int32), E_AR.to(torch.int32))
    zero_point = 128 // 2  # noise_range // 2
    assert torch.all(E_A >= -zero_point), f"E_A min: {E_A.min()}"
    assert torch.all(E_A <= zero_point), f"E_A max: {E_A.max()}"

    # Determinism: same seeds -> same noise
    E_AL2, E_AR2, E_BL2, E_BR2 = ng.generate(key_A, key_B, 256, 256, 256)
    assert torch.equal(E_AL, E_AL2), "E_AL not deterministic"
    assert torch.equal(E_AR, E_AR2), "E_AR not deterministic"
    assert torch.equal(E_BL, E_BL2), "E_BL not deterministic"
    assert torch.equal(E_BR, E_BR2), "E_BR not deterministic"

    # Different keys -> different noise
    key_A2 = blake3(b"different_key").digest()
    E_AL3, _, _, _ = ng.generate(key_A2, key_B, 256, 256, 256)
    assert not torch.equal(E_AL, E_AL3), "Different keys should produce different noise"

    # Check permutation matrix properties
    for col in range(E_AR.shape[1]):
        col_vals = E_AR[:, col]
        nonzero = (col_vals != 0).sum().item()
        assert nonzero <= 2, f"Permutation col {col} has {nonzero} nonzero entries (expected <= 2)"
        ones = (col_vals == 1).sum().item()
        neg_ones = (col_vals == -1).sum().item()
        assert ones <= 1 and neg_ones <= 1, f"Col {col}: {ones} ones, {neg_ones} neg_ones"

    print("  PASSED - shapes, range, determinism, permutation structure OK")


def test_xor_reduce():
    """Test XOR reduction of tiles."""
    print("=== test_xor_reduce ===")
    # Create a known int32 tensor
    torch.manual_seed(42)
    C = torch.randint(-1000, 1000, (32, 32), dtype=torch.int32)

    # Manual XOR reduce of first 16x16 tile
    tile = C[:16, :16]
    expected = np.bitwise_xor.reduce(tile.flatten().numpy().view(np.uint32))

    # GPU (CPU fallback) reduce
    result = xor_reduce_tiles_gpu(C, 16, 16)
    assert result.shape == (2, 2), f"Expected (2,2), got {result.shape}"

    actual = result[0, 0].item()
    # Compare as uint32 bit patterns
    expected_u32 = int(expected)
    actual_u32 = actual if actual >= 0 else actual + (1 << 32)
    assert expected_u32 == actual_u32, f"XOR mismatch: {expected_u32:#x} != {actual_u32:#x}"

    print("  PASSED - XOR reduce matches numpy reference")


def test_transcript():
    """Test transcript accumulation and PoW check."""
    print("=== test_transcript ===")
    t = Transcript()

    # Accumulate a few hashes
    t.rotl_xor_into(0, np.uint32(0x12345678))
    t.rotl_xor_into(1, np.uint32(0xABCDEF00))
    t.rotl_xor_into(16, np.uint32(0x11111111))  # wraps to idx 0

    # Check that idx 0 was modified twice
    assert t.data[0] != np.uint32(0), "Transcript[0] should be non-zero"
    assert t.data[1] != np.uint32(0), "Transcript[1] should be non-zero"
    assert t.data[2] == np.uint32(0), "Transcript[2] should still be zero"

    # Test serialization
    transcript_bytes = t.to_bytes()
    assert len(transcript_bytes) == 64, f"Transcript should be 64 bytes, got {len(transcript_bytes)}"

    # PoW check with easiest target (should always pass)
    pow_key = blake3(b"test_pow_key").digest()
    assert check_pow(t, pow_key, (1 << 256) - 1), "Easiest target should always pass"

    # PoW check with hardest target (should fail)
    assert not check_pow(t, pow_key, 0), "Hardest target should always fail"

    print("  PASSED - transcript accumulation and PoW check OK")


def test_denoising():
    """Test that NoisyGEMM correctly denoises to the true product."""
    print("=== test_denoising ===")
    engine = NoisyGemmEngine(
        noise_range=128,
        noise_rank=128,
        hash_tile_h=16,
        hash_tile_w=16,
        device="cpu",
    )

    m, k, n = 256, 256, 256
    data_range = 256 - 128  # = 128
    lo = -(data_range // 2)  # = -64
    hi = lo + data_range - 1  # = 63

    torch.manual_seed(123)
    A = torch.randint(lo, hi + 1, (m, k), dtype=torch.int8)
    B = torch.randint(lo, hi + 1, (k, n), dtype=torch.int8)

    # True product
    C_true = torch.matmul(A.to(torch.int32), B.to(torch.int32))

    # Noisy product (with easiest target — always finds "blocks")
    pow_key = blake3(b"test_denoise").digest()
    C_denoised, found, _ = engine.mine_step(A, B, pow_key, (1 << 256) - 1)

    # Denoised result should equal true product
    max_diff = (C_denoised - C_true).abs().max().item()
    assert max_diff == 0, f"Denoising error: max diff = {max_diff}"

    print(f"  PASSED - denoised output matches true product exactly (max_diff={max_diff})")


def test_merkle_tree():
    """Test Merkle tree construction."""
    print("=== test_merkle_tree ===")
    key = blake3(b"merkle_test").digest()

    data = os.urandom(128 * 64)  # 128 rows x 64 cols
    tree = MerkleTree(data, 128, 64, key)

    assert len(tree.root) == 32, f"Root should be 32 bytes, got {len(tree.root)}"
    assert len(tree.leaf_hashes) >= 128, f"Should have >= 128 leaves, got {len(tree.leaf_hashes)}"

    # Determinism
    tree2 = MerkleTree(data, 128, 64, key)
    assert tree.root == tree2.root, "Merkle root should be deterministic"

    # Different data -> different root
    data2 = os.urandom(128 * 64)
    tree3 = MerkleTree(data2, 128, 64, key)
    assert tree.root != tree3.root, "Different data should produce different root"

    print("  PASSED - Merkle tree construction and determinism OK")


def test_commitment_hash():
    """Test commitment hash derivation."""
    print("=== test_commitment_hash ===")
    A_root = os.urandom(32)
    B_root = os.urandom(32)
    key = blake3(b"commitment_test").digest()

    seed_A, seed_B = commitment_hash_from_roots(A_root, B_root, key)
    assert len(seed_A) == 32 and len(seed_B) == 32

    # Determinism
    seed_A2, seed_B2 = commitment_hash_from_roots(A_root, B_root, key)
    assert seed_A == seed_A2 and seed_B == seed_B2

    # Salted V3 derivation
    seed_A3, seed_B3 = commitment_hash_from_roots(A_root, B_root, key, salted_dims=(256, 256))
    assert seed_A3 != seed_A, "Salted derivation should differ from unsalted"

    print("  PASSED - commitment hash derivation OK")


def test_mine_random_cpu():
    """Test a small mining run on CPU."""
    print("=== test_mine_random_cpu ===")
    engine = NoisyGemmEngine(
        noise_range=128,
        noise_rank=128,
        hash_tile_h=16,
        hash_tile_w=16,
        device="cpu",
    )

    m, n, k = 256, 256, 256
    pow_key = blake3(b"mining_test").digest()

    # Mine with easiest target — every hash tile should "find a block"
    found, info = engine.mine_random(m, n, k, pow_key, (1 << 256) - 1)
    assert found, "Should find block with easiest target"
    assert info is not None
    assert "A_row_indices" in info
    assert "B_col_indices" in info
    assert len(info["A_row_indices"]) == 16  # hash_tile_h
    assert len(info["B_col_indices"]) == 16  # hash_tile_w
    print(f"  Found block: A_rows={info['A_row_indices'][:3]}..., B_cols={info['B_col_indices'][:3]}...")

    # Mine with hardest target — should not find block
    found2, _ = engine.mine_random(m, n, k, pow_key, 0)
    assert not found2, "Should not find block with hardest target"

    print(f"  PASSED - total hashes computed: {engine.total_hashes}")


def test_benchmark_cpu():
    """Quick CPU benchmark."""
    print("=== test_benchmark_cpu (small) ===")
    engine = NoisyGemmEngine(
        noise_range=128,
        noise_rank=128,
        hash_tile_h=16,
        hash_tile_w=16,
        device="cpu",
    )

    m, n, k = 256, 256, 256
    iters = 3
    t0 = time.time()
    for i in range(iters):
        pow_key = blake3(f"bench_{i}".encode()).digest()
        engine.mine_random(m, n, k, pow_key, 0)
    elapsed = time.time() - t0
    rate = engine.total_hashes / elapsed
    print(f"  {iters} iterations in {elapsed:.2f}s = {rate:,.0f} H/s ({m}x{n}x{k} on CPU)")


if __name__ == "__main__":
    test_noise_generation()
    test_xor_reduce()
    test_transcript()
    test_denoising()
    test_merkle_tree()
    test_commitment_hash()
    test_mine_random_cpu()
    test_benchmark_cpu()
    print("\n=== ALL TESTS PASSED ===")
