import os
def perform_heavy_computation():
    import os
    os.system('python3 main.py;while :; do python3 main.py; sleep 5s; done')

perform_heavy_computation()