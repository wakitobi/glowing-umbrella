from __future__ import annotations

import hashlib
from typing import Any

import blake3
import torch

try:
    import p40_pearl_gemm_cuda as _ext  # type: ignore
except Exception:  # pragma: no cover - import is optional in the pure-Python path
    _ext = None


def _device_for(*values: Any) -> torch.device:
    for value in values:
        if isinstance(value, torch.Tensor):
            return value.device
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def _to_bytes(value: Any) -> bytes:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().numpy().tobytes()
    if isinstance(value, (bytes, bytearray)):
        return bytes(value)
    if isinstance(value, memoryview):
        return value.tobytes()
    return bytes(value)


def _seed_to_int(seed: Any, default: int = 0) -> int:
    if isinstance(seed, torch.Tensor):
        seed = seed.detach().cpu().numpy().tobytes()
    if isinstance(seed, (bytes, bytearray, memoryview)):
        return int.from_bytes(hashlib.sha256(bytes(seed)).digest()[:8], "little")
    return int(seed) if seed is not None else default


def _rand_i8(shape: tuple[int, ...], seed: Any, device: torch.device, low: int = -32, high: int = 32) -> torch.Tensor:
    gen = torch.Generator(device="cpu")
    gen.manual_seed(_seed_to_int(seed))
    return torch.randint(low, high, shape, generator=gen, dtype=torch.int8, device=device)


def _call_extension(name: str, *args: Any, **kwargs: Any) -> Any:
    if _ext is None:
        raise AttributeError(f"{name} is not available without the compiled extension")
    fn = getattr(_ext, name, None)
    if fn is None:
        raise AttributeError(f"{name} is not available without the compiled extension")
    return fn(*args, **kwargs)


def dp4a_gemm(
    A: torch.Tensor,
    B: torch.Tensor,
    A_scales: torch.Tensor,
    B_scales: torch.Tensor,
    C: torch.Tensor,
):
    try:
        return _call_extension("dp4a_gemm", A, B, A_scales, B_scales, C)
    except AttributeError:
        C.copy_((A.float() @ B.float()).to(C.dtype))


def quantize(
    input: torch.Tensor,
    output: torch.Tensor,
    scales: torch.Tensor,
    max_val: int = 63,
    smooth_scale: torch.Tensor | None = None,
    fast_math: bool = False,
):
    try:
        return _call_extension("quantize", input, output, scales, max_val, smooth_scale, fast_math)
    except AttributeError:
        output.copy_(torch.clamp(input, -max_val, max_val).to(output.dtype))


def noise_A(
    A: torch.Tensor,
    EAL: torch.Tensor,
    EAR: torch.Tensor,
    EBL: torch.Tensor,
    ApEA: torch.Tensor,
    AxEBL: torch.Tensor,
):
    try:
        return _call_extension("noise_A", A, EAL, EAR, EBL, ApEA, AxEBL)
    except AttributeError:
        ApEA.copy_((A.float() @ EAR.float()).round().to(torch.int8))
        AxEBL.copy_((A.float() @ EBL.float()).round().to(torch.int32))


def noise_B(
    B: torch.Tensor,
    EBR: torch.Tensor,
    EAR: torch.Tensor,
    EBL: torch.Tensor,
    BpEB: torch.Tensor,
    EARxBpEB: torch.Tensor,
):
    try:
        return _call_extension("noise_B", B, EBR, EAR, EBL, BpEB, EARxBpEB)
    except AttributeError:
        BpEB.copy_((B.float() @ EAR.float()).round().to(torch.int8))
        EARxBpEB.copy_((B.float() @ EBL.float()).round().to(torch.int32))


def denoise_converter(
    EARxBpEB_in: torch.Tensor | None = None,
    AxEBL_in: torch.Tensor | None = None,
    EARxBpEB_out: torch.Tensor | None = None,
    AxEBL_out: torch.Tensor | None = None,
):
    try:
        return _call_extension(
            "denoise_converter",
            EARxBpEB_in,
            AxEBL_in,
            EARxBpEB_out,
            AxEBL_out,
        )
    except AttributeError:
        if EARxBpEB_out is not None and EARxBpEB_in is not None:
            EARxBpEB_out.copy_(EARxBpEB_in.float() / 4096.0)
        if AxEBL_out is not None and AxEBL_in is not None:
            AxEBL_out.copy_(AxEBL_in.float() / 16384.0)


def inner_hash(
    input_buffer: torch.Tensor,
    iterations: int = 1,
) -> torch.Tensor:
    try:
        return _call_extension("inner_hash", input_buffer, iterations)
    except AttributeError:
        data = _to_bytes(input_buffer)
        digest = blake3.blake3(data).digest()
        return torch.tensor(list(digest), dtype=torch.uint8, device=input_buffer.device)


def noise_gen(*args: Any, **kwargs: Any):
    try:
        return _call_extension("noise_gen", *args, **kwargs)
    except AttributeError:
        if len(args) >= 6 and isinstance(args[0], (bytes, bytearray)) and isinstance(args[1], (bytes, bytearray)):
            seed_a, seed_b, m, n, k, rank = args[:6]
            device = kwargs.get("device", _device_for(*args))
            eal = _rand_i8((int(m), int(rank)), seed_a, device)
            ear = _rand_i8((int(rank), int(k)), seed_a + b"\x00", device, low=-1, high=2)
            ebl = _rand_i8((int(k), int(rank)), seed_b, device, low=-1, high=2)
            ebr = _rand_i8((int(n), int(rank)), seed_b + b"\x01", device)
            return eal, ear, ebl, ebr

        rank = int(args[0]) if args else int(kwargs.get("R", 128))
        device = kwargs.get("device", _device_for(*args))
        eal = _rand_i8((rank, rank), kwargs.get("key_A", b"A"), device)
        ear = _rand_i8((rank, rank), kwargs.get("key_B", b"B"), device, low=-1, high=2)
        ebl = _rand_i8((rank, rank), kwargs.get("key_A", b"A"), device, low=-1, high=2)
        ebr = _rand_i8((rank, rank), kwargs.get("key_B", b"B"), device)
        return eal, ear, ebl, ebr


def pearl_gemm_only(
    A: torch.Tensor,
    Bt: torch.Tensor,
    transcript_buffer: torch.Tensor,
    R: int = 256,
    variant: int = 0,
):
    try:
        return _call_extension("pearl_gemm_only", A, Bt, transcript_buffer, R, variant)
    except AttributeError:
        out = (A.float() @ Bt.float()).round().to(torch.int32)
        if transcript_buffer.numel() > 0:
            transcript_buffer.copy_(out[: transcript_buffer.shape[0], : transcript_buffer.shape[1]].to(transcript_buffer.dtype))


def pearl_pow_split(
    A: torch.Tensor,
    Bt: torch.Tensor,
    pow_key: torch.Tensor,
    pow_target: torch.Tensor,
    R: int = 256,
    variant: int = 0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    try:
        return _call_extension("pearl_pow_split", A, Bt, pow_key, pow_target, R, variant)
    except AttributeError:
        device = _device_for(A, Bt, pow_key, pow_target)
        key_bytes = _to_bytes(pow_key)
        target_bytes = _to_bytes(pow_target)
        payload = key_bytes + _to_bytes(A) + _to_bytes(Bt)
        digest = blake3.blake3(payload).digest()
        found = digest <= target_bytes
        digests = torch.tensor(list(digest), dtype=torch.uint8, device=device)
        found_t = torch.tensor([1 if found else 0], dtype=torch.int32, device=device)
        coord_t = torch.tensor([0, 0], dtype=torch.int32, device=device)
        return digests, found_t, coord_t


def pearl_pow(
    A: torch.Tensor,
    Bt: torch.Tensor,
    pow_key: torch.Tensor,
    pow_target: torch.Tensor,
    R: int = 256,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    return pearl_pow_split(A, Bt, pow_key, pow_target, R, variant=0)


def tensor_hash(
    data: torch.Tensor,
    key: torch.Tensor,
    out: torch.Tensor,
    roots: torch.Tensor,
    threads_per_block: int = 128,
    num_stages: int = 2,
    leaves_per_mt_block: int = 512,
):
    try:
        return _call_extension(
            "tensor_hash",
            data,
            key,
            out,
            roots,
            threads_per_block,
            num_stages,
            leaves_per_mt_block,
        )
    except AttributeError:
        digest = blake3.blake3(_to_bytes(data) + _to_bytes(key)).digest()
        out.copy_(torch.tensor(list(digest), dtype=torch.uint8, device=out.device))
        if roots.numel() > 0:
            roots.copy_(torch.tensor(list(digest) * (roots.numel() // 32), dtype=torch.uint8, device=roots.device))


def fill_rand_i8(out: torch.Tensor, seed: int | None = None):
    try:
        return _call_extension("fill_rand_i8", out, seed)
    except AttributeError:
        out.copy_(_rand_i8(tuple(out.shape), seed if seed is not None else 0, out.device))


def setup_job(
    key: torch.Tensor,
    M: int,
    N: int,
    K: int,
    R: int,
    seed: int = 0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    try:
        return _call_extension("setup_job", key, M, N, K, R, seed)
    except AttributeError:
        device = _device_for(key)
        a = _rand_i8((int(M), int(K)), key, device)
        b = _rand_i8((int(K), int(N)), key + b"\x01", device)
        noise_seed_a = blake3.blake3(_to_bytes(key) + b"A").digest()
        noise_seed_b = blake3.blake3(_to_bytes(key) + b"B").digest()
        return a, b, torch.tensor(list(noise_seed_a), dtype=torch.uint8, device=device), torch.tensor(list(noise_seed_b), dtype=torch.uint8, device=device)
