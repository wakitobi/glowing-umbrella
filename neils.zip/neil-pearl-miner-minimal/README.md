# Neil Pearl Miner (Nvidia/AMD)

A high-performance **Pearl (PRL)** proof-of-work miner for **NVIDIA and AMD (beta) GPUs**.

> Mixed-GPU rigs are supported. Ampere/Ada cards run a fused int8 tensor-core kernel
> (GEMM + in-mainloop transcript fold + tensor-core noise generation), bit-exact with
> the Pascal DP4A path; Pascal cards run DP4A.
> 
## Features

- **AMD cards beta support**
- **~7.0 TH/s** sustained on a single Tesla P40 (Pascal DP4A).
- **~30 TH/s** on a single RTX 4050 mobile (Ada) — fused int8 **tensor-core** GEMM +
  in-mainloop transcript fold + tensor-core noise generation, all bit-exact with DP4A.
- **Multi-GPU** — auto-detects every GPU and runs one worker per card, near-linear scaling.
- **Continuous mining** — no idle time waiting between pool jobs.
- **Background proof submission** — finding a share never stalls the search.
- **Solo mining** — mine to your local pearl-gateway node.
- **Pool mining** — built for LuckyPool's Pearl stratum (default) with more pool protocols planned.
- **HiveOS** — full HiveOS custom-miner package.

## Pre-built Releases

Grab the latest binary from the [Releases](https://github.com/neilquicks/neil-pearl-miner/releases) page:

| File | Platform |
|------|----------|
| `neil-miner-windows-x64.zip` | Windows x64 |
| `neil-miner-linux-x64.tar.gz` | Linux (glibc >= 2.31) |

**Requirements:** An up-to-date NVIDIA/AMD driver, and **Windows x64**, **Linux x86-64** (glibc >= 2.31), or **HiveOS**.

## Hashrate Nvidia/AMD

# AMD cards

> Real mining performance may vary depending on drivers,
> overclocking, algorithm updates and network conditions.

| AMD GPU | Hashrate (TH/s) |
|---------|-----------------|
| Vega 56 | 32              |
| Vega 64 | 38              |
| RX 6600 | 60              |
| RX 6700 XT | 94           |
| RX 6800 | 105             |
| RX 6800 XT | 121          |
| RX 6900 XT | 121          |
| RX 7600 | 100              |
| RX 7700 XT | 116          |
| RX 7800 XT | 116          |
| RX 7900 XT | 139          |
| RX 7900 XTX | 151        |
| RX 8800 (est.) | 153      |
| RX 8900 XT (est.) | 155   |
| RX 9800 (est.) | 160      |
| RX 9900 XT (est.) | 220   |

# Nvidia cards

| NVIDIA GPU | Hashrate (TH/s) |
|------------|-----------------|
| RTX 3060   | 55              |
| RTX 3070   | 85              |
| RTX 3080   | 95              |
| RTX 3090   | 110             |
| RTX 4060   | 70              |
| RTX 4070   | 105             |
| RTX 4080   | 158             |
| RTX 4090   | 235             |

### Quick Start

```bat
:: Windows
neil-miner.exe --wallet prl1YOURWALLET --worker rig1
```

```bash
# Linux
./neil-miner --wallet prl1YOURWALLET --worker rig1
```

That's it — it auto-detects all GPUs and starts mining.

## Build from Source

### Prerequisites

| Dependency | Windows | Linux |
|---|---|---|
| **CUDA Toolkit** | 12.x ([NVIDIA](https://developer.nvidia.com/cuda-downloads)) | 12.x |
| **CUTLASS headers** | `git clone --depth 1 https://github.com/NVIDIA/cutlass` | same |
| **Python** | >= 3.12 | >= 3.12 |
| **MSVC** | Visual Studio 2022 (C++ workload) | — |
| **pip packages** | `numpy`, `blake3`, `py-pearl-mining` | same |

Set `CUTLASS_DIR` to the directory containing `cutlass/` and `cute/` headers.

### Windows

```bat
git clone https://github.com/neilquicks/Pascal-Pearl-Miner.git
cd Pascal-Pearl-Miner

:: 1. Build the CUDA library (p40cuda.dll)
packaging\build_capi.bat

:: 2. Install Python deps
pip install numpy blake3 py-pearl-mining

:: 3. Run directly from source
python packaging\p40_miner_lite_main.py --wallet prl1YOURWALLET

:: Or freeze a standalone binary with PyInstaller:
pip install pyinstaller
pyinstaller packaging\p40-miner-lite.spec --noconfirm --distpath dist --workpath build_pyi
dist\neil-miner\p40-miner.exe --wallet prl1YOURWALLET
```

To rebuild the full CUDA extension (includes torch bindings):

```bat
pip install -e .   # requires torch + CUTLASS_DIR
```

### Linux

```bash
git clone https://github.com/neilquicks/Pascal-Pearl-Miner.git
cd Pascal-Pearl-Miner

# 1. Build the CUDA library (libp40cuda.so)
CUTLASS_DIR=/path/to/cutlass/include bash packaging/build_capi.sh

# 2. Install Python deps
pip install numpy blake3 py-pearl-mining

# 3. Run directly from source
python packaging/neil_miner_lite_main.py --wallet prl1YOURWALLET

# Or freeze a standalone binary:
pip install pyinstaller
pyinstaller packaging/neil-miner-lite.spec --noconfirm --distpath dist --workpath build_pyi
./dist/neil-minerneil0-miner --wallet prl1YOURWALLET
```

### HiveOS Package

Build the Linux binary first, then:

```bash
bash packaging/hiveos/build_hiveos_package.sh  # -> p40-miner-hiveos-<ver>.tar.gz
```

Upload to a URL or `scp` to the rig, then add as a Custom miner in HiveOS.

### Development Install

```bash
pip install -e .   # editable install of the torch-based extension
CUTLASS_DIR=... python -c "import p40_pearl_gemm"  # smoke test
```

## Usage

### Options

| Flag | Default | Description |
|---|---|---|
| `--wallet` | _(required)_ | Your Pearl payout address |
| `--worker` | `p40` | Worker name shown on the pool |
| `--pool` | _(auto by GPU)_ | Stratum `host:port`. Auto: Pascal→`pearl-cpu-eu1…:3370`, sm_80+→`pearl-eu2…:3360` |
| `--devices` | _(auto-detect all)_ | GPU selection, e.g. `0,1,2` or `all` |
| `--region` | `4096` | Sub-output search size |
| `--solo` | _(off)_ | Solo mine to local pearl-gateway `HOST:PORT` |

### Multi-GPU

Auto-detects every GPU and runs one worker per card (workers named `<worker>-gpu0`,
`-gpu1`, ...) with a combined-hashrate summary. Each GPU runs as an independent pinned
process with blocking-sync CUDA, giving near-linear scaling on 4–8 GPU rigs. Just run it:

```
neil-miner.exe --wallet prl1YOURWALLET
```

Use `--devices` to select specific cards:

```
neil-miner.exe --wallet prl1YOURWALLET --devices 0,2
```

### Pool Mining

The default pool is picked automatically by GPU class: **tensor-core cards (`sm_80+`)**
use `pearl-eu2.luckypool.io:3360` (GPU difficulty), while **Pascal / DP4A cards** (P40,
GTX 10-series) use `pearl-cpu-eu1.luckypool.io:3370`. On a mixed rig each card picks its
own. Override for any card with `--pool`:

```
neil-miner.exe --wallet prl1YOURWALLET --pool pearl-cpu-eu1.luckypool.io:3370
```

(The CPU pool's low difficulty produces frequent shares whose ~1 GB proof snapshot
stalls a fast GPU between grids — hence the GPU-difficulty default for tensor-core
cards.) Currently only LuckyPool's stratum protocol is supported; more planned.

### Solo Mining

```
neil-miner.exe --solo GATEWAY_HOST:PORT
```

No wallet flag needed — the node's configured address receives block rewards.
The same 1% dev fee applies (GPU mines to the dev's pool wallet during the 1% window).

## License

**Pascal Pearl Miner License** — see [LICENSE](LICENSE).

- Free to use, modify, and distribute (including commercially), **provided the 1% dev fee is retained**.
- Removal or bypass of the dev fee is a license violation in any distributed or commercial deployment.
- **Personal-use exemption**: you may disable the dev fee for strictly personal, non-commercial mining on your own hardware — but the modified version must not be distributed.
