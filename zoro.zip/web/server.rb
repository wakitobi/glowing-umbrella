#!/usr/bin/env ruby
# frozen_string_literal: true
# Serves the browser miner page, injects pool config from ../.env, and proxies
# a chat box to a LOCAL OpenAI-compatible LLM (Ollama / LM Studio / llama.cpp).
# Dependency-free: only Ruby stdlib (socket + json + net/http). Runs on Ruby >= 2.0.

require "socket"
require "json"
require "net/http"
require "uri"

HERE = File.expand_path(File.dirname(__FILE__))
ENV_FILE = File.join(HERE, "..", ".env")
PORT = (ENV["MINER_WEB_PORT"] && !ENV["MINER_WEB_PORT"].empty? ? ENV["MINER_WEB_PORT"].to_i : rand(10000..65000))
BIND = ENV["MINER_WEB_BIND"] || "127.0.0.1"

CONTENT_TYPES = {
  ".html" => "text/html; charset=utf-8",
  ".js"   => "text/javascript; charset=utf-8",
  ".css"  => "text/css; charset=utf-8",
  ".json" => "application/json",
  ".wasm" => "application/wasm",
  ".map"  => "application/json",
  ".ico"  => "image/x-icon",
  ".png"  => "image/png",
  ".svg"  => "image/svg+xml"
}.freeze

# Candidate local LLM endpoints (OpenAI-compatible /v1/chat/completions).
# Overridable via .env keys: llm_url, llm_model.
LLM_CANDIDATES = [
  "http://127.0.0.1:11434/v1/chat/completions", # Ollama
  "http://127.0.0.1:1234/v1/chat/completions",  # LM Studio
  "http://127.0.0.1:8080/v1/chat/completions"   # llama.cpp / llamafile
].freeze

def load_env
  cfg = {}
  File.foreach(ENV_FILE) do |line|
    line = line.strip
    next if line.empty? || line.start_with?("#") || !line.include?("=")
    k, v = line.split("=", 2)
    cfg[k.strip] = v.strip
  end
  cfg
rescue StandardError
  {}
end

# Config the browser is allowed to see: pool info WITHOUT the password.
def public_config
  cfg = load_env
  cfg.reject { |k, _| k.to_s.downcase == "password" }
end

def content_type(path)
  CONTENT_TYPES[File.extname(path).downcase] || "application/octet-stream"
end

def send_response(client, status, body, ctype, extra = {})
  headers = +"HTTP/1.1 #{status}\r\n"
  headers << "Content-Type: #{ctype}\r\n"
  headers << "Content-Length: #{body.bytesize}\r\n"
  headers << "Connection: close\r\n"
  extra.each { |k, v| headers << "#{k}: #{v}\r\n" }
  headers << "\r\n"
  client.write(headers)
  client.write(body)
end

def send_json(client, status, obj, extra = {})
  send_response(client, status, JSON.generate(obj), "application/json",
                { "Cache-Control" => "no-store" }.merge(extra))
end

# Resolve a URL path to a real file inside HERE, blocking traversal.
def resolve_path(url_path)
  url_path = "/index.html" if url_path == "/" || url_path.empty?
  clean = url_path.split("?").first
  fs = File.expand_path(File.join(HERE, clean.sub(%r{\A/}, "")))
  return nil unless fs == HERE || fs.start_with?(HERE + File::SEPARATOR)
  fs
end

# Pick the first LLM endpoint that responds, or the configured one.
def resolve_llm_url
  cfg = load_env
  return cfg["llm_url"] if cfg["llm_url"] && !cfg["llm_url"].empty?
  LLM_CANDIDATES.each do |url|
    u = URI(url)
    base = "#{u.scheme}://#{u.host}:#{u.port}/v1/models"
    begin
      Net::HTTP.start(u.host, u.port, open_timeout: 1, read_timeout: 1) do |http|
        return url if http.get("/v1/models").is_a?(Net::HTTPSuccess)
      end
    rescue StandardError
      next
    end
  end
  nil
end

def llm_model
  cfg = load_env
  return cfg["llm_model"] if cfg["llm_model"] && !cfg["llm_model"].empty?
  ENV["LLM_MODEL"] && !ENV["LLM_MODEL"].empty? ? ENV["LLM_MODEL"] : "local-model"
end

# Build the system prompt describing the miner so the LLM can answer about it.
def system_prompt(cfg, stats)
  <<~SYS
    You are an assistant embedded in the "power2b" browser crypto-miner dashboard.
    Answer the user's questions about the miner's current status and configuration
    concisely and accurately, using ONLY the data below. If asked about something
    not in the data, say you don't have that information. Do not invent numbers.

    POOL CONFIG:
      host: #{cfg['host']}
      port: #{cfg['port']}
      proxy: #{cfg['proxy']}
      username: #{cfg['username']}
      configured threads: #{cfg['threads']}

    LIVE STATUS (from the browser, may be stale a few seconds):
      connection: #{stats['conn']}
      authorized: #{stats['auth']}
      current job: #{stats['job']}
      difficulty: #{stats['diff']}
      active workers: #{stats['workers']}
      hashrate: #{stats['hashrate']}
      accepted shares: #{stats['accepted']}
      rejected shares: #{stats['rejected']}
      accept rate: #{stats['rate']}
      uptime: #{stats['uptime']}
  SYS
end

def handle_chat(client, body)
  req = JSON.parse(body) rescue {}
  user_msgs = req["messages"] || []
  stats = req["stats"] || {}
  cfg = public_config

  url = resolve_llm_url
  if url.nil?
    send_json(client, "503 Service Unavailable", {
      error: "no local LLM found. Start one (e.g. `ollama serve` then `ollama run " \
             "qwen2.5:0.5b`), or set llm_url in .env.",
      hint: "tried: #{LLM_CANDIDATES.join(', ')}"
    })
    return
  end

  messages = [{ "role" => "system", "content" => system_prompt(cfg, stats) }] + user_msgs
  payload = {
    "model" => llm_model,
    "messages" => messages,
    "temperature" => 0.3,
    "stream" => false,
    "max_tokens" => 512
  }

  u = URI(url)
  begin
    resp = Net::HTTP.start(u.host, u.port, open_timeout: 5, read_timeout: 120) do |http|
      post = Net::HTTP::Post.new(u.request_uri)
      post["Content-Type"] = "application/json"
      post.body = JSON.generate(payload)
      http.request(post)
    end
  rescue StandardError => e
    send_json(client, "502 Bad Gateway", { error: "LLM request failed: #{e.class}: #{e.message}" })
    return
  end

  unless resp.is_a?(Net::HTTPSuccess)
    send_json(client, "502 Bad Gateway", { error: "LLM returned #{resp.code}", body: resp.body.to_s[0, 500] })
    return
  end

  data = JSON.parse(resp.body) rescue {}
  reply = data.dig("choices", 0, "message", "content") ||
          data.dig("message", "content") || "(no reply)"
  send_json(client, "200 OK", { reply: reply, model: llm_model, endpoint: url })
end

def handle(client)
  request_line = client.gets
  return if request_line.nil?
  method, raw_path, _ = request_line.split(" ", 3)

  # read headers
  headers = {}
  while (line = client.gets) && line != "\r\n"
    k, v = line.split(":", 2)
    headers[k.strip.downcase] = v.strip if v
  end

  path = raw_path.to_s.split("?").first

  # read body if present
  body = ""
  if (len = headers["content-length"]) && len.to_i.positive?
    body = client.read(len.to_i).to_s
  end

  if method == "POST" && path == "/chat"
    handle_chat(client, body)
    return
  end

  if path == "/config.json"
    # Browser needs the full config (incl. password) to authorize with the pool.
    send_json(client, "200 OK", load_env)
    return
  end

  if path == "/llm-status"
    url = resolve_llm_url
    send_json(client, "200 OK", { available: !url.nil?, endpoint: url, model: llm_model })
    return
  end

  fs = resolve_path(raw_path.to_s)
  if fs.nil? || !File.file?(fs)
    send_response(client, "404 Not Found", "not found", "text/plain; charset=utf-8")
    return
  end

  body = File.binread(fs)
  send_response(client, "200 OK", body, content_type(fs))
rescue Errno::EPIPE, Errno::ECONNRESET
  # client went away mid-write; ignore
end

server = TCPServer.new(BIND, PORT)
puts "miner web UI: http://#{BIND}:#{PORT}/"
$stdout.flush

loop do
  begin
    client = server.accept
  rescue Interrupt
    break
  end
  Thread.new(client) do |c|
    begin
      handle(c)
    ensure
      c.close rescue nil
    end
  end
end
