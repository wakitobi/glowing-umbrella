#!/usr/bin/env ruby
# frozen_string_literal: true
# Launch the power2b web miner: start the Ruby web server (server.rb) and a
# headless Chrome/Chromium pointed at it. Pure Ruby stdlib — no gems.
# Works on Windows, Linux, macOS. Ruby replacement for setup.sh.
#
# Usage:   ruby setup.rb
# Tuning:  MINER_WEB_PORT=8765 MINER_CDP_PORT=9222 ruby setup.rb

require "socket"
require "net/http"
require "rbconfig"

HERE = File.expand_path(File.dirname(__FILE__))
WEB_DIR = File.join(HERE, "web")
WINDOWS = (RbConfig::CONFIG["host_os"] =~ /mswin|mingw|cygwin/)

def rand_port
  rand(10000..65000)
end

PORT = (ENV["MINER_WEB_PORT"] && !ENV["MINER_WEB_PORT"].empty? ? ENV["MINER_WEB_PORT"].to_i : rand_port)
# CDP port also random per launch (kept distinct from the web port).
CDP_PORT = if ENV["MINER_CDP_PORT"] && !ENV["MINER_CDP_PORT"].empty?
             ENV["MINER_CDP_PORT"].to_i
           else
             loop { p = rand_port; break p if p != PORT }
           end
PROFILE = File.join(Dir.home, ".chrome-miner-profile")

# persist chosen ports so stop.rb / the user can find this instance
File.write(File.join(HERE, ".miner-ports"), "WEB_PORT=#{PORT}\nCDP_PORT=#{CDP_PORT}\n")

def http_ok?(host, port, path = "/", timeout = 1)
  Net::HTTP.start(host, port, open_timeout: timeout, read_timeout: timeout) do |http|
    http.get(path)
  end
  true
rescue StandardError
  false
end

# --- locate a real chrome/chromium binary ---
def find_chrome
  if WINDOWS
    candidates = [
      ENV["CHROME_BIN"],
      "#{ENV['ProgramFiles']}\\Google\\Chrome\\Application\\chrome.exe",
      "#{ENV['ProgramFiles(x86)']}\\Google\\Chrome\\Application\\chrome.exe",
      "#{ENV['LOCALAPPDATA']}\\Google\\Chrome\\Application\\chrome.exe",
      "#{ENV['ProgramFiles']}\\Microsoft\\Edge\\Application\\msedge.exe",
      "#{ENV['ProgramFiles(x86)']}\\Microsoft\\Edge\\Application\\msedge.exe"
    ].compact
    candidates.each { |c| return c if File.file?(c) }
    %w[chrome.exe msedge.exe].each do |name|
      path = which(name)
      return path if path
    end
  else
    %w[google-chrome google-chrome-stable chromium chromium-browser chrome].each do |name|
      path = which(name)
      return path if path
    end
    [
      "/opt/google/chrome/chrome",
      *Dir.glob("#{Dir.home}/.cache/ms-playwright/chromium-*/chrome-linux/chrome")
    ].each { |c| return c if File.file?(c) }
  end
  nil
end

def which(cmd)
  exts = WINDOWS ? [".exe", ".bat", ".cmd", ""] : [""]
  ENV["PATH"].to_s.split(File::PATH_SEPARATOR).each do |dir|
    exts.each do |ext|
      full = File.join(dir, cmd + ext)
      return full if File.file?(full) && File.executable?(full)
    end
  end
  nil
end

# --- install a browser on Linux when none is present (mirrors setup.sh) ---
def sudo
  Process.uid.zero? ? [] : ["sudo"]
end

def run(*cmd)
  system(*cmd, out: File::NULL, err: File::NULL)
end

def install_chrome_linux
  puts "== no chrome/chromium found; attempting install =="
  deb = "/tmp/gchrome.deb"

  # 1) Debian/Ubuntu: official google-chrome-stable .deb
  if which("apt-get")
    url = "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"
    fetched = if which("wget")
                run("wget", "-q", url, "-O", deb)
              elsif which("curl")
                run("curl", "-sL", url, "-o", deb)
              else
                false
              end
    if fetched && File.file?(deb) && File.size(deb) > 100_000
      run(*sudo, "apt-get", "update")
      if run(*sudo, "apt-get", "install", "-y", deb)
        File.delete(deb) rescue nil
        return true if find_chrome
      end
    end
    File.delete(deb) rescue nil
    # fall back to distro chromium
    run(*sudo, "apt-get", "install", "-y", "chromium") ||
      run(*sudo, "apt-get", "install", "-y", "chromium-browser")
    return true if find_chrome
  end

  # 2) Fedora/RHEL
  if which("dnf")
    run(*sudo, "dnf", "install", "-y", "chromium")
    return true if find_chrome
  elsif which("yum")
    run(*sudo, "yum", "install", "-y", "chromium")
    return true if find_chrome
  end

  # 3) Arch
  if which("pacman")
    run(*sudo, "pacman", "-Sy", "--noconfirm", "chromium")
    return true if find_chrome
  end

  # 4) Alpine
  if which("apk")
    run(*sudo, "apk", "add", "--no-cache", "chromium")
    return true if find_chrome
  end

  # 5) Last resort: playwright chromium (container-friendly, no root deps)
  if which("npx")
    run("npx", "--yes", "playwright@latest", "install", "chromium", "--with-deps")
    return true if find_chrome
  end

  false
end

def spawn_bg(*cmd, log:)
  logf = File.open(log, "w")
  opts = { out: logf, err: logf }
  opts[:pgroup] = true unless WINDOWS
  pid = Process.spawn(*cmd, opts)
  logf.close
  Process.detach(pid)
  pid
end

# --- start web server ---
if http_ok?("127.0.0.1", PORT)
  puts "web server already running on :#{PORT}"
else
  env = { "MINER_WEB_PORT" => PORT.to_s }
  server_pid = spawn_bg(env, RbConfig.ruby, File.join(WEB_DIR, "server.rb"),
                        log: File.join(HERE, "server.log"))
  File.write(File.join(HERE, "server.pid"), server_pid.to_s)
  ok = false
  40.times do
    if http_ok?("127.0.0.1", PORT)
      ok = true
      break
    end
    sleep 0.25
  end
  unless ok
    warn "ERROR: web server did not come up on :#{PORT}. server.log:"
    warn File.read(File.join(HERE, "server.log")) rescue nil
    exit 1
  end
  puts "web server started (pid #{server_pid}): http://127.0.0.1:#{PORT}/"
end

# --- start headless chrome ---
chrome = find_chrome
if chrome.nil? && !WINDOWS
  chrome = find_chrome if install_chrome_linux
end
if chrome.nil?
  warn "ERROR: no Chrome/Chromium/Edge found and auto-install failed."
  warn "Install one manually, or set CHROME_BIN to the browser path."
  warn "Server is running at http://127.0.0.1:#{PORT}/ — open it in any browser to mine."
  exit 1
end
puts "browser: #{chrome}"

if http_ok?("127.0.0.1", CDP_PORT, "/json")
  puts "headless chrome already running (CDP :#{CDP_PORT})"
  exit 0
end

flags = [
  "--headless=new", "--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage",
  "--no-first-run", "--disable-extensions", "--disable-background-networking",
  "--mute-audio", "--remote-allow-origins=*",
  "--remote-debugging-port=#{CDP_PORT}", "--user-data-dir=#{PROFILE}",
  "--window-size=1280,900"
]

chrome_pid = spawn_bg(chrome, *flags, "http://127.0.0.1:#{PORT}/",
                      log: File.join(HERE, "chrome.log"))
File.write(File.join(HERE, "chrome.pid"), chrome_pid.to_s)

ok = false
24.times do
  if http_ok?("127.0.0.1", CDP_PORT, "/json")
    ok = true
    break
  end
  sleep 0.5
end

if ok
  puts "headless chrome started (pid #{chrome_pid}), mining now."
else
  warn "chrome did not expose CDP on :#{CDP_PORT}; it may still be mining. chrome.log:"
  warn File.read(File.join(HERE, "chrome.log")) rescue nil
end

puts
puts "  web UI: http://127.0.0.1:#{PORT}/   (open in any browser to watch stats)"
puts "  CDP:    http://127.0.0.1:#{CDP_PORT}/json"
puts "  stop:   ruby stop.rb"
