# power2b web miner (Linux deploy)

Runs the mbc power2b miner inside headless Chrome, driven by a web page that
talks Stratum over WebSocket straight to your Koyeb proxy (same pool config as
the Python miner). No third-party relay, no fee.

## Layout

    .env                 pool config (proxy wss URL, username, password, threads)
    web/index.html       the embedded miner page (JS Stratum client + stats UI)
    web/worker.js        power2b WASM miner worker (works on any OS/arch)
    web/server.py        tiny python3 web server, injects .env config, port 8765
    setup.sh             install chromium if needed, start server + headless chrome
    stop.sh              stop both

## Quick start (bash — Linux)

    tar xzf web-miner-linux.tar.gz
    cd web-miner-linux
    bash setup.sh

That's it. It auto-installs Chromium when missing (needs sudo for apt/dnf),
then launches headless Chrome mining the page. ~5 seconds later it's hashing.

## Quick start (Ruby — Windows / Linux / macOS)

Pure Ruby stdlib port, no gems required (Ruby >= 2.0; WEBrick not needed):

    ruby setup.rb        # starts server.rb + headless Chrome/Edge, begins mining
    ruby stop.rb         # stops both

    # tuning
    MINER_WEB_PORT=8765 MINER_CDP_PORT=9222 ruby setup.rb

Files:
    web/server.rb        Ruby web server (stdlib socket+json+net/http): serves the
                         page, injects .env at /config.json, and proxies /chat to a
                         local LLM
    setup.rb             finds Chrome/Chromium/Edge, launches headless, starts server
    stop.rb              kills server + chrome by pid (taskkill on Windows, TERM on *nix)

On Windows it auto-detects Chrome or Edge in Program Files; set CHROME_BIN to
override. If no browser is found, the server still runs — open the printed
http://127.0.0.1:PORT/ URL in any browser to mine.

## Chat box — ask the miner (local LLM)

The dashboard has a chat box at the bottom that answers natural-language
questions about the miner's live status and config ("what's my accept rate?",
"is it authorized?", "which pool am I on?"). It talks to a LOCAL, OpenAI-
compatible LLM — nothing leaves your machine, no API key, no cloud.

The server auto-detects a running local LLM on these endpoints (in order):

    http://127.0.0.1:11434   Ollama
    http://127.0.0.1:1234    LM Studio
    http://127.0.0.1:8080    llama.cpp / llamafile

Start one, then reload the page. Easiest is Ollama with a tiny model:

    # install: https://ollama.com/download   (or: curl -fsSL https://ollama.com/install.sh | sh)
    ollama serve                 # starts the API on :11434
    ollama run qwen2.5:0.5b      # ~400MB, fast on CPU — or llama3.2:1b, gemma2:2b

The green line under "Ask the miner" shows the detected model/endpoint. If no
LLM is running the chat box says so and mining is unaffected.

Override detection / model via .env:

    llm_url=http://127.0.0.1:11434/v1/chat/completions
    llm_model=qwen2.5:0.5b

How it works: the browser sends your question + the current dashboard stats to
the server's /chat endpoint; the server builds a system prompt from your pool
config and live stats and forwards it to the local LLM. The LLM only sees what's
on your dashboard — it answers grounded in real numbers, not guesses.

Check it:
    curl http://127.0.0.1:8765/          # page is served
    tail -f web/server.log chrome.log   # logs
    # open http://127.0.0.1:8765/ in any browser to watch stats live
    # (use --headless=new --remote-debugging-port=9222 for CDP automation)

Stop:   bash stop.sh
Restart: bash setup.sh

## Tuning

    MINER_WEB_PORT=8765 MINER_WORKERS=7 bash setup.sh   # workers + ports
    # note: page caps workers at min(7, CPU cores) via .env threads

## Notes

- .env contains your pool credentials — keep the tarball private.
- server binds 127.0.0.1 only. To view the dashboard from another machine,
  set MINER_WEB_PORT and edit server.py bind to 0.0.0.0 (or ssh -L 8765:localhost:8765).
- Wasm hashrate (~250-400 H/s/7 workers) is much lower than the native Python
  miner. Real valid shares, just slow — fine for monitoring/experiments.
