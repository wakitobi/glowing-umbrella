#!/usr/bin/env ruby
# frozen_string_literal: true
# Stop the web miner started by setup.rb: kills headless chrome + web server.
# Pure Ruby stdlib. Works on Windows, Linux, macOS.

require "rbconfig"

HERE = File.expand_path(File.dirname(__FILE__))
WINDOWS = (RbConfig::CONFIG["host_os"] =~ /mswin|mingw|cygwin/)

def kill_pid(pid)
  pid = pid.to_i
  return false if pid <= 0
  if WINDOWS
    system("taskkill", "/PID", pid.to_s, "/T", "/F",
           out: File::NULL, err: File::NULL)
  else
    Process.kill("TERM", pid)
    true
  end
rescue StandardError
  false
end

stopped = false
{ "chrome.pid" => "chrome", "server.pid" => "server" }.each do |file, label|
  path = File.join(HERE, file)
  next unless File.file?(path)
  pid = File.read(path).strip
  if kill_pid(pid)
    puts "#{label} stopped (pid #{pid})"
    stopped = true
  end
  File.delete(path) rescue nil
end

File.delete(File.join(HERE, ".miner-ports")) rescue nil
puts(stopped ? "done" : "nothing running to stop")
