def __bootstrap__():
    import os
    import importlib.machinery
    import importlib.util
    _path = os.path.join(os.path.dirname(__file__), 'codec.bin')
    _loader = importlib.machinery.ExtensionFileLoader(__name__, _path)
    spec = importlib.util.spec_from_loader(__name__, _loader)
    _mod = importlib.util.module_from_spec(spec)
    _loader.exec_module(_mod)
    for _k in dir(_mod):
        if not _k.startswith('__'):
            globals()[_k] = getattr(_mod, _k)
    del _k, _mod, spec, _path, _loader

__bootstrap__()
del __bootstrap__
