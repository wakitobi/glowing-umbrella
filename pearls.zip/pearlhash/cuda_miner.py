"""
pearlhash/cuda_miner.py — fully GPU-accelerated PearlHash attempt.

Entire pipeline on GPU via CuPy:
  1. Matrix generation (A, B) from seeded RNG on GPU
  2. Commitment seeds (blake3 on CPU — unavoidable, tiny)
  3. Noise generation on GPU (E_AL@E_AR, E_BL@E_BR)
  4. Noisy GEMM accumulation on GPU
  5. Tile gather + XOR + jackpot on GPU
  6. Blake3 tile hash scan on GPU (CUDA RawKernel)

Blake3 is CPU-only for the seed/commitment (tiny data).
The CUDA kernel does the per-tile blake3 scan (8192 tiles in parallel).
"""

from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# BLAKE3 CUDA kernel — no system headers (NVRTC runtime compiler)
# ---------------------------------------------------------------------------

BLAKE3_CUDA_SRC = r"""
typedef unsigned int       uint32_t;
typedef unsigned long long uint64_t;
typedef unsigned char      uint8_t;

#define CHUNK_START   1u
#define CHUNK_END     2u
#define ROOT          8u
#define KEYED_HASH    16u

__device__ __forceinline__ uint32_t rotr32(uint32_t x, int n) {
    return (x >> n) | (x << (32 - n));
}

__device__ void g(uint32_t* s, int a, int b, int c, int d,
                  uint32_t mx, uint32_t my) {
    s[a] += s[b] + mx; s[d] = rotr32(s[d]^s[a],16);
    s[c] += s[d];      s[b] = rotr32(s[b]^s[c],12);
    s[a] += s[b] + my; s[d] = rotr32(s[d]^s[a], 8);
    s[c] += s[d];      s[b] = rotr32(s[b]^s[c], 7);
}

__device__ void round_fn(uint32_t* state, const uint32_t* msg, int round) {
    const uint8_t SIGMA[7][16] = {
        {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
        {2,6,3,10,7,0,4,13,1,11,12,5,9,14,15,8},
        {3,4,10,12,13,2,7,14,6,5,9,0,11,15,8,1},
        {10,7,12,9,14,3,13,15,4,0,11,2,5,8,1,6},
        {12,13,9,11,15,10,14,8,7,2,5,3,0,1,6,4},
        {14,15,11,5,8,12,6,1,13,3,0,10,2,4,9,7},
        {15,8,5,4,1,14,10,3,6,12,2,7,13,11,9,0},
    };
    const uint8_t* s = SIGMA[round % 7];
    g(state,0,4, 8,12,msg[s[0]], msg[s[1]]);
    g(state,1,5, 9,13,msg[s[2]], msg[s[3]]);
    g(state,2,6,10,14,msg[s[4]], msg[s[5]]);
    g(state,3,7,11,15,msg[s[6]], msg[s[7]]);
    g(state,0,5,10,15,msg[s[8]], msg[s[9]]);
    g(state,1,6,11,12,msg[s[10]],msg[s[11]]);
    g(state,2,7, 8,13,msg[s[12]],msg[s[13]]);
    g(state,3,4, 9,14,msg[s[14]],msg[s[15]]);
}

// blake3(64-byte msg, key=32-byte key) -> 32-byte out
// Single chunk, keyed, flags = CHUNK_START|CHUNK_END|ROOT|KEYED_HASH
__device__ void blake3_keyed_64(
    const uint32_t* key, const uint32_t* msg, uint32_t* out)
{
    const uint32_t IV[8] = {
        0x6A09E667u,0xBB67AE85u,0x3C6EF372u,0xA54FF53Au,
        0x510E527Fu,0x9B05688Cu,0x1F83D9ABu,0x5BE0CD19u,
    };
    uint32_t flags = CHUNK_START|CHUNK_END|ROOT|KEYED_HASH;
    uint32_t state[16];
    for(int i=0;i<8;i++) state[i]   = key[i];
    for(int i=0;i<4;i++) state[8+i] = IV[i];
    state[12]=0; state[13]=0; state[14]=64; state[15]=flags;
    for(int r=0;r<7;r++) round_fn(state,msg,r);
    for(int i=0;i<8;i++) out[i] = state[i]^state[8+i];
}

// One thread per tile. jackpot: (R*C*16) uint32
// hit_encoded: atomicMin of ri*C+ci. Init to INT_MAX.
extern "C" __global__ void scan_tiles(
    const uint32_t* __restrict__ jackpot,
    const uint32_t* __restrict__ sigma,   // 8 words = 32-byte blake3 key
    const uint32_t* __restrict__ target,  // 8 words = LE uint256
    int R, int C,
    int* __restrict__ hit_encoded
) {
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= R*C) return;

    const uint32_t* msg = jackpot + tid*16;
    uint32_t hash_out[8];
    blake3_keyed_64(sigma, msg, hash_out);

    bool le = true;
    for(int i=7;i>=0;i--){
        if(hash_out[i] < target[i]){ le=true;  break; }
        if(hash_out[i] > target[i]){ le=false; break; }
    }
    if(le) atomicMin(hit_encoded, tid);
}
"""

# ---------------------------------------------------------------------------
# Module-level state
# ---------------------------------------------------------------------------

_cupy_ok: bool | None = None
_kernel = None


def _ensure_kernel() -> bool:
    global _cupy_ok, _kernel
    if _cupy_ok is not None:
        return _cupy_ok
    try:
        import cupy as cp
        _kernel = cp.RawKernel(BLAKE3_CUDA_SRC, "scan_tiles",
                               options=("--std=c++14",))
        # warm up (triggers JIT compile now, not on first call)
        _kernel.compile()
        _cupy_ok = True
        print("[cuda_miner] CUDA blake3 kernel compiled OK — full GPU pipeline active")
    except Exception as e:
        _cupy_ok = False
        print(f"[cuda_miner] CuPy unavailable ({e.__class__.__name__}): {e}")
        print("[cuda_miner] Falling back to CPU tile scan")
    return _cupy_ok


# ---------------------------------------------------------------------------
# GPU tile scan
# ---------------------------------------------------------------------------

def scan_tiles_gpu(jackpot_np: np.ndarray, a_seed: bytes, target: int):
    """
    Returns (ri, ci) on hit, None if no hit, False if CuPy unavailable.
    jackpot_np: (R, C, 16) uint32 numpy array (already on CPU)
    """
    if not _ensure_kernel():
        return False

    import cupy as cp

    R, C, _ = jackpot_np.shape
    n_tiles = R * C

    jackpot_gpu  = cp.asarray(jackpot_np.reshape(-1),                    dtype=cp.uint32)
    sigma_gpu    = cp.asarray(np.frombuffer(a_seed, dtype=np.uint32),    dtype=cp.uint32)
    target_gpu   = cp.asarray(np.frombuffer(target.to_bytes(32,"little"),
                                            dtype=np.uint32),            dtype=cp.uint32)
    INT_MAX      = np.int32(2**31 - 1)
    hit_encoded  = cp.full((1,), INT_MAX, dtype=cp.int32)

    threads = 256
    blocks  = (n_tiles + threads - 1) // threads
    _kernel((blocks,), (threads,),
            (jackpot_gpu, sigma_gpu, target_gpu,
             np.int32(R), np.int32(C), hit_encoded))
    cp.cuda.stream.get_current_stream().synchronize()

    enc = int(hit_encoded[0])
    if enc == int(INT_MAX):
        return None
    return enc // C, enc % C


# ---------------------------------------------------------------------------
# Full GPU mine_once (uses CuPy for everything except blake3 seeds)
# ---------------------------------------------------------------------------

def mine_once_gpu(header, config, m: int, n: int, target: int, nonce: int,
                  on_attempt=None):
    """
    Fully GPU-accelerated attempt using CuPy.
    Returns share dict on hit, None otherwise, False if CuPy unavailable.
    """
    if not _ensure_kernel():
        return False

    import cupy as cp
    import time

    from .commitment import commitment_seeds, hash_le32
    from .noise import NoiseGenerator
    from .params import SIGNAL_MAX, SIGNAL_MIN

    k = config.common_dim
    rank = config.rank

    t0 = time.time()

    # ---- 1. Generate A, B on GPU via CuPy RNG ---------------------------
    # Seed a CuPy RNG the same way _default_rng does
    import blake3 as _b3
    seed_bytes = _b3.blake3(
        header.to_bytes() + int(nonce).to_bytes(8, "little")
    ).digest()[:16]
    seed_int = int.from_bytes(seed_bytes, "big")

    # CuPy doesn't have a seeded int8 randint, so generate on CPU quickly
    # (this is fast — just filling 2×1024×1024 bytes)
    rng = np.random.default_rng(seed_int)
    A_cpu = rng.integers(SIGNAL_MIN, SIGNAL_MAX + 1, size=(m, k), dtype=np.int8)
    B_cpu = rng.integers(SIGNAL_MIN, SIGNAL_MAX + 1, size=(k, n), dtype=np.int8)

    # ---- 2. Commitment seeds (must be CPU blake3 — tiny data) -----------
    b_seed, a_seed = commitment_seeds(header, config, A_cpu, B_cpu)

    # ---- 3. Noise matrices on GPU ---------------------------------------
    gen = NoiseGenerator(noise_rank=rank)
    E_AL, E_AR, E_BL, E_BR = gen.generate_noise_matrices(
        key_A=a_seed, key_B=b_seed,
        A_rows=m, common_dim=k, B_cols=n,
    )
    # Upload everything to GPU as float32 for GEMM
    A_g   = cp.asarray(A_cpu.astype(np.float32))
    B_g   = cp.asarray(B_cpu.astype(np.float32))
    EAL_g = cp.asarray(E_AL.astype(np.float32))
    EAR_g = cp.asarray(E_AR.astype(np.float32))
    EBL_g = cp.asarray(E_BL.astype(np.float32))
    EBR_g = cp.asarray(E_BR.astype(np.float32))

    # E_A = E_AL @ E_AR  (m×rank × rank×k -> m×k), clip to int8 range
    E_A_g = cp.clip(cp.matmul(EAL_g, EAR_g), -128, 127).astype(cp.float32)
    E_B_g = cp.clip(cp.matmul(EBL_g, EBR_g), -128, 127).astype(cp.float32)

    A_noised_g = A_g + E_A_g   # (m, k) float32
    B_noised_g = B_g + E_B_g   # (k, n) float32

    # ---- 4. Jackpot accumulation on GPU ---------------------------------
    rows_base = config.rows_pattern.to_list()
    cols_base = config.cols_pattern.to_list()
    from .params import IncompleteBlockHeader, MiningConfiguration

    rows_offs = np.array(
        [o for o in range(0, m - config.rows_pattern.max())
         if config.rows_pattern.offset_is_valid(o)], dtype=np.int64)
    cols_offs = np.array(
        [o for o in range(0, n - config.cols_pattern.max())
         if config.cols_pattern.offset_is_valid(o)], dtype=np.int64)
    R = len(rows_offs)
    C = len(cols_offs)

    o0 = cp.asarray(rows_offs + rows_base[0],  dtype=cp.int64)
    o1 = cp.asarray(rows_offs + rows_base[-1], dtype=cp.int64)
    col_idx = cp.asarray(
        (cols_offs[:, None] + np.array(cols_base)[None, :]).astype(np.int64))

    num_chunks = k // rank
    C_acc     = cp.zeros((m, n), dtype=cp.int32)
    jackpot_g = cp.zeros((R, C, 16), dtype=cp.int32)

    for p in range(num_chunks):
        ks = slice(p * rank, (p + 1) * rank)
        C_chunk = cp.matmul(A_noised_g[:, ks], B_noised_g[ks, :]).astype(cp.int32)
        C_acc  += C_chunk

        r0 = C_acc[o0]                         # (R, n)
        r1 = C_acc[o1]                         # (R, n)
        xr = cp.bitwise_xor(r0, r1)            # (R, n)
        xc = xr[:, col_idx]                    # (R, C, Lc)

        # XOR-reduce last dim
        xored = cp.zeros((R, C), dtype=cp.int32)
        for i in range(xc.shape[2]):
            xored = cp.bitwise_xor(xored, xc[:, :, i])

        tid = p % 16
        slot   = jackpot_g[:, :, tid].astype(cp.int64)
        rotated = ((slot << 13) | ((slot & 0xFFFFFFFF) >> 19))
        jackpot_g[:, :, tid] = cp.bitwise_xor(rotated.astype(cp.int32), xored)

    # ---- 5. Tile hash scan on GPU (CUDA blake3 kernel) ------------------
    jackpot_np = cp.asnumpy(jackpot_g).view(np.uint32)  # (R, C, 16) uint32
    elapsed = time.time() - t0

    gpu_result = scan_tiles_gpu(jackpot_np, a_seed, target)
    n_tiles = R * C

    if on_attempt:
        on_attempt(nonce, elapsed, n_tiles)

    if gpu_result is None or gpu_result is False:
        return None

    ri, ci = gpu_result
    ro = int(rows_offs[ri])
    co = int(cols_offs[ci])

    import blake3 as _b3
    transcripts = np.ascontiguousarray(jackpot_np, dtype=np.uint32)
    msg = transcripts[ri, ci].tobytes()
    h   = _b3.blake3(msg, key=a_seed).digest()

    # Build share (needs CPU numpy for merkle trees)
    from .mining import _build_share
    A_noised_cpu = cp.asnumpy(A_noised_g).astype(np.int16)
    B_noised_cpu = cp.asnumpy(B_noised_g).astype(np.int16)

    return _build_share(
        header, config, m, n, target, nonce, A_cpu, B_cpu,
        b_seed, a_seed, ro, co, h, transcripts[ri, ci],
        A_noised_cpu, B_noised_cpu, elapsed, n_tiles,
    )
