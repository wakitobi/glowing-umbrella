@echo off
echo  lemurian-robot power2b miner
echo  Direct TCP Stratum - no proxy needed
echo.
python lemurian_miner.py
pause
