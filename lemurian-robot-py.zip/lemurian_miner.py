#!/usr/bin/env python3
"""
lemurian-robot — Pure Python CPU miner for power2b (MBC)
Direct TCP Stratum connection, no Koyeb WebSocket proxy needed.
"""

import ctypes
import hashlib
import json
import os
import socket
import struct
import sys
import threading
import time
import binascii

# ─── yespower DLL ───────────────────────────────────────────────
_DIR = os.path.dirname(os.path.abspath(__file__))
for dll in ['libgcc_s_seh-1.dll', 'libwinpthread-1.dll']:
    p = os.path.join(_DIR, dll)
    if os.path.exists(p):
        os.add_dll_directory(os.path.dirname(p))

_YESPOWER = ctypes.CDLL(os.path.join(_DIR, 'yespower.dll'))
_YESPOWER.yespower_hash.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
_YESPOWER.yespower_hash.restype = ctypes.c_int

def yespower_hash(data: bytes) -> bytes:
    """Run yespower(N=2048,r=32,pers='Death') on 80-byte header -> 32-byte LE hash."""
    inp = ctypes.create_string_buffer(data, len(data))
    out = ctypes.create_string_buffer(32)
    _YESPOWER.yespower_hash(inp, len(data), out)
    return out.raw

# ─── SHA-256 helpers ────────────────────────────────────────────
def sha256d(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()

def be32(v: int) -> bytes:
    return struct.pack('>I', v)

def le32(v: int) -> bytes:
    return struct.pack('<I', v)

def be32dec(data: bytes, off: int) -> int:
    return struct.unpack('>I', data[off:off+4])[0]

# ─── hex conversion ─────────────────────────────────────────────
def bin2hex(b: bytes) -> str:
    return binascii.hexlify(b).decode()

def hex2bin(h: str) -> bytes:
    return binascii.unhexlify(h)

# ─── Stratum client ─────────────────────────────────────────────
class StratumClient:
    def __init__(self, host: str, port: int, user: str, password: str):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.sock = None
        self.lock = threading.Lock()
        self.extranonce1 = b''
        self.extranonce2_size = 0
        self.job = None
        self.job_lock = threading.Lock()
        self._id = 0
        self._running = True
        self._response_queue = {}

    def _next_id(self):
        self._id += 1
        return self._id

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=30)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        # start listener EARLY so we catch notifications that arrive right after subscribe
        self._listener_thread = threading.Thread(target=self._listen, daemon=True)
        self._listener_thread.start()
        # subscribe
        self._send({'id': 1, 'method': 'mining.subscribe', 'params': []})
        # wait for subscribe response (id=1) while listener handles notifications
        resp = self._recv_response(1)
        if 'result' not in resp:
            raise RuntimeError(f"subscribe failed: {resp}")
        result = resp["result"]
        self.extranonce1 = hex2bin(result[1]) if isinstance(result[1], str) else result[1]
        self.extranonce2_size = result[2] if len(result) > 2 else 4
        print(f"[stratum] subscribed, extranonce1={bin2hex(self.extranonce1)}, extranonce2_size={self.extranonce2_size}")
        # authorize
        self._send({'id': 2, 'method': 'mining.authorize', 'params': [self.user, self.password]})
        resp = self._recv_response(2)
        if not resp.get('result', False):
            raise RuntimeError(f"authorize failed: {resp}")
        print(f"[stratum] authorized as {self.user}")

    def _recv_response(self, expected_id: int, timeout: float = 10.0) -> dict:
        """Wait for a response with a specific id."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self.lock:
                if expected_id in self._response_queue:
                    return self._response_queue.pop(expected_id)
            time.sleep(0.01)
        raise TimeoutError(f"no response for id={expected_id} in {timeout}s")

    def _send(self, msg: dict):
        line = json.dumps(msg) + '\n'
        with self.lock:
            self.sock.sendall(line.encode())

    def _send_recv(self, msg: dict) -> dict:
        self._send(msg)
        return self._recv()

    def _recv(self) -> dict:
        buf = b''
        while b'\n' not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("connection closed")
            buf += chunk
        line = buf.split(b'\n')[0]
        return json.loads(line)

    def _listen(self):
        """Background thread: receive new jobs and difficulty changes."""
        while self._running:
            try:
                msg = self._recv()
                # if it's a response to a request we're waiting for, put it in the queue
                msg_id = msg.get('id')
                if msg_id is not None and not msg.get('method'):
                    with self.lock:
                        self._response_queue[msg_id] = msg
                    continue
                method = msg.get('method', '')
                if method == 'mining.set_difficulty':
                    diff = msg['params'][0]
                    print(f"[stratum] difficulty set to {diff}")
                elif method == 'mining.notify':
                    params = msg['params']
                    job = {
                        'job_id':    params[0],
                        'prevhash':  hex2bin(params[1]),
                        'coinb1':    hex2bin(params[2]),
                        'coinb2':    hex2bin(params[3]),
                        'merkle_branches': [hex2bin(b) for b in params[4]],
                        'version':   hex2bin(params[5]),
                        'nbits':     hex2bin(params[6]),
                        'ntime':     hex2bin(params[7]),
                        'clean_jobs': params[8] if len(params) > 8 else False,
                    }
                    with self.job_lock:
                        self.job = job
                    print(f"[stratum] new job {job['job_id']}, block {bin2hex(job['prevhash'][:8])}...")
                    if job['clean_jobs']:
                        # signal all threads to restart
                        pass
            except Exception as e:
                if self._running:
                    print(f"[stratum] listener error: {e}")
                    time.sleep(1)

    def submit(self, job_id: str, extranonce2: str, ntime: str, nonce: str):
        resp = self._send_recv({
            'id': self._next_id(),
            'method': 'mining.submit',
            'params': [self.user, job_id, extranonce2, ntime, nonce]
        })
        accepted = resp.get('result', False)
        status = 'ACCEPTED' if accepted else f"REJECTED: {resp.get('error', 'unknown')}"
        return accepted, status

    def get_job(self):
        with self.job_lock:
            return self.job

    def disconnect(self):
        self._running = False
        try:
            self.sock.close()
        except:
            pass


# ─── Miner thread ───────────────────────────────────────────────
def miner_thread(client: StratumClient, thread_id: int, hashes_done: list, stop_event: threading.Event):
    """Single miner thread: builds block header, hashes, submits shares."""
    extranonce2_counter = 0
    hashrate_acc = 0
    last_report = time.time()

    while not stop_event.is_set():
        job = client.get_job()
        if job is None:
            time.sleep(0.1)
            continue

        # build extranonce2 (unique per thread)
        extranonce2_counter += 1
        extranonce2 = struct.pack('>I', extranonce2_counter)
        # pad to extranonce2_size
        while len(extranonce2) < client.extranonce2_size:
            extranonce2 = b'\x00' + extranonce2

        # build coinbase transaction
        coinbase = job['coinb1'] + client.extranonce1 + extranonce2 + job['coinb2']
        coinbase_hash_bin = sha256d(coinbase)

        # build merkle root
        merkle_root = coinbase_hash_bin
        for branch in job['merkle_branches']:
            merkle_root = sha256d(merkle_root + branch)

        # build block header (80 bytes)
        header = (
            job['version'] +         # 4 bytes
            job['prevhash'] +        # 32 bytes
            merkle_root +            # 32 bytes
            job['ntime'] +           # 4 bytes
            job['nbits'] +           # 4 bytes
            b'\x00\x00\x00\x00'     # nonce placeholder (4 bytes)
        )

        if len(header) != 80:
            raise RuntimeError(f"header length {len(header)}, expected 80")

        # scan nonces
        nonce = 0
        ntime_int = be32dec(job['ntime'], 0)
        target = int.from_bytes(job['nbits'], 'big')

        # get actual target from nbits for share submission
        # compact format: first byte = exp, rest = mantissa
        nbits_bytes = job['nbits']
        exp = nbits_bytes[0]
        mant = int.from_bytes(nbits_bytes[1:], 'big')
        share_target = (mant << (8 * (exp - 3)))

        max_nonce = 0xFFFFFFFF
        job_id = job['job_id']

        start = time.time()
        report_interval = 5.0  # report every 5 seconds

        while nonce <= max_nonce and not stop_event.is_set():
            # check if job changed
            current_job = client.get_job()
            if current_job and current_job['job_id'] != job_id:
                break

            # set nonce in header
            header = header[:76] + le32(nonce)

            # hash with yespower
            h = yespower_hash(header)

            # convert to int (little-endian)
            h_int = int.from_bytes(h, 'little')

            # check against share target
            if h_int < share_target:
                nonce_hex = bin2hex(le32(nonce))
                ntime_hex = bin2hex(job['ntime'])
                accepted, status = client.submit(
                    job_id,
                    bin2hex(extranonce2),
                    ntime_hex,
                    nonce_hex
                )
                hashes_done[thread_id] = hashes_done[thread_id] + 1 if thread_id < len(hashes_done) else 1
                print(f"[thread-{thread_id}] {status} nonce={nonce_hex} hash={bin2hex(h[:16])}")

            nonce += 1
            hashrate_acc += 1

            # periodic hashrate report
            now = time.time()
            if now - start >= report_interval:
                elapsed = now - start
                rate = hashrate_acc / elapsed
                print(f"[thread-{thread_id}] {rate:.1f} H/s  (nonce 0x{nonce:08X})")
                hashrate_acc = 0
                start = now


# ─── Main ───────────────────────────────────────────────────────
def main():
    # load config from .env or command line
    config = {}
    env_path = os.path.join(_DIR, '.env')
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if '=' in line and not line.startswith('#'):
                    k, v = line.split('=', 1)
                    config[k.strip()] = v.strip()

    host = config.get('host', '127.0.0.1')
    port = int(config.get('port', '3334'))
    user = config.get('username', '')
    password = config.get('password', 'x')
    threads = int(config.get('threads', '1'))
    use_proxy = config.get('use_proxy', 'false').lower() == 'true'

    # CLI overrides
    if '--host' in sys.argv:
        host = sys.argv[sys.argv.index('--host') + 1]
    if '--port' in sys.argv:
        port = int(sys.argv[sys.argv.index('--port') + 1])
    if '--user' in sys.argv:
        user = sys.argv[sys.argv.index('--user') + 1]
    if '--threads' in sys.argv:
        threads = int(sys.argv[sys.argv.index('--threads') + 1])

    if not user:
        print("Error: no wallet/username set. Edit .env or use --user")
        sys.exit(1)

    print("**********  lemurian-robot 1.0.0-power2b  ***********")
    print("     Pure Python CPU miner — direct TCP Stratum")
    print(f"     Algo: power2b | Threads: {threads}")
    print(f"     Server: {host}:{port}")
    print(f"     Wallet: {user}")
    print()

    client = StratumClient(host, port, user, password)
    try:
        client.connect()
    except Exception as e:
        print(f"Connection failed: {e}")
        sys.exit(1)

    stop_event = threading.Event()
    hashes_done = [0] * threads

    workers = []
    for i in range(threads):
        t = threading.Thread(target=miner_thread, args=(client, i, hashes_done, stop_event), daemon=True)
        t.start()
        workers.append(t)
        print(f"[main] started thread-{i}")

    print(f"\nMining with {threads} threads... Ctrl+C to stop\n")

    try:
        while True:
            time.sleep(10)
            total = sum(hashes_done)
            rate = total / 10.0 if total > 0 else 0
            print(f"[summary] total={total} shares accepted | ~{rate:.1f} shares/s")
            hashes_done = [0] * threads
    except KeyboardInterrupt:
        print("\nStopping...")
        stop_event.set()
        client.disconnect()
        print("Done.")


if __name__ == '__main__':
    main()
