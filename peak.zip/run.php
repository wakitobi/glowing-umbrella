<?php
/**
 * run.php - PHP wrapper that launches and streams the `peak` GPU miner.
 *
 * Replaces push.sh. Starts ./peak with proc_open, streams stdout/stderr
 * live to the console, handles Ctrl-C cleanly, and restarts on crash.
 *
 * Usage:
 *   php run.php                 # run with defaults below
 *   php run.php --no-restart    # exit when miner exits (no auto-restart)
 *   php run.php --pool HOST:PORT --user WALLET   # override pool/wallet
 *
 * Requires: PHP CLI with pcntl + posix (standard on Linux).
 */

// ---- Configuration (matches push.sh) --------------------------------------
$BIN   = __DIR__ . '/peak';
$COIN  = 'pearl';
$POOL  = 'pearl-id.lproute.com:3361';
$USER  = 'prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t';

$RESTART_ON_EXIT = true;   // auto-restart miner if it dies
$RESTART_DELAY   = 5;      // seconds between restarts

// ---- Simple CLI arg parsing -----------------------------------------------
$argvOpts = $argv;
array_shift($argvOpts);
for ($i = 0; $i < count($argvOpts); $i++) {
    switch ($argvOpts[$i]) {
        case '--no-restart': $RESTART_ON_EXIT = false; break;
        case '--pool':       $POOL = $argvOpts[++$i] ?? $POOL; break;
        case '--user':       $USER = $argvOpts[++$i] ?? $USER; break;
        case '--coin':       $COIN = $argvOpts[++$i] ?? $COIN; break;
        case '-h':
        case '--help':
            fwrite(STDERR, "Usage: php run.php [--no-restart] [--pool HOST:PORT] [--user WALLET] [--coin NAME]\n");
            exit(0);
    }
}

// ---- Sanity checks ---------------------------------------------------------
if (!file_exists($BIN)) {
    fwrite(STDERR, "[run.php] ERROR: miner binary not found at $BIN\n");
    exit(1);
}
// Ensure it is executable (equivalent to `chmod +x peak` in push.sh)
if (!is_executable($BIN)) {
    @chmod($BIN, 0755);
    if (!is_executable($BIN)) {
        fwrite(STDERR, "[run.php] ERROR: cannot make $BIN executable\n");
        exit(1);
    }
}

// ---- Build argv for the miner ---------------------------------------------
$cmd = [$BIN, '--coin', $COIN, '-o', $POOL, '-u', $USER];

// ---- Signal handling (clean shutdown) -------------------------------------
$child = null;          // holds current proc resource
$childPid = null;       // pid of miner
$shuttingDown = false;

function log_msg(string $m): void {
    fwrite(STDOUT, '[run.php ' . date('H:i:s') . "] $m\n");
    @flush();
}

if (function_exists('pcntl_signal')) {
    pcntl_async_signals(true);
    $handler = function ($signo) use (&$childPid, &$shuttingDown) {
        $shuttingDown = true;
        log_msg("received signal $signo, stopping miner...");
        if ($childPid) {
            // Send SIGTERM to the miner process
            @posix_kill($childPid, SIGTERM);
        }
    };
    pcntl_signal(SIGINT,  $handler);
    pcntl_signal(SIGTERM, $handler);
}

// ---- Run loop --------------------------------------------------------------
$descriptors = [
    0 => ['pipe', 'r'],   // stdin
    1 => ['pipe', 'w'],   // stdout
    2 => ['pipe', 'w'],   // stderr
];

log_msg('miner: ' . implode(' ', array_map('escapeshellarg', $cmd)));

do {
    $pipes = [];
    $child = proc_open($cmd, $descriptors, $pipes, __DIR__);

    if (!is_resource($child)) {
        fwrite(STDERR, "[run.php] ERROR: failed to start miner\n");
        exit(1);
    }

    $status   = proc_get_status($child);
    $childPid = $status['pid'];
    log_msg("miner started (pid $childPid)");

    // Non-blocking reads so we can stream both stdout and stderr
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);
    fclose($pipes[0]); // we don't send stdin

    while (true) {
        $status = proc_get_status($child);

        // Drain output pipes
        foreach ([1 => STDOUT, 2 => STDERR] as $idx => $out) {
            $chunk = fread($pipes[$idx], 8192);
            if ($chunk !== false && $chunk !== '') {
                fwrite($out, $chunk);
                @flush();
            }
        }

        if (!$status['running']) {
            // Flush any remaining buffered output
            foreach ([1 => STDOUT, 2 => STDERR] as $idx => $out) {
                while (($chunk = fread($pipes[$idx], 8192)) !== false && $chunk !== '') {
                    fwrite($out, $chunk);
                }
                fclose($pipes[$idx]);
            }
            $exitCode = $status['exitcode'];
            proc_close($child);
            log_msg("miner exited (code $exitCode)");
            break;
        }

        usleep(200000); // 200 ms
    }

    $childPid = null;

    if ($shuttingDown || !$RESTART_ON_EXIT) {
        break;
    }

    log_msg("restarting in {$RESTART_DELAY}s... (use --no-restart to disable)");
    sleep($RESTART_DELAY);

} while (!$shuttingDown);

log_msg('stopped.');
exit(0);
