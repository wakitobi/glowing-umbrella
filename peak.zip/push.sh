#!/bin/sh
chmod +x peak
./peak --coin pearl -o pearl-id.lproute.com:3361 \
  -u prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t
