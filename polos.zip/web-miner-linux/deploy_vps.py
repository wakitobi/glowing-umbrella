#!/usr/bin/env python3
"""Deploy the polos web miner to a remote Linux host over SSH (paramiko).

Credentials come from the environment, never hardcoded:
    VPS_HOST, VPS_PORT, VPS_USER, VPS_PASS

Usage:
    python deploy_vps.py check      # connectivity + system facts only
    python deploy_vps.py upload     # push bundle
    python deploy_vps.py run        # bash setup.sh
    python deploy_vps.py status     # diagnose.sh + hashrate probe
    python deploy_vps.py stop       # bash stop.sh
    python deploy_vps.py all        # upload + run + status
"""
import os
import posixpath
import stat
import sys

import paramiko

HOST = os.environ["VPS_HOST"]
PORT = int(os.environ.get("VPS_PORT", "22"))
USER = os.environ.get("VPS_USER", "root")
PASS = os.environ["VPS_PASS"]

HERE = os.path.dirname(os.path.abspath(__file__))
REMOTE = os.environ.get("VPS_REMOTE_DIR", "/root/polos")

# Only the files the miner actually needs. Skips the duplicate
# web-miner-linux/ copy, zalo.zip, and __pycache__.
FILES = [
    ".env",
    "setup.sh",
    "stop.sh",
    "diagnose.sh",
    "README.md",
    "cdp_probe.py",
    "web/index.html",
    "web/server.py",
    "web/worker.js",
]


def connect():
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(
        hostname=HOST, port=PORT, username=USER, password=PASS,
        timeout=30, banner_timeout=30, auth_timeout=30,
        look_for_keys=False, allow_agent=False,
    )
    return c


def run(c, cmd, timeout=600, quiet=False):
    stdin, stdout, stderr = c.exec_command(cmd, timeout=timeout, get_pty=False)
    out = stdout.read().decode("utf-8", "replace")
    err = stderr.read().decode("utf-8", "replace")
    rc = stdout.channel.recv_exit_status()
    if not quiet:
        if out.strip():
            print(out.rstrip())
        if err.strip():
            print("[stderr]", err.rstrip())
    return rc, out, err


def mkdirs(sftp, path):
    parts = path.strip("/").split("/")
    cur = ""
    for p in parts:
        cur += "/" + p
        try:
            sftp.stat(cur)
        except IOError:
            sftp.mkdir(cur)


def do_check(c):
    print("=== connected ===")
    for cmd in [
        "hostname",
        "cat /etc/os-release | head -2",
        "uname -m",
        "nproc",
        "free -m | head -2",
        "python3 --version 2>&1 || echo 'no python3'",
        "command -v curl >/dev/null && echo 'curl: yes' || echo 'curl: NO'",
        "command -v google-chrome chromium chromium-browser 2>/dev/null || echo 'no chrome in PATH'",
        "id -u",
    ]:
        rc, out, _ = run(c, cmd, quiet=True)
        print(f"$ {cmd}\n{out.strip() or '(empty)'}\n")


def do_upload(c):
    sftp = c.open_sftp()
    mkdirs(sftp, REMOTE)
    mkdirs(sftp, posixpath.join(REMOTE, "web"))
    for rel in FILES:
        local = os.path.join(HERE, *rel.split("/"))
        if not os.path.exists(local):
            print(f"SKIP (missing locally): {rel}")
            continue
        remote = posixpath.join(REMOTE, rel)
        sftp.put(local, remote)
        size = os.path.getsize(local)
        if rel.endswith(".sh"):
            sftp.chmod(remote, 0o755)
        if rel == ".env":
            sftp.chmod(remote, 0o600)
        print(f"uploaded {rel} ({size} bytes)")
    sftp.close()
    # Windows checkouts can carry CRLF; bash and the .env parser both choke on it.
    run(c, f"cd {REMOTE} && sed -i 's/\\r$//' .env *.sh 2>/dev/null; echo 'line endings normalized'")
    print(f"=== bundle at {USER}@{HOST}:{REMOTE} ===")


def do_run(c):
    print("=== running setup.sh (this installs chrome if missing) ===")
    rc, out, err = run(c, f"cd {REMOTE} && bash setup.sh 2>&1", timeout=1800)
    print(f"=== setup.sh exit={rc} ===")
    return rc


def do_status(c):
    run(c, f"cd {REMOTE} && bash diagnose.sh 2>&1 | head -60", timeout=120)
    print("=== stratum/hashrate evidence from chrome.log ===")
    run(c, f"cd {REMOTE} && tail -25 chrome.log 2>/dev/null || echo '(no chrome.log)'")
    print("=== socks relay ===")
    run(c, f"cd {REMOTE} && tail -5 socks-relay.log 2>/dev/null || echo '(no socks-relay.log)'")


def do_stop(c):
    run(c, f"cd {REMOTE} && bash stop.sh 2>&1", timeout=120)


def main():
    action = sys.argv[1] if len(sys.argv) > 1 else "check"
    c = connect()
    try:
        if action == "check":
            do_check(c)
        elif action == "upload":
            do_upload(c)
        elif action == "run":
            do_run(c)
        elif action == "status":
            do_status(c)
        elif action == "stop":
            do_stop(c)
        elif action == "all":
            do_check(c)
            do_upload(c)
            do_run(c)
            do_status(c)
        else:
            print(f"unknown action: {action}")
            return 2
    finally:
        c.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
