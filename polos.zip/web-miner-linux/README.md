# power2b web miner (Linux deploy)

Runs the mbc power2b miner inside headless Chrome, driven by a web page that
talks Stratum over WebSocket straight to your Koyeb proxy (same pool config as
the Python miner). No third-party relay, no fee.

## Layout

    .env                 pool config (proxy wss URL, username, password, threads, optional socks5_proxy)
    web/index.html       the embedded miner page (JS Stratum client + stats UI)
    web/worker.js        power2b WASM miner worker (works on any OS/arch)
    web/server.py        tiny python3 web server, injects .env config, port 8765
    setup.sh             install chromium if needed, start server + headless chrome
    stop.sh              stop both

## Quick start (on the Linux machine)

    tar xzf web-miner-linux.tar.gz
    cd web-miner-linux
    bash setup.sh

That's it. It auto-installs Chromium when missing (needs sudo for apt/dnf),
then launches headless Chrome mining the page. ~5 seconds later it's hashing.

## Deploy to a remote Linux box from this machine

`deploy_vps.py` pushes the bundle over SSH and drives it. Credentials come
from the environment — nothing is hardcoded:

    export VPS_HOST=1.2.3.4 VPS_PORT=22 VPS_USER=root VPS_PASS=...
    python deploy_vps.py check     # connectivity + os/cpu/python facts
    python deploy_vps.py upload    # sftp the 9 needed files, fix perms + CRLF
    python deploy_vps.py run       # bash setup.sh (installs chrome, starts miner)
    python deploy_vps.py status    # diagnose.sh + live CDP stats
    python deploy_vps.py stop      # bash stop.sh
    python deploy_vps.py all       # check + upload + run + status

Requires `pip install paramiko` locally. Override the remote path with
`VPS_REMOTE_DIR` (default `/root/polos`). It uploads only what the miner
needs — the duplicate `web-miner-linux/` copy, `zalo.zip` and `__pycache__`
are skipped.

Prefer keys over passwords for anything long-lived: `ssh-copy-id`, then drop
`VPS_PASS` and let paramiko use the agent.

## Live stats without a browser

`cdp_probe.py` runs on the miner host and reads the real page state over CDP:

    python3 cdp_probe.py        # one snapshot
    python3 cdp_probe.py 45     # two snapshots 45s apart + accepted-share delta

`diagnose.sh` calls it automatically when CDP is up. Needs
`pip3 install websocket-client` on the miner host.

Check it:
    curl http://127.0.0.1:8765/          # page is served
    tail -f web/server.log chrome.log   # logs
    # open http://127.0.0.1:8765/ in any browser to watch stats live
    # (use --headless=new --remote-debugging-port=9222 for CDP automation)

Stop:   bash stop.sh
Restart: bash setup.sh

## Tuning

    MINER_WEB_PORT=8765 MINER_WORKERS=7 bash setup.sh   # workers + ports
    # note: page caps workers at min(7, CPU cores) via .env threads

## Notes

## SOCKS5

Set a SOCKS5 endpoint in `.env` before running `setup.sh`:

    socks5_proxy=127.0.0.1:1080
    socks5_proxy=socks5://127.0.0.1:1080
    socks5_proxy=socks5://user:pass@1.2.3.4:30034     # authenticated

Headless Chrome routes the miner's outbound WebSocket through this proxy. The
local dashboard and CDP remain on loopback.

Chrome's `--proxy-server` cannot carry SOCKS5 credentials. When `socks5_proxy`
includes `user:pass@`, `setup.sh` detects it and starts a local unauthenticated
SOCKS5 relay (`pproxy`, auto-installed) on 127.0.0.1:1080 that forwards to the
authenticated upstream, then points Chrome at the relay. It prints the proxy
exit IP so you can confirm egress. Override the relay port with
`MINER_SOCKS_RELAY_PORT`. Relay log: `socks-relay.log`; `stop.sh` kills it too.

Remove the setting to disable proxying.

- .env contains your pool credentials — keep the tarball private.
- server binds 127.0.0.1 only. To view the dashboard from another machine,
  set MINER_WEB_PORT and edit server.py bind to 0.0.0.0 (or ssh -L 8765:localhost:8765).
- Wasm hashrate (~250-400 H/s/7 workers) is much lower than the native Python
  miner. Real valid shares, just slow — fine for monitoring/experiments.
