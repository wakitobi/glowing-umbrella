#!/usr/bin/env bash
# Stop the web miner: kills headless chrome + web server.
cd "$(dirname "$0")"
[ -f chrome.pid ] && kill "$(cat chrome.pid)" 2>/dev/null && rm -f chrome.pid && echo "chrome stopped"
[ -f server.pid ] && kill "$(cat server.pid)" 2>/dev/null && rm -f server.pid && echo "server stopped"
[ -f socks-relay.pid ] && kill "$(cat socks-relay.pid)" 2>/dev/null && rm -f socks-relay.pid && echo "socks5 relay stopped"
pkill -f "headless=new.*$PORT" 2>/dev/null || true
echo "done"
