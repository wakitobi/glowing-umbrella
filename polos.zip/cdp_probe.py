#!/usr/bin/env python3
"""Read live miner stats out of the headless Chrome page via CDP.

Runs ON the miner host (talks to 127.0.0.1:9222). Prints real page state:
pool connection, authorization, current job, difficulty, worker count,
hashrate, accepted/rejected shares, plus the newest page log lines.

Usage:  python3 cdp_probe.py [seconds_to_sample]
"""
import json
import sys
import time
import urllib.request

CDP = "http://127.0.0.1:9222"


def targets():
    with urllib.request.urlopen(CDP + "/json", timeout=10) as r:
        return json.load(r)


def pick_page(ts):
    for t in ts:
        if t.get("type") == "page" and "127.0.0.1:8765" in (t.get("url") or ""):
            return t
    for t in ts:
        if t.get("type") == "page":
            return t
    return None


def evaluate(ws, expr, req_id):
    ws.send(json.dumps({
        "id": req_id,
        "method": "Runtime.evaluate",
        "params": {"expression": expr, "returnByValue": True, "awaitPromise": True},
    }))
    while True:
        msg = json.loads(ws.recv())
        if msg.get("id") == req_id:
            res = msg.get("result", {})
            if "exceptionDetails" in res:
                return {"error": str(res["exceptionDetails"])[:300]}
            return res.get("result", {}).get("value")


SNAPSHOT = """
(() => {
  const t = id => (document.getElementById(id) || {}).textContent;
  const logs = [...document.querySelectorAll('#log div')].slice(0, 12).map(d => d.textContent);
  let s = null;
  try {
    s = { accepted: state.accepted, rejected: state.rejected,
          hrTotalKHs: state.hrTotal, workers: state.workers.length,
          diff: state.diff, job: state.job ? state.job.job_id : null,
          wsReadyState: state.ws ? state.ws.readyState : null,
          extranonce1: state.extranonce1 ? 'set' : null };
  } catch (e) { s = { error: String(e) }; }
  return { ui: { pool: t('conn'), auth: t('auth'), job: t('job'), diff: t('diff'),
                 workers: t('workers'), hashrate: t('hr'), accepted: t('acc'),
                 rejected: t('rej'), cfg: t('cfg') },
           state: s, logs };
})()
"""


def main():
    sample = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    try:
        import websocket
    except ImportError:
        print("ERROR: websocket-client missing. pip3 install websocket-client")
        return 1

    ts = targets()
    page = pick_page(ts)
    if not page:
        print("ERROR: no page target found. targets:", [t.get("type") for t in ts])
        return 1
    print("page url:", page.get("url"))

    ws = websocket.create_connection(page["webSocketDebuggerUrl"], timeout=30,
                                     suppress_origin=True)
    rid = 1
    snap = evaluate(ws, SNAPSHOT, rid)
    print("\n=== SNAPSHOT 1 ===")
    print(json.dumps(snap, indent=2)[:2500])

    if sample:
        time.sleep(sample)
        rid += 1
        snap2 = evaluate(ws, SNAPSHOT, rid)
        print(f"\n=== SNAPSHOT 2 (+{sample}s) ===")
        print(json.dumps(snap2, indent=2)[:2500])
        try:
            a1 = snap["state"]["accepted"]
            a2 = snap2["state"]["accepted"]
            print(f"\naccepted delta over {sample}s: {a2 - a1}")
        except Exception:
            pass
    ws.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
