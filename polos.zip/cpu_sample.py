#!/usr/bin/env python3
"""Measure real aggregate CPU usage of the miner's chrome processes.

Reads /proc directly (no top/awk quoting hazards). Reports total CPU as a
percentage of ONE core and of ALL cores, so a cgroup CPUQuota can be checked.

Usage: python3 cpu_sample.py [seconds]
"""
import os
import sys
import time

CLK = os.sysconf("SC_CLK_TCK")
CORES = os.cpu_count() or 1


def chrome_pids():
    pids = []
    for d in os.listdir("/proc"):
        if not d.isdigit():
            continue
        # /proc/<pid>/stat's comm field is the reliable process-name source;
        # cmdline can be unreadable for short-lived or re-exec'd children.
        try:
            with open(f"/proc/{d}/stat") as f:
                stat = f.read()
        except OSError:
            continue
        try:
            comm = stat[stat.index("(") + 1:stat.rindex(")")]
        except ValueError:
            continue
        if "chrome" not in comm:
            continue
        if "crashpad" in comm:
            continue
        pids.append(int(d))
    return pids


def jiffies(pid):
    try:
        with open(f"/proc/{pid}/stat") as f:
            raw = f.read()
        # comm can contain spaces/parens, so parse fields after the last ')'
        parts = raw[raw.rindex(")") + 1:].split()
        # after comm: state=0, ppid=1, ... utime=11, stime=12
        return int(parts[11]) + int(parts[12])
    except (OSError, IndexError, ValueError):
        return None


def main():
    dur = float(sys.argv[1]) if len(sys.argv) > 1 else 20.0
    pids = chrome_pids()
    if not pids:
        print("no chrome processes found")
        return 1
    start = {p: jiffies(p) for p in pids}
    t0 = time.time()
    time.sleep(dur)
    elapsed = time.time() - t0
    total = 0
    for p in pids:
        a, b = start.get(p), jiffies(p)
        if a is None or b is None:
            continue
        total += b - a
    cpu_sec = total / CLK
    pct_one = 100.0 * cpu_sec / elapsed
    pct_all = pct_one / CORES
    print(f"chrome procs sampled : {len(pids)}")
    print(f"cores                : {CORES}")
    print(f"window               : {elapsed:.1f}s")
    print(f"cpu used             : {cpu_sec:.2f} core-seconds")
    print(f"CPU% of one core     : {pct_one:.1f}%   (cgroup CPUQuota units)")
    print(f"CPU% of whole machine: {pct_all:.1f}%")
    return 0


if __name__ == "__main__":
    sys.exit(main())
