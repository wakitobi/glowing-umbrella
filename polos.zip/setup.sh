#!/usr/bin/env bash
# Deploy + launch the power2b web miner on a Linux machine (containers/VPS friendly).
# Usage: bash setup.sh   (normal user or root; sudo auto-detected)
set -uo pipefail
cd "$(dirname "$0")"

# Optional unauthenticated SOCKS5 proxy for Chrome's outbound traffic.
SOCKS5_PROXY=""
if [ -f .env ]; then
  SOCKS5_PROXY="$(grep -E '^[[:space:]]*socks5_proxy[[:space:]]*=' .env | tail -1 | cut -d= -f2- | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
fi
if [ -n "$SOCKS5_PROXY" ] && [[ "$SOCKS5_PROXY" != socks5://* ]]; then
  SOCKS5_PROXY="socks5://$SOCKS5_PROXY"
fi

PORT=${MINER_WEB_PORT:-8765}
CDP_PORT=${MINER_CDP_PORT:-9222}
RELAY_PORT=${MINER_SOCKS_RELAY_PORT:-1080}
PROFILE="$HOME/.chrome-miner-profile"

# CPU budget: worker count in the page scales with this, and when systemd cgroup
# v2 is available Chrome is additionally hard-capped so it CANNOT exceed it.
CPU_PERCENT="${MINER_CPU_PERCENT:-}"
if [ -z "$CPU_PERCENT" ] && [ -f .env ]; then
  CPU_PERCENT="$(grep -E '^[[:space:]]*cpu_percent[[:space:]]*=' .env | tail -1 | cut -d= -f2- | tr -d '\r' | sed 's/^[[:space:]]*//; s/[[:space:]]*$//')"
fi
case "$CPU_PERCENT" in
  ''|*[!0-9]*) CPU_PERCENT=100 ;;
esac
[ "$CPU_PERCENT" -lt 1 ] && CPU_PERCENT=100
[ "$CPU_PERCENT" -gt 100 ] && CPU_PERCENT=100

SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

# Chrome's --proxy-server cannot carry SOCKS5 credentials. If the configured
# proxy has user:pass, run a local unauthenticated SOCKS5 relay (pproxy) that
# forwards to the authenticated upstream, and point Chrome at the relay.
RELAY_UPSTREAM=""
if [ -n "$SOCKS5_PROXY" ]; then
  _bare="${SOCKS5_PROXY#socks5://}"
  case "$_bare" in
    *@*)
      _creds="${_bare%@*}"
      _hostport="${_bare##*@}"
      _puser="${_creds%%:*}"
      _ppass="${_creds#*:}"
      RELAY_UPSTREAM="socks5://${_hostport}#${_puser}:${_ppass}"
      SOCKS5_PROXY="socks5://127.0.0.1:$RELAY_PORT"
      echo "SOCKS5 proxy has credentials -> starting local unauth relay on 127.0.0.1:$RELAY_PORT"
      ;;
  esac
fi

echo "== checking python3 =="
if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 not found, attempting install..."
  $SUDO apt-get update >/dev/null 2>&1 || true
  $SUDO apt-get install -y python3 >/dev/null 2>&1 \
    || $SUDO dnf install -y python3 >/dev/null 2>&1 \
    || $SUDO yum install -y python3 >/dev/null 2>&1 || true
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 not found. Install it first, e.g.:  sudo apt install -y python3" >&2
  exit 1
fi
echo "python3: $(python3 --version 2>&1)"

# curl is used for every health check below; bootstrap it on minimal images.
if ! command -v curl >/dev/null 2>&1; then
  echo "== installing curl =="
  $SUDO apt-get update >/dev/null 2>&1 || true
  $SUDO apt-get install -y curl >/dev/null 2>&1 \
    || $SUDO dnf install -y curl >/dev/null 2>&1 \
    || $SUDO yum install -y curl >/dev/null 2>&1 || true
fi
if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl not found and could not be installed." >&2
  exit 1
fi

# --- find a REAL chrome/chromium binary ---
# Snap stubs are shell scripts. NOTE: google-chrome's /usr/bin/google-chrome is
# ALSO a script wrapper (it execs /opt/google/chrome/chrome), so we check known
# real binary locations too, not just PATH entries.
find_chrome() {
  for c in google-chrome google-chrome-stable chromium chromium-browser chrome; do
    if command -v "$c" >/dev/null 2>&1; then
      local path
      path="$(command -v "$c")"
      if [ -f "$path" ] && head -c 4 "$path" 2>/dev/null | grep -q ELF; then
        CHROME="$c"
        echo "browser: $CHROME ($("$CHROME" --version 2>&1 | head -1))"
        return 0
      fi
      echo "note: $c is a script wrapper, checking real binary locations"
    fi
  done
  # known real binaries, regardless of PATH wrappers
  local b
  for b in /opt/google/chrome/chrome \
           "$HOME"/.cache/ms-playwright/chromium-*/chrome-linux/chrome \
           "$HOME"/.cache/ms-playwright/chromium-*/chrome-headless-shell/chrome-headless-shell; do
    if [ -f "$b" ] && head -c 4 "$b" 2>/dev/null | grep -q ELF; then
      CHROME="$b"
      echo "browser: $CHROME ($("$CHROME" --version 2>&1 | head -1))"
      return 0
    fi
  done
  return 1
}

CHROME=""
if ! find_chrome; then
  echo "== no real chrome/chromium found; installing google-chrome-stable =="
  if command -v wget >/dev/null 2>&1; then
    wget -q https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -O /tmp/gchrome.deb
  elif command -v curl >/dev/null 2>&1; then
    curl -sL https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb -o /tmp/gchrome.deb
  else
    echo "ERROR: neither wget nor curl available." >&2
    exit 1
  fi
  $SUDO apt-get update >/dev/null 2>&1 || true
  if $SUDO apt-get install -y /tmp/gchrome.deb >/tmp/gchrome-install.log 2>&1; then
    rm -f /tmp/gchrome.deb
  else
    echo "google-chrome deb install failed, trying apt chromium..."
    tail -5 /tmp/gchrome-install.log
    $SUDO apt-get install -y chromium >/dev/null 2>&1 || true
    rm -f /tmp/gchrome.deb
  fi
  if ! find_chrome; then
    echo "== trying playwright chromium (container-friendly) =="
    if command -v npx >/dev/null 2>&1; then
      npx --yes playwright@latest install chromium --with-deps >/tmp/playwright-install.log 2>&1 || true
      if ! find_chrome; then
        echo "playwright chromium install did not produce a usable binary; log tail:"
        tail -10 /tmp/playwright-install.log
      fi
    fi
  fi
fi

if [ -z "$CHROME" ]; then
  echo "ERROR: could not install a browser. Install chromium/google-chrome manually." >&2
  exit 1
fi

# --- start the web server ---
if curl -s -o /dev/null "http://127.0.0.1:$PORT/"; then
  echo "web server already running on :$PORT"
else
  nohup python3 web/server.py > server.log 2>&1 &
  echo $! > server.pid
  ok=""
  for i in $(seq 1 20); do
    if curl -s -o /dev/null "http://127.0.0.1:$PORT/"; then ok=1; break; fi
    sleep 0.5
  done
  if [ -z "$ok" ]; then
    echo "ERROR: web server did not come up on :$PORT. server.log:" >&2
    cat server.log >&2
    exit 1
  fi
  echo "web server started (pid $(cat server.pid)): http://127.0.0.1:$PORT/"
fi

echo "config: $(curl -s http://127.0.0.1:$PORT/config.json | head -c 200)"

# --- start local SOCKS5 relay (only when upstream proxy needs auth) ---
if [ -n "$RELAY_UPSTREAM" ]; then
  if curl -s -o /dev/null -m 5 --socks5-hostname "127.0.0.1:$RELAY_PORT" http://example.com/ ; then
    echo "socks5 relay already running on :$RELAY_PORT"
  else
    if ! python3 -c "import pproxy" >/dev/null 2>&1; then
      echo "== installing pproxy (socks5 auth relay) =="
      if ! python3 -m pip --version >/dev/null 2>&1; then
        $SUDO apt-get install -y python3-pip >/dev/null 2>&1 \
          || $SUDO dnf install -y python3-pip >/dev/null 2>&1 \
          || $SUDO yum install -y python3-pip >/dev/null 2>&1 || true
      fi
      python3 -m pip install --quiet --user pproxy >/tmp/pproxy-install.log 2>&1 \
        || python3 -m pip install --quiet --user --break-system-packages pproxy >>/tmp/pproxy-install.log 2>&1 \
        || $SUDO python3 -m pip install --quiet --break-system-packages pproxy >>/tmp/pproxy-install.log 2>&1 \
        || { echo "ERROR: could not install pproxy. Install manually: python3 -m pip install pproxy" >&2; tail -5 /tmp/pproxy-install.log >&2; exit 1; }
    fi
    nohup python3 -m pproxy -l "socks5://127.0.0.1:$RELAY_PORT" -r "$RELAY_UPSTREAM" > socks-relay.log 2>&1 &
    echo $! > socks-relay.pid
    ok=""
    for i in $(seq 1 20); do
      if curl -s -o /dev/null -m 5 --socks5-hostname "127.0.0.1:$RELAY_PORT" http://example.com/ ; then ok=1; break; fi
      sleep 0.5
    done
    if [ -z "$ok" ]; then
      echo "ERROR: socks5 relay did not come up on :$RELAY_PORT. socks-relay.log:" >&2
      cat socks-relay.log >&2
      exit 1
    fi
    echo "socks5 relay up (pid $(cat socks-relay.pid)) -> ${RELAY_UPSTREAM%%#*}"
  fi
  EXIT_IP="$(curl -s -m 15 --socks5-hostname "127.0.0.1:$RELAY_PORT" https://api.ipify.org || echo unknown)"
  echo "proxy exit IP: $EXIT_IP"
fi

# --- CPU cap ---
# Two layers: the page spawns fewer workers (soft, via cpu_percent in
# /config.json), and systemd cgroup v2 enforces a ceiling Chrome cannot exceed.
# CPUQuota is expressed against ONE core, so 50% of an N-core box is N*50%.
CPU_WRAP=""
if [ "$CPU_PERCENT" -lt 100 ]; then
  CORES="$(nproc 2>/dev/null || echo 1)"
  QUOTA=$(( CORES * CPU_PERCENT ))
  [ "$QUOTA" -lt 1 ] && QUOTA=1
  if command -v systemd-run >/dev/null 2>&1 \
     && [ "$(stat -fc %T /sys/fs/cgroup 2>/dev/null)" = "cgroup2fs" ] \
     && systemctl is-system-running >/dev/null 2>&1; then
    CPU_WRAP="systemd-run --scope --collect --unit=polos-miner-$$ -p CPUQuota=${QUOTA}% -p CPUWeight=20"
    [ "$(id -u)" -eq 0 ] || CPU_WRAP="$CPU_WRAP --user"
    echo "cpu cap: ${CPU_PERCENT}% of ${CORES} cores (cgroup CPUQuota=${QUOTA}%, hard limit)"
  else
    echo "cpu cap: ${CPU_PERCENT}% requested; systemd cgroup v2 unavailable -> worker-count limit only (soft)"
  fi
else
  echo "cpu cap: none (100%)"
fi

# --- start headless chrome ---
if curl -s -o /dev/null "http://127.0.0.1:$CDP_PORT/json"; then
  echo "headless chrome already running (CDP :$CDP_PORT)"
  exit 0
fi

FLAGS="--disable-gpu --no-sandbox --disable-dev-shm-usage --no-first-run --disable-extensions --disable-background-networking --mute-audio --remote-allow-origins=* --remote-debugging-port=$CDP_PORT --user-data-dir=$PROFILE --window-size=1280,900"
if [ -n "$SOCKS5_PROXY" ]; then
  FLAGS="$FLAGS --proxy-server=$SOCKS5_PROXY"
  echo "SOCKS5 proxy enabled: ${SOCKS5_PROXY#socks5://}"
else
  echo "SOCKS5 proxy disabled"
fi

start_chrome() {
  if [ -n "$CPU_WRAP" ]; then
    nohup $CPU_WRAP "$CHROME" "$1" $FLAGS "http://127.0.0.1:$PORT/" > chrome.log 2>&1 &
  else
    nohup "$CHROME" "$1" $FLAGS "http://127.0.0.1:$PORT/" > chrome.log 2>&1 &
  fi
  echo $! > chrome.pid
  ok=""
  for i in $(seq 1 24); do
    if curl -s -o /dev/null "http://127.0.0.1:$CDP_PORT/json"; then ok=1; break; fi
    if ! kill -0 "$(cat chrome.pid)" 2>/dev/null; then break; fi
    sleep 0.5
  done
  [ -n "$ok" ]
}

if start_chrome "--headless=new"; then
  echo "headless chrome started (pid $(cat chrome.pid)), mining now."
elif start_chrome "--headless"; then
  echo "headless chrome started with legacy --headless (pid $(cat chrome.pid)), mining now."
else
  echo "ERROR: headless chrome failed to start. chrome.log:" >&2
  cat chrome.log >&2
  exit 1
fi

echo
echo "  web UI: http://127.0.0.1:$PORT/   (open in any browser to watch stats)"
echo "  CDP:    http://127.0.0.1:$CDP_PORT/json"
echo "  log:    tail -f chrome.log ; tail -f server.log"