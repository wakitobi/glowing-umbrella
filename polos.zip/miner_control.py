#!/usr/bin/env python3
"""Control primitives for the polos power2b web miner.

Pure-Python wrappers around setup.sh / stop.sh / .env / CDP that the AI agent
(ai_miner.py) and the web chat panel call as tools. Everything here is safe,
local, and reversible. No secrets are ever returned in plaintext — the pool
password is masked in every status/config payload.

These functions return plain dicts so they serialize straight to JSON for the
LLM tool-calling loop.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ENV = os.path.join(HERE, ".env")
CDP_PORT = int(os.environ.get("MINER_CDP_PORT", "9222"))
WEB_PORT = int(os.environ.get("MINER_WEB_PORT", "8765"))
SECRET_KEYS = {"password", "socks5_proxy"}


# --------------------------------------------------------------------------- #
# .env helpers
# --------------------------------------------------------------------------- #
def _read_env() -> dict:
    cfg = {}
    if not os.path.exists(ENV):
        return cfg
    with open(ENV, "r") as f:
        for line in f:
            s = line.strip()
            if s and "=" in s and not s.startswith("#"):
                k, v = s.split("=", 1)
                cfg[k.strip()] = v.strip().rstrip("\r")
    return cfg


def _write_env(cfg: dict) -> None:
    # Preserve original ordering + comments where possible; fall back to a
    # plain rewrite keyed by cfg. We keep it simple: rewrite k=v lines.
    lines = []
    seen = set()
    if os.path.exists(ENV):
        with open(ENV, "r") as f:
            for line in f:
                raw = line.rstrip("\n").rstrip("\r")
                s = raw.strip()
                if s and "=" in s and not s.startswith("#"):
                    k = s.split("=", 1)[0].strip()
                    if k in cfg:
                        lines.append(f"{k}={cfg[k]}")
                        seen.add(k)
                        continue
                lines.append(raw)
    for k, v in cfg.items():
        if k not in seen:
            lines.append(f"{k}={v}")
    with open(ENV, "w", newline="\n") as f:
        f.write("\n".join(lines) + "\n")


def _mask(cfg: dict) -> dict:
    out = {}
    for k, v in cfg.items():
        if k in SECRET_KEYS and v:
            out[k] = "***set***"
        else:
            out[k] = v
    return out


# --------------------------------------------------------------------------- #
# process / http helpers
# --------------------------------------------------------------------------- #
def _http_ok(url: str, timeout: float = 3.0) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return 200 <= r.status < 500
    except Exception:
        return False


def _pid_alive(pidfile: str) -> int | None:
    p = os.path.join(HERE, pidfile)
    if not os.path.exists(p):
        return None
    try:
        pid = int(open(p).read().strip())
    except Exception:
        return None
    try:
        os.kill(pid, 0)
        return pid
    except Exception:
        return None


# --------------------------------------------------------------------------- #
# AI-callable tools
# --------------------------------------------------------------------------- #
def get_config() -> dict:
    """Return the current miner configuration from .env (secrets masked)."""
    return {"ok": True, "config": _mask(_read_env())}


def set_config(key: str, value) -> dict:
    """Set a single .env key (e.g. cpu_percent, threads). Restart to apply."""
    key = str(key).strip()
    allowed = {"cpu_percent", "threads", "socks5_proxy", "host", "port",
               "username", "password", "proxy"}
    if key not in allowed:
        return {"ok": False, "error": f"key '{key}' not settable; allowed: {sorted(allowed)}"}
    cfg = _read_env()
    if key == "cpu_percent":
        try:
            iv = int(value)
        except Exception:
            return {"ok": False, "error": "cpu_percent must be an integer 1-100"}
        value = str(max(1, min(100, iv)))
    cfg[key] = str(value)
    _write_env(cfg)
    return {"ok": True, "set": {key: ("***set***" if key in SECRET_KEYS else str(value))},
            "note": "call restart_miner to apply"}


def miner_status() -> dict:
    """Report whether the web server + headless Chrome miner are running."""
    server = _http_ok(f"http://127.0.0.1:{WEB_PORT}/")
    cdp = _http_ok(f"http://127.0.0.1:{CDP_PORT}/json")
    return {
        "ok": True,
        "web_server": "up" if server else "down",
        "chrome_cdp": "up" if cdp else "down",
        "server_pid": _pid_alive("server.pid"),
        "chrome_pid": _pid_alive("chrome.pid"),
        "relay_pid": _pid_alive("socks-relay.pid"),
        "running": bool(server and cdp),
    }


def get_stats(sample_seconds: int = 0) -> dict:
    """Read live mining stats (pool, auth, hashrate, accepted/rejected shares)
    from the headless Chrome page over CDP. Optionally sample twice to get an
    accepted-share delta."""
    script = os.path.join(HERE, "cdp_probe.py")
    if not os.path.exists(script):
        return {"ok": False, "error": "cdp_probe.py not found"}
    try:
        args = [sys.executable, script]
        if sample_seconds:
            args.append(str(int(sample_seconds)))
        out = subprocess.run(args, capture_output=True, text=True,
                             timeout=(sample_seconds + 60))
        return {"ok": out.returncode == 0, "output": out.stdout[-4000:],
                "stderr": out.stderr[-1000:] if out.stderr else ""}
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "cdp_probe timed out"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _run_bash(script_name: str, env_extra: dict | None = None, timeout: int = 600) -> dict:
    path = os.path.join(HERE, script_name)
    if not os.path.exists(path):
        return {"ok": False, "error": f"{script_name} not found"}
    bash = shutil.which("bash") or "bash"
    env = dict(os.environ)
    if env_extra:
        env.update({k: str(v) for k, v in env_extra.items()})
    try:
        out = subprocess.run([bash, path], cwd=HERE, capture_output=True,
                             text=True, timeout=timeout, env=env)
        return {"ok": out.returncode == 0, "returncode": out.returncode,
                "output": out.stdout[-4000:], "stderr": out.stderr[-2000:]}
    except subprocess.TimeoutExpired as e:
        return {"ok": False, "error": "timeout",
                "output": (e.stdout or "")[-2000:] if hasattr(e, "stdout") else ""}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def start_miner(cpu_percent: int | None = None) -> dict:
    """Start the miner (web server + headless Chrome). Optionally override the
    CPU budget for this run (1-100)."""
    st = miner_status()
    if st.get("running"):
        return {"ok": True, "already_running": True, "status": st}
    env_extra = {}
    if cpu_percent is not None:
        try:
            env_extra["MINER_CPU_PERCENT"] = str(max(1, min(100, int(cpu_percent))))
        except Exception:
            pass
    res = _run_bash("setup.sh", env_extra, timeout=900)
    res["status"] = miner_status()
    return res


def stop_miner() -> dict:
    """Stop the miner (kills headless Chrome + web server + any relay)."""
    res = _run_bash("stop.sh", timeout=120)
    res["status"] = miner_status()
    return res


def restart_miner(cpu_percent: int | None = None) -> dict:
    """Stop then start the miner, applying any config changes."""
    stop_miner()
    time.sleep(2)
    return start_miner(cpu_percent=cpu_percent)


def tail_logs(lines: int = 40, which: str = "chrome") -> dict:
    """Return the last N lines of a miner log. which: chrome | server | relay."""
    fmap = {"chrome": "chrome.log", "server": "server.log", "relay": "socks-relay.log"}
    fn = fmap.get(which, "chrome.log")
    path = os.path.join(HERE, fn)
    if not os.path.exists(path):
        return {"ok": False, "error": f"{fn} not present yet"}
    try:
        with open(path, "r", errors="replace") as f:
            data = f.readlines()
        tail = data[-max(1, min(500, int(lines))):]
        return {"ok": True, "file": fn, "lines": "".join(tail)[-4000:]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# Tool registry consumed by ai_miner.py and the web /ai endpoint.
TOOLS = {
    "get_config": get_config,
    "set_config": set_config,
    "miner_status": miner_status,
    "get_stats": get_stats,
    "start_miner": start_miner,
    "stop_miner": stop_miner,
    "restart_miner": restart_miner,
    "tail_logs": tail_logs,
}


def call_tool(name: str, args: dict | None = None) -> dict:
    fn = TOOLS.get(name)
    if not fn:
        return {"ok": False, "error": f"unknown tool '{name}'"}
    args = args or {}
    try:
        return fn(**args)
    except TypeError as e:
        return {"ok": False, "error": f"bad arguments for {name}: {e}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


if __name__ == "__main__":
    # Tiny CLI: python miner_control.py <tool> [json-args]
    if len(sys.argv) < 2:
        print("tools:", ", ".join(TOOLS))
        sys.exit(0)
    name = sys.argv[1]
    a = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    print(json.dumps(call_tool(name, a), indent=2))
