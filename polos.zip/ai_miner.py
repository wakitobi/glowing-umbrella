#!/usr/bin/env python3
"""ai_miner.py — natural-language control of the polos power2b web miner.

A local, private AI agent: talks to a built-in Ollama server running a Qwen
model and drives the miner through the tools in miner_control.py using Ollama's
tool-calling API. Nothing leaves the machine — the LLM is local.

Usage:
    python3 ai_miner.py                     # interactive REPL
    python3 ai_miner.py "start mining at 50% cpu"   # one-shot command
    python3 ai_miner.py --model qwen2.5:3b  # pick a model

Requires a running Ollama (bash ai_setup.sh sets it up and pulls the model).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request

import miner_control as mc

OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
DEFAULT_MODEL = os.environ.get("MINER_AI_MODEL", "qwen2.5:3b")

SYSTEM_PROMPT = """You are the on-box operator for a power2b cryptocurrency web
miner (MicroBitcoin, WASM inside headless Chrome). You control it entirely
through the provided tools — never invent status, always call a tool to check.

Guidelines:
- To answer "is it mining / how is it doing", call miner_status then get_stats.
- To change CPU usage, call set_config(key='cpu_percent', value=N) then
  restart_miner so it takes effect. cpu_percent is 1-100.
- start_miner / stop_miner / restart_miner control the process.
- get_stats reads live accepted/rejected shares and hashrate over CDP.
- Never reveal pool credentials; they are masked for a reason.
- Be concise. After acting, report the real result from the tool output.
"""

# Ollama tool schema (OpenAI-compatible function format).
TOOL_SCHEMA = [
    {"type": "function", "function": {
        "name": "miner_status",
        "description": "Check whether the web server and headless Chrome miner are running.",
        "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {
        "name": "get_stats",
        "description": "Read live mining stats (pool connection, auth, hashrate, accepted/rejected shares) over CDP. Optionally sample twice for an accepted-share delta.",
        "parameters": {"type": "object", "properties": {
            "sample_seconds": {"type": "integer", "description": "seconds between two snapshots for a delta; 0 = single snapshot"}}}}},
    {"type": "function", "function": {
        "name": "get_config",
        "description": "Return current miner config from .env (secrets masked).",
        "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {
        "name": "set_config",
        "description": "Set one config key (cpu_percent, threads, socks5_proxy, host, port). Restart to apply.",
        "parameters": {"type": "object", "properties": {
            "key": {"type": "string"},
            "value": {"type": "string"}},
            "required": ["key", "value"]}}},
    {"type": "function", "function": {
        "name": "start_miner",
        "description": "Start the miner. Optionally set cpu_percent (1-100) for this run.",
        "parameters": {"type": "object", "properties": {
            "cpu_percent": {"type": "integer"}}}}},
    {"type": "function", "function": {
        "name": "stop_miner",
        "description": "Stop the miner (kills Chrome + web server + relay).",
        "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {
        "name": "restart_miner",
        "description": "Restart the miner, applying config changes. Optionally set cpu_percent.",
        "parameters": {"type": "object", "properties": {
            "cpu_percent": {"type": "integer"}}}}},
    {"type": "function", "function": {
        "name": "tail_logs",
        "description": "Return the last N lines of a miner log. which: chrome|server|relay.",
        "parameters": {"type": "object", "properties": {
            "lines": {"type": "integer"},
            "which": {"type": "string"}}}}},
]


def _post(path: str, payload: dict, timeout: int = 300) -> dict:
    data = json.dumps(payload).encode()
    req = urllib.request.Request(OLLAMA_URL + path, data=data,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def ollama_up() -> bool:
    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=5) as r:
            return r.status == 200
    except Exception:
        return False


def have_model(model: str) -> bool:
    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=5) as r:
            tags = json.load(r)
        names = [m.get("name", "") for m in tags.get("models", [])]
        return any(n == model or n.startswith(model.split(":")[0]) for n in names)
    except Exception:
        return False


def chat(messages: list, model: str) -> dict:
    """One /api/chat round with tools. Returns the assistant message dict."""
    payload = {"model": model, "messages": messages, "tools": TOOL_SCHEMA,
               "stream": False, "options": {"temperature": 0.1}}
    resp = _post("/api/chat", payload)
    return resp.get("message", {})


def run_agent(user_text: str, model: str, history: list | None = None,
              verbose: bool = True, max_steps: int = 6) -> tuple[str, list]:
    messages = history if history is not None else [
        {"role": "system", "content": SYSTEM_PROMPT}]
    messages.append({"role": "user", "content": user_text})

    for _ in range(max_steps):
        msg = chat(messages, model)
        messages.append(msg)
        calls = msg.get("tool_calls") or []
        if not calls:
            return msg.get("content", "").strip(), messages
        for c in calls:
            fn = c.get("function", {})
            name = fn.get("name", "")
            args = fn.get("arguments", {}) or {}
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except Exception:
                    args = {}
            if verbose:
                print(f"  \u2699 {name}({json.dumps(args) if args else ''})",
                      file=sys.stderr)
            result = mc.call_tool(name, args)
            messages.append({"role": "tool", "name": name,
                             "content": json.dumps(result)[:6000]})
    # ran out of steps — ask for a final summary
    messages.append({"role": "user",
                     "content": "Summarize the result for me in one or two lines."})
    final = chat(messages, model)
    return final.get("content", "").strip(), messages


def repl(model: str):
    print(f"polos AI miner — model {model} @ {OLLAMA_URL}")
    print("Type a command (e.g. 'start mining at 50% cpu', 'how many shares?', "
          "'stop'). Ctrl-D or 'quit' to exit.\n")
    history = [{"role": "system", "content": SYSTEM_PROMPT}]
    while True:
        try:
            line = input("miner> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line.lower() in {"quit", "exit"}:
            break
        try:
            answer, history = run_agent(line, model, history)
        except Exception as e:
            print(f"error: {e}", file=sys.stderr)
            continue
        print(answer + "\n")


def main():
    ap = argparse.ArgumentParser(description="AI control for the polos web miner")
    ap.add_argument("command", nargs="*", help="one-shot natural-language command")
    ap.add_argument("--model", default=DEFAULT_MODEL, help="Ollama model tag")
    args = ap.parse_args()

    if not ollama_up():
        print(f"ERROR: Ollama not reachable at {OLLAMA_URL}.\n"
              f"Run:  bash ai_setup.sh   (installs ollama + pulls {args.model})",
              file=sys.stderr)
        return 1
    if not have_model(args.model):
        print(f"WARNING: model '{args.model}' not found in Ollama. "
              f"Pull it:  ollama pull {args.model}", file=sys.stderr)

    if args.command:
        answer, _ = run_agent(" ".join(args.command), args.model)
        print(answer)
        return 0
    repl(args.model)
    return 0


if __name__ == "__main__":
    sys.exit(main())
