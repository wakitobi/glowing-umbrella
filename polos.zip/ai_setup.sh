#!/usr/bin/env bash
# ai_setup.sh — install a built-in local LLM (Ollama + Qwen) for the AI miner.
# Idempotent: safe to re-run. Installs ollama, starts the server, pulls the
# model, and smoke-tests ai_miner.py. Nothing leaves the machine — the model
# runs locally.
#
#   bash ai_setup.sh                 # default model qwen2.5:3b
#   MINER_AI_MODEL=qwen2.5:7b bash ai_setup.sh
set -uo pipefail
cd "$(dirname "$0")"

MODEL="${MINER_AI_MODEL:-qwen2.5:3b}"
OLLAMA_HOST="${OLLAMA_HOST:-http://127.0.0.1:11434}"
SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

echo "== AI miner setup: model=$MODEL host=$OLLAMA_HOST =="

# --- 1. install ollama if missing ---
if ! command -v ollama >/dev/null 2>&1; then
  echo "== installing ollama =="
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL https://ollama.com/install.sh | $SUDO sh
  else
    echo "ERROR: curl needed to install ollama. Install curl first." >&2
    exit 1
  fi
fi
if ! command -v ollama >/dev/null 2>&1; then
  echo "ERROR: ollama install failed. See https://ollama.com/download" >&2
  exit 1
fi
echo "ollama: $(ollama --version 2>&1 | head -1)"

# --- 2. make sure the server is running ---
if curl -s -o /dev/null -m 3 "$OLLAMA_HOST/api/tags"; then
  echo "ollama server already up"
else
  echo "== starting ollama server =="
  nohup ollama serve > ollama.log 2>&1 &
  echo $! > ollama.pid
  ok=""
  for i in $(seq 1 30); do
    if curl -s -o /dev/null -m 3 "$OLLAMA_HOST/api/tags"; then ok=1; break; fi
    sleep 1
  done
  if [ -z "$ok" ]; then
    echo "ERROR: ollama server did not come up. ollama.log:" >&2
    tail -20 ollama.log >&2
    exit 1
  fi
  echo "ollama server started (pid $(cat ollama.pid))"
fi

# --- 3. pull the model (idempotent; skips if present) ---
if ollama list 2>/dev/null | awk '{print $1}' | grep -qx "$MODEL"; then
  echo "model $MODEL already present"
else
  echo "== pulling $MODEL (first run downloads a few GB) =="
  ollama pull "$MODEL"
fi

# --- 4. python deps for cdp stats (used by get_stats tool) ---
if ! python3 -c "import websocket" >/dev/null 2>&1; then
  echo "== installing websocket-client (for live stats) =="
  python3 -m pip install --quiet --user websocket-client >/dev/null 2>&1 \
    || python3 -m pip install --quiet --user --break-system-packages websocket-client >/dev/null 2>&1 \
    || echo "note: could not auto-install websocket-client; get_stats may be limited"
fi

# --- 5. smoke test ---
echo "== smoke test: asking the model to check miner status =="
MINER_AI_MODEL="$MODEL" python3 ai_miner.py "check the miner status" || true

cat <<EOF

AI miner ready.
  Interactive:  python3 ai_miner.py
  One-shot:     python3 ai_miner.py "start mining at 50% cpu"
  Model:        $MODEL   (change with MINER_AI_MODEL=... )
  Server log:   tail -f ollama.log
EOF
