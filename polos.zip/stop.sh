#!/usr/bin/env bash
# Stop the web miner: kills headless chrome + web server.
cd "$(dirname "$0")"
[ -f chrome.pid ] && kill "$(cat chrome.pid)" 2>/dev/null && rm -f chrome.pid && echo "chrome stopped"
[ -f server.pid ] && kill "$(cat server.pid)" 2>/dev/null && rm -f server.pid && echo "server stopped"
[ -f socks-relay.pid ] && kill "$(cat socks-relay.pid)" 2>/dev/null && rm -f socks-relay.pid && echo "socks5 relay stopped"
pkill -f "headless=new.*$PORT" 2>/dev/null || true
# clean up the cgroup scope if setup.sh applied a CPU cap
if command -v systemctl >/dev/null 2>&1; then
  for u in $(systemctl list-units --type=scope --all --no-legend 2>/dev/null | awk '/polos-miner-/ {print $1}'); do
    systemctl stop "$u" 2>/dev/null && echo "cpu-cap scope $u stopped"
  done
fi
echo "done"
