#!/usr/bin/env bash
# Diagnose why the web miner isn't running. Prints all relevant state.
cd "$(dirname "$0")"
echo "==== processes ===="
ps aux | grep -E "chrome|server.py" | grep -v grep || echo "(none)"
echo
echo "==== ports ===="
for p in 8765 9222; do
  if curl -s -o /dev/null -m 2 "http://127.0.0.1:$p/"; then echo ":$p UP"; else echo ":$p DOWN"; fi
done
echo
echo "==== chrome.log (last 30) ===="
[ -f chrome.log ] && tail -30 chrome.log || echo "(no chrome.log)"
echo
echo "==== server.log (last 20) ===="
[ -f server.log ] && tail -20 server.log || echo "(no server.log)"
echo
echo "==== page state (via CDP if up) ===="
if curl -s -m 5 "http://127.0.0.1:9222/json" | grep -qi "websocketdebuggerurl"; then
  echo "CDP is up - open http://127.0.0.1:8765/ in a browser to see the stats page"
  if [ -f cdp_probe.py ]; then
    echo "--- live miner stats ---"
    python3 cdp_probe.py 2>&1 | head -40
  fi
else
  echo "CDP down - headless chrome not running"
fi
echo
echo "==== python3 / chrome ===="
command -v python3 && python3 --version
command -v chromium chromium-browser google-chrome 2>/dev/null || echo "(no chrome binary in PATH)"
echo
echo "If ports are DOWN, re-run:  bash setup.sh"