# power2b web miner (Linux deploy)

Runs the mbc power2b miner inside headless Chrome, driven by a web page that
talks Stratum over WebSocket straight to your Koyeb proxy (same pool config as
the Python miner). No third-party relay, no fee.

## Layout

    .env                 pool config (proxy wss URL, username, password, cpu_percent, optional socks5_proxy)
    web/index.html       the embedded miner page (JS Stratum client + stats UI + AI chat panel)
    web/worker.js        power2b WASM miner worker (works on any OS/arch)
    web/server.py        tiny python3 web server: injects .env config, serves the page, and hosts the /ai agent endpoint, port 8765
    miner_control.py     safe control primitives (start/stop/status/stats/config) the AI agent calls as tools
    ai_miner.py          local AI agent — drives the miner in natural language via a built-in Ollama + Qwen model
    ai_setup.sh          install Ollama, pull the Qwen model, start the server (one command)
    setup.sh             install chromium if needed, start server + headless chrome
    stop.sh              stop both
    diagnose.sh          full state dump + live stats
    cdp_probe.py         live miner stats over CDP (no browser needed)
    cpu_sample.py        measure real aggregate chrome CPU usage
    deploy_vps.py        push + run + verify on a remote Linux host over SSH

## AI-powered control (built-in Ollama + Qwen)

Run the miner with plain-English commands. A local Qwen model (via Ollama)
interprets what you want and calls the miner control tools — start, stop,
change CPU budget, read live shares. It's fully local: no cloud, no API key,
credentials never leave the box.

One-time setup (installs Ollama, pulls the model, smoke-tests it):

    bash ai_setup.sh                       # default model qwen2.5:3b (~2GB)
    MINER_AI_MODEL=qwen2.5:7b bash ai_setup.sh   # bigger/smarter, ~4.7GB

Then talk to it:

    python3 ai_miner.py                                  # interactive REPL
    python3 ai_miner.py "start mining at 50% cpu"        # one-shot
    python3 ai_miner.py "how many shares have we accepted?"
    python3 ai_miner.py "throttle to 25 percent and restart"
    python3 ai_miner.py "stop the miner"

Or use the chat box at the bottom of the web dashboard (http://127.0.0.1:8765/) —
same agent, same tools, in the browser.

Tools the agent can call (all local, reversible, secrets masked):
`miner_status`, `get_stats`, `get_config`, `set_config`, `start_miner`,
`stop_miner`, `restart_miner`, `tail_logs`. Test one directly:

    python3 miner_control.py miner_status
    python3 miner_control.py set_config '{"key":"cpu_percent","value":40}'

Pick the model with `MINER_AI_MODEL`; point at a remote Ollama with
`OLLAMA_HOST=http://host:11434`. The dashboard shows a green/red AI status dot.

## Layout

## Quick start (on the Linux machine)

    tar xzf web-miner-linux.tar.gz
    cd web-miner-linux
    bash setup.sh

That's it. It auto-installs Chromium when missing (needs sudo for apt/dnf),
then launches headless Chrome mining the page. ~5 seconds later it's hashing.

## Deploy to a remote Linux box from this machine

`deploy_vps.py` pushes the bundle over SSH and drives it. Credentials come
from the environment — nothing is hardcoded:

    export VPS_HOST=1.2.3.4 VPS_PORT=22 VPS_USER=root VPS_PASS=...
    python deploy_vps.py check     # connectivity + os/cpu/python facts
    python deploy_vps.py upload    # sftp the 9 needed files, fix perms + CRLF
    python deploy_vps.py run       # bash setup.sh (installs chrome, starts miner)
    python deploy_vps.py status    # diagnose.sh + live CDP stats
    python deploy_vps.py stop      # bash stop.sh
    python deploy_vps.py all       # check + upload + run + status

Requires `pip install paramiko` locally. Override the remote path with
`VPS_REMOTE_DIR` (default `/root/polos`). It uploads only what the miner
needs — the duplicate `web-miner-linux/` copy, `zalo.zip` and `__pycache__`
are skipped.

Prefer keys over passwords for anything long-lived: `ssh-copy-id`, then drop
`VPS_PASS` and let paramiko use the agent.

## Live stats without a browser

`cdp_probe.py` runs on the miner host and reads the real page state over CDP:

    python3 cdp_probe.py        # one snapshot
    python3 cdp_probe.py 45     # two snapshots 45s apart + accepted-share delta

`diagnose.sh` calls it automatically when CDP is up. Needs
`pip3 install websocket-client` on the miner host.

Check it:
    curl http://127.0.0.1:8765/          # page is served
    tail -f web/server.log chrome.log   # logs
    # open http://127.0.0.1:8765/ in any browser to watch stats live
    # (use --headless=new --remote-debugging-port=9222 for CDP automation)

Stop:   bash stop.sh
Restart: bash setup.sh

## Tuning

    MINER_WEB_PORT=8765 bash setup.sh                  # ports
    MINER_CPU_PERCENT=25 bash setup.sh                 # override cpu budget

### CPU budget

Set `cpu_percent` in `.env` (1-100, default 100):

    cpu_percent=50

Enforced in two layers:

1. **Worker count (soft)** — the page reads `cpu_percent` from `/config.json`
   and spawns `round(cores * pct / 100)` workers, minimum 1, still capped at 7.
   On 2 cores at 50% that's 1 worker; on 8 cores it's 4.
2. **cgroup CPUQuota (hard)** — when systemd + cgroup v2 are present,
   `setup.sh` launches Chrome inside a `systemd-run --scope` with
   `CPUQuota=(cores * pct)%` and `CPUWeight=20`. Chrome physically cannot
   exceed the budget even if a worker misbehaves, and the low weight means
   other processes win contention.

Without systemd (bare containers) only layer 1 applies — setup.sh says so
explicitly at startup. Verify actual usage with:

    python3 cpu_sample.py 40    # aggregate chrome CPU%, of one core and of machine

Measured on a 2-vCPU box: uncapped 199.8% of one core (99.9% of machine),
`cpu_percent=50` gives 100.1% of one core (50.1% of machine).

## Notes

## SOCKS5

Set a SOCKS5 endpoint in `.env` before running `setup.sh`:

    socks5_proxy=127.0.0.1:1080
    socks5_proxy=socks5://127.0.0.1:1080
    socks5_proxy=socks5://user:pass@1.2.3.4:30034     # authenticated

Headless Chrome routes the miner's outbound WebSocket through this proxy. The
local dashboard and CDP remain on loopback.

Chrome's `--proxy-server` cannot carry SOCKS5 credentials. When `socks5_proxy`
includes `user:pass@`, `setup.sh` detects it and starts a local unauthenticated
SOCKS5 relay (`pproxy`, auto-installed) on 127.0.0.1:1080 that forwards to the
authenticated upstream, then points Chrome at the relay. It prints the proxy
exit IP so you can confirm egress. Override the relay port with
`MINER_SOCKS_RELAY_PORT`. Relay log: `socks-relay.log`; `stop.sh` kills it too.

Remove the setting to disable proxying.

- .env contains your pool credentials — keep the tarball private.
- server binds 127.0.0.1 only. To view the dashboard from another machine,
  set MINER_WEB_PORT and edit server.py bind to 0.0.0.0 (or ssh -L 8765:localhost:8765).
- Wasm hashrate (~250-400 H/s/7 workers) is much lower than the native Python
  miner. Real valid shares, just slow — fine for monitoring/experiments.
