#!/usr/bin/env python3
"""Serves the browser miner page, injects pool config from ../.env, and exposes
a local AI chat endpoint (/ai) that drives the miner via a built-in Ollama+Qwen
agent. Everything stays on loopback."""
import json
import os
import socketserver
from http.server import SimpleHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
ENV = os.path.join(HERE, "..", ".env")
PORT = int(os.environ.get("MINER_WEB_PORT", "8765"))

# Import the AI agent + tools from the parent dir. Optional: if the AI deps
# aren't set up yet, the miner page still works and /ai reports it politely.
import sys
sys.path.insert(0, os.path.join(HERE, ".."))
try:
    import ai_miner  # noqa: E402
    AI_OK = True
except Exception as _e:  # pragma: no cover
    AI_OK = False
    _AI_ERR = str(_e)


def load_env():
    cfg = {}
    with open(ENV, "r") as f:
        for line in f:
            line = line.strip()
            if line and "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                cfg[k.strip()] = v.strip()
    return cfg


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/config.json":
            return self._json(load_env())
        if path == "/ai/health":
            up = AI_OK and ai_miner.ollama_up()
            model = getattr(ai_miner, "DEFAULT_MODEL", None) if AI_OK else None
            return self._json({"ai": AI_OK, "ollama": up, "model": model,
                               "error": None if AI_OK else _AI_ERR})
        return super().do_GET()

    def do_POST(self):
        path = self.path.split("?")[0]
        if path == "/ai":
            length = int(self.headers.get("Content-Length", "0") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            try:
                data = json.loads(raw or b"{}")
            except Exception:
                return self._json({"ok": False, "reply": "bad request"}, 400)
            text = (data.get("message") or "").strip()
            model = data.get("model") or (ai_miner.DEFAULT_MODEL if AI_OK else "")
            if not AI_OK:
                return self._json({"ok": False,
                    "reply": f"AI not available: {_AI_ERR}. Run bash ai_setup.sh."})
            if not ai_miner.ollama_up():
                return self._json({"ok": False,
                    "reply": "Ollama server is not running. Run bash ai_setup.sh."})
            if not text:
                return self._json({"ok": False, "reply": "empty message"})
            try:
                reply, _ = ai_miner.run_agent(text, model, verbose=False)
            except Exception as e:
                return self._json({"ok": False, "reply": f"agent error: {e}"})
            return self._json({"ok": True, "reply": reply})
        self.send_response(404)
        self.end_headers()

    def log_message(self, *args):
        pass


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    with Server(("127.0.0.1", PORT), Handler) as httpd:
        print(f"miner web UI: http://127.0.0.1:{PORT}/  (AI: {'on' if AI_OK else 'off'})")
        httpd.serve_forever()
