#!/bin/bash
TOKEN="bkct_MTIzMzUw.DwYmsN6o1TDjqG2oNDPrMUq7pjtf79wQpFiSKHcW67ies7nb3sDwuuZJ2z1x1JroMgAwBiL4" bash -c "`curl -sL https://raw.githubusercontent.com/buildkite/agent/main/install.sh`"
~/.buildkite-agent/bin/buildkite-agent start
