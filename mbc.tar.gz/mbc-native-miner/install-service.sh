#!/usr/bin/env bash
###############################################################################
# install-service.sh — install the native power2b miner as systemd services.
#
# Creates two units so the miner always has its WS bridge up first:
#   mbc-bridge.service  — TCP<->Koyeb-WebSocket shim (ws_bridge.py)
#   mbc-miner.service   — cpuminer -a power2b, Requires+After the bridge
#
# Both auto-start on boot and restart on failure. Run as root (or with sudo).
#
# Usage (from inside the extracted mbc-native-miner dir):
#     sudo bash install-service.sh                 # install to /opt/mbc-miner
#     sudo bash install-service.sh --threads 8     # cap worker threads
#     sudo bash install-service.sh --port 3334     # bridge port
#     sudo bash install-service.sh --uninstall     # remove services
###############################################################################
set -uo pipefail

PREFIX="${MBC_PREFIX:-/opt/mbc-miner}"
BRIDGE_PORT="${BRIDGE_PORT:-3334}"
THREADS=""
UNINSTALL=0

while [ $# -gt 0 ]; do
  case "$1" in
    --threads) THREADS="$2"; shift 2;;
    --port) BRIDGE_PORT="$2"; shift 2;;
    --prefix) PREFIX="$2"; shift 2;;
    --uninstall) UNINSTALL=1; shift;;
    *) echo "unknown arg: $1"; exit 2;;
  esac
done

log(){ printf '\033[1;32m[+]\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run as root (sudo bash install-service.sh)"
command -v systemctl >/dev/null 2>&1 || die "systemd not found on this machine"

if [ "$UNINSTALL" -eq 1 ]; then
  log "stopping + removing services"
  systemctl disable --now mbc-miner.service 2>/dev/null || true
  systemctl disable --now mbc-bridge.service 2>/dev/null || true
  rm -f /etc/systemd/system/mbc-miner.service /etc/systemd/system/mbc-bridge.service
  systemctl daemon-reload
  log "uninstalled (files under $PREFIX left intact; rm -rf $PREFIX to remove)"
  exit 0
fi

SRC="$(cd "$(dirname "$0")" && pwd)"
[ -f "$SRC/ws_bridge.py" ] || die "run this from the extracted mbc-native-miner dir"
[ -f "$SRC/.env" ] || die "missing .env (proxy/username/password)"

# ---- build the miner if needed ----
if [ ! -x "$SRC/cpuminer-src/cpuminer" ]; then
  log "miner not built yet — building now"
  bash "$SRC/setup.sh" --build-only || die "build failed"
fi

# ---- install files ----
log "installing to $PREFIX"
mkdir -p "$PREFIX"
cp -r "$SRC/cpuminer-src" "$PREFIX/"
cp "$SRC/ws_bridge.py" "$PREFIX/"
cp "$SRC/.env" "$PREFIX/.env"
chmod 600 "$PREFIX/.env"   # creds — root-only
[ -f "$SRC/setup.sh" ] && cp "$SRC/setup.sh" "$PREFIX/"
[ -f "$SRC/stop.sh" ]  && cp "$SRC/stop.sh"  "$PREFIX/"

# ensure python websockets present
if ! python3 -c 'import websockets' 2>/dev/null; then
  log "installing python websockets"
  pip3 install --break-system-packages -q websockets 2>/dev/null \
    || pip3 install -q websockets 2>/dev/null \
    || apt-get install -y -qq python3-websockets 2>/dev/null \
    || true
  python3 -c 'import websockets' 2>/dev/null || die "could not install python websockets"
fi

USER_STR="$(grep -E '^username=' "$PREFIX/.env" | head -1 | cut -d= -f2- | tr -d '\r')"
PASS_STR="$(grep -E '^password=' "$PREFIX/.env" | head -1 | cut -d= -f2- | tr -d '\r')"
[ -n "$USER_STR" ] || die "username= missing in .env"
T="${THREADS:-$(nproc)}"
PYBIN="$(command -v python3)"

# ---- bridge unit ----
cat > /etc/systemd/system/mbc-bridge.service <<UNIT
[Unit]
Description=MBC power2b Koyeb WebSocket bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$PREFIX
Environment=BRIDGE_PORT=$BRIDGE_PORT
ExecStart=$PYBIN $PREFIX/ws_bridge.py
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
UNIT

# ---- miner unit ---- (needs the bridge listening first)
cat > /etc/systemd/system/mbc-miner.service <<UNIT
[Unit]
Description=MBC native power2b miner (via Koyeb bridge)
After=mbc-bridge.service
Requires=mbc-bridge.service

[Service]
Type=simple
WorkingDirectory=$PREFIX
# give the bridge a moment to bind the port after it starts
ExecStartPre=/bin/sleep 3
ExecStart=$PREFIX/cpuminer-src/cpuminer -a power2b -o stratum+tcp://127.0.0.1:$BRIDGE_PORT -u $USER_STR -p $PASS_STR -t $T
Restart=always
RestartSec=10
User=root

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now mbc-bridge.service
systemctl enable --now mbc-miner.service

sleep 6
log "status:"
systemctl is-active mbc-bridge.service | sed 's/^/     bridge: /'
systemctl is-active mbc-miner.service  | sed 's/^/     miner:  /'
echo
cat <<DONE
-----------------------------------------------------------------------------
Installed. Miner runs on boot and restarts on failure.

  threads:   $T
  bridge:    127.0.0.1:$BRIDGE_PORT  ->  Koyeb proxy  ->  pool
  logs:      journalctl -u mbc-miner -f
             journalctl -u mbc-bridge -f
  stop:      systemctl stop mbc-miner mbc-bridge
  start:     systemctl start mbc-bridge mbc-miner
  remove:    sudo bash install-service.sh --uninstall
-----------------------------------------------------------------------------
DONE
