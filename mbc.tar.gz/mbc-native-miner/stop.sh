#!/usr/bin/env bash
# stop.sh — stop the miner and the WS bridge.
cd "$(dirname "$0")"
pkill -f 'cpuminer-src/cpuminer' 2>/dev/null && echo "miner stopped" || echo "no miner running"
if [ -f bridge.pid ]; then
  kill "$(cat bridge.pid)" 2>/dev/null && echo "bridge stopped (pid $(cat bridge.pid))"
  rm -f bridge.pid
fi
pkill -f 'ws_bridge.py' 2>/dev/null || true
