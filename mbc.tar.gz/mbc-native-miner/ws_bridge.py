#!/usr/bin/env python3
"""
ws_bridge.py — local TCP Stratum <-> Koyeb WebSocket Stratum bridge.

The native miner (cpuminer -a power2b) talks plain TCP Stratum. The Koyeb proxy
speaks the SAME Stratum JSON, but framed as text messages over a WebSocket
(wss://...). This bridge listens on a local TCP port, and for each miner
connection opens one WebSocket to the Koyeb proxy, relaying newline-delimited
Stratum lines in both directions verbatim. No protocol translation — just a
transport shim, identical to what the browser worker did with `new WebSocket`.

Config comes from ../.env (same file the browser miner used):
    proxy=wss://<host>/<base64 target>    (required)
Env overrides:
    BRIDGE_HOST (default 127.0.0.1)
    BRIDGE_PORT (default 3333)
"""
import asyncio
import os
import sys

try:
    import websockets
except ImportError:
    sys.exit("ERROR: pip3 install --break-system-packages websockets")

HERE = os.path.dirname(os.path.abspath(__file__))


def find_env():
    # packaged layout: .env beside this script; browser-miner layout: ../.env
    for cand in (os.path.join(HERE, ".env"), os.path.join(HERE, "..", ".env")):
        if os.path.isfile(cand):
            return cand
    # env override
    if os.environ.get("MINER_ENV") and os.path.isfile(os.environ["MINER_ENV"]):
        return os.environ["MINER_ENV"]
    sys.exit("ERROR: no .env found (looked beside ws_bridge.py and in ../)")


ENV = find_env()


def load_env(path):
    cfg = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line and "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                cfg[k.strip()] = v.strip()
    return cfg


CFG = load_env(ENV)
PROXY = CFG.get("proxy")
if not PROXY:
    sys.exit("ERROR: 'proxy' (wss URL) not set in .env")
HOST = os.environ.get("BRIDGE_HOST", "127.0.0.1")
PORT = int(os.environ.get("BRIDGE_PORT", "3333"))


def log(*a):
    print("[bridge]", *a, flush=True)


async def tcp_to_ws(reader, ws):
    """Miner -> Koyeb. Read TCP lines, forward as WS text messages."""
    try:
        while True:
            line = await reader.readline()
            if not line:
                break
            await ws.send(line.decode("utf-8", "replace"))
    except Exception as e:
        log("tcp->ws closed:", e)


async def ws_to_tcp(ws, writer):
    """Koyeb -> Miner. Read WS messages, forward as TCP bytes (ensure newline)."""
    try:
        async for msg in ws:
            data = msg if isinstance(msg, str) else msg.decode("utf-8", "replace")
            if not data.endswith("\n"):
                data += "\n"
            writer.write(data.encode())
            await writer.drain()
    except Exception as e:
        log("ws->tcp closed:", e)


async def handle_miner(reader, writer):
    peer = writer.get_extra_info("peername")
    log("miner connected:", peer)
    try:
        async with websockets.connect(PROXY, max_size=None, ping_interval=20) as ws:
            log("upstream WS open ->", PROXY.split("/")[2])
            await asyncio.gather(
                tcp_to_ws(reader, ws),
                ws_to_tcp(ws, writer),
            )
    except Exception as e:
        log("session error:", e)
    finally:
        try:
            writer.close()
        except Exception:
            pass
        log("miner disconnected:", peer)


async def main():
    server = await asyncio.start_server(handle_miner, HOST, PORT)
    log(f"listening on {HOST}:{PORT}  ->  {PROXY}")
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
