#!/usr/bin/env bash
###############################################################################
# setup.sh — build + run the native power2b miner on ANY Linux machine.
#
# It talks to the pool through the Koyeb WebSocket proxy defined in .env
# (same proxy the browser miner used), via a tiny local TCP<->WS bridge.
#
#   miner (cpuminer -a power2b, plain TCP) --> 127.0.0.1:3334 (ws_bridge.py)
#        --> wss://<koyeb>/<b64 target> --> zpool power2b stratum
#
# Usage:
#     tar xzf mbc-native-miner.tar.gz && cd mbc-native-miner
#     bash setup.sh                 # build (first run), start bridge + miner
#     bash setup.sh --threads 8     # cap worker threads (default: all cores)
#     bash setup.sh --build-only    # just compile, don't start mining
#
# Builds from source (portable) so it runs on any x86-64 CPU. Auto-installs
# build deps on apt / dnf / yum / pacman / apk / zypper (needs sudo/root).
###############################################################################
set -uo pipefail
cd "$(dirname "$0")"
ROOT="$(pwd)"

THREADS=""
BUILD_ONLY=0
BRIDGE_PORT="${BRIDGE_PORT:-3334}"
while [ $# -gt 0 ]; do
  case "$1" in
    --threads) THREADS="$2"; shift 2;;
    --build-only) BUILD_ONLY=1; shift;;
    --port) BRIDGE_PORT="$2"; shift 2;;
    *) echo "unknown arg: $1"; exit 2;;
  esac
done

SUDO=""; [ "$(id -u)" -eq 0 ] || SUDO="sudo"

log(){ printf '\033[1;32m[+]\033[0m %s\n' "$*"; }
warn(){ printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------- deps
install_deps(){
  log "installing build deps (needs sudo/root)"
  if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update -qq
    $SUDO apt-get install -y -qq build-essential automake autoconf pkg-config \
      libcurl4-openssl-dev libssl-dev libjansson-dev libgmp-dev zlib1g-dev \
      python3 python3-pip git >/dev/null
  elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf install -y -q gcc gcc-c++ make automake autoconf pkgconfig \
      libcurl-devel openssl-devel jansson-devel gmp-devel zlib-devel \
      python3 python3-pip git >/dev/null
  elif command -v yum >/dev/null 2>&1; then
    $SUDO yum install -y -q gcc gcc-c++ make automake autoconf pkgconfig \
      libcurl-devel openssl-devel jansson-devel gmp-devel zlib-devel \
      python3 python3-pip git >/dev/null
  elif command -v pacman >/dev/null 2>&1; then
    $SUDO pacman -Sy --noconfirm --needed base-devel curl openssl jansson gmp \
      zlib python python-pip git >/dev/null
  elif command -v apk >/dev/null 2>&1; then
    $SUDO apk add --no-cache build-base automake autoconf pkgconf curl-dev \
      openssl-dev jansson-dev gmp-dev zlib-dev python3 py3-pip git >/dev/null
  elif command -v zypper >/dev/null 2>&1; then
    $SUDO zypper -q install -y gcc gcc-c++ make automake autoconf pkg-config \
      libcurl-devel libopenssl-devel libjansson-devel gmp-devel zlib-devel \
      python3 python3-pip git >/dev/null
  else
    die "no supported package manager found. Install: gcc make autoconf automake pkg-config libcurl-dev libssl-dev libjansson-dev libgmp-dev zlib-dev python3"
  fi
}

# python websockets for the bridge
install_websockets(){
  if python3 -c 'import websockets' 2>/dev/null; then return 0; fi
  log "installing python 'websockets'"
  pip3 install --break-system-packages -q websockets 2>/dev/null \
    || pip3 install -q websockets 2>/dev/null \
    || $SUDO apt-get install -y -qq python3-websockets 2>/dev/null \
    || $SUDO pacman -Sy --noconfirm python-websockets 2>/dev/null \
    || $SUDO apk add --no-cache py3-websockets 2>/dev/null \
    || true
  python3 -c 'import websockets' 2>/dev/null || die "could not install python 'websockets' module"
}

# ---------------------------------------------------------------- build
build_miner(){
  local BIN="$ROOT/cpuminer-src/cpuminer"
  if [ -x "$BIN" ]; then
    log "miner already built: $BIN"
    return 0
  fi
  command -v gcc >/dev/null 2>&1 || install_deps
  python3 -c 'import sys' 2>/dev/null || install_deps
  log "compiling cpuminer (power2b) — portable build, ~1-2 min"
  ( cd "$ROOT/cpuminer-src"
    [ -x ./autogen.sh ] && ./autogen.sh >/tmp/mbc_autogen.log 2>&1 || true
    # portable: -O3 with SSE2 baseline (runs on any x86-64), NOT -march=native.
    # -fcommon fixes multiple-definition on gcc >=10.
    # The type-error downgrades are required on gcc >=14 (Fedora 40+, AlmaLinux 10,
    # Ubuntu 24.10+), where incompatible-pointer-types / implicit-function-declaration
    # / int-conversion became hard errors by default. This old cpuminer fork trips them.
    CFLAGS="-O3 -msse2 -fcommon -Wno-error -Wno-incompatible-pointer-types -Wno-implicit-function-declaration -Wno-int-conversion $(pkg-config --cflags libcurl 2>/dev/null)" \
      ./configure --with-curl >/tmp/mbc_conf.log 2>&1 \
      || { tail -20 /tmp/mbc_conf.log; die "configure failed"; }
    make -j"$(nproc)" >/tmp/mbc_make.log 2>&1 \
      || { tail -25 /tmp/mbc_make.log; die "make failed"; }
  )
  [ -x "$BIN" ] || die "build produced no binary"
  log "built: $BIN"
}

# ---------------------------------------------------------------- run
read_env(){
  [ -f "$ROOT/.env" ] || die "missing .env (needs proxy=, username=, password=)"
  USER_STR="$(grep -E '^username=' "$ROOT/.env" | head -1 | cut -d= -f2- | tr -d '\r')"
  PASS_STR="$(grep -E '^password=' "$ROOT/.env" | head -1 | cut -d= -f2- | tr -d '\r')"
  [ -n "$USER_STR" ] || die "username= missing in .env"
}

start_bridge(){
  if ss -tlnp 2>/dev/null | grep -q ":$BRIDGE_PORT " || \
     netstat -tln 2>/dev/null | grep -q ":$BRIDGE_PORT "; then
    log "bridge already listening on :$BRIDGE_PORT"; return 0
  fi
  log "starting WS bridge on 127.0.0.1:$BRIDGE_PORT"
  BRIDGE_PORT="$BRIDGE_PORT" setsid python3 "$ROOT/ws_bridge.py" \
    > "$ROOT/bridge.log" 2>&1 < /dev/null &
  echo $! > "$ROOT/bridge.pid"
  for i in $(seq 1 20); do
    if ss -tlnp 2>/dev/null | grep -q ":$BRIDGE_PORT " || \
       netstat -tln 2>/dev/null | grep -q ":$BRIDGE_PORT "; then
      log "bridge up (pid $(cat "$ROOT/bridge.pid"))"; return 0
    fi
    sleep 0.5
  done
  tail -10 "$ROOT/bridge.log"; die "bridge failed to bind :$BRIDGE_PORT"
}

# ---------------------------------------------------------------- main
install_deps_if_needed(){
  command -v gcc >/dev/null 2>&1 && command -v pkg-config >/dev/null 2>&1 || install_deps
}

install_deps_if_needed
build_miner

if [ "$BUILD_ONLY" -eq 1 ]; then
  log "build-only done. Binary: $ROOT/cpuminer-src/cpuminer"
  exit 0
fi

install_websockets
read_env
start_bridge

T="${THREADS:-$(nproc)}"
log "mining: $T threads -> 127.0.0.1:$BRIDGE_PORT -> Koyeb proxy -> pool"
echo "  stop with: bash stop.sh    logs: tail -f bridge.log"
echo
exec "$ROOT/cpuminer-src/cpuminer" -a power2b \
  -o "stratum+tcp://127.0.0.1:$BRIDGE_PORT" \
  -u "$USER_STR" -p "$PASS_STR" -t "$T"
