mbc native power2b miner (any Linux, x86-64)
============================================
Mines MicroBitcoin (power2b) through the Koyeb WebSocket proxy in .env.

  native cpuminer (plain TCP Stratum)
      -> 127.0.0.1:3334  ws_bridge.py  (TCP<->WebSocket shim)
      -> wss://<koyeb>/<b64 target>    (Koyeb proxy)
      -> zpool power2b stratum

QUICK START
  tar xzf mbc-native-miner.tar.gz
  cd mbc-native-miner
  bash setup.sh                 # builds on first run, then mines with all cores

OPTIONS
  bash setup.sh --threads 8     # limit worker threads
  bash setup.sh --build-only    # compile only, don't start
  bash setup.sh --port 3400     # use a different local bridge port
  bash stop.sh                  # stop miner + bridge

REQUIREMENTS
  - x86-64 Linux, sudo/root for the one-time dep install
  - deps auto-installed on apt / dnf / yum / pacman / apk / zypper
  - portable build (-msse2), runs on any x86-64 CPU

CONFIG (.env)  — already filled in
  proxy=wss://...     Koyeb WebSocket endpoint (target pool base64-encoded in path)
  username=ADDR.WORKER
  password=c=MBC,zap=MBC

NOTE: .env contains your pool worker credentials. Keep it private.

RUN AS A SERVICE (systemd, auto-start on boot)
  sudo bash install-service.sh              # build if needed, install + start
  sudo bash install-service.sh --threads 8  # limit threads
  journalctl -u mbc-miner -f                # watch miner
  sudo bash install-service.sh --uninstall  # remove
