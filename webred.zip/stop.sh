#!/bin/bash
pkill -f "web/server.py" 2>/dev/null && echo "stopped" || echo "nothing to stop"
