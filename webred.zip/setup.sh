#!/bin/bash
# Start the redis web miner (Windows + Linux)
cd "$(dirname "$0")"
PORT="${MINER_WEB_PORT:-8766}"

# Kill any existing instance
pkill -f "web/server.py" 2>/dev/null || true
sleep 0.5

# Start the web server
python web/server.py &
echo "server started (port $PORT)"
sleep 1

# Open browser — Windows paths first, then Linux
CHROME_WIN="/c/Program Files/Google/Chrome/Application/chrome.exe"
BRAVE_WIN="/c/Program Files/BraveSoftware/Brave-Browser/Application/brave.exe"
FF_WIN="/c/Program Files/Mozilla Firefox/firefox.exe"

if [ -f "$CHROME_WIN" ]; then
  "$CHROME_WIN" "http://127.0.0.1:$PORT/" &
elif [ -f "$BRAVE_WIN" ]; then
  "$BRAVE_WIN" "http://127.0.0.1:$PORT/" &
elif [ -f "$FF_WIN" ]; then
  "$FF_WIN" "http://127.0.0.1:$PORT/" &
elif command -v chromium-browser &>/dev/null; then
  chromium-browser "http://127.0.0.1:$PORT/" &
elif command -v google-chrome &>/dev/null; then
  google-chrome "http://127.0.0.1:$PORT/" &
elif command -v xdg-open &>/dev/null; then
  xdg-open "http://127.0.0.1:$PORT/" &
else
  echo "No browser found — open manually: http://127.0.0.1:$PORT/"
fi

echo "redis web miner UI: http://127.0.0.1:$PORT/"
echo "Run: bash stop.sh  to stop"
