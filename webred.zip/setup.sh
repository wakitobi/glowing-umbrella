#!/bin/bash
# Start the redis web miner
cd "$(dirname "$0")"
PORT="${MINER_WEB_PORT:-8766}"

# Kill any existing instance
pkill -f "web/server.py" 2>/dev/null || true
sleep 0.5

# Start the web server
python web/server.py &
SERVER_PID=$!
echo "server PID: $SERVER_PID (port $PORT)"

sleep 1

# Open browser (optional — comment out if running headless)
if command -v chromium-browser &>/dev/null; then
  chromium-browser --new-window "http://127.0.0.1:$PORT/" &
elif command -v chromium &>/dev/null; then
  chromium --new-window "http://127.0.0.1:$PORT/" &
elif command -v google-chrome &>/dev/null; then
  google-chrome --new-window "http://127.0.0.1:$PORT/" &
fi

echo "redis web miner UI: http://127.0.0.1:$PORT/"
echo "Run: bash stop.sh  to stop"
