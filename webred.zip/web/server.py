#!/usr/bin/env python3
"""Serves the browser miner page and injects pool config from ../.env"""
import json
import os
import socketserver
from http.server import SimpleHTTPRequestHandler

HERE = os.path.dirname(os.path.abspath(__file__))
ENV = os.path.join(HERE, "..", ".env")
PORT = int(os.environ.get("MINER_WEB_PORT", "8766"))

CORS = {
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Embedder-Policy": "require-corp",
}


def load_env():
    cfg = {}
    with open(ENV, "r") as f:
        for line in f:
            line = line.strip()
            if line and "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                cfg[k.strip()] = v.strip()
    return cfg


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=HERE, **kw)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/config.json":
            cfg = load_env()
            # Translate redis env vars to what the browser expects
            out = {
                "url": cfg.get("REDIS_URL", ""),
                "pair": cfg.get("REDIS_PAIR", ""),
                "username": cfg.get("REDIS_USER", ""),
                "password": cfg.get("REDIS_PASS", ""),
                "threads": int(cfg.get("REDIS_PIPE", "2")),
            }
            body = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in CORS.items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)
            return
        return super().do_GET()

    def send_response(self, code, message=None):
        super().send_response(code, message)

    def end_headers(self):
        # Add CORS headers to all responses so SharedArrayBuffer works
        for k, v in CORS.items():
            self.send_header(k, v)
        super().end_headers()

    def log_message(self, *args):
        pass


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


if __name__ == "__main__":
    with Server(("127.0.0.1", PORT), Handler) as httpd:
        print(f"redis web miner UI: http://127.0.0.1:{PORT}/")
        httpd.serve_forever()
