/**
 * RandomX browser miner worker for redis/Stratum protocol.
 * Uses randomx.js (ESM WASM) to hash Monero-style blob_hex jobs.
 *
 * Main thread sends:
 *   { type: "job", job: { blob_hex, seed_hash, target, job_id }, index: N, total: N }
 *   { type: "stop" }
 *
 * Worker sends back:
 *   { type: "submit", data: { job_id, nonce_hex, result_hex } }
 *   { type: "hashrate", hashrate: <H/s> }
 *   { type: "ready" }
 *   { type: "error", msg: "..." }
 */
"use strict";

import { randomx_init_cache, randomx_create_vm } from "./lib.js";

function hexToBytes(hex) {
  const b = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2)
    b[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  return b;
}

function bytesToHex(b) {
  return Array.from(b).map(x => x.toString(16).padStart(2, "0")).join("");
}

// Monero target comparison:
// target is 4-byte little-endian hex (8 chars): e.g. "f1290000" = bytes [0xf1,0x29,0x00,0x00] = uint32_LE 0x000029f1
// Share valid when: result_uint32_LE (last 4 bytes of 32-byte result, read as uint32 LE) < target_uint32_LE
function meetsTarget(resultHex, targetHex) {
  // target is already LE in the hex string — parse directly as LE uint32
  // "f1290000" as bytes: f1 29 00 00 → uint32 LE = 0x000029f1
  const t0 = parseInt(targetHex.slice(0, 2), 16);
  const t1 = parseInt(targetHex.slice(2, 4), 16);
  const t2 = parseInt(targetHex.slice(4, 6), 16);
  const t3 = parseInt(targetHex.slice(6, 8), 16);
  const tgt = (t3 * 0x1000000 + t2 * 0x10000 + t1 * 0x100 + t0) >>> 0;

  // result is 32 bytes as hex (64 chars), little-endian
  // last 4 bytes = result_hex[56..64], also in LE
  const r0 = parseInt(resultHex.slice(56, 58), 16);
  const r1 = parseInt(resultHex.slice(58, 60), 16);
  const r2 = parseInt(resultHex.slice(60, 62), 16);
  const r3 = parseInt(resultHex.slice(62, 64), 16);
  const res = (r3 * 0x1000000 + r2 * 0x10000 + r1 * 0x100 + r0) >>> 0;

  return res < tgt;
}

let vm = null;
let currentSeedHash = null;
let job = null;
let running = false;
let myIndex = 0;
let totalWorkers = 1;

async function initVM(seedHashHex) {
  if (currentSeedHash === seedHashHex && vm !== null) return true;
  try {
    self.postMessage({ type: "status", msg: "initializing RandomX cache for seed " + seedHashHex.slice(0, 8) + "..." });
    // randomx_init_cache expects raw bytes (32 bytes), NOT the hex string (64 chars)
    const seedBytes = hexToBytes(seedHashHex);
    const cache = randomx_init_cache(seedBytes);
    vm = randomx_create_vm(cache);
    currentSeedHash = seedHashHex;
    return true;
  } catch (e) {
    self.postMessage({ type: "error", msg: "VM init failed: " + (e.message || e) });
    return false;
  }
}

function mineLoop() {
  if (!job || !vm) return;
  running = true;
  const savedJob = job;

  // Defensive check + debug
  if (!savedJob.blob && !savedJob.blob_hex) {
    self.postMessage({ type: "error", msg: "no blob in job: " + JSON.stringify(Object.keys(savedJob)) });
    running = false;
    return;
  }

  // Pool sends field as 'blob' (not 'blob_hex')
  const blobHex = savedJob.blob || savedJob.blob_hex;
  const blobBytes = hexToBytes(blobHex);
  const targetHex = savedJob.target;
  const jobId = savedJob.job_id;

  // Test one hash before the loop to catch VM issues early
  try {
    const testResult = vm.calculate_hex_hash(blobBytes);
    if (typeof testResult !== "string") {
      self.postMessage({ type: "error", msg: "calculate_hex_hash returned non-string: " + typeof testResult + " val=" + JSON.stringify(testResult) });
      running = false;
      return;
    }
    self.postMessage({ type: "status", msg: "blob_len=" + blobBytes.length + " test_hash_ok target=" + targetHex });
  } catch(e) {
    self.postMessage({ type: "error", msg: "hash test failed: " + (e.message || e) });
    running = false;
    return;
  }

  // Nonce occupies bytes 39-42 in Monero blob (4 bytes LE)
  let nonce = myIndex >>> 0;
  let hashCount = 0;
  let lastHRTime = performance.now();

  while (running && job && job.job_id === jobId) {
    blobBytes[39] = nonce & 0xff;
    blobBytes[40] = (nonce >> 8) & 0xff;
    blobBytes[41] = (nonce >> 16) & 0xff;
    blobBytes[42] = (nonce >> 24) & 0xff;

    // calculate_hex_hash accepts Uint8Array directly
    const resultHex = vm.calculate_hex_hash(blobBytes);
    hashCount++;

    if (meetsTarget(resultHex, targetHex)) {
      const nonceHex = bytesToHex(blobBytes.slice(39, 43));
      self.postMessage({
        type: "submit",
        data: { job_id: jobId, nonce_hex: nonceHex, result_hex: resultHex }
      });
    }

    nonce = (nonce + totalWorkers) >>> 0;
    if (nonce === (myIndex >>> 0) && nonce > 0xfffff) {
      // wrapped around full nonce space — nothing found
      self.postMessage({ type: "status", msg: "nonce space exhausted for job " + jobId });
      break;
    }

    // Report hashrate every ~2s (check every 50 hashes for WASM speed)
    if (hashCount % 50 === 0) {
      const now = performance.now();
      const elapsed = (now - lastHRTime) / 1000;
      if (elapsed >= 2) {
        self.postMessage({ type: "hashrate", hashrate: hashCount / elapsed });
        hashCount = 0;
        lastHRTime = now;
      }
    }
  }

  running = false;
}

self.onmessage = async function(e) {
  const msg = e.data;
  if (!msg || !msg.type) return;

  if (msg.type === "init") {
    myIndex = (msg.index || 0) >>> 0;
    totalWorkers = (msg.total || 1) >>> 0;
    self.postMessage({ type: "ready" });
    return;
  }

  if (msg.type === "job") {
    running = false;
    job = msg.job;
    if (msg.index !== undefined) myIndex = (msg.index) >>> 0;
    if (msg.total !== undefined) totalWorkers = (msg.total) >>> 0;

    const ok = await initVM(job.seed_hash);
    if (!ok) return;

    self.postMessage({ type: "status", msg: "mining job " + job.job_id });
    setTimeout(mineLoop, 0);
    return;
  }

  if (msg.type === "stop") {
    running = false;
    job = null;
    return;
  }
};

self.postMessage({ type: "ready" });
