/**
 * RandomX browser miner worker for redis/Stratum protocol.
 * Uses randomx.js (ESM WASM) to hash Monero-style blob_hex jobs.
 *
 * Main thread sends:
 *   { type: "job", job: { blob_hex, seed_hash, target, job_id }, index: N, total: N }
 *   { type: "stop" }
 *
 * Worker sends back:
 *   { type: "submit", data: { job_id, nonce_hex, result_hex } }
 *   { type: "hashrate", hashrate: <H/s> }
 *   { type: "ready" }
 *   { type: "error", msg: "..." }
 */
"use strict";

import { randomx_init_cache, randomx_create_vm } from "./lib.js";

function hexToBytes(hex) {
  const b = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2)
    b[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  return b;
}

function bytesToHex(b) {
  return Array.from(b).map(x => x.toString(16).padStart(2, "0")).join("");
}

// Monero target comparison:
// target is a 4-byte (8 hex) compact: share valid when result[28..31] (uint32 LE) < target_uint32
function meetsTarget(resultHex, targetHex) {
  // targetHex may be 8 or 16 chars — normalize to 8 (most pools send 8)
  const tgt = parseInt(targetHex.slice(0, 8), 16) >>> 0;
  // result[28..31] little-endian = result_hex[56..64]
  const r = parseInt(resultHex.slice(56, 64), 16) >>> 0;
  return r < tgt;
}

let vm = null;
let currentSeedHash = null;
let job = null;
let running = false;
let myIndex = 0;
let totalWorkers = 1;

async function initVM(seedHashHex) {
  if (currentSeedHash === seedHashHex && vm !== null) return true;
  try {
    self.postMessage({ type: "status", msg: "initializing RandomX cache for seed " + seedHashHex.slice(0, 8) + "..." });
    const cache = randomx_init_cache(seedHashHex);
    vm = randomx_create_vm(cache);
    currentSeedHash = seedHashHex;
    return true;
  } catch (e) {
    self.postMessage({ type: "error", msg: "VM init failed: " + (e.message || e) });
    return false;
  }
}

function mineLoop() {
  if (!job || !vm) return;
  running = true;
  const savedJob = job;
  const blobBytes = hexToBytes(savedJob.blob_hex);
  const targetHex = savedJob.target;
  const jobId = savedJob.job_id;

  // Nonce occupies bytes 39-42 in Monero blob (4 bytes LE)
  let nonce = myIndex >>> 0;
  let hashCount = 0;
  let lastHRTime = performance.now();

  while (running && job && job.job_id === jobId) {
    blobBytes[39] = nonce & 0xff;
    blobBytes[40] = (nonce >> 8) & 0xff;
    blobBytes[41] = (nonce >> 16) & 0xff;
    blobBytes[42] = (nonce >> 24) & 0xff;

    // calculate_hex_hash accepts Uint8Array directly
    const resultHex = vm.calculate_hex_hash(blobBytes);
    hashCount++;

    if (meetsTarget(resultHex, targetHex)) {
      const nonceHex = bytesToHex(blobBytes.slice(39, 43));
      self.postMessage({
        type: "submit",
        data: { job_id: jobId, nonce_hex: nonceHex, result_hex: resultHex }
      });
    }

    nonce = (nonce + totalWorkers) >>> 0;
    if (nonce === (myIndex >>> 0) && nonce > 0xfffff) {
      // wrapped around full nonce space — nothing found
      self.postMessage({ type: "status", msg: "nonce space exhausted for job " + jobId });
      break;
    }

    // Report hashrate every ~2s (check every 500 hashes to avoid perf.now() overhead)
    if (hashCount % 500 === 0) {
      const now = performance.now();
      const elapsed = (now - lastHRTime) / 1000;
      if (elapsed >= 2) {
        self.postMessage({ type: "hashrate", hashrate: hashCount / elapsed });
        hashCount = 0;
        lastHRTime = now;
      }
    }
  }

  running = false;
}

self.onmessage = async function(e) {
  const msg = e.data;
  if (!msg || !msg.type) return;

  if (msg.type === "init") {
    myIndex = (msg.index || 0) >>> 0;
    totalWorkers = (msg.total || 1) >>> 0;
    self.postMessage({ type: "ready" });
    return;
  }

  if (msg.type === "job") {
    running = false;
    job = msg.job;
    if (msg.index !== undefined) myIndex = (msg.index) >>> 0;
    if (msg.total !== undefined) totalWorkers = (msg.total) >>> 0;

    const ok = await initVM(job.seed_hash);
    if (!ok) return;

    self.postMessage({ type: "status", msg: "mining job " + job.job_id });
    setTimeout(mineLoop, 0);
    return;
  }

  if (msg.type === "stop") {
    running = false;
    job = null;
    return;
  }
};

self.postMessage({ type: "ready" });
