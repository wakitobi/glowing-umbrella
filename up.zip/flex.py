import os
os.system("bash up.sh")
