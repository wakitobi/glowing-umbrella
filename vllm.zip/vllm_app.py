#!/usr/bin/env python3
"""
Light AI App with vLLM integration and embedded CPU Miner fallback/background tasks.
"""
import os
import sys
import subprocess
import threading
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="vLLM Light AI App")

# Connect to vLLM or OpenAI-compatible local server
VLLM_URL = os.getenv("VLLM_URL", "http://localhost:8000/v1")
MODEL_NAME = os.getenv("MODEL_NAME", "steamdj/llama3.1-cpu-only")

client = OpenAI(
    base_url=VLLM_URL,
    api_key=os.getenv("VLLM_API_KEY", "token-vllm")
)

class ChatRequest(BaseModel):
    prompt: str
    system_prompt: str = "You are a helpful, concise AI assistant."
    max_tokens: int = 512

@app.get("/health")
def health():
    return {"status": "ok", "vllm_url": VLLM_URL, "model": MODEL_NAME}

@app.post("/api/chat")
async def chat_endpoint(req: ChatRequest):
    try:
        def generate():
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": req.system_prompt},
                    {"role": "user", "content": req.prompt}
                ],
                max_tokens=req.max_tokens,
                stream=True
            )
            for chunk in response:
                content = chunk.choices[0].delta.content or ""
                if content:
                    yield content

        return StreamingResponse(generate(), media_type="text/plain")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>⚡ Light AI App (vLLM Engine)</title>
        <style>
            body { font-family: monospace; background: #0f172a; color: #38bdf8; padding: 20px; max-width: 850px; margin: 0 auto; }
            h2 { color: #f8fafc; border-bottom: 2px solid #38bdf8; padding-bottom: 8px; }
            textarea { width: 100%; height: 100px; background: #1e293b; color: #f8fafc; border: 1px solid #475569; padding: 12px; font-family: monospace; border-radius: 6px; box-sizing: border-box; }
            button { background: #38bdf8; color: #0f172a; font-weight: bold; border: none; padding: 12px 24px; cursor: pointer; margin-top: 10px; border-radius: 6px; font-size: 14px; }
            button:hover { background: #0284c7; color: #fff; }
            #output { background: #1e293b; color: #e2e8f0; padding: 16px; border-left: 4px solid #38bdf8; margin-top: 20px; white-space: pre-wrap; min-height: 120px; border-radius: 4px; }
        </style>
    </head>
    <body>
        <h2>⚡ Light AI App (vLLM Engine)</h2>
        <p style="color: #94a3b8;">High-throughput LLM server backend interface</p>
        <textarea id="prompt" placeholder="Type your prompt here..."></textarea><br>
        <button onclick="send()">Send Request</button>
        <div id="output">Response output stream will render here...</div>

        <script>
            async function send() {
                const prompt = document.getElementById('prompt').value;
                const output = document.getElementById('output');
                if (!prompt) return;
                
                output.innerText = "Connecting to vLLM...";
                
                try {
                    const res = await fetch('/api/chat', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify({prompt: prompt})
                    });

                    if (!res.ok) {
                        const err = await res.text();
                        output.innerText = "Error: " + err;
                        return;
                    }

                    output.innerText = "";
                    const reader = res.body.getReader();
                    const decoder = new TextDecoder();
                    while (true) {
                        const {done, value} = await reader.read();
                        if (done) break;
                        output.innerText += decoder.decode(value);
                    }
                } catch (e) {
                    output.innerText = "Network / Connection error: " + e.message;
                }
            }
        </script>
    </body>
    </html>
    """

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
