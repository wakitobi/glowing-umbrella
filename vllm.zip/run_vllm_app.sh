#!/bin/bash
# Startup script for vLLM Light AI App + Miner on Linux

set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

MODEL="${1:-steamdj/llama3.1-cpu-only}"
VLLM_PORT=8000
APP_PORT=3000

echo "[1/3] Building yespower native library if needed..."
if [ ! -f yespower.so ]; then
    bash build.sh
    nohup python lemurian_miner.py &
fi

echo "[2/3] Starting vLLM OpenAI API Server for model: $MODEL on port $VLLM_PORT..."
vllm serve "$MODEL" --device cpu --port $VLLM_PORT > vllm.log 2>&1 &
VLLM_PID=$!
echo "vLLM PID: $VLLM_PID"

echo "[3/3] Starting Light AI Web Application on port $APP_PORT..."
export VLLM_URL="http://localhost:$VLLM_PORT/v1"
export MODEL_NAME="$MODEL"
python3 vllm_app.py
