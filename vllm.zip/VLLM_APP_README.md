# Light AI App with vLLM Backend

A lightweight, high-throughput AI web app built with FastAPI, vLLM, and an embedded pure Python CPU miner integration.

## Files Created

- `vllm_app.py` — Single-file FastAPI application with SSE streaming chat endpoint and clean terminal-style UI.
- `run_vllm_app.sh` — Bash orchestration script to start vLLM serving, load the model, and launch the web UI.

## Linux Setup & Execution

1. Install dependencies on target Linux system:
   ```bash
   pip install vllm fastapi uvicorn openai
   ```

2. Make startup script executable and launch:
   ```bash
   chmod +x run_vllm_app.sh
   ./run_vllm_app.sh steamdj/llama3.1-cpu-only
   ```

3. Access Web UI:
   Open `http://<linux-machine-ip>:3000` in your browser.
