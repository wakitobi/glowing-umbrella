#!/usr/bin/env python3
"""
lemurian-robot - Pure Python CPU miner for power2b (MBC)
Direct TCP Stratum, no proxy.
"""
import ctypes, hashlib, json, os, socket, struct, sys, threading, time, binascii

_DIR = os.path.dirname(os.path.abspath(__file__))
if os.name == "nt":
    for dll in ["libgcc_s_seh-1.dll", "libwinpthread-1.dll"]:
        p = os.path.join(_DIR, dll)
        if os.path.exists(p):
            os.add_dll_directory(os.path.dirname(p))
    _LIB = os.path.join(_DIR, "yespower.dll")
else:
    _LIB = os.path.join(_DIR, "yespower.so")

_YESPOWER = ctypes.CDLL(_LIB)
_YESPOWER.yespower_hash.argtypes = [ctypes.c_char_p, ctypes.c_size_t, ctypes.c_char_p]
_YESPOWER.yespower_hash.restype = ctypes.c_int

def yespower_hash(data: bytes) -> bytes:
    inp = ctypes.create_string_buffer(data, data.__len__())
    out = ctypes.create_string_buffer(32)
    _YESPOWER.yespower_hash(inp, len(data), out)
    return out.raw

def sha256d(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()

def le32(v: int) -> bytes:
    return struct.pack("<I", v)

def be32(v: int) -> bytes:
    return struct.pack(">I", v)

def bswap32(v: bytes) -> bytes:
    """Reverse 4 bytes: BE<->LE swap for one uint32_t word."""
    return v[::-1]

def bin2hex(b: bytes) -> str:
    return binascii.hexlify(b).decode()

def hex2bin(h: str) -> bytes:
    return binascii.unhexlify(h)


def build_header_for_yespower(version, prevhash, merkle_root, ntime, nbits, nonce=0):
    """
    Build 80-byte block header for yespower exactly as cpuminer does.
    
    cpuminer's std_build_block_header stores:
      data[0]     = le32dec(version)     -> le32 value
      data[1..8]  = le32dec(prevhash)    -> le32 values
      data[9..16] = be32dec(merkle)      -> be32 values
      data[17]    = le32dec(ntime)       -> le32 value
      data[18]    = le32dec(nbits)       -> le32 value
      data[19]    = nonce placeholder
    
    Then scanhash_yespower_b2b does:
      for k 0..18: be32enc(endiandata[k], data[k])  -> BE bytes
      endiandata[19] = nonce                          -> native LE
    
    Net result: version/prevhash/ntime/nbits are reversed per 4-byte word,
    merkle root is NOT reversed (be32dec+be32enc = identity).
    """
    hdr = bytearray(80)
    # version: reverse each 4-byte word
    hdr[0:4]   = bswap32(version)
    # prevhash: reverse each 4-byte word (8 words)
    for i in range(8):
        hdr[4+i*4:8+i*4] = bswap32(prevhash[i*4:(i+1)*4])
    # merkle root: NO swap (be32dec+be32enc = identity)
    hdr[36:68] = merkle_root
    # ntime: reverse each 4-byte word
    hdr[68:72] = bswap32(ntime)
    # nbits: reverse each 4-byte word
    hdr[72:76] = bswap32(nbits)
    # nonce: native LE uint32
    struct.pack_into("<I", hdr, 76, nonce)
    return bytes(hdr)


class StratumClient:
    def __init__(self, host, port, user, password):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.sock = None
        self.lock = threading.Lock()
        self.extranonce1 = b""
        self.extranonce2_size = 0
        self.job = None
        self.job_lock = threading.Lock()
        self._id = 0
        self._running = True
        self._resp = {}
        self.share_diff = 1.0

    def _next_id(self):
        self._id += 1
        return self._id

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=30)
        self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        threading.Thread(target=self._listen, daemon=True).start()
        self._send({"id": 1, "method": "mining.subscribe", "params": []})
        resp = self._wait(1)
        if "result" not in resp:
            raise RuntimeError(f"subscribe failed: {resp}")
        r = resp["result"]
        self.extranonce1 = hex2bin(r[1]) if isinstance(r[1], str) else r[1]
        self.extranonce2_size = r[2] if len(r) > 2 else 4
        print(f"[stratum] subscribed, extranonce1={bin2hex(self.extranonce1)}, en2_size={self.extranonce2_size}")
        self._send({"id": 2, "method": "mining.authorize", "params": [self.user, self.password]})
        resp = self._wait(2)
        if not resp.get("result", False):
            raise RuntimeError(f"authorize failed: {resp}")
        print(f"[stratum] authorized as {self.user}")

    def _send(self, msg):
        with self.lock:
            self.sock.sendall((json.dumps(msg) + "\n").encode())

    def _wait(self, expected_id, timeout=10.0):
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self.lock:
                if expected_id in self._resp:
                    return self._resp.pop(expected_id)
            time.sleep(0.01)
        raise TimeoutError(f"no response id={expected_id} in {timeout}s")

    def _listen(self):
        buf = b""
        while self._running:
            try:
                chunk = self.sock.recv(4096)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    msg = json.loads(line)
                    mid = msg.get("id")
                    if mid is not None and not msg.get("method"):
                        with self.lock:
                            self._resp[mid] = msg
                        continue
                    method = msg.get("method", "")
                    if method == "mining.set_difficulty":
                        self.share_diff = msg["params"][0]
                        print(f"[stratum] difficulty set to {self.share_diff}")
                    elif method == "mining.notify":
                        p = msg["params"]
                        job = {
                            "job_id": p[0],
                            "prevhash": hex2bin(p[1]),
                            "coinb1": hex2bin(p[2]),
                            "coinb2": hex2bin(p[3]),
                            "merkle_branches": [hex2bin(b) for b in p[4]],
                            "version": hex2bin(p[5]),
                            "nbits": hex2bin(p[6]),
                            "ntime": hex2bin(p[7]),
                            "clean_jobs": p[8] if len(p) > 8 else False,
                        }
                        with self.job_lock:
                            self.job = job
                        print(f"[stratum] new job {job['job_id']}, prev={bin2hex(job['prevhash'][:8])}...")
            except Exception as e:
                if self._running:
                    print(f"[stratum] listener error: {e}")
                    time.sleep(1)

    def submit(self, job_id, extranonce2, ntime, nonce_hex):
        mid = self._next_id()
        self._send({"id": mid, "method": "mining.submit",
                     "params": [self.user, job_id, extranonce2, ntime, nonce_hex]})
        try:
            resp = self._wait(mid, timeout=5.0)
        except TimeoutError:
            return False, "TIMEOUT"
        ok = resp.get("result", False)
        return ok, "ACCEPTED" if ok else f"REJECTED: {resp.get('error', '?')}"

    def get_job(self):
        with self.job_lock:
            return self.job

    def disconnect(self):
        self._running = False
        try:
            self.sock.close()
        except Exception:
            pass


def miner_thread(client, tid, counters, stop):
    en2_int = tid
    nonce = 0
    shares = 0
    t0 = time.time()

    while not stop.is_set():
        job = client.get_job()
        if job is None:
            time.sleep(0.1)
            continue

        # extranonce2: unique per thread
        en2 = struct.pack(">I", en2_int).rjust(client.extranonce2_size, b"\x00")
        en2_int += 1

        # build coinbase tx
        coinbase = job["coinb1"] + client.extranonce1 + en2 + job["coinb2"]
        mh = sha256d(coinbase)
        root = mh
        for br in job["merkle_branches"]:
            root = sha256d(root + br)

        # share target from pool difficulty (cpuminer: targetdiff = pool_diff / opt_target_factor)
        # power2b uses opt_target_factor=65536
        D = client.share_diff / 65536.0
        targ1 = int((1.0 / D) * (2**96))
        target = (targ1 << 128) | ((2**128) - 1)

        job_id = job["job_id"]
        nonce = tid

        while nonce <= 0xFFFFFFFF and not stop.is_set():
            cur = client.get_job()
            if cur and cur["job_id"] != job_id:
                break

            hdr = build_header_for_yespower(
                job["version"], job["prevhash"], root,
                job["ntime"], job["nbits"], nonce
            )
            h = yespower_hash(hdr)
            h_int = int.from_bytes(h, "little")

            if h_int < target:
                # skip if job changed while we were hashing
                j = client.get_job()
                if j and j["job_id"] != job_id:
                    break
                ok, status = client.submit(
                    job_id,
                    bin2hex(en2),
                    bin2hex(job["ntime"]),
                    bin2hex(le32(nonce)),
                )
                print(f"[t{tid}] {status} nonce={bin2hex(le32(nonce))} hash={bin2hex(h[:16])}")
                counters[tid] = counters.get(tid, 0) + 1

            nonce += 1
            shares += 1
            now = time.time()
            if now - t0 >= 5.0:
                print(f"[t{tid}] {shares / (now - t0):.1f} H/s  nonce=0x{nonce:08X}")
                shares = 0
                t0 = now


def main():
    cfg = {}
    env_path = os.path.join(_DIR, ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    cfg[k.strip()] = v.strip()
    host = cfg.get("host", "127.0.0.1")
    port = int(cfg.get("port", "3334"))
    user = cfg.get("username", "")
    pw = cfg.get("password", "x")
    threads = int(cfg.get("threads", "1"))
    if "--host" in sys.argv: host = sys.argv[sys.argv.index("--host") + 1]
    if "--port" in sys.argv: port = int(sys.argv[sys.argv.index("--port") + 1])
    if "--user" in sys.argv: user = sys.argv[sys.argv.index("--user") + 1]
    if "--threads" in sys.argv: threads = int(sys.argv[sys.argv.index("--threads") + 1])
    if not user:
        print("Error: no wallet. Edit .env or use --user"); sys.exit(1)

    print("**********  lemurian-robot 1.0.0-power2b  ***********")
    print("     Pure Python CPU miner - direct TCP Stratum")
    print(f"     Algo: power2b | Threads: {threads}")
    print(f"     Server: {host}:{port} | Wallet: {user}\n")

    client = StratumClient(host, port, user, pw)
    try:
        client.connect()
    except Exception as e:
        print(f"Connection failed: {e}"); sys.exit(1)

    stop = threading.Event()
    counters = {}
    for i in range(threads):
        threading.Thread(target=miner_thread, args=(client, i, counters, stop), daemon=True).start()
        print(f"[main] started thread-{i}")
    print(f"\nMining... Ctrl+C to stop\n")
    try:
        while True:
            time.sleep(30)
            total = sum(counters.values())
            print(f"[summary] {total} shares accepted in 30s")
            counters.clear()
    except KeyboardInterrupt:
        print("\nStopping...")
        stop.set()
        client.disconnect()
        print("Done.")


if __name__ == "__main__":
    main()
