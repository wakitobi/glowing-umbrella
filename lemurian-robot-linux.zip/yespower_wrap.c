/* yespower_wrap.c - Shared library for Python ctypes binding */
#include <stdint.h>
#include <string.h>
#include "algo/yespower/yespower.h"

int yespower_hash(const uint8_t *input, size_t inputlen, uint8_t *output) {
    static yespower_params_t params = {
        .N = 2048,
        .r = 32,
        .pers = (const uint8_t *)"Now I am become Death, the destroyer of worlds",
        .perslen = 46
    };
    return yespower_tls((const yespower_binary_t *)input, inputlen, &params, (yespower_binary_t *)output);
}
