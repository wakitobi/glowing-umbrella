# lemurian-robot power2b miner

Pure Python CPU miner for power2b (MicroBitcoin) via direct TCP Stratum.

## Quick start

```bash
# 1. build the yespower hash library (requires gcc)
bash build.sh

# 2. edit .env with your wallet/pool settings
nano .env

# 3. mine!
python3 lemurian_miner.py
```

## Files

- `lemurian_miner.py`  — the miner (Python 3.10+, no pip packages)
- `yespower_wrap.c`    — C wrapper for yespower hash
- `algo/yespower/`     — yespower source (N=2048,r=32, pers="Death")
- `build.sh`           — compiles yespower.so
- `.env`               — config (wallet, pool, threads)

## Config (.env)

```
host=na.rplant.xyz
port=7022
username=YOUR_WALLET.CPU
password=x
threads=4
```

## Requirements

- Python 3.10+ (no pip packages needed)
- gcc (for building yespower.so)
