#!/bin/bash
# build.sh — compile yespower.so for Linux (x86_64)
# Run once on the target machine: bash build.sh
set -e
cd "$(dirname "$0")"

echo "=== lemurian-robot: building yespower.so ==="

# find gcc
CC="${CC:-gcc}"
if ! command -v "$CC" &>/dev/null; then
    echo "ERROR: gcc not found. Install with: sudo apt install build-essential"
    exit 1
fi

echo "Using compiler: $CC ($($CC --version | head -1))"

# compile yespower as shared library
$CC -O3 -msse2 -mavx2 -fcommon -shared -fPIC -o yespower.so \
    yespower_wrap.c \
    algo/yespower/yespower.c \
    algo/yespower/crypto/blake2b.c \
    -I. -Ialgo -Ialgo/yespower -Ialgo/yespower/crypto \
    -Wno-incompatible-pointer-types \
    -Wno-implicit-function-declaration \
    -Wno-int-conversion \
    -lpthread

echo "Built: yespower.so ($(ls -lh yespower.so | awk '{print $5}'))"

# quick smoke test
python3 -c "
import ctypes
dll = ctypes.CDLL('./yespower.dll' if __import__('os').name == 'nt' else './yespower.so')
inp = ctypes.create_string_buffer(b'\x00'*80, 80)
out = ctypes.create_string_buffer(32)
dll.yespower_hash(inp, 80, out)
h = out.raw.hex()
print(f'smoke test OK: {h[:16]}...')
" && echo "=== Build complete ===" || echo "=== Build succeeded but smoke test failed (may need python3) ==="
