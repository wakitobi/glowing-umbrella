"""
Local file bus: the glue between the pool connector and the miners.

jobs.txt   (written by pool_connector, read by pearl_miner)
shares.txt (appended by pearl_miner, drained by pool_connector)

Plain-file implementation — no GitHub, no network, no token needed.
"""

from __future__ import annotations

import os


class LocalBus:
    """Plain-file bus (no GitHub needed)."""

    def __init__(self, directory: str):
        os.makedirs(directory, exist_ok=True)
        self.dir = directory

    def _path(self, name: str) -> str:
        return os.path.join(self.dir, name)

    def read_text(self, path: str) -> str | None:
        try:
            with open(self._path(path), "r", encoding="utf-8") as f:
                return f.read()
        except FileNotFoundError:
            return None

    def write_text(self, path: str, text: str) -> None:
        with open(self._path(path), "w", encoding="utf-8") as f:
            f.write(text)

    def append_line(self, path: str, line: str) -> bool:
        with open(self._path(path), "a", encoding="utf-8") as f:
            f.write(line.rstrip("\n") + "\n")
        return True

    def clear(self, path: str) -> None:
        self.write_text(path, "")

    def get_file(self, path: str):
        c = self.read_text(path)
        return (None if c is None else c.encode()), None

    def put_file(self, path: str, content: bytes, **kw) -> str:
        self.write_text(path, content.decode("utf-8", errors="replace"))
        return "local"
