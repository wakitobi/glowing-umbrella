"""
github_sync.py — local bus convenience wrappers (GitHub removed).
"""

from __future__ import annotations

import os
from github_bus import LocalBus

DEFAULT_LOCAL_DIR = os.environ.get("PEARL_BUS_DIR", "./pearl_bus")

_default_bus: LocalBus | None = None


def get_default_bus(local_dir: str = DEFAULT_LOCAL_DIR) -> LocalBus:
    global _default_bus
    if _default_bus is None:
        _default_bus = LocalBus(local_dir)
    return _default_bus


def get_file(path: str, **kw) -> str | None:
    return get_default_bus().read_text(path)


def set_file(path: str, content: str, **kw) -> None:
    get_default_bus().write_text(path, content)


def append_file(path: str, line: str, **kw) -> bool:
    return get_default_bus().append_line(path, line)


def clear_file(path: str, **kw) -> None:
    get_default_bus().clear(path)
