"""
The PearlHash mining search: noisy GEMM -> per-tile jackpot transcript ->
keyed BLAKE3 PoW check.

Mirrors zk-pow `try_mine_one` / the GPU `headless_mine_kernel`:

  * A (m x k), B (k x n) are random int8 signal matrices in [-64, 63]
  * noise E_A/E_B (low-rank) is added -> A_noised/B_noised (int16)
  * C is accumulated in chunks of `rank` along k; after every chunk the
    XOR-reduction of each pattern tile (rows_pattern.size() x
    cols_pattern.size() = 2 x 64) is rotate-XOR-ed into a 16-word
    "jackpot" transcript (rotate by 13)
  * jackpot_hash = blake3(transcript64, key=a_noise_seed)
  * if little-endian jackpot_hash <= target  -> a share is found

The entire inner loop (matmul + tile gather + XOR + jackpot accumulation)
stays on the GPU (torch tensors throughout). Only the final 32-byte hash
check runs on CPU.
"""

from __future__ import annotations

import json
import os
import struct
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

from .commitment import commitment_seeds, hash_le32, jackpot_hash
from .noise import NoiseGenerator
from .params import (
    DEFAULT_COLS_PATTERN,
    DEFAULT_ROWS_PATTERN,
    IncompleteBlockHeader,
    MiningConfiguration,
    SIGNAL_MAX,
    SIGNAL_MIN,
)


def _backend_available(name: str) -> bool:
    if name == "torch":
        try:
            import torch  # noqa: F401
            return True
        except Exception:
            return False
    return True


def _get_device():
    import torch
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def rotl32(x: np.ndarray, n: int) -> np.ndarray:
    return ((x << n) | (x >> (32 - n))) & np.uint32(0xFFFFFFFF)


def rotl32_torch(x, n: int):
    """Rotate left 32-bit on a torch uint32-as-int32 tensor."""
    import torch
    x = x.to(torch.int64)
    return ((x << n) | ((x & 0xFFFFFFFF) >> (32 - n))).to(torch.int32)


class JackpotSearcher:
    """Computes per-tile jackpot transcripts for one noisy matmul."""

    def __init__(self, config: MiningConfiguration, m: int, n: int):
        self.config = config
        self.m = m
        self.n = n
        self.rank = config.rank
        rows_base = config.rows_pattern.to_list()
        cols_base = config.cols_pattern.to_list()
        self.rows_base = rows_base
        self.cols_base = cols_base

        rmax = config.rows_pattern.max()
        cmax = config.cols_pattern.max()
        self.rows_offs = np.array(
            [o for o in range(0, m - rmax) if config.rows_pattern.offset_is_valid(o)],
            dtype=np.int64,
        )
        self.cols_offs = np.array(
            [o for o in range(0, n - cmax) if config.cols_pattern.offset_is_valid(o)],
            dtype=np.int64,
        )
        self.R = len(self.rows_offs)
        self.C = len(self.cols_offs)
        self.num_chunks = config.common_dim // self.rank
        assert config.common_dim % self.rank == 0

        # o0/o1: the two opened rows per tile (numpy, used to build GPU tensors)
        self.o0 = self.rows_offs + rows_base[0]
        self.o1 = self.rows_offs + rows_base[-1]
        # column index table for the gather: shape (C, len(cols_base))
        self.col_idx = (self.cols_offs[:, None] + np.array(cols_base)[None, :]).astype(np.int64)

    # ------------------------------------------------------------------ #
    def search(self, A_noised: np.ndarray, B_noised: np.ndarray,
               backend: str = "auto") -> np.ndarray:
        """Return jackpot transcript tensor (R, C, 16) uint32 on CPU."""
        if backend == "auto":
            backend = "torch" if _backend_available("torch") else "numpy"
        if backend not in ("torch", "numpy"):
            raise ValueError(f"unknown backend {backend}")

        if backend == "torch":
            return self._search_torch(A_noised, B_noised)
        return self._search_numpy(A_noised, B_noised)

    # ------------------------------------------------------------------ #
    def _search_torch(self, A_noised: np.ndarray, B_noised: np.ndarray) -> np.ndarray:
        """Full GPU inner loop — no CPU round-trips inside the chunk loop."""
        import torch

        dev = _get_device()

        # Upload matrices once — keep as float32 for GEMM (CUDA has no int32 GEMM)
        # Inputs bounded by ±127+noise; float32 is exact for partial sums up to 2^24.
        A_t = torch.from_numpy(np.ascontiguousarray(A_noised).astype(np.float32)).to(dev)
        B_t = torch.from_numpy(np.ascontiguousarray(B_noised).astype(np.float32)).to(dev)

        # Accumulator in int32 on GPU
        C_acc = torch.zeros((self.m, self.n), dtype=torch.int32, device=dev)

        # Index tensors on GPU (long/int64)
        o0_t = torch.from_numpy(self.o0).to(dev)          # (R,)
        o1_t = torch.from_numpy(self.o1).to(dev)          # (R,)
        col_idx_t = torch.from_numpy(self.col_idx).to(dev)  # (C, Lc)  Lc=len(cols_base)

        # Jackpot on GPU as int32 (bit-pattern == uint32)
        jackpot_t = torch.zeros((self.R, self.C, 16), dtype=torch.int32, device=dev)

        for p in range(self.num_chunks):
            ks = slice(p * self.rank, (p + 1) * self.rank)

            # GEMM on GPU in float32 -> convert to int32 (exact for our value range)
            C_chunk = torch.matmul(A_t[:, ks], B_t[ks, :]).to(torch.int32)
            C_acc = C_acc + C_chunk

            # --- tile gather + XOR fully on GPU ---
            # row gather: (R, n)
            r0 = C_acc[o0_t]   # (R, n)
            r1 = C_acc[o1_t]   # (R, n)
            xr = torch.bitwise_xor(r0, r1)          # (R, n)  int32

            # column gather: col_idx_t is (C, Lc); we need (R, C, Lc)
            # xr[:, col_idx_t] -> (R, C, Lc)
            xc = xr[:, col_idx_t]                   # (R, C, Lc)  int32

            # XOR-reduce over last dim -> (R, C)
            xored = torch.zeros((self.R, self.C), dtype=torch.int32, device=dev)
            for i in range(xc.shape[2]):
                xored = torch.bitwise_xor(xored, xc[:, :, i])

            # jackpot update: rotl13 ^ xored
            tid = p % 16
            slot = jackpot_t[:, :, tid]
            # rotl32 in int32 bit-space
            slot_l = slot.to(torch.int64)
            rotated = ((slot_l << 13) | ((slot_l & 0xFFFFFFFF) >> 19)).to(torch.int32)
            jackpot_t[:, :, tid] = torch.bitwise_xor(rotated, xored)

        # Pull jackpot to CPU once at the end, reinterpret as uint32
        jackpot_np = jackpot_t.cpu().numpy().view(np.uint32)
        return jackpot_np  # (R, C, 16) uint32

    # ------------------------------------------------------------------ #
    def _search_numpy(self, A_noised: np.ndarray, B_noised: np.ndarray) -> np.ndarray:
        """CPU numpy fallback."""
        C_acc = np.zeros((self.m, self.n), dtype=np.int32)
        jackpot = np.zeros((self.R, self.C, 16), dtype=np.uint32)

        for p in range(self.num_chunks):
            ks = slice(p * self.rank, (p + 1) * self.rank)
            C_chunk = A_noised[:, ks].astype(np.int32) @ B_noised[ks, :].astype(np.int32)
            C_acc = C_acc + C_chunk

            xr = np.bitwise_xor(C_acc[self.o0], C_acc[self.o1])   # (R, n)
            xc = xr[:, self.col_idx]                               # (R, C, Lc)
            xored = np.bitwise_xor.reduce(xc, axis=2).view(np.uint32)  # (R, C)

            tid = p % 16
            jackpot[:, :, tid] = rotl32(jackpot[:, :, tid], 13) ^ xored

        return jackpot

    # ------------------------------------------------------------------ #
    def tile_positions(self):
        """Enumerate (row_off, col_off) tiles in a deterministic order."""
        for ri, ro in enumerate(self.rows_offs):
            for ci, co in enumerate(self.cols_offs):
                yield ri, ci, int(ro), int(co)


def _default_rng(header: IncompleteBlockHeader, nonce: int):
    import blake3 as _b3
    seed = _b3.blake3(header.to_bytes() + int(nonce).to_bytes(8, "little")).digest()[:16]
    return np.random.default_rng(int.from_bytes(seed, "big"))


def mine_once(
    header: IncompleteBlockHeader,
    config: MiningConfiguration,
    m: int,
    n: int,
    target: int,
    nonce: int,
    backend: str = "auto",
    max_hashes: int | None = None,
    on_attempt=None,
):
    """One full mining attempt (fresh A/B) -> share dict or None."""
    k = config.common_dim
    rng = _default_rng(header, nonce)

    A = rng.integers(SIGNAL_MIN, SIGNAL_MAX + 1, size=(m, k), dtype=np.int8)
    B = rng.integers(SIGNAL_MIN, SIGNAL_MAX + 1, size=(k, n), dtype=np.int8)

    b_seed, a_seed = commitment_seeds(header, config, A, B)

    gen = NoiseGenerator(noise_rank=config.rank)
    E_AL, E_AR, E_BL, E_BR = gen.generate_noise_matrices(
        key_A=a_seed, key_B=b_seed,
        A_rows=m, common_dim=k, B_cols=n,
    )
    E_A = (E_AL.astype(np.int32) @ E_AR.astype(np.int32)).astype(np.int8)
    E_B = (E_BL.astype(np.int32) @ E_BR.astype(np.int32)).astype(np.int8)
    A_noised = A.astype(np.int16) + E_A.astype(np.int16)
    B_noised = B.astype(np.int16) + E_B.astype(np.int16)

    searcher = JackpotSearcher(config, m, n)
    t0 = time.time()
    jackpot = searcher.search(A_noised, B_noised, backend=backend)
    elapsed = time.time() - t0

    # --- parallel tile hash scan (blake3 releases the GIL) ---
    tiles = list(searcher.tile_positions())
    if max_hashes:
        tiles = tiles[:max_hashes]
    n_tiles = len(tiles)

    # Pre-serialise all 32-byte jackpot transcripts into one bytes block
    # jackpot shape: (R, C, 16) uint32
    # Each tile transcript = 16 x uint32 LE = 64 bytes
    transcripts = np.ascontiguousarray(jackpot, dtype=np.uint32)  # (R, C, 16)

    n_workers = min(32, os.cpu_count() or 4)

    hit = None

    def check_tile(idx):
        ri, ci, ro, co = tiles[idx]
        words = transcripts[ri, ci]   # (16,) uint32 numpy view
        msg = words.tobytes()         # 64 bytes, already LE on any platform
        import blake3 as _b3
        h = _b3.blake3(msg, key=a_seed).digest()
        val = int.from_bytes(h, "little")
        if val <= target:
            return idx, ro, co, h, words
        return None

    with ThreadPoolExecutor(max_workers=n_workers) as pool:
        for result in pool.map(check_tile, range(n_tiles)):
            if result is not None:
                idx, ro, co, h, words = result
                hit = (ro, co, h, words)
                break   # found — cancel remaining (pool.map still runs all, but we exit early)

    if on_attempt:
        on_attempt(nonce, elapsed, n_tiles)

    if hit:
        ro, co, h, words = hit
        return _build_share(
            header, config, m, n, target, nonce, A, B,
            b_seed, a_seed, int(ro), int(co), h, words,
            A_noised, B_noised, elapsed, n_tiles,
        )
    return None


def _build_share(header, config, m, n, target, nonce, A, B,
                 b_seed, a_seed, t_rows, t_cols, jackpot_hash_bytes,
                 jackpot_words, A_noised, B_noised, elapsed, hashes):
    """Assemble the self-contained share payload (documented 'v2' format)."""
    from .commitment import job_key
    from .merkle import MerkleTree

    key = job_key(header, config)
    k = config.common_dim

    a_tree = MerkleTree(A.astype(np.uint8, copy=False).tobytes(), key)
    b_tree = MerkleTree(B.T.astype(np.uint8, copy=False).tobytes(), key)

    rows = config.rows_pattern.indices_with_offset(t_rows)
    cols = config.cols_pattern.indices_with_offset(t_cols)

    a_proof = a_tree.proof_for_rows(rows, row_bytes=k, total_rows=m)
    b_proof = b_tree.proof_for_rows(cols, row_bytes=k, total_rows=n)

    return {
        "version": 2,
        "job_id": None,          # filled by the miner when a job is attached
        "nonce": f"{int(nonce):08x}",
        "header": header.to_bytes().hex(),
        "m": m, "n": n, "k": k, "rank": config.rank,
        "rows_pattern": config.rows_pattern.to_list(),
        "cols_pattern": config.cols_pattern.to_list(),
        "t_rows": t_rows,
        "t_cols": t_cols,
        "sigma": a_seed.hex(),
        "b_seed": b_seed.hex(),
        "target": f"{target:064x}",
        "jackpot_hash": jackpot_hash_bytes.hex(),
        "jackpot": [int(w) for w in jackpot_words],
        "a_root": hash_a_hex(key, A),
        "b_root": hash_b_hex(key, B),
        "a_tree_root": a_tree.root.hex(),
        "b_tree_root": b_tree.root.hex(),
        "a_proof": a_proof,
        "b_proof": b_proof,
        "elapsed_s": round(elapsed, 3),
        "hashes": hashes,
    }


def hash_a_hex(key: bytes, A: np.ndarray) -> str:
    from .commitment import pad_to_chunk_boundary
    import blake3 as _b3
    data = pad_to_chunk_boundary(A.astype(np.uint8, copy=False).tobytes())
    return _b3.blake3(data, key=key).digest().hex()


def hash_b_hex(key: bytes, B: np.ndarray) -> str:
    from .commitment import pad_to_chunk_boundary
    import blake3 as _b3
    data = pad_to_chunk_boundary(B.T.astype(np.uint8, copy=False).tobytes())
    return _b3.blake3(data, key=key).digest().hex()


def share_to_line(share: dict, rig: str, job_id: str) -> str:
    out = dict(share)
    out["rig"] = rig
    out["job_id"] = job_id
    return json.dumps(out, separators=(",", ":"))
