import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { normalizeSummary, parseForgeOutput, TelemetryStore } from "./telemetry.mjs";

test("parses ForgeMiner shares and hashrate", () => {
  const event = parseForgeOutput("Stats: 1.50 MH/s | Shares 12 accepted | 2 stale | 1 rejected");
  assert.equal(event.hashrate, 1_500_000);
  assert.equal(event.accepted, 12);
  assert.equal(event.stale, 2);
  assert.equal(event.rejected, 1);
});

test("normalizes native API summary", () => {
  const state = normalizeSummary({ summary: { hashrate_hs: 2500, accepted: 4, stale: 1, rejected: 0 } });
  assert.deepEqual(state, { status: "mining", hashrate: 2500, accepted: 4, stale: 1, rejected: 0 });
});

test("stores sanitized metrics", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "forge-node-"));
  const store = new TelemetryStore(path.join(dir, "telemetry.jsonl"));
  store.record({ status: "mining", hashrate: 1000, accepted: 2, stale: 1, rejected: 0, wallet: "secret" });
  assert.equal(store.metrics().acceptance_pct, 66.67);
  assert.equal(fs.readFileSync(path.join(dir, "telemetry.jsonl"), "utf8").includes("secret"), false);
  fs.rmSync(dir, { recursive: true, force: true });
});
