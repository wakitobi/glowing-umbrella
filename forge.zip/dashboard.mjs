export const page = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ForgeMiner</title><style>
:root{color-scheme:dark;font-family:Inter,system-ui,sans-serif;background:#101312;color:#edf2ef}body{margin:0}
header{border-bottom:1px solid #303735;padding:22px max(22px,calc((100% - 980px)/2))}h1{font-size:24px;margin:0}small{color:#98a6a0}
main{max-width:980px;margin:0 auto;padding:28px 22px}.status{display:flex;align-items:center;gap:9px;margin-bottom:24px}.dot{width:10px;height:10px;border-radius:50%;background:#31c26b}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{border:1px solid #303735;border-radius:6px;padding:18px;background:#171b1a}.label{color:#98a6a0;font-size:13px}.value{font-size:26px;margin-top:8px;font-variant-numeric:tabular-nums}
section{margin-top:28px;border-top:1px solid #303735;padding-top:20px}pre{white-space:pre-wrap;color:#b8c3be}@media(max-width:680px){.grid{grid-template-columns:repeat(2,1fr)}}
</style></head><body><header><h1>ForgeMiner</h1><small>Node.js controller and native miner telemetry</small></header>
<main><div class="status"><span class="dot"></span><strong id="status">Starting</strong></div><div class="grid">
<div class="metric"><div class="label">Hashrate</div><div class="value" id="rate">0 H/s</div></div>
<div class="metric"><div class="label">Accepted</div><div class="value" id="accepted">0</div></div>
<div class="metric"><div class="label">Stale</div><div class="value" id="stale">0</div></div>
<div class="metric"><div class="label">Rejected</div><div class="value" id="rejected">0</div></div></div>
<section><div class="label">Latest event</div><pre id="message">Waiting for telemetry.</pre></section></main><script>
const fmt=n=>n>=1e9?(n/1e9).toFixed(2)+' GH/s':n>=1e6?(n/1e6).toFixed(2)+' MH/s':n>=1e3?(n/1e3).toFixed(2)+' kH/s':n.toFixed(2)+' H/s';
async function refresh(){try{const r=await fetch('/api/telemetry');const x=await r.json();const m=x.metrics;status.textContent=m.status;rate.textContent=fmt(m.hashrate);accepted.textContent=m.accepted;stale.textContent=m.stale;rejected.textContent=m.rejected;message.textContent=m.last_message||'Waiting for telemetry.'}catch{status.textContent='Dashboard disconnected'}}refresh();setInterval(refresh,3000);
</script></body></html>`;
