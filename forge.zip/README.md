# ForgeMiner Node.js controller

This folder now follows the same concept as `xmrig`: Node.js controls the existing native mining engine, records sanitized telemetry, and serves a local dashboard.

The mining algorithm remains in the bundled Linux x86-64 `forge` executable. Rewriting that CUDA miner in JavaScript would not preserve its performance or behavior.

## Requirements

- Linux x86-64 with a supported NVIDIA GPU and driver
- Node.js 18 or newer
- The bundled `forge` executable

## Configure and run

```bash
cp .env.example .env
# Edit FORGE_POOL and FORGE_WALLET
chmod +x forge
npm start
```

Dashboard: `http://127.0.0.1:8876`

CLI arguments override `.env` values:

```bash
node main.mjs --pool host:port --wallet address --worker rig01 --algorithm pearlhash
```

Verify the Node controller without Linux, a GPU, pool access, or wallet configuration:

```bash
npm test
npm run dry-run
```

Endpoints:

- `/health` controller health
- `/api/telemetry` sanitized metrics and non-secret configuration
- `/` dashboard

Wallet, password, and pool are intentionally excluded from telemetry and API responses.
