#!/usr/bin/env node
import { spawn } from "node:child_process";
import http from "node:http";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath } from "node:url";
import { configuration, minerArguments, publicConfig } from "./config.mjs";
import { page } from "./dashboard.mjs";
import { normalizeSummary, parseForgeOutput, TelemetryStore } from "./telemetry.mjs";

const base = path.dirname(fileURLToPath(import.meta.url));
let config;
try { config = configuration(base); }
catch (error) { console.error(`Configuration error: ${error.message}`); process.exit(2); }

const store = new TelemetryStore(path.join(base, "telemetry.jsonl"));
let state = { status: "starting", hashrate: 0, accepted: 0, stale: 0, rejected: 0 };
let miner = null;
let stopping = false;
let poller = null;

function record(update) {
  state = { ...state, ...update };
  store.record(state);
}

function consume(line, stream = "stdout") {
  if (stream === "stderr") process.stderr.write(`[forge] ${line}\n`);
  else process.stdout.write(`[forge] ${line}\n`);
  const update = parseForgeOutput(line, state);
  if (update) record(update);
}

async function pollSummary() {
  try {
    const response = await fetch(`http://${config.minerApi}/summary`, { signal: AbortSignal.timeout(2000) });
    if (response.ok) record(normalizeSummary(await response.json(), state));
  } catch {}
}

function startDryRun() {
  record({ status: "dry-run", message: "Dry-run active; native Linux miner was not launched." });
  let tick = 0;
  poller = setInterval(() => {
    tick += 1;
    record({ status: "dry-run", hashrate: 1000000 + tick * 25000, accepted: Math.floor(tick / 2), message: "Synthetic telemetry for controller verification." });
  }, 1000);
}

function startMiner() {
  try { miner = spawn(config.binary, minerArguments(config), { cwd: base, env: process.env, stdio: ["ignore", "pipe", "pipe"] }); }
  catch (error) { record({ status: "error", message: error.message }); return; }
  readline.createInterface({ input: miner.stdout }).on("line", (line) => consume(line));
  readline.createInterface({ input: miner.stderr }).on("line", (line) => consume(line, "stderr"));
  miner.on("error", (error) => record({ status: "error", message: `Could not launch ForgeMiner: ${error.message}` }));
  miner.on("exit", (code, signal) => {
    if (!stopping) record({ status: "exited", hashrate: 0, message: `ForgeMiner exited (code=${code}, signal=${signal ?? "none"}).` });
  });
  poller = setInterval(pollSummary, 5000);
  record({ status: "launching", message: "ForgeMiner process launched." });
}

const server = http.createServer((request, response) => {
  if (request.url === "/api/telemetry") {
    const body = JSON.stringify({ controller: "forge-node", process: miner?.pid ? "running" : config.dryRun ? "dry-run" : state.status, config: publicConfig(config), metrics: store.metrics() });
    response.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
    response.end(body); return;
  }
  if (request.url === "/health") {
    response.writeHead(200, { "content-type": "application/json" });
    response.end(JSON.stringify({ ok: true, status: state.status })); return;
  }
  response.writeHead(200, { "content-type": "text/html; charset=utf-8" });
  response.end(page);
});

server.on("error", (error) => {
  console.error(`Dashboard startup failed: ${error.message}`);
  process.exitCode = 2;
});

server.listen(config.dashboardPort, "127.0.0.1", () => {
  console.log(`Forge dashboard: http://127.0.0.1:${config.dashboardPort}`);
  console.log(`Algorithm: ${config.algorithm} | Worker: ${config.worker}`);
  if (config.dryRun) startDryRun(); else startMiner();
});

function shutdown() {
  if (stopping) return;
  stopping = true;
  if (poller) clearInterval(poller);
  if (miner && !miner.killed) miner.kill("SIGTERM");
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
