import fs from "node:fs";
import os from "node:os";
import path from "node:path";

export function loadEnv(file) {
  const values = {};
  try {
    for (const raw of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("#") || !line.includes("=")) continue;
      const index = line.indexOf("=");
      values[line.slice(0, index).trim()] = line.slice(index + 1).trim().replace(/^(['"])(.*)\1$/, "$2");
    }
  } catch {}
  return values;
}

export function configuration(base, argv = process.argv.slice(2), environment = process.env) {
  const fileEnv = loadEnv(path.join(base, ".env"));
  const env = { ...fileEnv, ...environment };
  const value = (flag, key, fallback = "") => {
    const index = argv.indexOf(flag);
    return index >= 0 && argv[index + 1] ? argv[index + 1] : env[key] || fallback;
  };
  const config = {
    binary: path.resolve(base, value("--binary", "FORGE_BINARY", "forge")),
    algorithm: value("--algorithm", "FORGE_ALGO", "pearlhash"),
    pool: value("--pool", "FORGE_POOL"),
    wallet: value("--wallet", "FORGE_WALLET"),
    worker: value("--worker", "FORGE_WORKER", os.hostname()),
    password: value("--password", "FORGE_PASSWORD", "x"),
    proto: value("--proto", "FORGE_PROTO", "stratum"),
    dashboardPort: Number(value("--dashboard-port", "DASHBOARD_PORT", "8876")),
    minerApi: value("--miner-api", "FORGE_API", "127.0.0.1:7777"),
    dryRun: argv.includes("--dry-run"),
  };
  if (!Number.isInteger(config.dashboardPort) || config.dashboardPort < 1 || config.dashboardPort > 65535) {
    throw new Error("DASHBOARD_PORT must be between 1 and 65535");
  }
  if (!config.dryRun) {
    const missing = ["pool", "wallet"].filter((key) => !config[key]);
    if (missing.length) throw new Error(`Missing Forge configuration: ${missing.join(", ")}`);
    if (!fs.existsSync(config.binary)) throw new Error(`Forge binary not found: ${config.binary}`);
  }
  return config;
}

export function minerArguments(config) {
  return [
    "--algorithm", config.algorithm,
    "--pool", config.pool,
    "--wallet", config.wallet,
    "--worker", config.worker,
    "--password", config.password,
    "--proto", config.proto,
    "--api-bind", config.minerApi,
  ];
}

export function publicConfig(config) {
  return {
    algorithm: config.algorithm,
    worker: config.worker,
    dashboard_port: config.dashboardPort,
    miner_api: config.minerApi,
    dry_run: config.dryRun,
  };
}
