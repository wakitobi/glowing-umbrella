import fs from "node:fs";
import path from "node:path";

export function stripAnsi(text) {
  return String(text).replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").replace(/\r/g, "");
}

export function parseForgeOutput(line, previous = {}) {
  const text = stripAnsi(line).trim();
  const event = { ...previous };
  let changed = false;

  const rates = [...text.matchAll(/([0-9]+(?:\.[0-9]+)?)\s*([kKmMgGtT]?)\s*(?:H\/s|hash\/s)/g)];
  if (rates.length) {
    const [, value, prefix] = rates.at(-1);
    const multiplier = { "": 1, k: 1e3, m: 1e6, g: 1e9, t: 1e12 }[prefix.toLowerCase()];
    event.hashrate = Number(value) * multiplier;
    event.status = "mining";
    changed = true;
  }

  const shares = text.match(/Shares\s+([0-9]+)\s+accepted\s+\|\s+([0-9]+)\s+stale\s+\|\s+([0-9]+)\s+rejected/i);
  if (shares) {
    event.accepted = Number(shares[1]);
    event.stale = Number(shares[2]);
    event.rejected = Number(shares[3]);
    changed = true;
  } else if (/share accepted/i.test(text)) {
    event.accepted = Number(event.accepted || 0) + 1;
    event.status = "mining";
    changed = true;
  } else if (/share stale/i.test(text)) {
    event.stale = Number(event.stale || 0) + 1;
    changed = true;
  } else if (/share rejected/i.test(text)) {
    event.rejected = Number(event.rejected || 0) + 1;
    event.status = "warning";
    changed = true;
  }

  if (/authorized|connected/i.test(text)) {
    event.status = "connected";
    changed = true;
  } else if (/new job|job received/i.test(text)) {
    event.status = "mining";
    changed = true;
  } else if (/error|failed|rejected/i.test(text) && !/share rejected/i.test(text)) {
    event.status = "error";
    changed = true;
  }

  return changed ? { ...event, message: text.slice(0, 300) } : null;
}

export function normalizeSummary(body, previous = {}) {
  const source = body?.summary ?? body ?? {};
  const pickNumber = (...values) => {
    for (const value of values) {
      const number = Number(value);
      if (Number.isFinite(number)) return number;
    }
    return undefined;
  };
  const hashrate = pickNumber(source.hashrate, source.hashrate_hs, source.total_hashrate, body?.hashrate);
  const accepted = pickNumber(source.accepted, source.shares_accepted, body?.accepted);
  const stale = pickNumber(source.stale, source.shares_stale, body?.stale);
  const rejected = pickNumber(source.rejected, source.shares_rejected, body?.rejected);
  return {
    ...previous,
    status: hashrate > 0 ? "mining" : String(source.status ?? previous.status ?? "connected"),
    ...(hashrate !== undefined && { hashrate: Math.max(0, hashrate) }),
    ...(accepted !== undefined && { accepted: Math.max(0, accepted) }),
    ...(stale !== undefined && { stale: Math.max(0, stale) }),
    ...(rejected !== undefined && { rejected: Math.max(0, rejected) }),
  };
}

export class TelemetryStore {
  constructor(logPath) {
    this.logPath = path.resolve(logPath);
    this.history = [];
    try {
      this.history = fs.readFileSync(this.logPath, "utf8").trim().split(/\r?\n/).filter(Boolean).slice(-240).map(JSON.parse);
    } catch {
      this.history = [];
    }
  }

  record(state) {
    const snapshot = {
      timestamp: Date.now(),
      status: String(state.status ?? "unknown"),
      hashrate: Math.max(0, Number(state.hashrate) || 0),
      accepted: Math.max(0, Number(state.accepted) || 0),
      stale: Math.max(0, Number(state.stale) || 0),
      rejected: Math.max(0, Number(state.rejected) || 0),
      message: String(state.message ?? "").slice(0, 300),
    };
    this.history.push(snapshot);
    this.history = this.history.slice(-240);
    fs.mkdirSync(path.dirname(this.logPath), { recursive: true });
    fs.appendFileSync(this.logPath, `${JSON.stringify(snapshot)}\n`, "utf8");
    return snapshot;
  }

  metrics() {
    const latest = this.history.at(-1) ?? {};
    const rates = this.history.map((item) => item.hashrate).filter((value) => value > 0);
    const average = rates.length ? rates.reduce((sum, value) => sum + value, 0) / rates.length : 0;
    const total = Number(latest.accepted || 0) + Number(latest.stale || 0) + Number(latest.rejected || 0);
    return {
      samples: this.history.length,
      status: latest.status ?? "starting",
      hashrate: Number(Number(latest.hashrate || 0).toFixed(2)),
      average_hashrate: Number(average.toFixed(2)),
      accepted: Number(latest.accepted || 0),
      stale: Number(latest.stale || 0),
      rejected: Number(latest.rejected || 0),
      acceptance_pct: total ? Number((Number(latest.accepted || 0) / total * 100).toFixed(2)) : 0,
      last_message: latest.message ?? "",
      updated_at: latest.timestamp ?? null,
    };
  }
}
