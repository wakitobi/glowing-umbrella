#!/usr/bin/env bash
# Fake krig-miner for testing the supervisor: prints a couple of realistic
# lines (including a hashrate + an accepted share), then exits non-zero so the
# supervisor's crash-restart path fires.
echo "krig-miner 1.2.1 starting, url=$*"
echo "GPU0 Tesla T4: 3.10 MH/s"
echo "Share accepted (1/0)"
sleep 1
echo "GPU0 Tesla T4: 3.12 MH/s"
echo "boom: simulated crash"
exit 7
