import sys, time
print("krig-miner 1.2.1 starting, args=" + " ".join(sys.argv[1:]), flush=True)
print("GPU0 Tesla T4: 3.10 MH/s", flush=True)
print("Share accepted (1/0)", flush=True)
time.sleep(1)
print("GPU0 Tesla T4: 3.12 MH/s", flush=True)
print("share rejected: stale", flush=True)
print("boom: simulated crash", flush=True)
sys.exit(7)
