# krig-supervisor

A small Rust supervisor for the closed-source **krig-miner** Pearl (PRL) GPU
binary. krig-miner itself can't be reimplemented (no source), so this wraps it
with production supervision:

- launches krig-miner with your pool URL + wallet,
- streams + timestamps its stdout/stderr,
- parses hashrate / accepted / rejected(stale) shares,
- auto-restarts on **crash** (exit) or **stall** (no output for N seconds),
  with capped exponential backoff,
- prints a 60s summary (uptime, restarts, accepted, rejected, last hashrate).

## Build (on the Linux T4 box)

```bash
cd krig-supervisor
cargo build --release          # needs a Rust toolchain (rustup)
```

If Rust isn't installed:
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
. "$HOME/.cargo/env"
```

## Get krig-miner

```bash
wget https://github.com/kryptex/krig-miner/releases/download/v1.2.1/krig-miner-1.2.1-linux-x64.tar.gz
tar xzf krig-miner-1.2.1-linux-x64.tar.gz
```

## Run

```bash
./target/release/krig-supervisor \
  --miner ./krig-miner \
  --url  stratum+ssl://prl.kryptex.network:8048 \
  --user prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t
```

Or use the helper script (auto-detects `./krig-miner`):

```bash
AKOYA_WALLET=prl1p2jan…9sc9ux2t ./run.sh
```

Any extra krig-miner flags go after a literal `--`:

```bash
./target/release/krig-supervisor --miner ./krig-miner \
  --url stratum+ssl://prl.kryptex.network:8048 \
  --user prl1… \
  -- --device 0 --log-level debug
```

## Options

| Flag | Default | Meaning |
|------|---------|---------|
| `--miner <path>` | `./krig-miner` | path to the krig-miner binary |
| `--url <url>` | — | pool URL, forwarded as `--url` |
| `--user <wallet[.worker]>` | — | wallet, forwarded as `--user` |
| `--stall-timeout <secs>` | 180 | restart if no miner output this long |
| `--max-backoff <secs>` | 60 | cap on restart backoff |
| `-- <args…>` | — | passed verbatim to krig-miner |

## Run as a service (systemd)

Edit `krig-supervisor.service` (set `WorkingDirectory`, wallet, binary paths),
then:

```bash
sudo cp krig-supervisor.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now krig-supervisor
journalctl -u krig-supervisor -f      # follow logs
```

## Pool notes (probed live)

- `prl.kryptex.network:8048` — valid Sectigo TLS cert, `stratum+ssl`,
  classic array-style auth `["wallet","x"]`, serves `cert_version=3` (post
  salted-seed hard fork) jobs. The wallet above authorizes successfully.
- krig-miner speaks this protocol natively; the supervisor just runs it.
