//! krig-supervisor — a small, robust launcher for the closed-source
//! `krig-miner` Pearl (PRL) binary.
//!
//! krig-miner is a prebuilt GPU miner; it cannot be reimplemented in Rust
//! without its source. What this Rust app *does* add is production supervision
//! around it:
//!
//!   * spawns `krig-miner` with your pool URL + wallet,
//!   * streams and timestamps its stdout/stderr,
//!   * parses hashrate / accepted / rejected shares from the output,
//!   * detects a *stall* (no output for `--stall-timeout` seconds) and a
//!     *crash* (process exit), and auto-restarts with capped backoff,
//!   * prints a periodic summary (uptime, restarts, last hashrate, shares).
//!
//! Usage:
//! ```bash
//! krig-supervisor \
//!   --miner ./krig-miner \
//!   --url stratum+ssl://prl.kryptex.network:8048 \
//!   --user prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t \
//!   -- --any --extra --krig --flags
//! ```
//! Everything after a lone `--` is passed through verbatim to krig-miner.

use std::collections::VecDeque;
use std::process::Stdio;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use regex::Regex;
use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::process::Command;
use tokio::sync::Mutex;

/// Parsed CLI options.
struct Opts {
    miner: String,
    url: Option<String>,
    user: Option<String>,
    stall_timeout: u64,
    max_backoff: u64,
    passthrough: Vec<String>,
}

fn parse_args() -> Result<Opts, String> {
    let mut miner = "./krig-miner".to_string();
    let mut url = None;
    let mut user = None;
    let mut stall_timeout = 180u64;
    let mut max_backoff = 60u64;
    let mut passthrough = Vec::new();

    let mut args = std::env::args().skip(1);
    while let Some(a) = args.next() {
        match a.as_str() {
            "--miner" => miner = args.next().ok_or("--miner needs a value")?,
            "--url" => url = Some(args.next().ok_or("--url needs a value")?),
            "--user" => user = Some(args.next().ok_or("--user needs a value")?),
            "--stall-timeout" => {
                stall_timeout = args
                    .next()
                    .ok_or("--stall-timeout needs a value")?
                    .parse()
                    .map_err(|_| "bad --stall-timeout")?
            }
            "--max-backoff" => {
                max_backoff = args
                    .next()
                    .ok_or("--max-backoff needs a value")?
                    .parse()
                    .map_err(|_| "bad --max-backoff")?
            }
            "--" => {
                passthrough.extend(args.by_ref());
                break;
            }
            "-h" | "--help" => return Err(HELP.to_string()),
            other => return Err(format!("unknown arg: {other}\n\n{HELP}")),
        }
    }
    Ok(Opts {
        miner,
        url,
        user,
        stall_timeout,
        max_backoff,
        passthrough,
    })
}

const HELP: &str = "\
krig-supervisor — launch + auto-restart the krig-miner binary

  --miner <path>            path to krig-miner (default ./krig-miner)
  --url <stratum-url>       pool URL, forwarded as `--url` to krig-miner
  --user <wallet[.worker]>  wallet, forwarded as `--user`
  --stall-timeout <secs>    restart if no miner output for this long (default 180)
  --max-backoff <secs>      cap on restart backoff (default 60)
  -- <args...>              everything after `--` is passed verbatim to krig-miner

example:
  krig-supervisor --miner ./krig-miner \\
    --url stratum+ssl://prl.kryptex.network:8048 \\
    --user prl1p2jan…9sc9ux2t";

/// Shared runtime stats.
#[derive(Default)]
struct Stats {
    restarts: AtomicU64,
    accepted: AtomicU64,
    rejected: AtomicU64,
    last_hashrate: Mutex<String>,
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")),
        )
        .with_target(false)
        .init();

    let opts = match parse_args() {
        Ok(o) => o,
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(2);
        }
    };

    // Build the krig-miner argv: our known flags first, then passthrough.
    let mut argv: Vec<String> = Vec::new();
    if let Some(url) = &opts.url {
        argv.push("--url".into());
        argv.push(url.clone());
    }
    if let Some(user) = &opts.user {
        argv.push("--user".into());
        argv.push(user.clone());
    }
    argv.extend(opts.passthrough.iter().cloned());

    tracing::info!(
        "krig-supervisor starting: miner={} args={:?} stall_timeout={}s",
        opts.miner,
        argv,
        opts.stall_timeout
    );

    let stats = Arc::new(Stats::default());
    let started = Instant::now();

    // Periodic summary task.
    {
        let stats = stats.clone();
        tokio::spawn(async move {
            let mut tick = tokio::time::interval(Duration::from_secs(60));
            loop {
                tick.tick().await;
                let hr = stats.last_hashrate.lock().await.clone();
                tracing::info!(
                    "summary: uptime={}s restarts={} accepted={} rejected={} last_hashrate={}",
                    started.elapsed().as_secs(),
                    stats.restarts.load(Ordering::Relaxed),
                    stats.accepted.load(Ordering::Relaxed),
                    stats.rejected.load(Ordering::Relaxed),
                    if hr.is_empty() { "?".into() } else { hr },
                );
            }
        });
    }

    // Restart loop with capped exponential backoff.
    let mut attempt: u32 = 0;
    loop {
        let run_start = Instant::now();
        match run_once(&opts, &argv, &stats).await {
            Ok(code) => tracing::warn!("krig-miner exited (code={code:?}) — restarting"),
            Err(e) => tracing::error!("supervisor error: {e} — restarting"),
        }
        // A run that lasted a while resets backoff; a fast-failing one escalates.
        if run_start.elapsed() >= Duration::from_secs(120) {
            attempt = 0;
        } else {
            attempt = attempt.saturating_add(1);
        }
        stats.restarts.fetch_add(1, Ordering::Relaxed);
        let backoff = (2u64.saturating_pow(attempt.min(6))).min(opts.max_backoff);
        tracing::info!("restarting in {backoff}s (attempt {attempt})");
        tokio::time::sleep(Duration::from_secs(backoff)).await;
    }
}

/// Spawn krig-miner once and pump its output until it exits or stalls.
async fn run_once(
    opts: &Opts,
    argv: &[String],
    stats: &Arc<Stats>,
) -> Result<Option<i32>, String> {
    let mut child = Command::new(&opts.miner)
        .args(argv)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .kill_on_drop(true)
        .spawn()
        .map_err(|e| format!("failed to spawn {}: {e}", opts.miner))?;

    let stdout = child.stdout.take().ok_or("no stdout pipe")?;
    let stderr = child.stderr.take().ok_or("no stderr pipe")?;

    // Last-output timestamp, shared with the stall watchdog.
    let last_output = Arc::new(Mutex::new(Instant::now()));

    let hr_re = Arc::new(build_hashrate_regex());
    let acc_re = Arc::new(Regex::new(r"(?i)\b(accepted|share accepted|yes!|✔)\b").unwrap());
    let rej_re = Arc::new(Regex::new(r"(?i)\b(rejected|stale|invalid share)\b").unwrap());

    let pump = |reader: BufReader<Box<dyn tokio::io::AsyncRead + Unpin + Send>>,
                tag: &'static str| {
        let last_output = last_output.clone();
        let stats = stats.clone();
        let hr_re = hr_re.clone();
        let acc_re = acc_re.clone();
        let rej_re = rej_re.clone();
        tokio::spawn(async move {
            let mut lines = reader.lines();
            while let Ok(Some(line)) = lines.next_line().await {
                *last_output.lock().await = Instant::now();
                // Forward the miner's own line, tagged.
                tracing::info!("[{tag}] {line}");
                if let Some(c) = hr_re.captures(&line) {
                    if let Some(m) = c.get(0) {
                        *stats.last_hashrate.lock().await = m.as_str().trim().to_string();
                    }
                }
                if acc_re.is_match(&line) {
                    stats.accepted.fetch_add(1, Ordering::Relaxed);
                }
                if rej_re.is_match(&line) {
                    let n = stats.rejected.fetch_add(1, Ordering::Relaxed) + 1;
                    tracing::warn!("rejected/stale share detected (total {n})");
                }
            }
        })
    };

    let out_box: Box<dyn tokio::io::AsyncRead + Unpin + Send> = Box::new(stdout);
    let err_box: Box<dyn tokio::io::AsyncRead + Unpin + Send> = Box::new(stderr);
    let out_task = pump(BufReader::new(out_box), "out");
    let err_task = pump(BufReader::new(err_box), "err");

    // Stall watchdog + process wait, whichever fires first.
    let stall = Duration::from_secs(opts.stall_timeout);
    loop {
        tokio::select! {
            status = child.wait() => {
                out_task.abort();
                err_task.abort();
                let code = status.map_err(|e| e.to_string())?.code();
                return Ok(code);
            }
            _ = tokio::time::sleep(Duration::from_secs(5)) => {
                let idle = last_output.lock().await.elapsed();
                if idle > stall {
                    tracing::warn!(
                        "stall detected: no miner output for {}s (> {}s) — killing",
                        idle.as_secs(), stall.as_secs()
                    );
                    let _ = child.kill().await;
                    out_task.abort();
                    err_task.abort();
                    return Ok(None);
                }
            }
        }
    }
}

/// Recognize common hashrate print formats: "12.3 MH/s", "1.2 kH/s",
/// "450 H/s", "3.1 Msol/s", etc.
fn build_hashrate_regex() -> Regex {
    Regex::new(r"(?i)\d+(?:\.\d+)?\s*[kMGT]?(?:H|sol|Sol)/s").unwrap()
}

#[allow(dead_code)]
fn _keep_vecdeque_used(_: VecDeque<u8>) {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_stratum_ssl_url() {
        // The supervisor forwards the URL verbatim; this just documents the
        // shapes krig-miner accepts (validated in akoya-stratum too).
        let cases = [
            "stratum+ssl://prl.kryptex.network:8048",
            "stratum+tcp://host:3333",
            "stratum://host:3333",
        ];
        for c in cases {
            assert!(c.contains("://"));
        }
    }

    #[test]
    fn hashrate_regex_matches_common_formats() {
        let re = build_hashrate_regex();
        for s in ["12.3 MH/s", "450 H/s", "1.2kH/s", "3.10 MSol/s", "7 GH/s"] {
            assert!(re.is_match(s), "should match {s}");
        }
        assert!(!re.is_match("height 103835"));
    }

    #[test]
    fn accepted_rejected_regex() {
        let acc = Regex::new(r"(?i)\b(accepted|share accepted|yes!|✔)\b").unwrap();
        let rej = Regex::new(r"(?i)\b(rejected|stale|invalid share)\b").unwrap();
        assert!(acc.is_match("Share accepted (1/0)"));
        assert!(rej.is_match("share rejected: stale"));
        assert!(!acc.is_match("connecting to pool"));
    }
}
