#!/usr/bin/env bash
# run.sh — build (if needed) and launch krig-supervisor on the T4 box.
#
#   AKOYA_WALLET=prl1...  ./run.sh
#
# Env knobs:
#   AKOYA_WALLET   (required) your prl1… payout address (optionally wallet.worker)
#   POOL_URL       default stratum+ssl://prl.kryptex.network:8048
#   KRIG_BIN       default ./krig-miner
#   STALL_TIMEOUT  default 180
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

: "${AKOYA_WALLET:?set AKOYA_WALLET=prl1... }"
POOL_URL="${POOL_URL:-stratum+ssl://prl.kryptex.network:8048}"
KRIG_BIN="${KRIG_BIN:-./krig-miner}"
STALL_TIMEOUT="${STALL_TIMEOUT:-180}"

if ! command -v cargo >/dev/null; then
  echo "[run] installing rust…"
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
  . "$HOME/.cargo/env"
fi

if [ ! -x target/release/krig-supervisor ]; then
  echo "[run] building krig-supervisor (release)…"
  cargo build --release
fi

if [ ! -x "$KRIG_BIN" ]; then
  echo "[run] WARNING: $KRIG_BIN not found/executable."
  echo "[run] fetch it with:"
  echo "  wget https://github.com/kryptex/krig-miner/releases/download/v1.2.1/krig-miner-1.2.1-linux-x64.tar.gz"
  echo "  tar xzf krig-miner-1.2.1-linux-x64.tar.gz"
fi

echo "[run] starting supervisor: url=$POOL_URL wallet=$AKOYA_WALLET miner=$KRIG_BIN"
exec ./target/release/krig-supervisor \
  --miner "$KRIG_BIN" \
  --url "$POOL_URL" \
  --user "$AKOYA_WALLET" \
  --stall-timeout "$STALL_TIMEOUT"
