//! Generated tonic/prost client stubs for the Akoya pool V2 protocol.
//!
//! The wire types and `MinerServiceClient` are generated at build time from
//! `proto/miner.proto` (package `pearlpool.mining.v2`) via `protox` +
//! `tonic-build`, so no system `protoc` is required.

pub mod v2 {
    tonic::include_proto!("pearlpool.mining.v2");
}

pub use v2::miner_service_client::MinerServiceClient;
