//! Compile the V2 miner protocol without requiring a system `protoc`.
//!
//! We use `protox` (a pure-Rust protobuf compiler) to produce a
//! `FileDescriptorSet`, then hand it to `tonic-build` for Rust codegen.

use std::path::PathBuf;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let proto = "proto/miner.proto";
    println!("cargo:rerun-if-changed={proto}");

    // Pure-Rust compile → FileDescriptorSet (no external protoc needed).
    let fds = protox::compile([proto], ["proto"])?;

    let out_dir = PathBuf::from(std::env::var("OUT_DIR")?);
    let descriptor_path = out_dir.join("miner_descriptor.bin");
    std::fs::write(&descriptor_path, protox_bytes(&fds))?;

    tonic_build::configure()
        .build_server(false)
        .build_client(true)
        .compile_fds(fds)?;

    Ok(())
}

fn protox_bytes(fds: &prost_types::FileDescriptorSet) -> Vec<u8> {
    use prost::Message;
    let mut buf = Vec::new();
    fds.encode(&mut buf).expect("encode descriptor set");
    buf
}
