//! Minimal CUDA Runtime API FFI for device-buffer management in the solve loop.
//!
//! The pearl-gemm CAPI owns most device memory via its per-σ workspace, but the
//! solve loop still needs to: allocate the A/B int8 device buffers + pinned host
//! header slots, memcpy the winning A rows back to the host to build the merkle
//! proof, and create/destroy a stream. We bind just those entry points from the
//! CUDA Runtime library (`cudart`), loaded at runtime with libloading so the host
//! binary still builds/runs on GPU-less machines (selftest/version/probe-submit).
//!
//! All calls return `cudaError_t` (0 == cudaSuccess). Only compiled paths that
//! actually mine touch these — everything is behind `CudaRt::load()` which fails
//! gracefully when cudart is absent.

use std::ffi::{c_int, c_void};
use libloading::Library;

#[cfg(target_os = "windows")]
const CUDART_CANDIDATES: &[&str] = &[
    "cudart64_12.dll",
    "cudart64_120.dll",
    "cudart64_110.dll",
    "cudart64_11.dll",
    "cudart.dll",
];
#[cfg(all(unix, not(target_os = "macos")))]
const CUDART_CANDIDATES: &[&str] = &["libcudart.so", "libcudart.so.12", "libcudart.so.11.0"];
#[cfg(target_os = "macos")]
const CUDART_CANDIDATES: &[&str] = &["libcudart.dylib"];

#[derive(Debug, thiserror::Error)]
pub enum CudaError {
    #[error("cannot load CUDA runtime: {0}")]
    Load(String),
    #[error("cuda call `{func}` failed: cudaError {code}")]
    Call { func: &'static str, code: i32 },
}

// cudaMemcpyKind
const MEMCPY_HOST_TO_DEVICE: c_int = 1;
const MEMCPY_DEVICE_TO_HOST: c_int = 2;

type FnMalloc = unsafe extern "C" fn(*mut *mut c_void, usize) -> c_int;
type FnFree = unsafe extern "C" fn(*mut c_void) -> c_int;
type FnHostAlloc = unsafe extern "C" fn(*mut *mut c_void, usize, u32) -> c_int;
type FnFreeHost = unsafe extern "C" fn(*mut c_void) -> c_int;
type FnMemcpy = unsafe extern "C" fn(*mut c_void, *const c_void, usize, c_int) -> c_int;
type FnStreamCreate = unsafe extern "C" fn(*mut *mut c_void) -> c_int;
type FnStreamDestroy = unsafe extern "C" fn(*mut c_void) -> c_int;
type FnStreamSync = unsafe extern "C" fn(*mut c_void) -> c_int;
type FnSetDevice = unsafe extern "C" fn(c_int) -> c_int;

/// A loaded CUDA runtime with the handful of entry points the solve loop needs.
pub struct CudaRt {
    _lib: Library,
    malloc: FnMalloc,
    free: FnFree,
    host_alloc: FnHostAlloc,
    free_host: FnFreeHost,
    memcpy: FnMemcpy,
    stream_create: FnStreamCreate,
    stream_destroy: FnStreamDestroy,
    stream_sync: FnStreamSync,
    set_device: FnSetDevice,
}

macro_rules! sym {
    ($lib:expr, $name:literal, $ty:ty) => {{
        let s: libloading::Symbol<$ty> = unsafe {
            $lib.get($name).map_err(|e| CudaError::Load(e.to_string()))?
        };
        unsafe { *s.into_raw() }
    }};
}

impl CudaRt {
    /// Load cudart from the first candidate name that resolves.
    pub fn load() -> Result<Self, CudaError> {
        let mut last = String::from("no candidate names");
        for name in CUDART_CANDIDATES {
            match unsafe { Library::new(name) } {
                Ok(lib) => return Self::bind(lib),
                Err(e) => last = format!("{name}: {e}"),
            }
        }
        Err(CudaError::Load(last))
    }

    fn bind(lib: Library) -> Result<Self, CudaError> {
        Ok(Self {
            malloc: sym!(lib, b"cudaMalloc", FnMalloc),
            free: sym!(lib, b"cudaFree", FnFree),
            host_alloc: sym!(lib, b"cudaHostAlloc", FnHostAlloc),
            free_host: sym!(lib, b"cudaFreeHost", FnFreeHost),
            memcpy: sym!(lib, b"cudaMemcpy", FnMemcpy),
            stream_create: sym!(lib, b"cudaStreamCreate", FnStreamCreate),
            stream_destroy: sym!(lib, b"cudaStreamDestroy", FnStreamDestroy),
            stream_sync: sym!(lib, b"cudaStreamSynchronize", FnStreamSync),
            set_device: sym!(lib, b"cudaSetDevice", FnSetDevice),
            _lib: lib,
        })
    }

    #[inline]
    fn check(func: &'static str, code: c_int) -> Result<(), CudaError> {
        if code == 0 {
            Ok(())
        } else {
            Err(CudaError::Call { func, code })
        }
    }

    pub fn set_device(&self, dev: i32) -> Result<(), CudaError> {
        Self::check("cudaSetDevice", unsafe { (self.set_device)(dev) })
    }

    /// Allocate `bytes` of device memory. Returns the device pointer.
    pub fn malloc(&self, bytes: usize) -> Result<*mut c_void, CudaError> {
        let mut p: *mut c_void = std::ptr::null_mut();
        Self::check("cudaMalloc", unsafe { (self.malloc)(&mut p, bytes) })?;
        Ok(p)
    }

    /// # Safety
    /// `ptr` must be a device pointer from [`malloc`].
    pub unsafe fn free(&self, ptr: *mut c_void) -> Result<(), CudaError> {
        Self::check("cudaFree", (self.free)(ptr))
    }

    /// Allocate `bytes` of pinned host memory (flag 0 = cudaHostAllocDefault).
    pub fn host_alloc(&self, bytes: usize) -> Result<*mut c_void, CudaError> {
        let mut p: *mut c_void = std::ptr::null_mut();
        Self::check("cudaHostAlloc", unsafe { (self.host_alloc)(&mut p, bytes, 0) })?;
        Ok(p)
    }

    /// # Safety
    /// `ptr` must be a pinned host pointer from [`host_alloc`].
    pub unsafe fn free_host(&self, ptr: *mut c_void) -> Result<(), CudaError> {
        Self::check("cudaFreeHost", (self.free_host)(ptr))
    }

    /// Copy `bytes` from a device pointer into a host slice.
    ///
    /// # Safety
    /// `src` must be a valid device pointer with at least `dst.len()` bytes.
    pub unsafe fn memcpy_dtoh(&self, dst: &mut [u8], src: *const c_void) -> Result<(), CudaError> {
        Self::check(
            "cudaMemcpy(DtoH)",
            (self.memcpy)(dst.as_mut_ptr() as *mut c_void, src, dst.len(), MEMCPY_DEVICE_TO_HOST),
        )
    }

    /// Copy a host slice into a device pointer.
    ///
    /// # Safety
    /// `dst` must be a valid device pointer with at least `src.len()` bytes.
    pub unsafe fn memcpy_htod(&self, dst: *mut c_void, src: &[u8]) -> Result<(), CudaError> {
        Self::check(
            "cudaMemcpy(HtoD)",
            (self.memcpy)(dst, src.as_ptr() as *const c_void, src.len(), MEMCPY_HOST_TO_DEVICE),
        )
    }

    pub fn stream_create(&self) -> Result<*mut c_void, CudaError> {
        let mut s: *mut c_void = std::ptr::null_mut();
        Self::check("cudaStreamCreate", unsafe { (self.stream_create)(&mut s) })?;
        Ok(s)
    }

    /// # Safety
    /// `stream` must be from [`stream_create`].
    pub unsafe fn stream_destroy(&self, stream: *mut c_void) -> Result<(), CudaError> {
        Self::check("cudaStreamDestroy", (self.stream_destroy)(stream))
    }

    /// # Safety
    /// `stream` must be a valid stream (or null for the default stream).
    pub unsafe fn stream_synchronize(&self, stream: *mut c_void) -> Result<(), CudaError> {
        Self::check("cudaStreamSynchronize", (self.stream_sync)(stream))
    }
}
