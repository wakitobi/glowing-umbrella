//! Runtime FFI bindings to `libpearl_gemm_capi` (the CUDA proof-of-work GEMM
//! kernels), mirroring `Akoya.PearlGemm.PearlGemmNative` from the C# miner.
//!
//! Like the C# host, we load the native library **at runtime** via
//! `libloading` rather than link against it at build time — the miner host
//! binary must build and run on machines without CUDA (e.g. for `selftest`
//! and `version`), and the correct architecture-specific `.so`/`.dll` is
//! selected at startup. The path is resolved from `AKOYA_PEARL_GEMM_LIB`
//! (absolute), else the platform default library name on the loader path.
//!
//! All `repr(C)` structs below mirror the layouts in
//! `native/pearl-gemm/csrc/capi/pearl_gemm_capi.h` exactly. All entry points
//! return `i32` (`0` = success, `< 0` = failure). All raw pointers are device
//! pointers unless a doc comment says otherwise.

use std::ffi::{c_char, c_int, c_void, CStr};
use std::path::PathBuf;

use libloading::{Library, Symbol};

pub mod cuda_rt;
pub use cuda_rt::{CudaError, CudaRt};

/// Default library file name per platform (matches the C# `NativeLibs` helper).
#[cfg(target_os = "windows")]
pub const GEMM_LIB_FILE: &str = "pearl_gemm_capi.dll";
#[cfg(target_os = "macos")]
pub const GEMM_LIB_FILE: &str = "libpearl_gemm_capi.dylib";
#[cfg(all(unix, not(target_os = "macos")))]
pub const GEMM_LIB_FILE: &str = "libpearl_gemm_capi.so";

#[derive(Debug, thiserror::Error)]
pub enum GemmError {
    #[error("failed to load pearl-gemm library: {0}")]
    Load(#[from] libloading::Error),
    #[error("native call `{func}` returned status {status}")]
    Status { func: &'static str, status: i32 },
}

/// `struct PearlCapiNoiseBParams` — noise_B σ-refresh parameters.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct NoiseBParams {
    pub n: i32,
    pub k: i32,
    pub r: i32,
    pub b: *mut c_void,
    pub ear_k_major: *mut c_void,
    pub ebl_r_major: *mut c_void,
    pub ebr: *mut c_void,
    pub ear_x_bpeb: *mut c_void,
    pub bpeb: *mut c_void,
    pub workspace: *mut c_void,
}

/// `struct PearlCapiInstallBParams` — full B-side σ install.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct InstallBParams {
    pub m: i32,
    pub n: i32,
    pub k: i32,
    pub r: i32,
    pub expand_bseed: i32,
    pub th_num_blocks: u32,
    pub th_threads: u32,
    pub th_stages: u32,
    pub th_leaves: u32,
    pub device_id: i32,
    pub bseed: *const u8,
    pub b: *mut c_void,
    pub b_hash: *mut c_void,
    pub key: *mut c_void,
    pub roots: *mut c_void,
    pub a_hash: *mut c_void,
    pub commit_a: *mut c_void,
    pub commit_b: *mut c_void,
    pub ear_k_major: *mut c_void,
    pub ebl_r_major: *mut c_void,
    pub ebl_k_major: *mut c_void,
    pub ebr: *mut c_void,
    pub ebr_fp16: *mut c_void,
    pub ear_x_bpeb: *mut c_void,
    pub bpeb: *mut c_void,
    pub workspace: *mut c_void,
    pub leaf_cvs: *mut c_void,
}

/// `struct PearlCapiNoisyGemmParams` — the hot inner-loop kernel parameters.
#[repr(C)]
#[derive(Clone, Copy)]
pub struct NoisyGemmParams {
    pub m: i32,
    pub n: i32,
    pub k: i32,
    pub r: i32,
    pub bm: i32,
    pub bn: i32,
    pub bk: i32,
    pub cm: i32,
    pub cn: i32,
    pub a: *mut c_void,
    pub b: *mut c_void,
    pub eal: *mut c_void,
    pub eal_fp16: *mut c_void,
    pub ebr: *mut c_void,
    pub ebr_fp16: *mut c_void,
    pub ear_r_major: *mut c_void,
    pub ebl_r_major: *mut c_void,
    pub ear_k_major: *mut c_void,
    pub ebl_k_major: *mut c_void,
    pub ax_ebl_fp16: *mut c_void,
    pub ear_x_bpeb_fp16: *mut c_void,
    pub ap_ea: *mut c_void,
    pub bpeb: *mut c_void,
    pub a_scales: *mut c_void,
    pub b_scales: *mut c_void,
    pub c: *mut c_void,
    pub host_signal_header_pinned: *mut c_void,
    pub host_signal_sync: *mut c_void,
    pub pow_target: *mut c_void,
    pub pow_key: *mut c_void,
    pub workspace: *mut c_void,
}

/// `struct PearlCapiWorkspaceParams` — per-σ constant cache (see C ABI header).
#[repr(C)]
#[derive(Clone, Copy)]
pub struct WorkspaceParams {
    pub m: i32,
    pub n: i32,
    pub k: i32,
    pub r: i32,
    pub bm: i32,
    pub bn: i32,
    pub bk: i32,
    pub cm: i32,
    pub cn: i32,
    pub th_num_blocks: u32,
    pub th_threads: u32,
    pub th_stages: u32,
    pub th_leaves: u32,
    pub sigma_seed: u64,
    pub a: *mut c_void,
    pub b: *mut c_void,
    pub a_hash: *mut c_void,
    pub b_hash: *mut c_void,
    pub key: *mut c_void,
    pub roots: *mut c_void,
    pub commit_a: *mut c_void,
    pub commit_b: *mut c_void,
    pub eal: *mut c_void,
    pub eal_fp16: *mut c_void,
    pub ebr: *mut c_void,
    pub ebr_fp16: *mut c_void,
    pub ear_r_major: *mut c_void,
    pub ebl_r_major: *mut c_void,
    pub ear_k_major: *mut c_void,
    pub ebl_k_major: *mut c_void,
    pub ax_ebl_fp16: *mut c_void,
    pub ear_x_bpeb_fp16: *mut c_void,
    pub ap_ea: *mut c_void,
    pub bpeb: *mut c_void,
    pub a_scales: *mut c_void,
    pub b_scales: *mut c_void,
    pub c: *mut c_void,
    pub host_signal_sync: *mut c_void,
    pub pow_target: *mut c_void,
    pub pow_key: *mut c_void,
}

// Function-pointer type aliases for the entry points the miner uses.
type FnAbiVersion = unsafe extern "C" fn() -> c_int;
type FnBuildProfile = unsafe extern "C" fn() -> *const c_char;
type FnSupportsSm = unsafe extern "C" fn(c_int, c_int) -> c_int;
type FnHostSignalSyncSize = unsafe extern "C" fn() -> c_int;
type FnHostSignalHeaderSize = unsafe extern "C" fn() -> c_int;
type FnWorkspaceAlloc = unsafe extern "C" fn(
    i32,
    i32,
    i32,
    i32,
    c_int,
    c_int,
    *mut *mut c_void,
    *mut c_void,
) -> c_int;
type FnWorkspaceFree = unsafe extern "C" fn(*mut c_void, *mut c_void) -> c_int;
type FnWorkspaceInstallParams =
    unsafe extern "C" fn(*mut c_void, *const WorkspaceParams) -> c_int;
type FnIter = unsafe extern "C" fn(*mut c_void, u64, *mut c_void, *mut c_void) -> c_int;
type FnIterBatch =
    unsafe extern "C" fn(*mut c_void, u64, *const *mut c_void, i32, *mut c_void) -> c_int;
type FnNoisyGemm = unsafe extern "C" fn(*const NoisyGemmParams, *mut c_void) -> c_int;
type FnNoiseB = unsafe extern "C" fn(*const NoiseBParams, *mut c_void) -> c_int;
type FnInstallB = unsafe extern "C" fn(*const InstallBParams, *mut c_void) -> c_int;
type FnLcgInt7Fill = unsafe extern "C" fn(*mut c_void, i64, u64, u64, *mut c_void) -> c_int;
type FnBseedExpandRawDevice =
    unsafe extern "C" fn(*const u8, *mut c_void, i64, *mut c_void) -> c_int;

/// Resolve the pearl-gemm library path: `AKOYA_PEARL_GEMM_LIB` if set (and
/// non-empty), else the platform default name (resolved via the loader path).
pub fn resolve_lib_path() -> PathBuf {
    match std::env::var("AKOYA_PEARL_GEMM_LIB") {
        Ok(p) if !p.is_empty() => PathBuf::from(p),
        _ => PathBuf::from(GEMM_LIB_FILE),
    }
}

/// A loaded pearl-gemm native library plus resolved entry-point symbols.
///
/// This owns the `Library`; entry points borrow from it, so `PearlGemm` must
/// outlive any call. Dropping it unloads the native library.
pub struct PearlGemm {
    _lib: Library,
    abi_version: FnAbiVersion,
    build_profile: FnBuildProfile,
    supports_sm: FnSupportsSm,
    host_signal_sync_size: FnHostSignalSyncSize,
    host_signal_header_size: FnHostSignalHeaderSize,
    workspace_alloc: FnWorkspaceAlloc,
    workspace_free: FnWorkspaceFree,
    workspace_install_params: FnWorkspaceInstallParams,
    iter: FnIter,
    iter_batch: FnIterBatch,
    noisy_gemm: FnNoisyGemm,
    noise_b: FnNoiseB,
    install_b: FnInstallB,
    lcg_int7_fill: FnLcgInt7Fill,
    bseed_expand_raw_device: FnBseedExpandRawDevice,
}

macro_rules! sym {
    ($lib:expr, $name:literal, $ty:ty) => {{
        let s: Symbol<$ty> = unsafe { $lib.get($name)? };
        unsafe { *s.into_raw() }
    }};
}

impl PearlGemm {
    /// Load from the path resolved by [`resolve_lib_path`].
    pub fn load_default() -> Result<Self, GemmError> {
        Self::load(&resolve_lib_path())
    }

    /// Load a specific library file and bind all entry points.
    pub fn load(path: &std::path::Path) -> Result<Self, GemmError> {
        // SAFETY: loading a native library and reading its exported symbols.
        // The symbol signatures below match the stable C ABI header.
        let lib = unsafe { Library::new(path)? };
        let me = Self {
            abi_version: sym!(lib, b"pearl_capi_abi_version", FnAbiVersion),
            build_profile: sym!(lib, b"pearl_capi_build_profile", FnBuildProfile),
            supports_sm: sym!(lib, b"pearl_capi_supports_sm", FnSupportsSm),
            host_signal_sync_size: sym!(
                lib,
                b"pearl_capi_get_host_signal_sync_size",
                FnHostSignalSyncSize
            ),
            host_signal_header_size: sym!(
                lib,
                b"pearl_capi_get_host_signal_header_size",
                FnHostSignalHeaderSize
            ),
            workspace_alloc: sym!(lib, b"pearl_capi_workspace_alloc", FnWorkspaceAlloc),
            workspace_free: sym!(lib, b"pearl_capi_workspace_free", FnWorkspaceFree),
            workspace_install_params: sym!(
                lib,
                b"pearl_capi_workspace_install_params",
                FnWorkspaceInstallParams
            ),
            iter: sym!(lib, b"pearl_capi_iter", FnIter),
            iter_batch: sym!(lib, b"pearl_capi_iter_batch", FnIterBatch),
            noisy_gemm: sym!(lib, b"pearl_capi_noisy_gemm", FnNoisyGemm),
            noise_b: sym!(lib, b"pearl_capi_noise_B", FnNoiseB),
            install_b: sym!(lib, b"pearl_capi_install_B", FnInstallB),
            lcg_int7_fill: sym!(lib, b"pearl_capi_lcg_int7_fill", FnLcgInt7Fill),
            bseed_expand_raw_device: sym!(
                lib,
                b"pearl_capi_bseed_expand_raw_device",
                FnBseedExpandRawDevice
            ),
            _lib: lib,
        };
        Ok(me)
    }

    #[inline]
    fn check(func: &'static str, status: c_int) -> Result<(), GemmError> {
        if status == 0 {
            Ok(())
        } else {
            Err(GemmError::Status { func, status })
        }
    }

    pub fn abi_version(&self) -> i32 {
        unsafe { (self.abi_version)() }
    }

    /// The native build profile string (e.g. `"turing"`, `"ada"`, `"h100"`).
    pub fn build_profile(&self) -> String {
        let ptr = unsafe { (self.build_profile)() };
        if ptr.is_null() {
            return "unknown".to_string();
        }
        unsafe { CStr::from_ptr(ptr) }
            .to_string_lossy()
            .into_owned()
    }

    /// Whether the loaded kernel supports the given compute capability
    /// `(major, minor)` — e.g. `(7, 5)` for a Tesla T4 (Turing).
    pub fn supports_sm(&self, major: i32, minor: i32) -> bool {
        unsafe { (self.supports_sm)(major, minor) != 0 }
    }

    pub fn host_signal_sync_size(&self) -> i32 {
        unsafe { (self.host_signal_sync_size)() }
    }

    pub fn host_signal_header_size(&self) -> i32 {
        unsafe { (self.host_signal_header_size)() }
    }

    /// Allocate a per-σ workspace. `out` receives the opaque handle.
    ///
    /// # Safety
    /// `stream` must be a valid `cudaStream_t` (or null for the default
    /// stream). The returned handle must be freed with [`workspace_free`].
    pub unsafe fn workspace_alloc(
        &self,
        m: i32,
        n: i32,
        k: i32,
        r: i32,
        with_noise_a: bool,
        with_noise_b: bool,
        stream: *mut c_void,
    ) -> Result<*mut c_void, GemmError> {
        let mut out: *mut c_void = std::ptr::null_mut();
        let status = (self.workspace_alloc)(
            m,
            n,
            k,
            r,
            with_noise_a as c_int,
            with_noise_b as c_int,
            &mut out,
            stream,
        );
        Self::check("pearl_capi_workspace_alloc", status)?;
        Ok(out)
    }

    /// # Safety
    /// `workspace` must be a handle from [`workspace_alloc`]; `stream` valid.
    pub unsafe fn workspace_free(
        &self,
        workspace: *mut c_void,
        stream: *mut c_void,
    ) -> Result<(), GemmError> {
        Self::check(
            "pearl_capi_workspace_free",
            (self.workspace_free)(workspace, stream),
        )
    }

    /// # Safety
    /// `workspace` valid; `params` device pointers must remain valid for the
    /// workspace lifetime.
    pub unsafe fn workspace_install_params(
        &self,
        workspace: *mut c_void,
        params: &WorkspaceParams,
    ) -> Result<(), GemmError> {
        Self::check(
            "pearl_capi_workspace_install_params",
            (self.workspace_install_params)(workspace, params as *const _),
        )
    }

    /// Per-iteration hot path (one nonce).
    ///
    /// # Safety
    /// `workspace` must have had params installed; `host_signal_header_pinned`
    /// must be a valid pinned-host buffer; `stream` valid.
    pub unsafe fn iter(
        &self,
        workspace: *mut c_void,
        seed_lo: u64,
        host_signal_header_pinned: *mut c_void,
        stream: *mut c_void,
    ) -> Result<(), GemmError> {
        Self::check(
            "pearl_capi_iter",
            (self.iter)(workspace, seed_lo, host_signal_header_pinned, stream),
        )
    }

    /// Batched hot path: `count` consecutive nonces from `seed_lo_start`.
    ///
    /// # Safety
    /// `batch` must point to `count` valid pinned-host header slots.
    pub unsafe fn iter_batch(
        &self,
        workspace: *mut c_void,
        seed_lo_start: u64,
        batch: *const *mut c_void,
        count: i32,
        stream: *mut c_void,
    ) -> Result<(), GemmError> {
        Self::check(
            "pearl_capi_iter_batch",
            (self.iter_batch)(workspace, seed_lo_start, batch, count, stream),
        )
    }

    /// # Safety
    /// All device pointers in `p` must be valid for the given dims; `stream` valid.
    pub unsafe fn noisy_gemm(
        &self,
        p: &NoisyGemmParams,
        stream: *mut c_void,
    ) -> Result<(), GemmError> {
        Self::check("pearl_capi_noisy_gemm", (self.noisy_gemm)(p as *const _, stream))
    }

    /// # Safety
    /// See [`noisy_gemm`].
    pub unsafe fn noise_b(&self, p: &NoiseBParams, stream: *mut c_void) -> Result<(), GemmError> {
        Self::check("pearl_capi_noise_B", (self.noise_b)(p as *const _, stream))
    }

    /// # Safety
    /// See [`noisy_gemm`]; `p.bseed` may be a host pointer per the C ABI.
    pub unsafe fn install_b(&self, p: &InstallBParams, stream: *mut c_void) -> Result<(), GemmError> {
        Self::check("pearl_capi_install_B", (self.install_b)(p as *const _, stream))
    }

    /// Deterministic int7 device fill (host-replayable via `akoya_crypto::lcg_int7`).
    ///
    /// # Safety
    /// `dst` must be a device buffer of at least `n` bytes; `stream` valid.
    pub unsafe fn lcg_int7_fill(
        &self,
        dst: *mut c_void,
        n: i64,
        seed_lo: u64,
        seed_hi: u64,
        stream: *mut c_void,
    ) -> Result<(), GemmError> {
        Self::check(
            "pearl_capi_lcg_int7_fill",
            (self.lcg_int7_fill)(dst, n, seed_lo, seed_hi, stream),
        )
    }

    /// B-seed XOF expansion directly into a device buffer.
    ///
    /// # Safety
    /// `bseed` is a host pointer to 32 bytes; `dst` a device buffer of >= `n`
    /// bytes; `stream` valid.
    pub unsafe fn bseed_expand_raw_device(
        &self,
        bseed: *const u8,
        dst: *mut c_void,
        n: i64,
        stream: *mut c_void,
    ) -> Result<(), GemmError> {
        Self::check(
            "pearl_capi_bseed_expand_raw_device",
            (self.bseed_expand_raw_device)(bseed, dst, n, stream),
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::mem::size_of;

    #[test]
    fn resolve_default_when_env_unset() {
        // Only assert the default-name branch here to avoid mutating the
        // process env in parallel tests; the env branch is exercised by the
        // miner's selftest.
        std::env::remove_var("AKOYA_PEARL_GEMM_LIB");
        assert_eq!(resolve_lib_path(), PathBuf::from(GEMM_LIB_FILE));
    }

    #[test]
    fn struct_layouts_are_c_repr_and_nonzero() {
        // Guard against accidental field reordering shrinking the structs.
        assert!(size_of::<NoisyGemmParams>() >= size_of::<i32>() * 9);
        assert!(size_of::<WorkspaceParams>() > size_of::<NoisyGemmParams>() - 64);
        assert!(size_of::<NoiseBParams>() >= size_of::<i32>() * 3);
        assert!(size_of::<InstallBParams>() > size_of::<NoiseBParams>());
    }
}
