//! Wire message types for the LuckyPool Pearl Stratum-style protocol.
//!
//! The pool speaks newline-delimited JSON-RPC 2.0-ish frames over a TLS
//! socket (self-signed `*.luckypool.io` cert, no ALPN — so this is a plain
//! TLS stream, NOT gRPC/HTTP2).
//!
//! Observed flow against `pearl-sg1.lproute.com:3360`:
//!
//! ```text
//! → {"id":1,"method":"mining.authorize",
//!    "params":{"wallet":"prl1…","worker":"t4rig","agent":"akoya-rs/0.1"}}
//! ← {"error":null,"id":1,"result":true,"type":"plain"}
//! ← {"id":null,"method":"mining.notify","params":{
//!      "cert_version":3,"diff":262144,"height":103799,
//!      "job_id":"535db0ce_262144",
//!      "header":"00000020a1a5…e90018",
//!      "target":"0000000000003fffc0…0000"}}
//! ```
//!
//! `mining.submit` takes an OBJECT param (array is rejected with code 20:
//! "params must be an object"); an unknown/stale job yields code 21
//! ("job not found / stale").

use serde::{Deserialize, Serialize};

/// An outbound request frame.
#[derive(Debug, Clone, Serialize)]
pub struct Request {
    pub id: u64,
    pub method: String,
    pub params: serde_json::Value,
}

impl Request {
    pub fn new(id: u64, method: &str, params: serde_json::Value) -> Self {
        Self {
            id,
            method: method.to_string(),
            params,
        }
    }
}

/// Authorize parameters (object form — the only shape the pool accepts).
#[derive(Debug, Clone, Serialize)]
pub struct AuthorizeParams {
    pub wallet: String,
    pub worker: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub agent: Option<String>,
}

/// Submit parameters for LuckyPool Pearl. DISCOVERED via live probe (Aug 2026):
/// the pool wants `{job_id, plain_proof}` where `plain_proof` is BASE64 of the
/// bincode-fixint-serialized `PlainProof` (gzip+base64 also accepted; hex is
/// rejected with "plain_proof not base64"). There is NO nonce field — Pearl is
/// Proof-of-Useful-Work, the proof IS the work. The pool decodes then validates
/// (e.g. rejects noise_rank < 128 with code 23).
#[derive(Debug, Clone, Serialize)]
pub struct SubmitParams {
    pub job_id: String,
    /// Base64 of the bincode-serialized PlainProof.
    pub plain_proof: String,
}

/// A pool `mining.notify` job.
#[derive(Debug, Clone, Deserialize)]
pub struct NotifyParams {
    #[serde(default)]
    pub cert_version: u32,
    #[serde(default)]
    pub diff: u64,
    #[serde(default)]
    pub height: i64,
    pub job_id: String,
    /// Incomplete block header bytes, hex-encoded.
    pub header: String,
    /// 256-bit PoW target, hex-encoded (big-endian).
    pub target: String,
}

/// A parsed inbound frame: either a result for one of our requests, or a
/// server-initiated notification.
#[derive(Debug, Clone)]
pub enum Inbound {
    /// Response to a request `id` — `ok` is the JSON `result`, `error` the
    /// pool's error object when present.
    Result {
        id: u64,
        ok: Option<serde_json::Value>,
        error: Option<PoolError>,
    },
    /// `mining.notify` — a new job.
    Notify(NotifyParams),
    /// `mining.set_difficulty` — a difficulty change (params is the raw value).
    SetDifficulty(serde_json::Value),
    /// Any other server method we don't specifically model.
    Other {
        method: String,
        params: serde_json::Value,
    },
}

/// Pool error object (`{"code":21,"msg":"job not found / stale"}`).
#[derive(Debug, Clone, Deserialize)]
pub struct PoolError {
    pub code: i64,
    #[serde(alias = "message")]
    pub msg: String,
}

impl std::fmt::Display for PoolError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "pool error {}: {}", self.code, self.msg)
    }
}

/// Parse one raw JSON line into an [`Inbound`].
pub fn parse_line(line: &str) -> Result<Inbound, serde_json::Error> {
    let v: serde_json::Value = serde_json::from_str(line)?;

    // Server notifications carry a `method`; some pools set id=null.
    if let Some(method) = v.get("method").and_then(|m| m.as_str()) {
        let params = v.get("params").cloned().unwrap_or(serde_json::Value::Null);
        return Ok(match method {
            "mining.notify" => {
                let np: NotifyParams = serde_json::from_value(params)?;
                Inbound::Notify(np)
            }
            "mining.set_difficulty" | "mining.set_target" => Inbound::SetDifficulty(params),
            other => Inbound::Other {
                method: other.to_string(),
                params,
            },
        });
    }

    // Otherwise it's a response to one of our requests.
    let id = v.get("id").and_then(|i| i.as_u64()).unwrap_or(0);
    let error = match v.get("error") {
        Some(serde_json::Value::Null) | None => None,
        Some(e) => serde_json::from_value::<PoolError>(e.clone()).ok(),
    };
    let ok = v.get("result").cloned();
    Ok(Inbound::Result { id, ok, error })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_authorize_result() {
        let line = r#"{"error":null,"id":1,"result":true,"type":"plain"}"#;
        match parse_line(line).unwrap() {
            Inbound::Result { id, ok, error } => {
                assert_eq!(id, 1);
                assert_eq!(ok, Some(serde_json::Value::Bool(true)));
                assert!(error.is_none());
            }
            _ => panic!("expected Result"),
        }
    }

    #[test]
    fn parses_error_result() {
        let line = r#"{"error":{"code":21,"msg":"job not found / stale"},"id":2,"result":null}"#;
        match parse_line(line).unwrap() {
            Inbound::Result { id, error, .. } => {
                assert_eq!(id, 2);
                let e = error.unwrap();
                assert_eq!(e.code, 21);
                assert!(e.msg.contains("stale"));
            }
            _ => panic!("expected Result"),
        }
    }

    #[test]
    fn parses_notify() {
        let line = r#"{"id":null,"method":"mining.notify","params":{"cert_version":3,"diff":262144,"header":"00000020aa","height":103799,"job_id":"535db0ce_262144","target":"0000000000003fffc0"}}"#;
        match parse_line(line).unwrap() {
            Inbound::Notify(n) => {
                assert_eq!(n.cert_version, 3);
                assert_eq!(n.diff, 262144);
                assert_eq!(n.height, 103799);
                assert_eq!(n.job_id, "535db0ce_262144");
                assert_eq!(n.header, "00000020aa");
                assert!(n.target.starts_with("0000000000003fff"));
            }
            _ => panic!("expected Notify"),
        }
    }

    #[test]
    fn authorize_params_serialize_object() {
        let p = AuthorizeParams {
            wallet: "prl1x".into(),
            worker: "t4".into(),
            agent: Some("akoya-rs/0.1".into()),
        };
        let v = serde_json::to_value(&p).unwrap();
        assert!(v.is_object());
        assert_eq!(v["wallet"], "prl1x");
        assert_eq!(v["worker"], "t4");
    }

    #[test]
    fn submit_params_shape() {
        let p = SubmitParams {
            job_id: "j".into(),
            plain_proof: "QUJD".into(),
        };
        let v = serde_json::to_value(&p).unwrap();
        assert_eq!(v["job_id"], "j");
        assert_eq!(v["plain_proof"], "QUJD");
        assert!(v.get("nonce").is_none());
    }
}
