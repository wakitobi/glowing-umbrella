//! Live connectivity check against a LuckyPool Pearl endpoint.
//!
//! Connects, authorizes, and prints the first few jobs, then exits. Run with:
//!
//! ```bash
//! AKOYA_STRATUM_HOST=pearl-sg1.lproute.com \
//! AKOYA_STRATUM_PORT=3360 \
//! AKOYA_POOL_WALLET=prl1... \
//! cargo run -p akoya-stratum --example connect
//! ```

use std::time::Duration;

use akoya_stratum::{Inbound, StratumClient, StratumConfig};

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new("info")),
        )
        .with_target(false)
        .init();

    let host = std::env::var("AKOYA_STRATUM_HOST").unwrap_or_else(|_| "pearl-sg1.lproute.com".into());
    let port: u16 = std::env::var("AKOYA_STRATUM_PORT")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(3360);
    let wallet = std::env::var("AKOYA_POOL_WALLET").expect("set AKOYA_POOL_WALLET");
    let worker = std::env::var("AKOYA_POOL_WORKER").unwrap_or_else(|_| "rig01".into());

    let mut cfg = StratumConfig::new(&host, port, &wallet);
    cfg.worker = worker;

    tracing::info!("connecting to {host}:{port} …");
    let mut client = StratumClient::connect(&cfg).await.expect("connect");
    tracing::info!("TLS connected — authorizing wallet={wallet} worker={}", cfg.worker);

    let jobs = client.authorize(&cfg).await.expect("authorize");
    tracing::info!("authorized ✓ ({} job(s) delivered during handshake)", jobs.len());
    for j in &jobs {
        tracing::info!(
            "job job_id={} height={} diff={} cert_version={} target={}…",
            j.job_id,
            j.height,
            j.diff,
            j.cert_version,
            &j.target[..j.target.len().min(20)]
        );
    }

    // Read a few more inbound frames (jobs / difficulty) for ~10s, then exit.
    let mut seen = jobs.len();
    let deadline = tokio::time::Instant::now() + Duration::from_secs(12);
    while tokio::time::Instant::now() < deadline && seen < 5 {
        match tokio::time::timeout(Duration::from_secs(12), client.next_inbound()).await {
            Ok(Ok(Inbound::Notify(j))) => {
                seen += 1;
                tracing::info!(
                    "job job_id={} height={} diff={} target={}…",
                    j.job_id,
                    j.height,
                    j.diff,
                    &j.target[..j.target.len().min(20)]
                );
            }
            Ok(Ok(Inbound::SetDifficulty(v))) => tracing::info!("set_difficulty {v}"),
            Ok(Ok(Inbound::Result { id, ok, error })) => {
                tracing::info!("result id={id} ok={ok:?} error={error:?}")
            }
            Ok(Ok(Inbound::Other { method, .. })) => tracing::info!("other method={method}"),
            Ok(Err(e)) => {
                tracing::error!("stream error: {e}");
                break;
            }
            Err(_) => break, // timeout
        }
    }

    tracing::info!("done — connectivity + authorize + job delivery verified");
}
