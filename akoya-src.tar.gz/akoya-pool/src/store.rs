//! Persistent session state (port of `Akoya.Pool.SessionStore`).
//!
//! On-disk JSON, written atomically via temp + rename. Default path
//! `$HOME/.akoya/session.json`. Enough to Resume a MiningStream after a
//! restart without burning a fresh registration.

use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

const MINER_ID_HEX_LEN: usize = 32; // 16 bytes hex-encoded
const SESSION_TOKEN_MAX: usize = 4096;
const IDENTITY_KEY_MAX: usize = 4096;

/// Immutable session record persisted across restarts.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SessionRecord {
    pub miner_id_hex: String,
    pub session_token: String,
    pub identity_key: String,
    pub pool_endpoint: String,
    pub last_seen_utc: String,
}

impl SessionRecord {
    /// Returns `None` if valid, else an error message (mirrors C# `Validate`).
    pub fn validate(&self) -> Option<String> {
        if self.miner_id_hex.len() != MINER_ID_HEX_LEN {
            return Some(format!(
                "miner_id_hex must be {MINER_ID_HEX_LEN} hex chars (got {})",
                self.miner_id_hex.len()
            ));
        }
        if !self.miner_id_hex.chars().all(|c| c.is_ascii_hexdigit()) {
            return Some("miner_id_hex contains non-hex chars".into());
        }
        if self.session_token.len() > SESSION_TOKEN_MAX {
            return Some("session_token exceeds max length".into());
        }
        if self.identity_key.is_empty() {
            return Some("identity_key is empty".into());
        }
        if self.identity_key.len() > IDENTITY_KEY_MAX {
            return Some("identity_key exceeds max length".into());
        }
        if self.pool_endpoint.is_empty() {
            return Some("pool_endpoint is empty".into());
        }
        if self.last_seen_utc.is_empty() {
            return Some("last_seen_utc is empty".into());
        }
        None
    }
}

/// File-backed session persistence.
pub struct SessionStore {
    path: PathBuf,
}

impl SessionStore {
    pub fn new(path: impl Into<PathBuf>) -> Self {
        Self { path: path.into() }
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Load the session if present, parseable, from the same pool, and valid.
    /// Returns `None` on any of: missing, corrupt, wrong-pool, invalid.
    pub fn try_load(&self, current_pool_endpoint: &str) -> Option<SessionRecord> {
        let bytes = std::fs::read(&self.path).ok()?;
        let rec: SessionRecord = serde_json::from_slice(&bytes).ok()?;
        if !rec.pool_endpoint.eq_ignore_ascii_case(current_pool_endpoint) {
            tracing::warn!(
                "session: stored pool {} differs from current {} — discarding",
                rec.pool_endpoint,
                current_pool_endpoint
            );
            return None;
        }
        if let Some(err) = rec.validate() {
            tracing::warn!("session: stored record invalid ({err}) — discarding");
            return None;
        }
        Some(rec)
    }

    /// Atomically persist the record (temp file + rename). Errors on I/O
    /// failure because losing the record breaks worker continuity.
    pub fn save(&self, rec: &SessionRecord) -> std::io::Result<()> {
        if let Some(err) = rec.validate() {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                format!("session record invalid: {err}"),
            ));
        }
        if let Some(dir) = self.path.parent() {
            std::fs::create_dir_all(dir)?;
        }
        let tmp = self.path.with_extension("tmp");
        let json = serde_json::to_vec_pretty(rec)
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
        std::fs::write(&tmp, &json)?;
        set_owner_only(&tmp);
        std::fs::rename(&tmp, &self.path)?;
        Ok(())
    }

    /// Delete the session file (e.g. after "session expired"). No-op if absent.
    pub fn delete(&self) {
        let _ = std::fs::remove_file(&self.path);
    }

    /// Drop only the session token, preserving miner_id + identity_key, so
    /// the next start re-registers (reclaiming the same miner_id).
    pub fn clear_session_token(&self) {
        if let Ok(bytes) = std::fs::read(&self.path) {
            if let Ok(mut rec) = serde_json::from_slice::<SessionRecord>(&bytes) {
                rec.session_token = String::new();
                // session_token may now be empty, which validate() allows.
                let _ = self.save(&rec);
            }
        }
    }
}

#[cfg(unix)]
fn set_owner_only(path: &Path) {
    use std::os::unix::fs::PermissionsExt;
    let _ = std::fs::set_permissions(path, std::fs::Permissions::from_mode(0o600));
}

#[cfg(not(unix))]
fn set_owner_only(_path: &Path) {}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> SessionRecord {
        SessionRecord {
            miner_id_hex: "0123456789abcdef0123456789abcdef".into(),
            session_token: "tok".into(),
            identity_key: "idk".into(),
            pool_endpoint: "https://pool-v2.akoyapool.com:443".into(),
            last_seen_utc: "2024-01-01T00:00:00Z".into(),
        }
    }

    #[test]
    fn valid_record_passes() {
        assert!(sample().validate().is_none());
    }

    #[test]
    fn short_miner_id_rejected() {
        let mut r = sample();
        r.miner_id_hex = "abc".into();
        assert!(r.validate().is_some());
    }

    #[test]
    fn non_hex_miner_id_rejected() {
        let mut r = sample();
        r.miner_id_hex = "zz23456789abcdef0123456789abcdef".into();
        assert!(r.validate().is_some());
    }

    #[test]
    fn save_load_roundtrip() {
        let dir = std::env::temp_dir().join(format!("akoya-sess-{}", std::process::id()));
        let path = dir.join("session.json");
        let store = SessionStore::new(&path);
        let rec = sample();
        store.save(&rec).unwrap();
        let loaded = store.try_load(&rec.pool_endpoint).unwrap();
        assert_eq!(loaded.miner_id_hex, rec.miner_id_hex);
        assert_eq!(loaded.identity_key, rec.identity_key);
        store.delete();
        assert!(store.try_load(&rec.pool_endpoint).is_none());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn wrong_pool_discarded() {
        let dir = std::env::temp_dir().join(format!("akoya-sess2-{}", std::process::id()));
        let path = dir.join("session.json");
        let store = SessionStore::new(&path);
        let rec = sample();
        store.save(&rec).unwrap();
        assert!(store.try_load("https://other:443").is_none());
        let _ = std::fs::remove_dir_all(&dir);
    }

    #[test]
    fn clear_token_keeps_identity() {
        let dir = std::env::temp_dir().join(format!("akoya-sess3-{}", std::process::id()));
        let path = dir.join("session.json");
        let store = SessionStore::new(&path);
        store.save(&sample()).unwrap();
        store.clear_session_token();
        let bytes = std::fs::read(&path).unwrap();
        let rec: SessionRecord = serde_json::from_slice(&bytes).unwrap();
        assert_eq!(rec.session_token, "");
        assert_eq!(rec.identity_key, "idk");
        let _ = std::fs::remove_dir_all(&dir);
    }
}
