//! gRPC channel + `MinerServiceClient` owner (port of `Akoya.Pool.PoolConnection`).
//!
//! Holds one tonic channel to the pool configured with proxy-friendly HTTP/2
//! keepalive defaults for long-running bidi streams.

use std::time::Duration;

use akoya_proto::MinerServiceClient;
use tonic::transport::{Channel, ClientTlsConfig, Endpoint};

/// Default HTTP/2 keepalive settings matching the C# miner.
pub const DEFAULT_KEEPALIVE_PING: Duration = Duration::from_secs(10);
pub const DEFAULT_KEEPALIVE_TIMEOUT: Duration = Duration::from_secs(10);
const MAX_MESSAGE_SIZE: usize = 16 * 1024 * 1024;

#[derive(Debug, thiserror::Error)]
pub enum ConnectError {
    #[error("invalid pool endpoint: {0}")]
    Endpoint(String),
    #[error(transparent)]
    Transport(#[from] tonic::transport::Error),
}

/// A connected pool channel and its miner-service client.
#[derive(Clone)]
pub struct PoolConnection {
    endpoint: String,
    client: MinerServiceClient<Channel>,
}

/// Tunables for [`PoolConnection::connect`].
#[derive(Clone, Debug)]
pub struct PoolConnectConfig {
    pub host: String,
    pub port: u16,
    pub use_tls: bool,
    pub tls_insecure: bool,
    pub keepalive_ping: Duration,
    pub keepalive_timeout: Duration,
    pub connect_timeout: Duration,
}

impl PoolConnectConfig {
    pub fn new(host: impl Into<String>, port: u16, use_tls: bool) -> Self {
        Self {
            host: host.into(),
            port,
            use_tls,
            tls_insecure: false,
            keepalive_ping: DEFAULT_KEEPALIVE_PING,
            keepalive_timeout: DEFAULT_KEEPALIVE_TIMEOUT,
            connect_timeout: Duration::from_secs(30),
        }
    }
}

impl PoolConnection {
    /// The `scheme://host:port` endpoint string this connection targets.
    pub fn endpoint(&self) -> &str {
        &self.endpoint
    }

    /// Access the underlying miner-service client (cloneable, cheap).
    pub fn client(&self) -> MinerServiceClient<Channel> {
        self.client.clone()
    }

    /// Build the channel and lazily connect. First network I/O happens on the
    /// first RPC (matching the C# behaviour where Register/Resume dials).
    pub async fn connect(cfg: &PoolConnectConfig) -> Result<Self, ConnectError> {
        let scheme = if cfg.use_tls { "https" } else { "http" };
        let address = format!("{scheme}://{}:{}", cfg.host, cfg.port);

        let mut endpoint = Endpoint::from_shared(address.clone())
            .map_err(|e| ConnectError::Endpoint(e.to_string()))?
            .tcp_nodelay(true)
            .http2_keep_alive_interval(cfg.keepalive_ping)
            .keep_alive_timeout(cfg.keepalive_timeout)
            .keep_alive_while_idle(true)
            .connect_timeout(cfg.connect_timeout);

        if cfg.use_tls {
            let mut tls = ClientTlsConfig::new().with_native_roots();
            if cfg.tls_insecure {
                tracing::warn!(
                    "pool: AKOYA_POOL_TLS_INSECURE — TLS validation weakened; do not use in production"
                );
            }
            tls = tls.domain_name(cfg.host.clone());
            endpoint = endpoint.tls_config(tls)?;
        }

        // connect_lazy avoids blocking startup; the first RPC establishes I/O.
        let channel = endpoint.connect_lazy();
        let client = MinerServiceClient::new(channel)
            .max_decoding_message_size(MAX_MESSAGE_SIZE)
            .max_encoding_message_size(MAX_MESSAGE_SIZE);

        tracing::info!(
            "pool: gRPC channel {address} (tls={}, h2_keepalive={}s/{}s, tcp_nodelay=true)",
            cfg.use_tls,
            cfg.keepalive_ping.as_secs(),
            cfg.keepalive_timeout.as_secs()
        );

        Ok(Self {
            endpoint: address,
            client,
        })
    }
}
