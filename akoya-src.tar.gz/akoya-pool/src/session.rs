//! Logical pool session (port of `Akoya.Pool.MiningSession`).
//!
//! Owns Register/Resume orchestration, the bidi `MiningStream`, an outbound
//! event queue any task can enqueue to, and inbound dispatch to callbacks.
//! A stream-liveness watchdog forces a reconnect if the pool goes silent.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

use akoya_proto::v2::{
    miner_event, pool_event, AuthEvent, DifficultyAdjust, GpuCard, JobAssignment, MinerEvent,
    PingEvent, PoolError, PongEvent, RegisterRequest, ResumeRequest, ResumeResponse, ShareResult,
};
use tokio::sync::mpsc;
use tokio_stream::wrappers::ReceiverStream;
use tokio_stream::StreamExt;

use crate::connection::PoolConnection;
use crate::store::{SessionRecord, SessionStore};

/// Unary deadline for Register / Resume (matches C# `RegisterResumeDeadline`).
pub const REGISTER_RESUME_DEADLINE: Duration = Duration::from_secs(30);

#[derive(Debug, thiserror::Error)]
pub enum SessionError {
    #[error("pool unreachable connecting to {endpoint}: {source}")]
    Unreachable {
        endpoint: String,
        #[source]
        source: tonic::Status,
    },
    #[error("register rejected by pool: {0}")]
    RegisterRejected(String),
    #[error("stream idle: {0}")]
    StreamIdle(String),
    #[error("not connected: call connect() first")]
    NotConnected,
    #[error(transparent)]
    Rpc(#[from] tonic::Status),
}

/// Everything needed to Register or Resume.
#[derive(Clone, Debug)]
pub struct SessionIdentity {
    pub wallet_address: String,
    pub worker_name: String,
    pub miner_version: String,
    pub git_sha: String,
    pub k: u32,
    pub claimed_total_hashrate: f64,
    pub gpu_cards: Vec<GpuCard>,
}

/// Inbound event callbacks. Boxed async closures invoked on the reader task.
#[derive(Default)]
pub struct MiningSessionCallbacks {
    #[allow(clippy::type_complexity)]
    pub on_job: Option<Box<dyn Fn(JobAssignment) + Send + Sync>>,
    #[allow(clippy::type_complexity)]
    pub on_share_result: Option<Box<dyn Fn(ShareResult) + Send + Sync>>,
    #[allow(clippy::type_complexity)]
    pub on_vardiff: Option<Box<dyn Fn(DifficultyAdjust) + Send + Sync>>,
    #[allow(clippy::type_complexity)]
    pub on_pong: Option<Box<dyn Fn(PongEvent) + Send + Sync>>,
    #[allow(clippy::type_complexity)]
    pub on_error: Option<Box<dyn Fn(PoolError) + Send + Sync>>,
}

/// Monotonic sequence counter for outbound events.
#[derive(Default)]
struct SequenceCounter(AtomicU64);
impl SequenceCounter {
    fn next(&self) -> u64 {
        self.0.fetch_add(1, Ordering::SeqCst) + 1
    }
}

/// The logical session over one pool connection.
pub struct MiningSession {
    pool: PoolConnection,
    store: Arc<SessionStore>,
    seq: SequenceCounter,
    miner_id: Option<Vec<u8>>,
    session_token: Option<String>,
    identity_key: Option<String>,
    outbound_tx: Option<mpsc::Sender<MinerEvent>>,
}

impl MiningSession {
    pub fn new(pool: PoolConnection, store: Arc<SessionStore>) -> Self {
        Self {
            pool,
            store,
            seq: SequenceCounter::default(),
            miner_id: None,
            session_token: None,
            identity_key: None,
            outbound_tx: None,
        }
    }

    pub fn miner_id(&self) -> Option<&[u8]> {
        self.miner_id.as_deref()
    }

    pub fn session_token(&self) -> Option<&str> {
        self.session_token.as_deref()
    }

    /// Establish a logical session, preferring Resume when a stored token
    /// exists and falling back to Register. Returns the initial job on the
    /// Resume path, or `None` when Register was used (first job arrives on
    /// the stream).
    pub async fn connect(
        &mut self,
        identity: &SessionIdentity,
    ) -> Result<Option<ResumeResponse>, SessionError> {
        let stored = self.store.try_load(self.pool.endpoint());
        let mut initial_job = None;

        if let Some(rec) = &stored {
            match self.try_resume(rec).await {
                Some(resp) if resp.success => {
                    self.miner_id = Some(hex::decode(&rec.miner_id_hex).unwrap_or_default());
                    self.session_token = Some(resp.session_token_refreshed.clone());
                    self.identity_key = Some(rec.identity_key.clone());
                    self.persist();
                    initial_job = Some(resp);
                }
                other => {
                    tracing::info!(
                        "session: Resume failed ({}) — falling back to Register",
                        other
                            .and_then(|r| Some(r.error_message))
                            .unwrap_or_else(|| "no response".into())
                    );
                    self.store.delete();
                }
            }
        }

        if self.session_token.is_none() {
            self.register(identity, stored.as_ref().map(|r| r.identity_key.clone()))
                .await?;
        }

        Ok(initial_job)
    }

    async fn try_resume(&mut self, stored: &SessionRecord) -> Option<ResumeResponse> {
        let mut client = self.pool.client();
        let req = ResumeRequest {
            miner_id: hex::decode(&stored.miner_id_hex).unwrap_or_default(),
            session_token: stored.session_token.clone(),
            last_seen_job_id: Vec::new(),
        };
        let mut request = tonic::Request::new(req);
        request.set_timeout(REGISTER_RESUME_DEADLINE);
        match client.resume(request).await {
            Ok(resp) => Some(resp.into_inner()),
            Err(status) => {
                tracing::info!("session: Resume RPC failed ({}): {}", status.code(), status.message());
                None
            }
        }
    }

    async fn register(
        &mut self,
        id: &SessionIdentity,
        reclaim_identity_key: Option<String>,
    ) -> Result<(), SessionError> {
        let mut client = self.pool.client();
        let req = RegisterRequest {
            miner_id: Vec::new(),
            identity_key: reclaim_identity_key.unwrap_or_default(),
            wallet_address: id.wallet_address.clone(),
            worker_name: id.worker_name.clone(),
            gpu_cards: id.gpu_cards.clone(),
            claimed_total_hashrate: id.claimed_total_hashrate,
            miner_version: id.miner_version.clone(),
            git_sha: id.git_sha.clone(),
            protocol_version: 2,
            k: id.k,
        };
        tracing::info!(
            "session: Register wallet={} worker={} gpus={}",
            id.wallet_address,
            id.worker_name,
            id.gpu_cards.len()
        );

        let mut request = tonic::Request::new(req);
        request.set_timeout(REGISTER_RESUME_DEADLINE);
        let resp = match client.register(request).await {
            Ok(r) => r.into_inner(),
            Err(status)
                if matches!(
                    status.code(),
                    tonic::Code::DeadlineExceeded | tonic::Code::Unavailable
                ) =>
            {
                return Err(SessionError::Unreachable {
                    endpoint: self.pool.endpoint().to_string(),
                    source: status,
                });
            }
            Err(status) => return Err(SessionError::Rpc(status)),
        };

        if !resp.success {
            return Err(SessionError::RegisterRejected(resp.error_message));
        }

        let miner_id_hex = hex::encode(&resp.miner_id);
        self.miner_id = Some(resp.miner_id);
        self.session_token = Some(resp.session_token);
        self.identity_key = Some(resp.identity_key);
        self.persist_with_hex(&miner_id_hex);
        tracing::info!(
            "session: Registered miner_id={} initial_nbits={}",
            miner_id_hex,
            resp.initial_difficulty_nbits
        );
        Ok(())
    }

    /// Enqueue an event for sending. Assigns `seq` automatically.
    pub async fn enqueue(&self, mut ev: MinerEvent) -> Result<(), SessionError> {
        ev.seq = self.seq.next();
        let tx = self.outbound_tx.as_ref().ok_or(SessionError::NotConnected)?;
        tx.send(ev).await.map_err(|_| SessionError::NotConnected)
    }

    /// Open the bidi MiningStream and pump inbound/outbound until the server
    /// closes it, a fatal PoolError arrives, or the liveness watchdog trips.
    pub async fn run_stream(
        &mut self,
        callbacks: MiningSessionCallbacks,
        stream_watchdog: Duration,
    ) -> Result<(), SessionError> {
        let miner_id = self.miner_id.clone().ok_or(SessionError::NotConnected)?;
        let session_token = self.session_token.clone().ok_or(SessionError::NotConnected)?;

        // Outbound channel (bounded so a runaway producer can't OOM us).
        let (tx, rx) = mpsc::channel::<MinerEvent>(1024);
        self.outbound_tx = Some(tx.clone());

        // First frame MUST be the AuthEvent.
        let auth = MinerEvent {
            seq: self.seq.next(),
            event: Some(miner_event::Event::Auth(AuthEvent {
                miner_id,
                session_token,
                register: None,
            })),
        };
        // Prime the outbound stream with auth before anything else.
        tx.send(auth)
            .await
            .map_err(|_| SessionError::NotConnected)?;

        let outbound = ReceiverStream::new(rx);
        let mut client = self.pool.client();
        let response = client.mining_stream(outbound).await?;
        let mut inbound = response.into_inner();

        let watchdog = tokio::time::sleep(stream_watchdog);
        tokio::pin!(watchdog);

        loop {
            tokio::select! {
                biased;
                _ = &mut watchdog, if !stream_watchdog.is_zero() => {
                    return Err(SessionError::StreamIdle(format!(
                        "stream-liveness watchdog tripped after {}s without inbound traffic",
                        stream_watchdog.as_secs()
                    )));
                }
                item = inbound.next() => {
                    match item {
                        Some(Ok(ev)) => {
                            // Any inbound frame resets the watchdog.
                            watchdog.as_mut().reset(tokio::time::Instant::now() + stream_watchdog);
                            if self.dispatch(&callbacks, ev) {
                                return Ok(()); // fatal error or reconnect hint
                            }
                        }
                        Some(Err(status)) => {
                            tracing::info!(
                                "session: stream ended ({}): {}",
                                status.code(),
                                status.message()
                            );
                            return Ok(());
                        }
                        None => {
                            tracing::info!("session: server closed stream");
                            return Ok(());
                        }
                    }
                }
            }
        }
    }

    /// Returns true if the stream should be surrendered (fatal error / reconnect).
    fn dispatch(&self, cb: &MiningSessionCallbacks, ev: akoya_proto::v2::PoolEvent) -> bool {
        let Some(event) = ev.event else {
            return false;
        };
        match event {
            pool_event::Event::Job(job) => {
                if let Some(f) = &cb.on_job {
                    f(job);
                }
                false
            }
            pool_event::Event::ShareResult(sr) => {
                if let Some(f) = &cb.on_share_result {
                    f(sr);
                }
                false
            }
            pool_event::Event::Vardiff(v) => {
                if let Some(f) = &cb.on_vardiff {
                    f(v);
                }
                false
            }
            pool_event::Event::Pong(p) => {
                if let Some(f) = &cb.on_pong {
                    f(p);
                }
                false
            }
            pool_event::Event::Error(e) => {
                let fatal = e.fatal;
                if fatal {
                    tracing::error!("session: fatal PoolError {}: {}", e.code, e.message);
                }
                if let Some(f) = &cb.on_error {
                    f(e);
                }
                fatal
            }
            pool_event::Event::Reconnect(hint) => {
                tracing::info!(
                    "session: server ReconnectHint wait={}s reason={}",
                    hint.wait_seconds,
                    hint.reason
                );
                true
            }
        }
    }

    /// Build a Ping event (helper for the caller's keepalive pump).
    pub fn make_ping(timestamp: i64) -> MinerEvent {
        MinerEvent {
            seq: 0, // set by enqueue()
            event: Some(miner_event::Event::Ping(PingEvent { timestamp })),
        }
    }

    fn persist(&self) {
        if let Some(id) = &self.miner_id {
            let hex = hex::encode(id);
            self.persist_with_hex(&hex);
        }
    }

    fn persist_with_hex(&self, miner_id_hex: &str) {
        let rec = SessionRecord {
            miner_id_hex: miner_id_hex.to_string(),
            session_token: self.session_token.clone().unwrap_or_default(),
            identity_key: self.identity_key.clone().unwrap_or_default(),
            pool_endpoint: self.pool.endpoint().to_string(),
            last_seen_utc: now_iso8601(),
        };
        if let Err(e) = self.store.save(&rec) {
            tracing::warn!("session: persist failed ({e}) — restart will re-Register");
        }
    }
}

/// Minimal RFC3339-ish UTC timestamp without pulling in `chrono`.
fn now_iso8601() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs())
        .unwrap_or(0);
    // Store as epoch-seconds marker; only used informationally.
    format!("epoch:{secs}")
}
