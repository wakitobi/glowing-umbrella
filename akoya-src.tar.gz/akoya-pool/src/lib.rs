//! Akoya pool V2 client: connection, session state machine, and persistence.

pub mod connection;
pub mod session;
pub mod store;

pub use connection::{ConnectError, PoolConnectConfig, PoolConnection};
pub use session::{
    MiningSession, MiningSessionCallbacks, SessionError, SessionIdentity, REGISTER_RESUME_DEADLINE,
};
pub use store::{SessionRecord, SessionStore};
