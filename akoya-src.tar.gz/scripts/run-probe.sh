#!/usr/bin/env bash
# run-probe.sh — build (if needed) and run the LuckyPool submit-schema probe on
# the T4 box. Reads pool creds from env or a .env beside this script.
#
# Usage:
#   AKOYA_POOL_WALLET=prl1yourwallet \
#   AKOYA_STRATUM_HOST=pearl-sg1.lproute.com AKOYA_STRATUM_PORT=3360 \
#   bash run-probe.sh
#
# Or drop a .env next to this file with those vars, then just: bash run-probe.sh
set -uo pipefail
cd "$(dirname "$0")/.."

# Load .env if present (KEY=VALUE lines).
if [ -f .env ]; then
  set -a; . ./.env; set +a
fi

: "${AKOYA_POOL_WALLET:?set AKOYA_POOL_WALLET (your prl1... address)}"
: "${AKOYA_STRATUM_HOST:=pearl-sg1.lproute.com}"
: "${AKOYA_STRATUM_PORT:=3360}"
: "${AKOYA_POOL_WORKER:=probe01}"
export AKOYA_POOL_WALLET AKOYA_STRATUM_HOST AKOYA_STRATUM_PORT AKOYA_POOL_WORKER
export AKOYA_LOG_LEVEL="${AKOYA_LOG_LEVEL:-info}"

BIN=./target/release/akoya-miner
if [ ! -x "$BIN" ] && [ ! -x "$BIN.exe" ]; then
  echo ">> building akoya-miner (release)..."
  cargo build --release -p akoya-miner || { echo "build failed"; exit 1; }
fi
[ -x "$BIN.exe" ] && BIN="$BIN.exe"

echo ">> probing $AKOYA_STRATUM_HOST:$AKOYA_STRATUM_PORT as $AKOYA_POOL_WALLET.$AKOYA_POOL_WORKER"
echo ">> each candidate prints: probe[<shape>]: RESULT code=<n> msg=\"...\""
echo ">> WIN = the shape whose msg changes from 'must be an object'/'stale' to 'low difficulty'/'invalid share'"
echo "======================================================================"
"$BIN" probe-submit
