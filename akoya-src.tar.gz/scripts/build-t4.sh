#!/usr/bin/env bash
# build-t4.sh — one-shot build of the Pearl private miner on a Tesla T4 box.
#
# Does everything:
#   1. checks toolchain (nvcc, gcc, git, cargo — installs rustup if missing)
#   2. clones akoya-miner + CUTLASS submodule, builds libpearl_gemm_capi.so (sm_75)
#   3. builds the akoya-miner-rs Rust host (release)
#   4. runs selftest to confirm the T4 loads the kernel
#
# Usage:
#   AKOYA_POOL_WALLET=prl1yourwallet bash build-t4.sh
#
# Run this FROM the akoya-miner-rs source dir (where you extracted akoya-src.tar.gz),
# or set MINER_SRC=/path/to/akoya-miner-rs.
set -uo pipefail

MINER_SRC="${MINER_SRC:-$(cd "$(dirname "$0")/.." && pwd)}"   # scripts/ -> workspace root
AKOYA_UPSTREAM="${AKOYA_UPSTREAM:-$HOME/akoya-miner}"
ARCH="${PEARL_GEMM_ARCH:-turing}"   # T4 = Turing = sm_75
: "${AKOYA_POOL_WALLET:?set AKOYA_POOL_WALLET (your prl1... address) before running}"

say() { printf '\n\033[1;36m>> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mFAIL: %s\033[0m\n' "$*"; exit 1; }

# ---------------------------------------------------------------------------
say "1/4  toolchain check"
command -v nvcc  >/dev/null || die "nvcc not found — install CUDA Toolkit 12.4+ (Colab T4 has it; on Ubuntu: apt-get install -y nvidia-cuda-toolkit)"
command -v gcc   >/dev/null || die "gcc not found — apt-get install -y build-essential"
command -v git   >/dev/null || die "git not found — apt-get install -y git"
echo "nvcc: $(nvcc --version | tail -1)"

if ! command -v cargo >/dev/null; then
  say "cargo missing — installing rustup (stable)"
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y || die "rustup install failed"
  # shellcheck disable=SC1090
  . "$HOME/.cargo/env"
fi
# ensure a modern cargo (edition2024 deps need >= 1.85)
rustup update stable >/dev/null 2>&1 || true
rustup default stable >/dev/null 2>&1 || true
echo "cargo: $(cargo --version)"

# ---------------------------------------------------------------------------
say "2/4  build native pearl-gemm lib (PEARL_GEMM_ARCH=$ARCH)"
if [ ! -d "$AKOYA_UPSTREAM" ]; then
  git clone --recurse-submodules https://github.com/akoyapool/akoya-miner "$AKOYA_UPSTREAM" \
    || die "clone failed"
fi
git -C "$AKOYA_UPSTREAM" submodule update --init --depth 1 \
  native/pearl-gemm/third_party/cutlass || die "cutlass submodule init failed"

make -C "$AKOYA_UPSTREAM/native/pearl-gemm/csrc/capi" PEARL_GEMM_ARCH="$ARCH" \
  || die "pearl-gemm build failed (check nvcc + cutlass submodule)"

GEMM_LIB="$(find "$AKOYA_UPSTREAM/native/pearl-gemm" -name 'libpearl_gemm_capi.so' | head -1)"
[ -n "$GEMM_LIB" ] || die "libpearl_gemm_capi.so not produced"
echo "built: $GEMM_LIB"

# ---------------------------------------------------------------------------
say "3/4  build the Rust host (release)"
cd "$MINER_SRC" || die "MINER_SRC not found: $MINER_SRC"
rm -f Cargo.lock          # avoid v4-lockfile error on older cargo
cargo build --release -p akoya-miner || die "cargo build failed"
BIN="$MINER_SRC/target/release/akoya-miner"
[ -x "$BIN" ] || BIN="$BIN.exe"
[ -x "$BIN" ] || die "miner binary not found after build"
echo "built: $BIN"

# ---------------------------------------------------------------------------
say "4/4  selftest (confirm the T4 loads the kernel)"
export AKOYA_PEARL_GEMM_LIB="$GEMM_LIB"
echo "AKOYA_PEARL_GEMM_LIB=$AKOYA_PEARL_GEMM_LIB"
"$BIN" selftest || true    # selftest exits non-zero if the gRPC pool probe fails; that's expected in stratum mode

cat <<EOF

======================================================================
Done. Look at the selftest JSON above:
  pearl_gemm_lib: pass  profile=$ARCH   <- kernel loaded
  gpu:            pass  Tesla T4 sm_75  <- your card matches
  (pool_tcp: fail on pool-v2.akoyapool.com is a FALSE alarm in stratum mode)

To keep this env for the next step, in THIS shell run:
  export AKOYA_PEARL_GEMM_LIB="$GEMM_LIB"

Paste the selftest JSON back so we can wire + run the device solve loop.
======================================================================
EOF
