#!/usr/bin/env bash
# deploy-t4.sh — build + run the Akoya Rust miner on a Linux Tesla T4 box.
#
# What it does, in order:
#   1. Ensures a Rust toolchain (installs rustup if missing).
#   2. Clones the upstream akoya-miner repo (for the native pearl-gemm CUDA
#      kernels + CUTLASS submodule) unless already present.
#   3. Builds libpearl_gemm_capi.so with the Turing (sm_75) profile — the T4.
#   4. Builds THIS Rust workspace in release.
#   5. Prints the exact run command (or runs it if RUN=1).
#
# Requirements on the box (the script checks and reports missing ones):
#   - NVIDIA driver + CUDA Toolkit 12.4+ (nvcc)   → for the native lib
#   - build-essential / clang, make, git, python3 → kernel codegen + build
#   - curl                                        → rustup bootstrap
#
# Usage:
#   chmod +x scripts/deploy-t4.sh
#   AKOYA_POOL_WALLET=prl1... ./scripts/deploy-t4.sh            # build only
#   AKOYA_POOL_WALLET=prl1... RUN=1 ./scripts/deploy-t4.sh      # build + mine
#
# Env knobs:
#   PEARL_GEMM_ARCH   default "turing" (T4 = sm_75). Override for other cards.
#   UPSTREAM_DIR      where to clone akoya-miner (default ../akoya-miner-upstream)
#   AKOYA_STRATUM_HOST/PORT   pool endpoint (default pearl-sg1.lproute.com:3360)
#   AKOYA_POOL_WORKER         worker label (default: hostname)
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # workspace root
ARCH="${PEARL_GEMM_ARCH:-turing}"
UPSTREAM_DIR="${UPSTREAM_DIR:-$HERE/../akoya-miner-upstream}"
POOL_HOST="${AKOYA_STRATUM_HOST:-pearl-sg1.lproute.com}"
POOL_PORT="${AKOYA_STRATUM_PORT:-3360}"
WORKER="${AKOYA_POOL_WORKER:-$(hostname)}"

log()  { printf '\033[1;36m[deploy]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[deploy]\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31m[deploy]\033[0m %s\n' "$*" >&2; exit 1; }

# ── 0. preflight ──────────────────────────────────────────────────────────
log "checking prerequisites…"
MISSING=()
for t in git make python3 curl; do command -v "$t" >/dev/null || MISSING+=("$t"); done
command -v nvcc >/dev/null || MISSING+=("nvcc (CUDA Toolkit 12.4+)")
command -v cc  >/dev/null || command -v clang >/dev/null || MISSING+=("a C compiler (build-essential/clang)")
if [ "${#MISSING[@]}" -gt 0 ]; then
  warn "missing tools: ${MISSING[*]}"
  warn "install them, e.g.:  sudo apt update && sudo apt install -y build-essential clang git python3 curl"
  warn "and the CUDA Toolkit from https://developer.nvidia.com/cuda-downloads"
  die  "cannot continue without the toolchain above"
fi

if command -v nvidia-smi >/dev/null; then
  log "GPU(s):"; nvidia-smi --query-gpu=name,compute_cap,memory.total --format=csv,noheader | sed 's/^/  /'
else
  warn "nvidia-smi not found — proceeding, but verify the driver is installed"
fi

# ── 1. rust toolchain ─────────────────────────────────────────────────────
if ! command -v cargo >/dev/null; then
  log "installing rustup (stable, minimal)…"
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
  # shellcheck disable=SC1091
  . "$HOME/.cargo/env"
fi
log "rust: $(rustc --version)"

# ── 2. clone upstream for the native CUDA kernels ─────────────────────────
if [ ! -d "$UPSTREAM_DIR/.git" ]; then
  log "cloning akoya-miner upstream (native pearl-gemm) → $UPSTREAM_DIR"
  git clone --recurse-submodules https://github.com/akoyapool/akoya-miner.git "$UPSTREAM_DIR"
else
  log "upstream present at $UPSTREAM_DIR"
fi
log "ensuring CUTLASS submodule…"
git -C "$UPSTREAM_DIR" submodule update --init --depth 1 native/pearl-gemm/third_party/cutlass

# ── 3. build the native CUDA library (Turing / sm_75) ─────────────────────
log "building libpearl_gemm_capi.so (PEARL_GEMM_ARCH=$ARCH)…"
make -C "$UPSTREAM_DIR/native/pearl-gemm/csrc/capi" PEARL_GEMM_ARCH="$ARCH"

GEMM_LIB="$(find "$UPSTREAM_DIR/native/pearl-gemm" -name 'libpearl_gemm_capi.so' | head -1)"
[ -n "$GEMM_LIB" ] || die "native build finished but libpearl_gemm_capi.so not found"
log "native lib: $GEMM_LIB"

# ── 4. build this Rust workspace ──────────────────────────────────────────
log "building akoya-miner-rs (release)…"
( cd "$HERE" && cargo build --release )
BIN="$HERE/target/release/akoya-miner"
[ -x "$BIN" ] || die "cargo build did not produce $BIN"
log "miner binary: $BIN"

# ── 5. run or print the command ───────────────────────────────────────────
: "${AKOYA_POOL_WALLET:?set AKOYA_POOL_WALLET=prl1... before running}"

RUN_ENV=(
  "AKOYA_PEARL_GEMM_LIB=$GEMM_LIB"
  "AKOYA_STRATUM_HOST=$POOL_HOST"
  "AKOYA_STRATUM_PORT=$POOL_PORT"
  "AKOYA_POOL_WALLET=$AKOYA_POOL_WALLET"
  "AKOYA_POOL_WORKER=$WORKER"
)

log "self-test:"
env "${RUN_ENV[@]}" "$BIN" selftest || warn "selftest reported failures (see JSON above)"

echo
log "to mine (Stratum / LuckyPool):"
echo "  ${RUN_ENV[*]} \\"
echo "    $BIN stratum"
echo

if [ "${RUN:-0}" = "1" ]; then
  log "starting miner (stratum)…"
  exec env "${RUN_ENV[@]}" "$BIN" stratum
fi
