//! Pure-Rust port of the Akoya miner's managed crypto layer (`Akoya.Crypto`).
//!
//! Every routine here is a byte-faithful reimplementation of the C# reference
//! so that job keys, commitment hashes, noise, jackpot words, and B-matrix
//! expansions match what the Akoya pool computes and verifies.

pub mod blake3;
pub mod bseed;
pub mod host_signal;
pub mod jackpot;
pub mod lcg_int7;
pub mod merkle;
pub mod mining_config;
pub mod noise;
pub mod plain_proof;

pub use mining_config::{commitment, MiningConfiguration, MmaType, PeriodicPattern};
pub use plain_proof::{MatrixMerkleProof, MerkleProof, MoEProofParams, PlainProof};
pub use merkle::MerkleTree;
pub use host_signal::{extract_indices, is_winner, ProofTileIndices};

#[cfg(test)]
mod tests {
    use super::*;

    fn hex(bytes: &[u8]) -> String {
        bytes.iter().map(|b| format!("{:02x}", b)).collect()
    }

    // ---- BLAKE3 official test vectors -------------------------------------
    // From the BLAKE3 team's test_vectors.json (hash + keyed, first 32 bytes).
    // Input byte i = i % 251.
    fn tv_input(len: usize) -> Vec<u8> {
        (0..len).map(|i| (i % 251) as u8).collect()
    }

    #[test]
    fn blake3_hash_empty() {
        // Official: empty input, unkeyed.
        let got = blake3::hash(&[]);
        assert_eq!(
            hex(&got),
            "af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262"
        );
    }

    #[test]
    fn blake3_hash_1024() {
        let got = blake3::hash(&tv_input(1024));
        assert_eq!(
            hex(&got),
            "42214739f095a406f3fc83deb889744ac00df831c10daa55189b5d121c855af7"
        );
    }

    #[test]
    fn blake3_hash_matches_reference_random_lengths() {
        // Cross-check our port against the `blake3` crate for many lengths.
        for len in [0usize, 1, 63, 64, 65, 127, 128, 200, 500, 1000, 1024] {
            let input = tv_input(len);
            let got = blake3::hash(&input);
            let want = ::blake3::hash(&input);
            assert_eq!(hex(&got), hex(want.as_bytes()), "hash mismatch at len {len}");
        }
    }

    #[test]
    fn blake3_keyed_matches_reference() {
        let key = tv_input(32).try_into().unwrap();
        for len in [0usize, 1, 64, 100, 1024] {
            let input = tv_input(len);
            let got = blake3::keyed_hash(&key, &input);
            let want = ::blake3::keyed_hash(&key, &input);
            assert_eq!(hex(&got), hex(want.as_bytes()), "keyed mismatch at len {len}");
        }
    }

    #[test]
    fn blake3_xof_matches_reference() {
        let input = tv_input(200);
        let mut got = vec![0u8; 512];
        blake3::xof(&input, &mut got);

        let mut hasher = ::blake3::Hasher::new();
        hasher.update(&input);
        let mut reader = hasher.finalize_xof();
        let mut want = vec![0u8; 512];
        reader.fill(&mut want);

        assert_eq!(hex(&got), hex(&want));
    }

    #[test]
    fn blake3_xof_at_equals_xof_slice() {
        // Random-access read must equal the corresponding slice of full XOF.
        let input = tv_input(64);
        let mut full = vec![0u8; 300];
        blake3::xof(&input, &mut full);

        for &off in &[0u64, 1, 63, 64, 65, 130, 200] {
            let len = 40usize;
            let mut got = vec![0u8; len];
            blake3::xof_at(&input, off, &mut got);
            assert_eq!(
                hex(&got),
                hex(&full[off as usize..off as usize + len]),
                "xof_at mismatch at offset {off}"
            );
        }
    }

    // ---- LCG int7 ---------------------------------------------------------

    #[test]
    fn lcg_int7_range_and_determinism() {
        let a = lcg_int7::fill_new(1000, 12345, 67890);
        let b = lcg_int7::fill_new(1000, 12345, 67890);
        assert_eq!(a, b, "same seed must produce same bytes");
        for &byte in &a {
            let v = byte as i8;
            assert!((-63..=63).contains(&(v as i32)), "value {v} out of int7 range");
        }
        // Different seed -> different output (overwhelmingly likely).
        let c = lcg_int7::fill_new(1000, 12346, 67890);
        assert_ne!(a, c);
    }

    #[test]
    fn lcg_int7_tail_handling() {
        // Length not divisible by 8 exercises the tail path.
        let v = lcg_int7::fill_new(13, 1, 2);
        assert_eq!(v.len(), 13);
        for &byte in &v {
            let s = byte as i8;
            assert!((-63..=63).contains(&(s as i32)));
        }
    }

    // ---- B-seed expansion -------------------------------------------------

    #[test]
    fn bseed_expand_range_matches_full() {
        let seed = [7u8; 32];
        let (n, k) = (4usize, 32usize);
        let full = bseed::expand_raw(&seed, n, k);
        // Read a sub-range and compare.
        let mut part = vec![0u8; 20];
        bseed::expand_range_raw(&seed, 40, &mut part);
        assert_eq!(part, &full[40..60]);
    }

    #[test]
    fn bseed_values_in_int7_range() {
        let seed = [0x11u8; 32];
        let b = bseed::expand_raw(&seed, 8, 16);
        for &byte in &b {
            let s = byte as i8;
            assert!((-63..=63).contains(&(s as i32)));
        }
    }

    #[test]
    fn bseed_hash_b_is_stable() {
        let seed = [3u8; 32];
        let key = [9u8; 32];
        let h1 = bseed::expand_and_compute_hash_b(&seed, 4, 256, &key);
        let h2 = bseed::expand_and_compute_hash_b(&seed, 4, 256, &key);
        assert_eq!(h1, h2);
    }

    // ---- Mining configuration wire format ---------------------------------

    #[test]
    fn mining_config_wire_size_and_reserved_zero() {
        let cfg = MiningConfiguration::default_with(2048, 128);
        let bytes = cfg.to_bytes();
        assert_eq!(bytes.len(), MiningConfiguration::SERIALIZED_SIZE);
        assert!(bytes[20..].iter().all(|&b| b == 0), "reserved must be zero");
        // common_dim little-endian at [0..4]
        assert_eq!(u32::from_le_bytes(bytes[0..4].try_into().unwrap()), 2048);
        assert_eq!(u16::from_le_bytes(bytes[4..6].try_into().unwrap()), 128);
        assert_eq!(u16::from_le_bytes(bytes[6..8].try_into().unwrap()), 0);
    }

    #[test]
    fn periodic_pattern_rows_roundtrip() {
        // rows [0,8]: size 2, stride 8 -> to_bytes factor/length encoding.
        let p = PeriodicPattern::from_indices(&[0, 8]);
        assert_eq!(p.size(), 2);
        let b = p.to_bytes();
        assert_eq!(b.len(), 6);
    }

    #[test]
    fn periodic_pattern_default_cols_size_64() {
        let cols = MiningConfiguration::default_cols_indices();
        assert_eq!(cols.len(), 64);
        let p = PeriodicPattern::from_indices(&cols);
        assert_eq!(p.size(), 64);
    }

    #[test]
    fn dot_product_length_floor_rounds() {
        let cfg = MiningConfiguration::default_with(2048, 128);
        assert_eq!(cfg.dot_product_length(), 2048); // 2048 divisible by 128
        let cfg2 = MiningConfiguration::default_with(2000, 128);
        assert_eq!(cfg2.dot_product_length(), (2000 / 128) * 128); // 1920
    }

    // ---- Commitment / noise seeds -----------------------------------------

    #[test]
    fn commitment_key_is_blake3_header_concat_config() {
        let cfg = MiningConfiguration::default_with(2048, 128);
        let header = [0xABu8; 76];
        let key = commitment::get_key(&header, &cfg);

        // Recompute independently with the reference blake3 crate.
        let mut input = Vec::new();
        input.extend_from_slice(&header);
        input.extend_from_slice(&cfg.to_bytes());
        let want = ::blake3::hash(&input);
        assert_eq!(hex(&key), hex(want.as_bytes()));
    }

    #[test]
    fn noise_seeds_chain_correctly() {
        let job_key = [1u8; 32];
        let hash_a = [2u8; 32];
        let hash_b = [3u8; 32];
        let (b_seed, a_seed) = commitment::derive_noise_seeds(&job_key, &hash_a, &hash_b);

        // b_noise_seed = BLAKE3(job_key ‖ hash_b)
        let mut bi = Vec::new();
        bi.extend_from_slice(&job_key);
        bi.extend_from_slice(&hash_b);
        assert_eq!(hex(&b_seed), hex(::blake3::hash(&bi).as_bytes()));

        // a_noise_seed = BLAKE3(b_noise_seed ‖ hash_a)
        let mut ai = Vec::new();
        ai.extend_from_slice(&b_seed);
        ai.extend_from_slice(&hash_a);
        assert_eq!(hex(&a_seed), hex(::blake3::hash(&ai).as_bytes()));
    }

    // ---- V3 salted-seed hard fork (mainnet block 99000) -------------------

    #[test]
    fn v3_seed_salts_match_context_strings() {
        // The upstream consensus salts are blake3 of these context strings.
        // Pinned bytes from zk-pow/src/api/seed.rs.
        let salt_a = blake3::hash(b"pearl/cert-v3/noise-seed/A");
        let salt_b = blake3::hash(b"pearl/cert-v3/noise-seed/B");
        const SEED_SALT_A: [u8; 32] = [
            0x82, 0x49, 0x40, 0x6c, 0xa0, 0xed, 0x15, 0x16, 0x96, 0x16, 0xf6, 0x92, 0xfc, 0xf0,
            0x76, 0xf8, 0x92, 0xdb, 0xdb, 0x2a, 0x70, 0x23, 0xb8, 0x52, 0xf0, 0xd4, 0x77, 0x19,
            0xc3, 0x90, 0x01, 0x7b,
        ];
        const SEED_SALT_B: [u8; 32] = [
            0x11, 0x30, 0x06, 0x32, 0xec, 0x63, 0x01, 0xca, 0x2b, 0xe2, 0xaf, 0x71, 0x8b, 0x3f,
            0x4d, 0x4f, 0x1a, 0xe9, 0xc6, 0x39, 0x88, 0xe8, 0xcc, 0x04, 0x48, 0x44, 0x30, 0x1d,
            0x71, 0xb8, 0x9a, 0xa9,
        ];
        assert_eq!(salt_a, SEED_SALT_A);
        assert_eq!(salt_b, SEED_SALT_B);
    }

    #[test]
    fn v3_commitment_hash_pinned_vectors() {
        use commitment::SeedDerivation;
        // Pinned vectors from zk-pow/src/api/seed.rs::commitment_hash_pinned_vectors.
        // job_key = 0x11*32, hash_a = 0xAA*32, hash_b = 0xBB*32,
        // dims from PublicProofParams::new_for_tests(192, 320, 256) → m=192, n=320.
        let job_key = [0x11u8; 32];
        let hash_a = [0xAAu8; 32];
        let hash_b = [0xBBu8; 32];
        let (m, n) = (192u32, 320u32);

        // Legacy (pre-fork): returns (b_noise_seed, a_noise_seed).
        let expected_b_legacy = [
            0xad, 0xd6, 0xf7, 0xea, 0x5f, 0xee, 0xbf, 0x89, 0xc8, 0xa7, 0x7e, 0x2e, 0xbf, 0xa0,
            0xd8, 0x24, 0x42, 0xe7, 0xdb, 0xb0, 0x04, 0x6d, 0xbd, 0x48, 0x97, 0x18, 0x61, 0xd1,
            0x2f, 0xcb, 0x01, 0x77,
        ];
        let expected_a_legacy = [
            0x48, 0x3b, 0x07, 0xb6, 0xf7, 0x31, 0x05, 0x03, 0x0b, 0x94, 0x82, 0x25, 0x5f, 0x37,
            0x72, 0x3f, 0x3f, 0xed, 0x69, 0xae, 0x91, 0x67, 0x24, 0xee, 0x82, 0x91, 0x84, 0x8b,
            0x8c, 0x28, 0x79, 0x4b,
        ];
        let (b, a) = commitment::derive_noise_seeds_versioned(
            &job_key,
            &hash_a,
            &hash_b,
            m,
            n,
            SeedDerivation::Legacy,
        );
        assert_eq!(b, expected_b_legacy, "legacy b_noise_seed");
        assert_eq!(a, expected_a_legacy, "legacy a_noise_seed");

        // Salted (V3 fork): dimension-bound roots.
        let expected_b_salted = [
            0x60, 0xed, 0x9b, 0x73, 0xc5, 0xa9, 0x59, 0x9b, 0x20, 0x0b, 0x6c, 0xd5, 0x63, 0xe7,
            0xf0, 0xd5, 0xd9, 0xa6, 0x7d, 0x24, 0x02, 0xd8, 0x5f, 0xd4, 0xef, 0x96, 0x6c, 0x58,
            0x00, 0x80, 0xd0, 0xe5,
        ];
        let expected_a_salted = [
            0x30, 0x17, 0x84, 0x16, 0x80, 0x05, 0xec, 0x83, 0x3a, 0xb0, 0xaa, 0x60, 0x00, 0x6f,
            0x7f, 0xe7, 0xfa, 0xaa, 0x95, 0x30, 0x7d, 0x8c, 0x1f, 0xc6, 0x81, 0x9b, 0x2f, 0xfd,
            0xd7, 0x17, 0xec, 0xcf,
        ];
        let (b, a) = commitment::derive_noise_seeds_versioned(
            &job_key,
            &hash_a,
            &hash_b,
            m,
            n,
            SeedDerivation::Salted,
        );
        assert_eq!(b, expected_b_salted, "salted (V3) b_noise_seed — consensus break");
        assert_eq!(a, expected_a_salted, "salted (V3) a_noise_seed — consensus break");
    }

    #[test]
    fn v3_cert_version_maps_to_derivation() {
        use commitment::SeedDerivation;
        assert_eq!(SeedDerivation::from_cert_version(1), SeedDerivation::Legacy);
        assert_eq!(SeedDerivation::from_cert_version(2), SeedDerivation::Legacy);
        assert_eq!(SeedDerivation::from_cert_version(3), SeedDerivation::Salted);
    }

    // ---- Noise generator --------------------------------------------------

    #[test]
    fn noise_uniform_range_is_signed_6bit() {
        let seed = noise::seed_labels::a();
        let key = [5u8; 32];
        let rows = noise::generate_uniform_random_matrix(&seed, &key, &[0, 1, 2], 128);
        assert_eq!(rows.len(), 3);
        for row in &rows {
            assert_eq!(row.len(), 128);
            for &v in row {
                assert!((-32..=31).contains(&(v as i32)), "value {v} out of range");
            }
        }
    }

    #[test]
    fn noise_mul_hi_u32_matches_widening() {
        for (a, b) in [(0u32, 0u32), (u32::MAX, u32::MAX), (123456, 987654), (127, 0xDEAD_BEEF)] {
            let want = (((a as u64) * (b as u64)) >> 32) as u32;
            assert_eq!(noise::mul_hi_u32(a, b), want);
        }
    }

    #[test]
    fn noise_permutation_indices_within_rank() {
        let seed = noise::seed_labels::b();
        let key = [6u8; 32];
        let rank = 128usize;
        let perm = noise::generate_permutation_matrix(&seed, &key, 256, rank);
        assert_eq!(perm.len(), 256);
        for p in &perm {
            assert!((p.first_index as usize) < rank);
            assert!((p.second_index as usize) < rank);
        }
    }

    // ---- Jackpot ----------------------------------------------------------

    #[test]
    fn jackpot_deterministic_and_hashes() {
        let h = 2usize;
        let w = 2usize;
        let k = 128usize;
        let r = 128usize;
        let secret_a = vec![vec![1i8; k]; h];
        let secret_b = vec![vec![1i8; k]; w];
        let noise_a = vec![vec![0i8; k]; h];
        let noise_b = vec![vec![0i8; k]; w];

        let j1 = jackpot::compute(h, w, k, r, &secret_a, &secret_b, &noise_a, &noise_b);
        let j2 = jackpot::compute(h, w, k, r, &secret_a, &secret_b, &noise_a, &noise_b);
        assert_eq!(j1, j2);

        // Each tile entry = sum_{l} 1*1 = k = 128; XOR of 4 identical = 0;
        // rotl(0,13) ^ 0 = 0. So all jackpot words are zero here.
        assert!(j1.iter().all(|&x| x == 0));

        let a_seed = [7u8; 32];
        let hash = jackpot::hash(&j1, &a_seed);
        // Must equal keyed BLAKE3 over 64 zero bytes.
        let want = ::blake3::keyed_hash(&a_seed, &[0u8; 64]);
        assert_eq!(hex(&hash), hex(want.as_bytes()));
    }
}
