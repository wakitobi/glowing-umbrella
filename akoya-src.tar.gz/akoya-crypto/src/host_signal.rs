//! Host-signal header layout — Rust port of the C# `HostSignalHeaderLayout`
//! (`src/Akoya.MinerCore/HostSignalHeaderLayout.cs`), which mirrors the C++
//! `HostSignalHeader` the pearl-gemm kernel writes into the pinned host buffer.
//!
//! After a batch of `pearl_capi_iter` calls, each slot's pinned header has a
//! leading `status: i32`. status==1 means that nonce produced a tile whose
//! keyed-BLAKE3 beat the pow_target — a WINNER. We then read the tile coords +
//! thread row/col registers to reconstruct which A rows / B columns were opened,
//! which the PlainProof must carry merkle inclusion proofs for.
//!
//! Layout (from the C# comment block, verified field offsets):
//! ```text
//!   offset  size  field
//!        0     4  status                    (i32; 1 == winner)
//!        4    12  gridDim[3]                u32
//!       16    12  blockDim[3]               u32
//!       28    12  blockIdx[3]               u32
//!       40    12  tileCoord[3]              u32   <- tileRow=tileCoord[0], tileCol=[1]
//!       52    12  threadIdx[3]              u32
//!       64     2  num_registers_per_thread  u16
//!       66   256  thread_rows[256]          u8
//!      322   256  thread_cols[256]          u8
//!      580    12  mma_size                  3 x i32   (+2 pad to 4-byte align)
//!      592    12  mma_tile_size             3 x i32   <- mmaTileM=[0], mmaTileN=[1]
//!      604    32  target[8]                 u32
//! ```
//! `host_signal_header_size` on the C side rounds sizeof up to a 128 multiple
//! (636 -> 640); query it at runtime via `pearl_capi_get_host_signal_header_size`
//! rather than hardcoding.

use std::collections::BTreeSet;

pub const OFF_STATUS: usize = 0;
pub const OFF_TILE_COORD: usize = 40;
pub const OFF_NUM_REGISTERS_PER_THREAD: usize = 64;
pub const OFF_THREAD_ROWS: usize = 66;
pub const OFF_THREAD_COLS: usize = 322;
pub const OFF_MMA_TILE_SIZE: usize = 592;
pub const OFF_TARGET: usize = 604;

pub const MAX_NUM_REGISTERS_PER_THREAD: usize = 256;

/// The status value the kernel writes when a nonce wins (beats pow_target).
pub const STATUS_WINNER: i32 = 1;

#[inline]
fn rd_u32(h: &[u8], off: usize) -> u32 {
    u32::from_le_bytes([h[off], h[off + 1], h[off + 2], h[off + 3]])
}
#[inline]
fn rd_i32(h: &[u8], off: usize) -> i32 {
    i32::from_le_bytes([h[off], h[off + 1], h[off + 2], h[off + 3]])
}
#[inline]
fn rd_u16(h: &[u8], off: usize) -> u16 {
    u16::from_le_bytes([h[off], h[off + 1]])
}

/// The opened row/column indices for the winning tile, as global matrix indices.
#[derive(Debug, Clone, PartialEq)]
pub struct ProofTileIndices {
    pub a_row_indices: Vec<u64>,
    pub b_col_indices: Vec<u64>,
}

/// `status` of a header slot (`> 0` at OFF_STATUS). 1 == winner.
pub fn status(header: &[u8]) -> i32 {
    if header.len() < 4 {
        return 0;
    }
    rd_i32(header, OFF_STATUS)
}

pub fn is_winner(header: &[u8]) -> bool {
    status(header) == STATUS_WINNER
}

/// Debug fields (tile coords + mma tile size + register count) for logging.
pub struct DebugInfo {
    pub tile_row: u32,
    pub tile_col: u32,
    pub mma_tile_m: i32,
    pub mma_tile_n: i32,
    pub num_regs: u16,
}

pub fn debug_info(header: &[u8]) -> DebugInfo {
    DebugInfo {
        tile_row: rd_u32(header, OFF_TILE_COORD),
        tile_col: rd_u32(header, OFF_TILE_COORD + 4),
        mma_tile_m: rd_i32(header, OFF_MMA_TILE_SIZE),
        mma_tile_n: rd_i32(header, OFF_MMA_TILE_SIZE + 4),
        num_regs: rd_u16(header, OFF_NUM_REGISTERS_PER_THREAD),
    }
}

/// Mirror of `pearl_gemm.helpers.extract_indices(header)`:
///   row_tile_coord = tileCoord[0] * mma_tile_size.m
///   col_tile_coord = tileCoord[1] * mma_tile_size.n
///   thread_rows = sorted(set(thread_rows[:num_registers_per_thread]))
///   A_row_indices    = [row_tile_coord + r for r in thread_rows]
///   B_column_indices = [col_tile_coord + c for c in thread_cols]
pub fn extract_indices(header: &[u8]) -> Result<ProofTileIndices, String> {
    if header.len() < OFF_TARGET {
        return Err(format!(
            "header too short: {} bytes, need >= {}",
            header.len(),
            OFF_TARGET
        ));
    }
    let tile_row = rd_u32(header, OFF_TILE_COORD) as u64;
    let tile_col = rd_u32(header, OFF_TILE_COORD + 4) as u64;
    let mma_tile_m = rd_i32(header, OFF_MMA_TILE_SIZE) as u64;
    let mma_tile_n = rd_i32(header, OFF_MMA_TILE_SIZE + 4) as u64;

    let num_regs = rd_u16(header, OFF_NUM_REGISTERS_PER_THREAD) as usize;
    if num_regs == 0 || num_regs > MAX_NUM_REGISTERS_PER_THREAD {
        return Err(format!("num_registers_per_thread out of range: {num_regs}"));
    }

    let mut rows: BTreeSet<u8> = BTreeSet::new();
    let mut cols: BTreeSet<u8> = BTreeSet::new();
    for i in 0..num_regs {
        rows.insert(header[OFF_THREAD_ROWS + i]);
        cols.insert(header[OFF_THREAD_COLS + i]);
    }

    let row_off = tile_row * mma_tile_m;
    let col_off = tile_col * mma_tile_n;

    let a_row_indices = rows.iter().map(|&r| row_off + r as u64).collect();
    let b_col_indices = cols.iter().map(|&c| col_off + c as u64).collect();

    Ok(ProofTileIndices {
        a_row_indices,
        b_col_indices,
    })
}

/// Read the 256-bit pow target (8 x u32 LE) the kernel compared against.
pub fn target_u32x8(header: &[u8]) -> [u32; 8] {
    let mut t = [0u32; 8];
    for (i, slot) in t.iter_mut().enumerate() {
        *slot = rd_u32(header, OFF_TARGET + i * 4);
    }
    t
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mk_header() -> Vec<u8> {
        let mut h = vec![0u8; 640];
        // status = winner
        h[OFF_STATUS..OFF_STATUS + 4].copy_from_slice(&1i32.to_le_bytes());
        // tileCoord = (2, 3, 0)
        h[OFF_TILE_COORD..OFF_TILE_COORD + 4].copy_from_slice(&2u32.to_le_bytes());
        h[OFF_TILE_COORD + 4..OFF_TILE_COORD + 8].copy_from_slice(&3u32.to_le_bytes());
        // mma_tile_size = (16, 8, 0)
        h[OFF_MMA_TILE_SIZE..OFF_MMA_TILE_SIZE + 4].copy_from_slice(&16i32.to_le_bytes());
        h[OFF_MMA_TILE_SIZE + 4..OFF_MMA_TILE_SIZE + 8].copy_from_slice(&8i32.to_le_bytes());
        // num_regs = 3, thread_rows = [1,1,4] (dedup->{1,4}), cols = [0,2,2] ({0,2})
        h[OFF_NUM_REGISTERS_PER_THREAD..OFF_NUM_REGISTERS_PER_THREAD + 2]
            .copy_from_slice(&3u16.to_le_bytes());
        h[OFF_THREAD_ROWS] = 1;
        h[OFF_THREAD_ROWS + 1] = 1;
        h[OFF_THREAD_ROWS + 2] = 4;
        h[OFF_THREAD_COLS] = 0;
        h[OFF_THREAD_COLS + 1] = 2;
        h[OFF_THREAD_COLS + 2] = 2;
        h
    }

    #[test]
    fn detects_winner() {
        let h = mk_header();
        assert!(is_winner(&h));
        let mut h2 = h.clone();
        h2[OFF_STATUS] = 0;
        assert!(!is_winner(&h2));
    }

    #[test]
    fn extracts_tile_indices() {
        let h = mk_header();
        let idx = extract_indices(&h).unwrap();
        // row_off = 2*16 = 32; rows {1,4} -> [33, 36]
        assert_eq!(idx.a_row_indices, vec![33, 36]);
        // col_off = 3*8 = 24; cols {0,2} -> [24, 26]
        assert_eq!(idx.b_col_indices, vec![24, 26]);
    }

    #[test]
    fn debug_info_reads_coords() {
        let d = debug_info(&mk_header());
        assert_eq!((d.tile_row, d.tile_col), (2, 3));
        assert_eq!((d.mma_tile_m, d.mma_tile_n), (16, 8));
        assert_eq!(d.num_regs, 3);
    }

    #[test]
    fn rejects_bad_regcount() {
        let mut h = mk_header();
        h[OFF_NUM_REGISTERS_PER_THREAD..OFF_NUM_REGISTERS_PER_THREAD + 2]
            .copy_from_slice(&0u16.to_le_bytes());
        assert!(extract_indices(&h).is_err());
    }
}
