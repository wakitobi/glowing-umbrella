//! Spec-faithful BLAKE3 port of `Akoya.Crypto.Blake3` (C#).
//!
//! Scope matches the C# original: single-chunk (<=1024 byte) hashing, keyed
//! hashing, XOF (streaming + random-access), Merkle chunk/parent/root chaining
//! values, and a keyed Merkle root over arbitrarily long data.
//!
//! This is intentionally a straight port of the reference construction rather
//! than a wrapper over the `blake3` crate, so that every intermediate value
//! (chunk CV, parent CV, XOF block) is byte-identical to the C# host the Akoya
//! pool verifies against.

pub const DIGEST_SIZE: usize = 32;
pub const CHUNK_LEN: usize = 1024;
const BLOCK_LEN: usize = 64;

const FLAG_CHUNK_START: u32 = 1 << 0;
const FLAG_CHUNK_END: u32 = 1 << 1;
const FLAG_PARENT: u32 = 1 << 2;
const FLAG_ROOT: u32 = 1 << 3;
const FLAG_KEYED_HASH: u32 = 1 << 4;

const IV: [u32; 8] = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A, 0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
];

const MSG_PERMUTATION: [usize; 16] =
    [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];

#[inline]
fn rotr(x: u32, n: u32) -> u32 {
    (x >> n) | (x << (32 - n))
}

#[inline]
#[allow(clippy::too_many_arguments)]
fn g(s: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize, mx: u32, my: u32) {
    s[a] = s[a].wrapping_add(s[b]).wrapping_add(mx);
    s[d] = rotr(s[d] ^ s[a], 16);
    s[c] = s[c].wrapping_add(s[d]);
    s[b] = rotr(s[b] ^ s[c], 12);
    s[a] = s[a].wrapping_add(s[b]).wrapping_add(my);
    s[d] = rotr(s[d] ^ s[a], 8);
    s[c] = s[c].wrapping_add(s[d]);
    s[b] = rotr(s[b] ^ s[c], 7);
}

/// Core compression. `out_words` receives all 16 output words (the first 8 are
/// the chaining value / digest words; the upper 8 are used by the XOF path).
fn compress(
    cv: &[u32; 8],
    block: &[u32; 16],
    counter: u64,
    block_len: u32,
    flags: u32,
    out_words: &mut [u32; 16],
) {
    let mut state: [u32; 16] = [
        cv[0], cv[1], cv[2], cv[3], cv[4], cv[5], cv[6], cv[7], IV[0], IV[1], IV[2], IV[3],
        (counter & 0xFFFF_FFFF) as u32,
        (counter >> 32) as u32,
        block_len,
        flags,
    ];

    let mut m = *block;

    for round in 0..7 {
        g(&mut state, 0, 4, 8, 12, m[0], m[1]);
        g(&mut state, 1, 5, 9, 13, m[2], m[3]);
        g(&mut state, 2, 6, 10, 14, m[4], m[5]);
        g(&mut state, 3, 7, 11, 15, m[6], m[7]);
        g(&mut state, 0, 5, 10, 15, m[8], m[9]);
        g(&mut state, 1, 6, 11, 12, m[10], m[11]);
        g(&mut state, 2, 7, 8, 13, m[12], m[13]);
        g(&mut state, 3, 4, 9, 14, m[14], m[15]);

        if round < 6 {
            let mut permuted = [0u32; 16];
            for i in 0..16 {
                permuted[i] = m[MSG_PERMUTATION[i]];
            }
            m = permuted;
        }
    }

    for i in 0..8 {
        out_words[i] = state[i] ^ state[i + 8];
        out_words[i + 8] = state[i + 8] ^ cv[i];
    }
}

fn load_block(data: &[u8], words: &mut [u32; 16]) {
    *words = [0u32; 16];
    let full_words = data.len() / 4;
    for i in 0..full_words.min(16) {
        words[i] = u32::from_le_bytes([
            data[i * 4],
            data[i * 4 + 1],
            data[i * 4 + 2],
            data[i * 4 + 3],
        ]);
    }
    let tail = data.len() % 4;
    if tail > 0 && full_words < 16 {
        let mut tmp = [0u8; 4];
        tmp[..tail].copy_from_slice(&data[full_words * 4..full_words * 4 + tail]);
        words[full_words] = u32::from_le_bytes(tmp);
    }
}

fn load_key_words(key: &[u8; 32]) -> [u32; 8] {
    let mut w = [0u32; 8];
    for i in 0..8 {
        w[i] = u32::from_le_bytes([
            key[i * 4],
            key[i * 4 + 1],
            key[i * 4 + 2],
            key[i * 4 + 3],
        ]);
    }
    w
}

fn words_to_bytes(words: &[u32]) -> Vec<u8> {
    let mut out = vec![0u8; words.len() * 4];
    for (i, w) in words.iter().enumerate() {
        out[i * 4..i * 4 + 4].copy_from_slice(&w.to_le_bytes());
    }
    out
}

/// Hash arbitrary-length input <= 1024 bytes. Returns 32 bytes.
///
/// # Panics
/// Panics if `input.len() > 1024` (mirrors the C# `NotSupportedException`).
pub fn hash(input: &[u8]) -> [u8; 32] {
    assert!(
        input.len() <= CHUNK_LEN,
        "Blake3::hash only supports inputs <= 1024 bytes"
    );

    let mut cv = IV;
    let mut block_words = [0u32; 16];
    let total_blocks = ((input.len() + BLOCK_LEN - 1) / BLOCK_LEN).max(1);

    for blocks_consumed in 0..total_blocks {
        let offset = blocks_consumed * BLOCK_LEN;
        let block_bytes = BLOCK_LEN.min(input.len() - offset);
        load_block(&input[offset..offset + block_bytes], &mut block_words);

        let mut flags = 0;
        if blocks_consumed == 0 {
            flags |= FLAG_CHUNK_START;
        }
        let is_last = blocks_consumed == total_blocks - 1;
        if is_last {
            flags |= FLAG_CHUNK_END | FLAG_ROOT;
        }

        let mut compressed = [0u32; 16];
        compress(&cv, &block_words, 0, block_bytes as u32, flags, &mut compressed);

        if is_last {
            let bytes = words_to_bytes(&compressed[..8]);
            let mut out = [0u8; 32];
            out.copy_from_slice(&bytes);
            return out;
        }
        cv.copy_from_slice(&compressed[..8]);
    }
    unreachable!()
}

/// Keyed BLAKE3 hash for data <= 1024 bytes (single chunk).
///
/// # Panics
/// Panics if `input.len() > 1024`.
pub fn keyed_hash(key: &[u8; 32], input: &[u8]) -> [u8; 32] {
    assert!(
        input.len() <= CHUNK_LEN,
        "Blake3::keyed_hash only supports inputs <= 1024 bytes"
    );

    let mut cv = load_key_words(key);
    let mut block_words = [0u32; 16];
    let total_blocks = ((input.len() + BLOCK_LEN - 1) / BLOCK_LEN).max(1);

    for i in 0..total_blocks {
        let offset = i * BLOCK_LEN;
        let block_bytes = BLOCK_LEN.min(input.len() - offset);
        load_block(&input[offset..offset + block_bytes], &mut block_words);

        let mut flags = FLAG_KEYED_HASH;
        if i == 0 {
            flags |= FLAG_CHUNK_START;
        }
        let is_last = i == total_blocks - 1;
        if is_last {
            flags |= FLAG_CHUNK_END | FLAG_ROOT;
        }

        let mut compressed = [0u32; 16];
        compress(&cv, &block_words, 0, block_bytes as u32, flags, &mut compressed);

        if is_last {
            let mut out = [0u8; 32];
            out.copy_from_slice(&words_to_bytes(&compressed[..8]));
            return out;
        }
        cv.copy_from_slice(&compressed[..8]);
    }
    unreachable!()
}

/// BLAKE3 XOF: hash `input` (<=1024 B) then emit `output.len()` bytes.
///
/// # Panics
/// Panics if `input.len() > 1024`.
pub fn xof(input: &[u8], output: &mut [u8]) {
    xof_at(input, 0, output)
}

/// Random-access BLAKE3 XOF read at byte offset `byte_offset`.
///
/// # Panics
/// Panics if `input.len() > 1024`.
pub fn xof_at(input: &[u8], byte_offset: u64, output: &mut [u8]) {
    assert!(
        input.len() <= CHUNK_LEN,
        "Blake3::xof_at only supports inputs <= 1024 bytes"
    );

    let mut cv = IV;
    let mut block_words = [0u32; 16];
    let total_blocks = ((input.len() + BLOCK_LEN - 1) / BLOCK_LEN).max(1);
    let last_block_offset = (total_blocks - 1) * BLOCK_LEN;
    let last_block_len = BLOCK_LEN.min(input.len() - last_block_offset);

    for i in 0..total_blocks - 1 {
        let offset = i * BLOCK_LEN;
        let block_bytes = BLOCK_LEN.min(input.len() - offset);
        load_block(&input[offset..offset + block_bytes], &mut block_words);
        let mut flags = 0;
        if i == 0 {
            flags |= FLAG_CHUNK_START;
        }
        let mut compressed = [0u32; 16];
        compress(&cv, &block_words, 0, block_bytes as u32, flags, &mut compressed);
        cv.copy_from_slice(&compressed[..8]);
    }

    load_block(
        &input[last_block_offset..last_block_offset + last_block_len],
        &mut block_words,
    );
    let mut last_flags = FLAG_CHUNK_END | FLAG_ROOT;
    if total_blocks == 1 {
        last_flags |= FLAG_CHUNK_START;
    }

    let mut counter = byte_offset / 64;
    let mut skip_in_first = (byte_offset % 64) as usize;

    let mut xof_out = [0u32; 16];
    let mut block_buf = [0u8; 64];
    let mut written = 0usize;

    while written < output.len() {
        compress(
            &cv,
            &block_words,
            counter,
            last_block_len as u32,
            last_flags,
            &mut xof_out,
        );
        for w in 0..16 {
            block_buf[w * 4..w * 4 + 4].copy_from_slice(&xof_out[w].to_le_bytes());
        }
        let take = (64 - skip_in_first).min(output.len() - written);
        output[written..written + take]
            .copy_from_slice(&block_buf[skip_in_first..skip_in_first + take]);
        written += take;
        skip_in_first = 0;
        counter += 1;
    }
}

/// Compute the chaining value (CV) for a single chunk in keyed mode (non-root).
pub fn chunk_cv(chunk: &[u8], chunk_index: u64, key: &[u8; 32]) -> [u8; 32] {
    assert!(
        !chunk.is_empty() && chunk.len() <= CHUNK_LEN,
        "chunk must be 1..=1024 bytes"
    );

    let mut cv = load_key_words(key);
    let mut block_words = [0u32; 16];
    let total_blocks = ((chunk.len() + BLOCK_LEN - 1) / BLOCK_LEN).max(1);

    for i in 0..total_blocks {
        let offset = i * BLOCK_LEN;
        let block_bytes = BLOCK_LEN.min(chunk.len() - offset);
        load_block(&chunk[offset..offset + block_bytes], &mut block_words);

        let mut flags = FLAG_KEYED_HASH;
        if i == 0 {
            flags |= FLAG_CHUNK_START;
        }
        if i == total_blocks - 1 {
            flags |= FLAG_CHUNK_END;
        }

        let mut compressed = [0u32; 16];
        compress(
            &cv,
            &block_words,
            chunk_index,
            block_bytes as u32,
            flags,
            &mut compressed,
        );

        if i == total_blocks - 1 {
            let mut out = [0u8; 32];
            out.copy_from_slice(&words_to_bytes(&compressed[..8]));
            return out;
        }
        cv.copy_from_slice(&compressed[..8]);
    }
    unreachable!()
}

fn compress_parent(left: &[u8; 32], right: &[u8; 32], key: &[u8; 32], flags: u32) -> [u32; 16] {
    let cv = load_key_words(key);
    let mut block_words = [0u32; 16];
    for i in 0..8 {
        block_words[i] = u32::from_le_bytes([
            left[i * 4],
            left[i * 4 + 1],
            left[i * 4 + 2],
            left[i * 4 + 3],
        ]);
    }
    for i in 0..8 {
        block_words[8 + i] = u32::from_le_bytes([
            right[i * 4],
            right[i * 4 + 1],
            right[i * 4 + 2],
            right[i * 4 + 3],
        ]);
    }
    let mut out = [0u32; 16];
    compress(&cv, &block_words, 0, BLOCK_LEN as u32, flags, &mut out);
    out
}

/// Non-root parent CV from two child CVs (keyed mode).
pub fn parent_cv(left: &[u8; 32], right: &[u8; 32], key: &[u8; 32]) -> [u8; 32] {
    let words = compress_parent(left, right, key, FLAG_PARENT | FLAG_KEYED_HASH);
    let mut out = [0u8; 32];
    out.copy_from_slice(&words_to_bytes(&words[..8]));
    out
}

/// Root CV from two child CVs (keyed mode). Sets ROOT flag.
pub fn root_cv(left: &[u8; 32], right: &[u8; 32], key: &[u8; 32]) -> [u8; 32] {
    let words = compress_parent(left, right, key, FLAG_PARENT | FLAG_ROOT | FLAG_KEYED_HASH);
    let mut out = [0u8; 32];
    out.copy_from_slice(&words_to_bytes(&words[..8]));
    out
}

/// Build a keyed BLAKE3 Merkle root over arbitrarily long data.
///
/// Data is split into 1024-byte chunks (zero-padded to the chunk boundary).
/// Matches the pool's `Blake3MerkleHasher` construction.
pub fn merkle_root(data: &[u8], key: &[u8; 32]) -> [u8; 32] {
    let padded_len = {
        let p = ((data.len() + CHUNK_LEN - 1) / CHUNK_LEN) * CHUNK_LEN;
        if p == 0 {
            CHUNK_LEN
        } else {
            p
        }
    };
    let total_leaves = padded_len / CHUNK_LEN;

    // Materialize padded data (only copies when padding is required).
    let mut owned;
    let padded: &[u8] = if padded_len == data.len() {
        data
    } else {
        owned = vec![0u8; padded_len];
        owned[..data.len()].copy_from_slice(data);
        &owned
    };

    if total_leaves == 1 {
        return keyed_hash(key, &padded[..CHUNK_LEN]);
    }

    let mut cvs: Vec<[u8; 32]> = (0..total_leaves)
        .map(|i| chunk_cv(&padded[i * CHUNK_LEN..(i + 1) * CHUNK_LEN], i as u64, key))
        .collect();

    while cvs.len() > 2 {
        let next_len = (cvs.len() + 1) / 2;
        let mut next = Vec::with_capacity(next_len);
        let mut i = 0;
        while i < cvs.len() {
            if i + 1 < cvs.len() {
                next.push(parent_cv(&cvs[i], &cvs[i + 1], key));
            } else {
                next.push(cvs[i]);
            }
            i += 2;
        }
        cvs = next;
    }

    root_cv(&cvs[0], &cvs[1], key)
}
