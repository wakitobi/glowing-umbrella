//! Keyed-BLAKE3 Merkle tree with multi-leaf inclusion proofs — Rust port of
//! `pearl-blake3` `native/pearl-blake3/src/merkle.rs::MerkleTree`, built on the
//! chunk/parent/root primitives already in `crate::blake3`.
//!
//! Used to build the A/B `MatrixMerkleProof`s a `PlainProof` must carry: the
//! pool re-derives the matrix rows from the opened leaves + siblings and checks
//! them against the committed root, so this must match the pool's tree layout
//! byte-for-byte (1024-byte chunks, keyed BLAKE3, level-by-level pairing with a
//! lone-node carry-up, root gets the ROOT flag).

use std::collections::BTreeSet;

use crate::blake3;
use crate::plain_proof::{MatrixMerkleProof, MerkleProof, CHUNK_LEN};

/// A built keyed-BLAKE3 Merkle tree over row-major byte data.
pub struct MerkleTree {
    key: [u8; 32],
    /// layers[0] = leaf CVs, ... last = [root].
    layers: Vec<Vec<[u8; 32]>>,
    data: Vec<u8>,
}

impl MerkleTree {
    /// Build from `data` (zero-padded up to a 1024-byte chunk boundary).
    pub fn new(data: &[u8], key: [u8; 32]) -> Self {
        if data.is_empty() {
            return Self { key, layers: vec![vec![]], data: vec![] };
        }
        if data.len() <= CHUNK_LEN {
            // Single chunk: root is the keyed hash of the (padded) chunk.
            let mut chunk = vec![0u8; CHUNK_LEN];
            chunk[..data.len()].copy_from_slice(data);
            let root = blake3::keyed_hash(&key, &chunk);
            return Self { key, layers: vec![vec![root]], data: data.to_vec() };
        }

        let padded_len = data.len().div_ceil(CHUNK_LEN) * CHUNK_LEN;
        let total_leaves = padded_len / CHUNK_LEN;
        let leaf = |i: usize| -> [u8; 32] {
            let start = i * CHUNK_LEN;
            let end = (start + CHUNK_LEN).min(data.len());
            let mut chunk = [0u8; CHUNK_LEN];
            chunk[..end - start].copy_from_slice(&data[start..end]);
            blake3::chunk_cv(&chunk, i as u64, &key)
        };
        let chunk_cvs: Vec<[u8; 32]> = (0..total_leaves).map(leaf).collect();
        let mut layers: Vec<Vec<[u8; 32]>> = vec![chunk_cvs];

        // Combine up until 2 nodes remain, carrying a lone node up unchanged.
        while layers.last().unwrap().len() > 2 {
            let prev = layers.last().unwrap();
            let mut next = Vec::with_capacity(prev.len().div_ceil(2));
            let mut i = 0;
            while i < prev.len() {
                if i + 1 < prev.len() {
                    next.push(blake3::parent_cv(&prev[i], &prev[i + 1], &key));
                } else {
                    next.push(prev[i]);
                }
                i += 2;
            }
            layers.push(next);
        }
        let last = layers.last().unwrap();
        if last.len() == 2 {
            let root = blake3::root_cv(&last[0], &last[1], &key);
            layers.push(vec![root]);
        }
        Self { key, layers, data: data.to_vec() }
    }

    pub fn key(&self) -> [u8; 32] {
        self.key
    }

    pub fn num_leaves(&self) -> usize {
        self.layers[0].len()
    }

    pub fn root(&self) -> [u8; 32] {
        self.layers.last().map(|l| l[0]).unwrap_or([0u8; 32])
    }

    /// Leaf indices that cover the given matrix rows for a `(rows, cols)` shape.
    /// Each row spans `cols` bytes row-major; a leaf is `CHUNK_LEN` bytes.
    pub fn leaf_indices_from_rows(row_indices: &[usize], cols: usize) -> Vec<usize> {
        let mut set = BTreeSet::new();
        for &row in row_indices {
            let first = (row * cols) / CHUNK_LEN;
            let last = ((row + 1) * cols - 1) / CHUNK_LEN;
            for i in first..=last {
                set.insert(i);
            }
        }
        set.into_iter().collect()
    }

    /// Generate a multi-leaf inclusion proof (matches upstream
    /// `get_multileaf_proof`): dedup + sort indices, collect the padded leaf
    /// bytes, then walk levels collecting sibling digests not already covered.
    pub fn multileaf_proof(&self, leaf_indices: &[usize]) -> MerkleProof {
        assert!(!leaf_indices.is_empty(), "leaf_indices must be non-empty");
        let unique: BTreeSet<usize> = leaf_indices.iter().copied().collect();
        let total_leaves = self.num_leaves();
        assert!(*unique.last().unwrap() < total_leaves, "leaf index out of bounds");

        let sorted: Vec<usize> = unique.iter().copied().collect();
        let leaf_data: Vec<[u8; CHUNK_LEN]> = sorted
            .iter()
            .map(|&i| {
                let start = i * CHUNK_LEN;
                let end = (start + CHUNK_LEN).min(self.data.len());
                let mut chunk = [0u8; CHUNK_LEN];
                chunk[..end - start].copy_from_slice(&self.data[start..end]);
                chunk
            })
            .collect();

        let mut siblings: Vec<[u8; 32]> = Vec::new();
        let mut current: BTreeSet<usize> = unique;
        let mut level_len = total_leaves;
        let mut level = 0;
        while level_len > 1 && !current.is_empty() {
            let nodes = &self.layers[level];
            for &i in &current {
                if i % 2 == 1 {
                    if !current.contains(&(i - 1)) {
                        siblings.push(nodes[i - 1]);
                    }
                } else if !current.contains(&(i + 1)) && (i + 1) < level_len {
                    siblings.push(nodes[i + 1]);
                }
            }
            current = current.iter().map(|&i| i / 2).collect();
            level_len = level_len.div_ceil(2);
            level += 1;
        }

        MerkleProof {
            leaf_data,
            leaf_indices: sorted.iter().map(|&i| i as u64).collect(),
            total_leaves: total_leaves as u64,
            root: self.root(),
            siblings,
        }
    }

    /// Build a `MatrixMerkleProof` opening the given matrix rows: the row_indices
    /// are carried verbatim (the pool needs them to reconstruct the tile) and
    /// the inclusion proof covers the leaves those rows span.
    pub fn matrix_proof(&self, row_indices: &[u64], cols: usize) -> MatrixMerkleProof {
        let rows_usize: Vec<usize> = row_indices.iter().map(|&r| r as usize).collect();
        let leaves = Self::leaf_indices_from_rows(&rows_usize, cols);
        MatrixMerkleProof {
            proof: self.multileaf_proof(&leaves),
            row_indices: row_indices.to_vec(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn root_matches_merkle_root_fn() {
        // The tree root must equal the streaming keyed merkle_root() for the
        // same data — cross-check the two code paths agree.
        for len in [1usize, 500, 1024, 1025, 2048, 4096, 5000] {
            let data: Vec<u8> = (0..len).map(|i| (i % 251) as u8).collect();
            let key = [0x42u8; 32];
            let tree = MerkleTree::new(&data, key);
            let want = blake3::merkle_root(&data, &key);
            assert_eq!(tree.root(), want, "root mismatch at len {len}");
        }
    }

    #[test]
    fn multileaf_proof_shape() {
        let data: Vec<u8> = (0..8192).map(|i| (i % 251) as u8).collect(); // 8 leaves
        let key = [7u8; 32];
        let tree = MerkleTree::new(&data, key);
        assert_eq!(tree.num_leaves(), 8);
        let p = tree.multileaf_proof(&[0, 3]);
        assert_eq!(p.total_leaves, 8);
        assert_eq!(p.leaf_indices, vec![0, 3]);
        assert_eq!(p.leaf_data.len(), 2);
        assert_eq!(p.root, tree.root());
        assert!(!p.siblings.is_empty());
    }

    #[test]
    fn matrix_proof_opens_rows() {
        // 16 rows x 512 cols = 8192 bytes = 8 leaves (2 rows per leaf).
        let data: Vec<u8> = (0..8192).map(|i| (i % 251) as u8).collect();
        let key = [9u8; 32];
        let tree = MerkleTree::new(&data, key);
        let mp = tree.matrix_proof(&[0, 5], 512);
        assert_eq!(mp.row_indices, vec![0, 5]);
        // row 0 -> leaf 0; row 5 -> byte 2560..3072 -> leaf 2. Two leaves.
        assert_eq!(mp.proof.leaf_indices, vec![0, 2]);
        assert_eq!(mp.proof.root, tree.root());
    }
}
