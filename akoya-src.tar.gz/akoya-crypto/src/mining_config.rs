//! Port of `Akoya.Crypto.MiningConfiguration` + `CommitmentHasher`.
//!
//! Verbatim 52-byte little-endian wire layout of the Pearl proof system's
//! MiningConfiguration, plus the V2 canonical job-key / commitment-hash /
//! noise-seed derivations.

use crate::blake3;

/// MMA type. Only `Int7xInt7ToInt32 = 0` is valid today.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u16)]
pub enum MmaType {
    Int7xInt7ToInt32 = 0,
}

/// A single periodic dimension: `(stride, length)`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Dim {
    pub stride: u32,
    pub length: u32,
}

/// Three-dim periodic pattern. Serializes each dim as 2 bytes
/// `(factor-1, length-1)` where `factor = stride / min_stride`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PeriodicPattern {
    pub d: [Dim; 3],
}

impl PeriodicPattern {
    pub const SERIALIZED_SIZE: usize = 6;

    /// Identity pattern: all dims `(1, 1)`.
    pub fn identity() -> Self {
        PeriodicPattern {
            d: [Dim { stride: 1, length: 1 }; 3],
        }
    }

    pub fn to_bytes(&self) -> [u8; 6] {
        let mut data = [0u8; 6];
        let mut min_stride: u32 = 1;
        for i in 0..3 {
            let (stride, length) = (self.d[i].stride, self.d[i].length);
            let factor = stride / min_stride;
            data[2 * i] = (factor - 1) as u8;
            data[2 * i + 1] = (length - 1) as u8;
            min_stride = stride * length;
        }
        data
    }

    /// Reverse-engineer the `(stride, length)` shape from a sorted, zero-rooted
    /// index list, padding trailing dims with `(period, 1)` to reach 3 dims.
    ///
    /// # Panics
    /// Panics if the pattern is empty, not sorted/unique, does not start at 0,
    /// or is not periodic — matching the C# `ArgumentException` behaviour.
    pub fn from_indices(pattern: &[u32]) -> Self {
        assert!(!pattern.is_empty(), "Pattern cannot be empty");
        for i in 1..pattern.len() {
            assert!(
                pattern[i] > pattern[i - 1],
                "Pattern must be sorted and have no duplicates"
            );
        }
        assert!(pattern[0] == 0, "Pattern must start at 0");

        let mut p: Vec<u32> = pattern.to_vec();
        let mut shape: Vec<Dim> = Vec::new();

        while p.len() > 1 {
            let mut found = false;
            for period in 1..p.len() {
                if p.len() % period != 0 {
                    continue;
                }
                let s = p[period];
                let mut is_periodic = true;
                let mut i = 0;
                while i + period < p.len() {
                    if p[i] + s != p[i + period] {
                        is_periodic = false;
                        break;
                    }
                    i += 1;
                }
                if is_periodic {
                    shape.push(Dim {
                        stride: s,
                        length: (p.len() / period) as u32,
                    });
                    p.truncate(period);
                    found = true;
                    break;
                }
            }
            assert!(found, "Pattern is not periodic");
        }

        shape.reverse();
        let trailing = if shape.is_empty() {
            1
        } else {
            shape[shape.len() - 1].stride * shape[shape.len() - 1].length
        };
        while shape.len() < 3 {
            shape.push(Dim { stride: trailing, length: 1 });
        }

        PeriodicPattern {
            d: [shape[0], shape[1], shape[2]],
        }
    }

    /// Number of elements (product of dim lengths).
    pub fn size(&self) -> u32 {
        self.d[0].length * self.d[1].length * self.d[2].length
    }
}

/// Full mining configuration.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct MiningConfiguration {
    pub common_dim: u32,
    pub rank: u16,
    pub mma_type: MmaType,
    pub rows_pattern: PeriodicPattern,
    pub cols_pattern: PeriodicPattern,
}

impl MiningConfiguration {
    pub const SERIALIZED_SIZE: usize = 52;
    pub const RESERVED_SIZE: usize = 32;

    /// Default rows indices `[0, 8]` (H100 hash-tile pattern).
    pub fn default_rows_indices() -> Vec<u32> {
        vec![0, 8]
    }

    /// Default cols indices: for r in 0..32 emit `(8r, 8r+1)` — 64 values.
    pub fn default_cols_indices() -> Vec<u32> {
        let mut c = vec![0u32; 64];
        for r in 0..32 {
            c[2 * r] = (8 * r) as u32;
            c[2 * r + 1] = (8 * r + 1) as u32;
        }
        c
    }

    /// Default configuration: `common_dim = k`, `rank = 128`, Int7 MMA,
    /// default H100 row/col hash-tile patterns.
    pub fn default_with(common_dim: u32, rank: u16) -> Self {
        MiningConfiguration {
            common_dim,
            rank,
            mma_type: MmaType::Int7xInt7ToInt32,
            rows_pattern: PeriodicPattern::from_indices(&Self::default_rows_indices()),
            cols_pattern: PeriodicPattern::from_indices(&Self::default_cols_indices()),
        }
    }

    /// Protocol dot-product length: `common_dim` floor-rounded to the MMA quantum.
    pub fn dot_product_length(&self) -> u32 {
        let quantum: u32 = match self.mma_type {
            MmaType::Int7xInt7ToInt32 => 128,
        };
        (self.common_dim / quantum) * quantum
    }

    /// Difficulty adjustment factor: `rows.size * cols.size * dot_product_length`.
    pub fn difficulty_adjustment_factor(&self) -> u64 {
        self.rows_pattern.size() as u64
            * self.cols_pattern.size() as u64
            * self.dot_product_length() as u64
    }

    pub fn to_bytes(&self) -> [u8; 52] {
        let mut buf = [0u8; 52];
        buf[0..4].copy_from_slice(&self.common_dim.to_le_bytes());
        buf[4..6].copy_from_slice(&self.rank.to_le_bytes());
        buf[6..8].copy_from_slice(&(self.mma_type as u16).to_le_bytes());
        buf[8..14].copy_from_slice(&self.rows_pattern.to_bytes());
        buf[14..20].copy_from_slice(&self.cols_pattern.to_bytes());
        // buf[20..52] reserved — already zero.
        buf
    }
}

/// V2/V3 commitment-key / commitment-hash / noise-seed derivations.
///
/// Pearl hard-forked at the salted-seed height (mainnet block 99000): from the
/// fork on, `getblocktemplate` / the pool's job reports `cert_version = 3` and
/// miners MUST salt each Merkle root (binding its matrix dimension) before the
/// seed chain. Pre-fork software derives seeds the old way and produces shares
/// the pool rejects — which is exactly the "full hashrate, nothing accepted"
/// failure. Always drive this from the job's `cert_version`; never hardcode
/// the fork height.
pub mod commitment {
    use super::*;

    /// Noise-seed derivation version, selected per job by `cert_version`.
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub enum SeedDerivation {
        /// V1/V2 (pre-fork): raw roots feed the seed chain.
        Legacy,
        /// V3 (salted-seed fork): roots are dimension-bound before the chain.
        Salted,
    }

    impl SeedDerivation {
        /// Map a job's `cert_version` to the derivation it requires.
        /// 1/2 → Legacy, 3 → Salted.
        pub fn from_cert_version(cert_version: u32) -> Self {
            match cert_version {
                3 => SeedDerivation::Salted,
                _ => SeedDerivation::Legacy,
            }
        }
    }

    /// V2 canonical 32-byte job key: `BLAKE3(incomplete_header ‖ config_bytes)`.
    /// No minerId is mixed in (network block-find consensus has no miner identity).
    /// Unchanged by the V3 fork.
    pub fn get_key(incomplete_header_bytes: &[u8], mining_config: &MiningConfiguration) -> [u8; 32] {
        let cfg = mining_config.to_bytes();
        let mut input = Vec::with_capacity(incomplete_header_bytes.len() + cfg.len());
        input.extend_from_slice(incomplete_header_bytes);
        input.extend_from_slice(&cfg);
        blake3::hash(&input)
    }

    /// Keyed commitment hashes for A and B slices. Unchanged by the fork —
    /// shares still carry the raw roots on the wire.
    pub fn commitment_hashes(job_key: &[u8; 32], a_slice: &[u8], b_slice: &[u8]) -> ([u8; 32], [u8; 32]) {
        (
            blake3::keyed_hash(job_key, a_slice),
            blake3::keyed_hash(job_key, b_slice),
        )
    }

    /// V3 domain-separation salts (keys for the root-binding BLAKE3).
    fn seed_salt_a() -> [u8; 32] {
        blake3::hash(b"pearl/cert-v3/noise-seed/A")
    }
    fn seed_salt_b() -> [u8; 32] {
        blake3::hash(b"pearl/cert-v3/noise-seed/B")
    }

    /// Bind a Merkle root to its matrix dimension (V3). The message is exactly
    /// one 64-byte BLAKE3 block: `root(32) ‖ dim_le32(4) ‖ 0^28`, keyed by the
    /// domain salt.
    fn bind_root(root: &[u8; 32], dim: u32, salt: &[u8; 32]) -> [u8; 32] {
        let mut msg = [0u8; 64];
        msg[..32].copy_from_slice(root);
        msg[32..36].copy_from_slice(&dim.to_le_bytes());
        // msg[36..64] left as 28 zero bytes.
        blake3::keyed_hash(salt, &msg)
    }

    /// V3 salting of A's Merkle root; commits the row count `m`.
    pub fn bind_root_a(a_merkle_root: &[u8; 32], m: u32) -> [u8; 32] {
        bind_root(a_merkle_root, m, &seed_salt_a())
    }

    /// V3 salting of B's Merkle root; commits the column count `n`.
    pub fn bind_root_b(b_merkle_root: &[u8; 32], n: u32) -> [u8; 32] {
        bind_root(b_merkle_root, n, &seed_salt_b())
    }

    /// V2 (legacy) chained noise seeds:
    /// `b_noise_seed = BLAKE3(job_key ‖ hash_b)`,
    /// `a_noise_seed = BLAKE3(b_noise_seed ‖ hash_a)`.
    pub fn derive_noise_seeds(
        job_key: &[u8; 32],
        hash_a: &[u8; 32],
        hash_b: &[u8; 32],
    ) -> ([u8; 32], [u8; 32]) {
        let mut b_input = [0u8; 64];
        b_input[..32].copy_from_slice(job_key);
        b_input[32..].copy_from_slice(hash_b);
        let b_noise_seed = blake3::hash(&b_input);

        let mut a_input = [0u8; 64];
        a_input[..32].copy_from_slice(&b_noise_seed);
        a_input[32..].copy_from_slice(hash_a);
        let a_noise_seed = blake3::hash(&a_input);

        (b_noise_seed, a_noise_seed)
    }

    /// Version-aware noise-seed derivation. For `SeedDerivation::Salted` (V3),
    /// each root is dimension-bound (`m` for A, `n` for B) before the otherwise
    /// unchanged seed chain. `SeedDerivation::Legacy` ignores `m`/`n` and
    /// matches [`derive_noise_seeds`] exactly.
    pub fn derive_noise_seeds_versioned(
        job_key: &[u8; 32],
        hash_a: &[u8; 32],
        hash_b: &[u8; 32],
        m: u32,
        n: u32,
        derivation: SeedDerivation,
    ) -> ([u8; 32], [u8; 32]) {
        match derivation {
            SeedDerivation::Legacy => derive_noise_seeds(job_key, hash_a, hash_b),
            SeedDerivation::Salted => {
                let bound_a = bind_root_a(hash_a, m);
                let bound_b = bind_root_b(hash_b, n);
                derive_noise_seeds(job_key, &bound_a, &bound_b)
            }
        }
    }
}
