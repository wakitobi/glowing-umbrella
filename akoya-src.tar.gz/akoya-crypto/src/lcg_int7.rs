//! Port of `Akoya.Crypto.LcgInt7` — host-side replay of
//! `pearl_capi_lcg_int7_fill`.
//!
//! Byte-identical to the device kernel and the Python reference. Produces
//! signed int7 values in `[-63, +63]`.

#[inline]
fn split_mix64(mut z: u64) -> u64 {
    z = z.wrapping_add(0x9E37_79B9_7F4A_7C15);
    z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
    z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
    z ^ (z >> 31)
}

/// Fill `dst` with deterministic int7 bytes derived from `(seed_lo, seed_hi)`.
pub fn fill(dst: &mut [i8], seed_lo: u64, seed_hi: u64) {
    let base_seed = split_mix64(seed_lo ^ split_mix64(seed_hi));
    let n = dst.len() as i64;
    let n8 = n / 8;

    for i in 0..n8 {
        let z = split_mix64(base_seed.wrapping_add(i as u64));
        for b in 0..8 {
            let v = ((z >> (b * 8)) & 0xFF) as u32;
            let r = v % 127;
            dst[(i * 8 + b as i64) as usize] = (r as i32 - 63) as i8;
        }
    }

    let tail_off = n8 * 8;
    let tail_len = n - tail_off;
    if tail_len > 0 {
        let z = split_mix64(base_seed.wrapping_add(n8 as u64));
        for b in 0..tail_len {
            let v = ((z >> (b * 8)) & 0xFF) as u32;
            let r = v % 127;
            dst[(tail_off + b) as usize] = (r as i32 - 63) as i8;
        }
    }
}

/// Allocate a fresh `n`-byte int7 buffer and fill it (raw `u8` reinterpretation).
pub fn fill_new(n: usize, seed_lo: u64, seed_hi: u64) -> Vec<u8> {
    let mut arr = vec![0i8; n];
    fill(&mut arr, seed_lo, seed_hi);
    // reinterpret i8 -> u8 (bit-identical)
    arr.into_iter().map(|x| x as u8).collect()
}
