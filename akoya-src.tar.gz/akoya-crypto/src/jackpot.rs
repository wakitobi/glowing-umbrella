//! Port of `Akoya.Crypto.JackpotComputer` — Pearl jackpot accumulator words
//! and keyed-BLAKE3 jackpot hash.

use crate::blake3;
use crate::noise::{self, PermutationPair};

pub const JACKPOT_SIZE: usize = 16;
const ROTATE_LEFT: u32 = 13;

/// Compute the 16 jackpot words from signal and pre-expanded noise slices.
///
/// `secret_a`: h x k, `secret_b`: w x k, `noise_a`: h x k, `noise_b`: w x k.
pub fn compute(
    h: usize,
    w: usize,
    k: usize,
    r: usize,
    secret_a: &[Vec<i8>],
    secret_b: &[Vec<i8>],
    noise_a: &[Vec<i8>],
    noise_b: &[Vec<i8>],
) -> [u32; JACKPOT_SIZE] {
    let mut tile = vec![vec![0i32; w]; h];
    let mut msg = [0u32; JACKPOT_SIZE];

    let mut ll = r;
    while ll <= k {
        for u in 0..h {
            for v in 0..w {
                let mut acc = tile[u][v];
                for l in (ll - r)..ll {
                    let a = secret_a[u][l] as i32 + noise_a[u][l] as i32;
                    let b = secret_b[v][l] as i32 + noise_b[v][l] as i32;
                    acc = acc.wrapping_add(a.wrapping_mul(b));
                }
                tile[u][v] = acc;
            }
        }

        let mut xored: u32 = 0;
        for u in 0..h {
            for v in 0..w {
                xored ^= tile[u][v] as u32;
            }
        }

        let tid = ((ll / r) - 1) % JACKPOT_SIZE;
        msg[tid] = msg[tid].rotate_left(ROTATE_LEFT) ^ xored;

        ll += r;
    }
    msg
}

/// Compute jackpot from raw E matrices (expands noise internally).
#[allow(clippy::too_many_arguments)]
pub fn compute_from_e(
    h: usize,
    w: usize,
    k: usize,
    r: usize,
    secret_a: &[Vec<i8>],
    secret_b: &[Vec<i8>],
    e_al: &[Vec<i8>],
    e_ar: &[PermutationPair],
    e_bl: &[PermutationPair],
    e_br: &[Vec<i8>],
) -> [u32; JACKPOT_SIZE] {
    let noise_a: Vec<Vec<i8>> = e_al
        .iter()
        .map(|row| noise::apply_sparse_permutation(e_ar, row))
        .collect();
    let noise_b: Vec<Vec<i8>> = e_br
        .iter()
        .map(|row| noise::apply_sparse_permutation(e_bl, row))
        .collect();
    compute(h, w, k, r, secret_a, secret_b, &noise_a, &noise_b)
}

/// Keyed-BLAKE3 jackpot hash over the 16 little-endian jackpot words.
pub fn hash(jackpot_words: &[u32; JACKPOT_SIZE], a_noise_seed: &[u8; 32]) -> [u8; 32] {
    let mut buf = [0u8; JACKPOT_SIZE * 4];
    for (i, w) in jackpot_words.iter().enumerate() {
        buf[i * 4..i * 4 + 4].copy_from_slice(&w.to_le_bytes());
    }
    blake3::keyed_hash(a_noise_seed, &buf)
}
