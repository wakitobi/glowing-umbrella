//! Pearl `PlainProof` wire format — bincode (fixint) serialization matching
//! `pearl-research-labs/pearl` `zk-pow/src/ffi/plain_proof.rs`.
//!
//! DISCOVERY (Aug 2026, via live LuckyPool submit probe): LuckyPool's
//! `mining.submit` does NOT take a nonce. It takes a serialized `PlainProof`.
//! The pool decodes the submitted bytes trying gzip → plain → zstd, then
//! bincode-deserializes with `with_fixint_encoding`, accepting the current
//! format or a legacy V1 blob (same layout minus the trailing `moe` Option
//! tag). Field lookup: the pool finds the job by `job_id` FIRST (wrong id ⇒
//! code 21 "stale"), then decodes the proof.
//!
//! Struct layout (bincode fixint, little-endian, field order EXACT):
//!   PlainProof {
//!     m: u64, n: u64, k: u64, noise_rank: u64,       // usize -> 8 bytes each
//!     a: MatrixMerkleProof,
//!     bt: MatrixMerkleProof,
//!     moe: Option<MoEProofParams>,                    // 0x00 = None, 0x01 = Some
//!   }
//!   MatrixMerkleProof { proof: MerkleProof, row_indices: Vec<u64> }
//!   MerkleProof {
//!     leaf_data:    Vec<Vec<u8>>,   // serde_chunk_vec: each leaf is 1024 bytes
//!     leaf_indices: Vec<u64>,
//!     total_leaves: u64,
//!     root:         [u8; 32],       // fixed array — 32 raw bytes, no length
//!     siblings:     Vec<[u8; 32]>,  // u64 count + 32 bytes each
//!   }
//!
//! bincode fixint rules used here:
//!   - Vec<T>            => u64 length prefix, then elements
//!   - usize             => 8 bytes LE (fixint)
//!   - [u8; 32]          => 32 raw bytes (no length prefix)
//!   - Option<T>         => 1 tag byte (0/1), then the value if Some
//!
//! We serialize by hand (no bincode dep needed at consumers) but ALSO provide
//! serde structs so we can cross-check against the `bincode` crate in tests.

use serde::{Deserialize, Serialize};

pub const CHUNK_LEN: usize = 1024;
pub const DIGEST_LEN: usize = 32;

/// BLAKE3 keyed-merkle inclusion proof for one matrix (row-major int8 bytes).
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct MerkleProof {
    /// Opened leaves — each exactly `CHUNK_LEN` (1024) bytes. Serialized via
    /// the upstream `serde_chunk_vec` shim as `Vec<Vec<u8>>`.
    #[serde(with = "serde_chunk_vec")]
    pub leaf_data: Vec<[u8; CHUNK_LEN]>,
    pub leaf_indices: Vec<u64>,
    pub total_leaves: u64,
    pub root: [u8; DIGEST_LEN],
    pub siblings: Vec<[u8; DIGEST_LEN]>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct MatrixMerkleProof {
    pub proof: MerkleProof,
    pub row_indices: Vec<u64>,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct MoEProofParams {
    pub e: u64,
    pub top_k: u64,
    pub expert_idx: u16,
    pub routing_end_offsets: Vec<u32>,
    pub inner_a_rows: Vec<u64>,
    pub routing_proof: MerkleProof,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq)]
pub struct PlainProof {
    pub m: u64,
    pub n: u64,
    pub k: u64,
    pub noise_rank: u64,
    pub a: MatrixMerkleProof,
    pub bt: MatrixMerkleProof,
    pub moe: Option<MoEProofParams>,
}

/// Matches upstream `serde_chunk_vec`: leaves serialize as `Vec<Vec<u8>>`.
mod serde_chunk_vec {
    use super::CHUNK_LEN;
    use serde::{Deserialize, Deserializer, Serialize, Serializer};

    pub fn serialize<S: Serializer>(
        data: &[[u8; CHUNK_LEN]],
        serializer: S,
    ) -> Result<S::Ok, S::Error> {
        let vecs: Vec<&[u8]> = data.iter().map(|a| a.as_slice()).collect();
        vecs.serialize(serializer)
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(
        deserializer: D,
    ) -> Result<Vec<[u8; CHUNK_LEN]>, D::Error> {
        let vecs: Vec<Vec<u8>> = Vec::deserialize(deserializer)?;
        vecs.into_iter()
            .map(|v| {
                v.try_into()
                    .map_err(|_| serde::de::Error::custom("leaf data must be CHUNK_LEN bytes"))
            })
            .collect()
    }
}

/// bincode options that MATCH the pool's `bincode::options().with_fixint_encoding()`.
fn bincode_opts() -> impl bincode::Options {
    use bincode::Options;
    bincode::options()
        .with_fixint_encoding()
        .with_little_endian()
        .allow_trailing_bytes()
}

impl PlainProof {
    /// Serialize exactly as the pool's `deserialize_compat` expects (bincode
    /// fixint LE). This is the `plain` (uncompressed) form.
    pub fn to_bincode(&self) -> Result<Vec<u8>, bincode::Error> {
        use bincode::Options;
        bincode_opts().serialize(self)
    }

    /// Parse from bincode fixint bytes (the `plain` decode path).
    pub fn from_bincode(bytes: &[u8]) -> Result<Self, bincode::Error> {
        use bincode::Options;
        bincode_opts().deserialize(bytes)
    }

    /// gzip-compress the bincode form (the pool's `gzip` decode path).
    pub fn to_gzip(&self) -> Result<Vec<u8>, std::io::Error> {
        use flate2::write::GzEncoder;
        use flate2::Compression;
        use std::io::Write;
        let raw = self
            .to_bincode()
            .map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
        let mut enc = GzEncoder::new(Vec::new(), Compression::default());
        enc.write_all(&raw)?;
        enc.finish()
    }

    /// Base64 (standard) of the plain bincode form — the most common JSON
    /// carrier for a binary proof field.
    pub fn to_base64(&self) -> Result<String, bincode::Error> {
        use base64::{engine::general_purpose::STANDARD, Engine as _};
        Ok(STANDARD.encode(self.to_bincode()?))
    }

    /// Lowercase hex of the plain bincode form.
    pub fn to_hex(&self) -> Result<String, bincode::Error> {
        let bytes = self.to_bincode()?;
        let mut s = String::with_capacity(bytes.len() * 2);
        for b in bytes {
            s.push_str(&format!("{b:02x}"));
        }
        Ok(s)
    }

    /// A structurally-valid dummy proof for wire-format PROBING only. It has
    /// consistent declared dimensions and one opened leaf per matrix, so the
    /// pool will DECODE it successfully (bincode + tree-size checks that only
    /// look at counts) and then fail later on merkle-root / PoW-target
    /// verification — which is exactly the signal that the wire format is
    /// correct. NOT a valid share.
    pub fn dummy_for_probe(m: u64, n: u64, k: u64, noise_rank: u64) -> Self {
        let mk = |total_leaves: u64, rows: u64| MatrixMerkleProof {
            proof: MerkleProof {
                leaf_data: vec![[0u8; CHUNK_LEN]],
                leaf_indices: vec![0],
                total_leaves,
                root: [0u8; DIGEST_LEN],
                siblings: vec![[0u8; DIGEST_LEN]],
            },
            row_indices: (0..rows).collect(),
        };
        // A tree: m*k int8 bytes -> padded to CHUNK_LEN leaves.
        let a_leaves = ((m * k) as usize).div_ceil(CHUNK_LEN).max(1) as u64;
        let b_leaves = ((n * k) as usize).div_ceil(CHUNK_LEN).max(1) as u64;
        PlainProof {
            m,
            n,
            k,
            noise_rank,
            a: mk(a_leaves, 8),
            bt: mk(b_leaves, 8),
            moe: None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bincode_roundtrip() {
        let p = PlainProof::dummy_for_probe(192, 320, 4096, 4);
        let bytes = p.to_bincode().unwrap();
        let back = PlainProof::from_bincode(&bytes).unwrap();
        assert_eq!(p, back);
    }

    #[test]
    fn option_none_tag_is_last_byte() {
        // The trailing `moe: None` must serialize to a single 0x00 tag byte,
        // matching the pool's BINCODE_OPTION_NONE_TAG legacy-pad logic.
        let p = PlainProof::dummy_for_probe(8, 8, 1024, 1);
        let bytes = p.to_bincode().unwrap();
        assert_eq!(*bytes.last().unwrap(), 0x00, "moe None tag must be trailing 0x00");
    }

    #[test]
    fn header_fields_are_le_u64() {
        // First 32 bytes = m,n,k,noise_rank as u64 LE.
        let p = PlainProof::dummy_for_probe(0x11, 0x22, 0x33, 0x44);
        let b = p.to_bincode().unwrap();
        assert_eq!(&b[0..8], &[0x11, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(&b[8..16], &[0x22, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(&b[16..24], &[0x33, 0, 0, 0, 0, 0, 0, 0]);
        assert_eq!(&b[24..32], &[0x44, 0, 0, 0, 0, 0, 0, 0]);
    }

    #[test]
    fn gzip_and_base64_produce_output() {
        let p = PlainProof::dummy_for_probe(192, 320, 4096, 4);
        assert!(!p.to_gzip().unwrap().is_empty());
        assert!(!p.to_base64().unwrap().is_empty());
        assert!(!p.to_hex().unwrap().is_empty());
    }
}
