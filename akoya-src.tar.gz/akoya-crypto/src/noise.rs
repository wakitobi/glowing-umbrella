//! Port of `Akoya.Crypto.NoiseGenerator` — deterministic Pearl noise
//! generation using keyed BLAKE3 counter mode.

use crate::blake3;

const DIGEST_SIZE: usize = 32;
const UNIFORM_RANGE: i32 = 64;
const ZERO_POINT: i32 = UNIFORM_RANGE / 2;
const RANGE_MASK: u8 = (UNIFORM_RANGE - 1) as u8;
const BYTES_PER_LINE: usize = 4;
const LINES_PER_HASH: usize = DIGEST_SIZE / BYTES_PER_LINE;

/// A sparse permutation entry: two indices whose difference forms the noise.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PermutationPair {
    pub first_index: u32,
    pub second_index: u32,
}

/// High 32 bits of the 64-bit product `a * b`.
#[inline]
pub fn mul_hi_u32(a: u32, b: u32) -> u32 {
    (((a as u64) * (b as u64)) >> 32) as u32
}

/// Keyed BLAKE3 hash of a 64-byte message: `u32_le(index+1)` placed at word
/// `prepend_index`, followed by the 32-byte seed at offset 32.
pub fn get_random_hash(index: u32, seed: &[u8; 32], key: &[u8; 32], prepend_index: usize) -> [u8; 32] {
    let mut message = [0u8; 64];
    let val = index.checked_add(1).expect("index overflow");
    message[prepend_index * 4..prepend_index * 4 + 4].copy_from_slice(&val.to_le_bytes());
    message[32..].copy_from_slice(seed);
    blake3::keyed_hash(key, &message)
}

/// Generate a uniform-random int8 matrix (rows selected by `row_indices`),
/// each element mapped to `[-32, 31]` via `(byte & 63) - 32`.
pub fn generate_uniform_random_matrix(
    seed: &[u8; 32],
    key: &[u8; 32],
    row_indices: &[u32],
    num_cols: usize,
) -> Vec<Vec<i8>> {
    let mut rows = Vec::with_capacity(row_indices.len());
    for &row_index in row_indices {
        let start_index = row_index as i64 * num_cols as i64;
        let end_index = start_index + num_cols as i64;
        let start_block = (start_index / DIGEST_SIZE as i64) as i64;
        let end_block = (end_index + DIGEST_SIZE as i64 - 1) / DIGEST_SIZE as i64;

        let mut values = Vec::with_capacity(num_cols);
        for block in start_block..end_block {
            let hash = get_random_hash(block as u32, seed, key, 0);
            for (i, &byte) in hash.iter().enumerate() {
                let abs_idx = block * DIGEST_SIZE as i64 + i as i64;
                if abs_idx < start_index || abs_idx >= end_index {
                    continue;
                }
                values.push(((byte & RANGE_MASK) as i32 - ZERO_POINT) as i8);
            }
        }
        rows.push(values);
    }
    rows
}

/// Generate a sparse permutation matrix of length `k`.
pub fn generate_permutation_matrix(
    seed: &[u8; 32],
    key: &[u8; 32],
    k: usize,
    noise_rank: usize,
) -> Vec<PermutationPair> {
    let rank_mask = (noise_rank - 1) as u32;
    let mut result = vec![PermutationPair { first_index: 0, second_index: 0 }; k];

    let mut chunk = 0usize;
    while chunk * LINES_PER_HASH < k {
        let hash = get_random_hash(chunk as u32, seed, key, 1);
        let len = LINES_PER_HASH.min(k - chunk * LINES_PER_HASH);
        for j in 0..len {
            let rand = u32::from_le_bytes([
                hash[j * BYTES_PER_LINE],
                hash[j * BYTES_PER_LINE + 1],
                hash[j * BYTES_PER_LINE + 2],
                hash[j * BYTES_PER_LINE + 3],
            ]);
            let first = rand & rank_mask;
            let second = first ^ (1u32.wrapping_add(mul_hi_u32((noise_rank - 1) as u32, rand)));
            result[chunk * LINES_PER_HASH + j] = PermutationPair {
                first_index: first,
                second_index: second,
            };
        }
        chunk += 1;
    }
    result
}

/// Apply a sparse permutation to a vector: `result[i] = v[first] - v[second]`.
pub fn apply_sparse_permutation(perm: &[PermutationPair], vector: &[i8]) -> Vec<i8> {
    perm.iter()
        .map(|p| {
            vector[p.first_index as usize].wrapping_sub(vector[p.second_index as usize])
        })
        .collect()
}

/// Domain-separation seed labels (`"A_tensor"` / `"B_tensor"`, zero-padded to 32).
pub mod seed_labels {
    fn label(prefix: &[u8]) -> [u8; 32] {
        let mut out = [0u8; 32];
        out[..prefix.len()].copy_from_slice(prefix);
        out
    }
    pub fn a() -> [u8; 32] {
        label(b"A_tensor")
    }
    pub fn b() -> [u8; 32] {
        label(b"B_tensor")
    }
}
