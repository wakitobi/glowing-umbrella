//! Port of `Akoya.Crypto.BSeedExpander` — deterministic per-miner B-matrix
//! generation via BLAKE3-XOF plus int7 mapping, and the keyed-Merkle HashB.

use crate::blake3;

/// Map a raw XOF byte to int7 in `[-63, +63]`: `(byte % 127) - 63`.
#[inline]
fn map_int7(byte: u8) -> u8 {
    (((byte % 127) as i32 - 63) as i8) as u8
}

/// Expand a 32-byte B-seed into `n*k` bytes of int7 values in `[-63, +63]`.
/// Row-major: `B[i,j]` at offset `i*k + j`.
///
/// # Panics
/// Panics if `b_seed.len() != 32` or `n == 0 || k == 0`.
pub fn expand_raw(b_seed: &[u8; 32], n: usize, k: usize) -> Vec<u8> {
    assert!(n != 0 && k != 0, "n and k must be positive");
    let total = n.checked_mul(k).expect("n*k overflow");
    let mut xof_buf = vec![0u8; total];
    blake3::xof(b_seed, &mut xof_buf);
    for byte in xof_buf.iter_mut() {
        *byte = map_int7(*byte);
    }
    xof_buf
}

/// Fill a caller-supplied buffer (>= `n*k` bytes) with the int7 expansion.
pub fn expand_raw_into(b_seed: &[u8; 32], n: usize, k: usize, dst: &mut [u8]) {
    assert!(n != 0 && k != 0, "n and k must be positive");
    let total = n.checked_mul(k).expect("n*k overflow");
    assert!(dst.len() >= total, "destination too small");
    blake3::xof(b_seed, &mut dst[..total]);
    for byte in dst[..total].iter_mut() {
        *byte = map_int7(*byte);
    }
}

/// Random-access expansion of the int7 byte range
/// `[byte_offset, byte_offset + dst.len())` without materializing the rest.
pub fn expand_range_raw(b_seed: &[u8; 32], byte_offset: u64, dst: &mut [u8]) {
    if dst.is_empty() {
        return;
    }
    blake3::xof_at(b_seed, byte_offset, dst);
    for byte in dst.iter_mut() {
        *byte = map_int7(*byte);
    }
}

/// Expand B and compute the expected HashB as the keyed-BLAKE3 Merkle root.
pub fn expand_and_compute_hash_b(b_seed: &[u8; 32], n: usize, k: usize, job_key: &[u8; 32]) -> [u8; 32] {
    let b_bytes = expand_raw(b_seed, n, k);
    blake3::merkle_root(&b_bytes, job_key)
}
