//! GPU detection via the CUDA driver API (`nvcuda.dll` / `libcuda.so.1`),
//! loaded at runtime with `libloading`. Mirrors the parts of `Akoya.Cuda`
//! the miner needs: enumerate devices, read name + compute capability.
//!
//! This is intentionally dependency-light and never links CUDA at build time,
//! so the host binary builds and runs `selftest`/`version` on machines with
//! no GPU.

use std::ffi::{c_char, c_int, c_void, CStr};

use libloading::Library;

#[cfg(target_os = "windows")]
const CUDA_LIB: &str = "nvcuda.dll";
#[cfg(all(unix, not(target_os = "macos")))]
const CUDA_LIB: &str = "libcuda.so.1";
#[cfg(target_os = "macos")]
const CUDA_LIB: &str = "libcuda.dylib";

/// A detected CUDA device.
#[derive(Clone, Debug)]
pub struct GpuInfo {
    pub index: i32,
    pub name: String,
    pub cc_major: i32,
    pub cc_minor: i32,
}

impl GpuInfo {
    /// Human-readable architecture label matching the miner's arch table.
    pub fn arch_label(&self) -> &'static str {
        match (self.cc_major, self.cc_minor) {
            (12, _) => "blackwell",
            (10, _) => "b200",
            (9, _) => "h100",
            (8, 9) => "ada",
            (8, _) => "ampere",
            (7, 5) => "turing",
            (7, _) => "volta",
            _ => "portable",
        }
    }
}

/// Attempt to enumerate CUDA devices. Returns an empty vec (with a reason in
/// the `Err`) when the driver is missing or no device is present — callers
/// that only need `selftest`/`version` can ignore the error.
pub fn detect_gpus() -> Result<Vec<GpuInfo>, String> {
    // SAFETY: we load the CUDA driver library and call documented C ABI
    // entry points with correct signatures.
    unsafe {
        let lib = Library::new(CUDA_LIB).map_err(|e| format!("cannot load {CUDA_LIB}: {e}"))?;

        type CuInit = unsafe extern "C" fn(c_int) -> c_int;
        type CuDeviceGetCount = unsafe extern "C" fn(*mut c_int) -> c_int;
        type CuDeviceGet = unsafe extern "C" fn(*mut c_int, c_int) -> c_int;
        type CuDeviceGetName = unsafe extern "C" fn(*mut c_char, c_int, c_int) -> c_int;
        type CuDeviceGetAttribute = unsafe extern "C" fn(*mut c_int, c_int, c_int) -> c_int;

        let cu_init: libloading::Symbol<CuInit> =
            lib.get(b"cuInit").map_err(|e| e.to_string())?;
        let cu_count: libloading::Symbol<CuDeviceGetCount> =
            lib.get(b"cuDeviceGetCount").map_err(|e| e.to_string())?;
        let cu_get: libloading::Symbol<CuDeviceGet> =
            lib.get(b"cuDeviceGet").map_err(|e| e.to_string())?;
        let cu_name: libloading::Symbol<CuDeviceGetName> =
            lib.get(b"cuDeviceGetName").map_err(|e| e.to_string())?;
        let cu_attr: libloading::Symbol<CuDeviceGetAttribute> =
            lib.get(b"cuDeviceGetAttribute").map_err(|e| e.to_string())?;

        // CUdevice_attribute: COMPUTE_CAPABILITY_MAJOR = 75, MINOR = 76.
        const ATTR_CC_MAJOR: c_int = 75;
        const ATTR_CC_MINOR: c_int = 76;

        if cu_init(0) != 0 {
            return Err("cuInit failed (no usable CUDA driver/device)".into());
        }
        let mut count: c_int = 0;
        if cu_count(&mut count) != 0 {
            return Err("cuDeviceGetCount failed".into());
        }

        let mut out = Vec::new();
        for i in 0..count {
            let mut dev: c_int = 0;
            if cu_get(&mut dev, i) != 0 {
                continue;
            }
            let mut buf = [0i8; 256];
            let name = if cu_name(buf.as_mut_ptr() as *mut c_char, 256, dev) == 0 {
                CStr::from_ptr(buf.as_ptr() as *const c_char)
                    .to_string_lossy()
                    .into_owned()
            } else {
                "unknown".to_string()
            };
            let mut major: c_int = 0;
            let mut minor: c_int = 0;
            cu_attr(&mut major, ATTR_CC_MAJOR, dev);
            cu_attr(&mut minor, ATTR_CC_MINOR, dev);
            out.push(GpuInfo {
                index: i,
                name,
                cc_major: major,
                cc_minor: minor,
            });
        }
        Ok(out)
    }
}

/// Silence the unused-import lint on platforms where `c_void` isn't used.
#[allow(dead_code)]
fn _use_c_void(_: *mut c_void) {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn arch_label_table() {
        let mk = |maj, min| GpuInfo {
            index: 0,
            name: "x".into(),
            cc_major: maj,
            cc_minor: min,
        };
        assert_eq!(mk(7, 5).arch_label(), "turing"); // Tesla T4
        assert_eq!(mk(8, 0).arch_label(), "ampere"); // A100
        assert_eq!(mk(8, 9).arch_label(), "ada"); // RTX 40xx
        assert_eq!(mk(9, 0).arch_label(), "h100");
        assert_eq!(mk(12, 0).arch_label(), "blackwell");
        assert_eq!(mk(6, 1).arch_label(), "portable");
    }
}
