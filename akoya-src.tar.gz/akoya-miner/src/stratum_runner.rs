//! `stratum` subcommand: connect to a LuckyPool-style Pearl pool (JSON-over-TLS),
//! authorize the wallet, and run the job loop.
//!
//! This is the wire protocol used by endpoints like `pearl-sg1.lproute.com:3360`
//! — distinct from the Akoya gRPC V2 gateway handled by `run_mine`. Jobs are
//! logged and (on a GPU host with the native lib) handed to the GEMM worker;
//! the actual share solve/submit is gated on CUDA hardware.

use std::time::Duration;

use akoya_stratum::{Inbound, StratumClient, StratumConfig, StratumError};

/// Stratum connection settings sourced from `AKOYA_*` env vars.
pub struct StratumSettings {
    pub host: String,
    pub port: u16,
    pub wallet: String,
    pub worker: String,
    pub insecure_tls: bool,
}

impl StratumSettings {
    pub fn from_env() -> Result<Self, String> {
        let host = std::env::var("AKOYA_STRATUM_HOST")
            .or_else(|_| std::env::var("AKOYA_POOL_HOST"))
            .map_err(|_| "AKOYA_STRATUM_HOST (or AKOYA_POOL_HOST) is required".to_string())?;
        let port: u16 = std::env::var("AKOYA_STRATUM_PORT")
            .or_else(|_| std::env::var("AKOYA_POOL_PORT"))
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(3360);
        let wallet = std::env::var("AKOYA_POOL_WALLET")
            .map_err(|_| "AKOYA_POOL_WALLET is required".to_string())?;
        let worker = std::env::var("AKOYA_POOL_WORKER").unwrap_or_else(|_| "rig01".to_string());
        // LuckyPool uses a self-signed cert; accept it unless the operator
        // explicitly opts into strict verification.
        let insecure_tls = std::env::var("AKOYA_STRATUM_STRICT_TLS")
            .map(|v| v != "1" && !v.eq_ignore_ascii_case("true"))
            .unwrap_or(true);
        Ok(Self {
            host,
            port,
            wallet,
            worker,
            insecure_tls,
        })
    }
}

/// Connect, authorize, then loop over jobs until the stream ends or a fatal
/// error occurs. Returns `Ok(())` on a clean stream end (caller reconnects).
pub async fn run(settings: &StratumSettings, has_gpu: bool) -> Result<(), StratumError> {
    let mut cfg = StratumConfig::new(&settings.host, settings.port, &settings.wallet);
    cfg.worker = settings.worker.clone();
    cfg.insecure_tls = settings.insecure_tls;

    tracing::info!(
        "stratum: connecting to {}:{} (tls_insecure={})",
        settings.host,
        settings.port,
        settings.insecure_tls
    );
    let mut client = StratumClient::connect(&cfg).await?;
    tracing::info!("stratum: TLS connected — authorizing wallet={} worker={}", settings.wallet, settings.worker);

    let jobs = client.authorize(&cfg).await?;
    tracing::info!("stratum: authorized ✓ ({} job(s) during handshake)", jobs.len());
    for j in &jobs {
        log_job(j, has_gpu);
    }

    loop {
        // Idle watchdog: the pool pushes a fresh job well within 2 minutes.
        match tokio::time::timeout(Duration::from_secs(120), client.next_inbound()).await {
            Ok(Ok(Inbound::Notify(job))) => log_job(&job, has_gpu),
            Ok(Ok(Inbound::SetDifficulty(v))) => {
                tracing::info!("stratum: set_difficulty {v}");
            }
            Ok(Ok(Inbound::Result { id, ok, error })) => {
                if let Some(err) = error {
                    tracing::warn!("stratum: result id={id} error={err}");
                } else {
                    tracing::info!("stratum: result id={id} ok={ok:?}");
                }
            }
            Ok(Ok(Inbound::Other { method, .. })) => {
                tracing::debug!("stratum: unhandled server method={method}");
            }
            Ok(Err(StratumError::Closed)) => {
                tracing::info!("stratum: pool closed the connection");
                return Ok(());
            }
            Ok(Err(e)) => return Err(e),
            Err(_) => {
                tracing::warn!("stratum: no job within 120s — reconnecting");
                return Ok(());
            }
        }
    }
}

fn log_job(j: &akoya_stratum::NotifyParams, has_gpu: bool) {
    tracing::info!(
        "stratum: job job_id={} height={} diff={} cert_version={} target={}…",
        j.job_id,
        j.height,
        j.diff,
        j.cert_version,
        &j.target[..j.target.len().min(24)]
    );
    if !has_gpu {
        tracing::debug!(
            "stratum: no GPU worker attached — job {} received but not solved (needs pearl-gemm on a supported CUDA device)",
            j.job_id
        );
    }
    // On a GPU host: hand (header, target, cert_version, job_id) to the GEMM
    // worker; on a winning tile call `client.submit(job_id, nonce, result)`.
    // That path is gated on CUDA hardware + the built pearl-gemm library.
}
