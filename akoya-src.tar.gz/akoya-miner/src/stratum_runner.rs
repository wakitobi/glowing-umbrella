//! `stratum` subcommand: connect to a LuckyPool-style Pearl pool (JSON-over-TLS),
//! authorize the wallet, and run the job loop.
//!
//! This is the wire protocol used by endpoints like `pearl-sg1.lproute.com:3360`
//! — distinct from the Akoya gRPC V2 gateway handled by `run_mine`. Jobs are
//! logged and (on a GPU host with the native lib) handed to the GEMM worker;
//! the actual share solve/submit is gated on CUDA hardware.

use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Duration;

use akoya_stratum::{Inbound, StratumClient, StratumConfig, StratumError};

use crate::device_loop::{target_be_hex_to_le32, DeviceMiner};
use crate::worker::{GpuWorker, SolveJob};

/// Stratum connection settings sourced from `AKOYA_*` env vars.
pub struct StratumSettings {
    pub host: String,
    pub port: u16,
    pub wallet: String,
    pub worker: String,
    pub insecure_tls: bool,
}

impl StratumSettings {
    pub fn from_env() -> Result<Self, String> {
        let host = std::env::var("AKOYA_STRATUM_HOST")
            .or_else(|_| std::env::var("AKOYA_POOL_HOST"))
            .map_err(|_| "AKOYA_STRATUM_HOST (or AKOYA_POOL_HOST) is required".to_string())?;
        let port: u16 = std::env::var("AKOYA_STRATUM_PORT")
            .or_else(|_| std::env::var("AKOYA_POOL_PORT"))
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(3360);
        let wallet = std::env::var("AKOYA_POOL_WALLET")
            .map_err(|_| "AKOYA_POOL_WALLET is required".to_string())?;
        let worker = std::env::var("AKOYA_POOL_WORKER").unwrap_or_else(|_| "rig01".to_string());
        // LuckyPool uses a self-signed cert; accept it unless the operator
        // explicitly opts into strict verification.
        let insecure_tls = std::env::var("AKOYA_STRATUM_STRICT_TLS")
            .map(|v| v != "1" && !v.eq_ignore_ascii_case("true"))
            .unwrap_or(true);
        Ok(Self {
            host,
            port,
            wallet,
            worker,
            insecure_tls,
        })
    }
}

/// Connect, authorize, then loop over jobs until the stream ends or a fatal
/// error occurs. Returns `Ok(())` on a clean stream end (caller reconnects).
///
/// When `has_gpu`, a dedicated OS thread owns the `DeviceMiner` (raw CUDA
/// pointers never cross threads — the worker is built inside that thread) and
/// mines the latest job; solved shares come back over an mpsc channel and are
/// submitted on the async side.
pub async fn run(settings: &StratumSettings, has_gpu: bool) -> Result<(), StratumError> {
    let mut cfg = StratumConfig::new(&settings.host, settings.port, &settings.wallet);
    cfg.worker = settings.worker.clone();
    cfg.insecure_tls = settings.insecure_tls;

    tracing::info!(
        "stratum: connecting to {}:{} (tls_insecure={})",
        settings.host,
        settings.port,
        settings.insecure_tls
    );
    let mut client = StratumClient::connect(&cfg).await?;
    tracing::info!("stratum: TLS connected — authorizing wallet={} worker={}", settings.wallet, settings.worker);

    let jobs = client.authorize(&cfg).await?;
    tracing::info!("stratum: authorized ✓ ({} job(s) during handshake)", jobs.len());

    // --- GPU mining thread setup ------------------------------------------
    // Shared "latest job" + epoch; the miner thread snapshots on each σ and
    // aborts its inner loop when the epoch bumps (new job / difficulty).
    let job_slot: Arc<std::sync::Mutex<Option<(SolveJob, [u8; 32])>>> =
        Arc::new(std::sync::Mutex::new(None));
    let epoch = Arc::new(AtomicU64::new(0));
    let (share_tx, mut share_rx) = tokio::sync::mpsc::unbounded_channel::<crate::worker::SolvedShare>();
    let mine_defaults = mining_shape_from_env();

    let miner_handle = if has_gpu {
        let job_slot = job_slot.clone();
        let epoch = epoch.clone();
        Some(std::thread::spawn(move || {
            miner_thread(job_slot, epoch, share_tx, mine_defaults);
        }))
    } else {
        None
    };

    // Push handshake jobs into the slot.
    for j in &jobs {
        publish_job(&job_slot, &epoch, j, &mine_defaults, has_gpu);
    }

    loop {
        // Drain any solved shares first and submit them.
        while let Ok(share) = share_rx.try_recv() {
            tracing::info!(
                "stratum: SHARE FOUND job={} seed={} tile=({},{}) — submitting",
                share.job_id, share.winning_seed, share.tile_row, share.tile_col
            );
            let id = client.submit(&share.job_id, &share.plain_proof_b64).await?;
            tracing::info!("stratum: submitted plain_proof (req id={id}, {} b64 bytes)", share.plain_proof_b64.len());
        }

        match tokio::time::timeout(Duration::from_secs(120), client.next_inbound()).await {
            Ok(Ok(Inbound::Notify(job))) => publish_job(&job_slot, &epoch, &job, &mine_defaults, has_gpu),
            Ok(Ok(Inbound::SetDifficulty(v))) => tracing::info!("stratum: set_difficulty {v}"),
            Ok(Ok(Inbound::Result { id, ok, error })) => {
                if let Some(err) = error {
                    tracing::warn!("stratum: submit/result id={id} REJECTED: {err}");
                } else {
                    tracing::info!("stratum: result id={id} ok={ok:?} (share ACCEPTED if this was a submit)");
                }
            }
            Ok(Ok(Inbound::Other { method, .. })) => tracing::debug!("stratum: unhandled server method={method}"),
            Ok(Err(StratumError::Closed)) => {
                tracing::info!("stratum: pool closed the connection");
                break;
            }
            Ok(Err(e)) => {
                // stop the miner thread before returning
                epoch.fetch_add(1, Ordering::SeqCst);
                if let Some(h) = miner_handle { let _ = h.join(); }
                return Err(e);
            }
            Err(_) => {
                tracing::warn!("stratum: no job within 120s — reconnecting");
                break;
            }
        }
    }
    // signal the miner thread to exit its current σ and stop.
    epoch.fetch_add(1, Ordering::SeqCst);
    { *job_slot.lock().unwrap() = None; }
    if let Some(h) = miner_handle {
        // bump epoch again + drop slot already done; the thread checks slot None -> exits
        let _ = h.join();
    }
    Ok(())
}

/// Matrix shape for the GEMM, from env (defaults match akoya-config).
#[derive(Clone, Copy)]
struct MineShape {
    m: usize,
    n: usize,
    k: usize,
    noise_rank: usize,
    batch: usize,
}

fn mining_shape_from_env() -> MineShape {
    let env_us = |k: &str, d: usize| {
        std::env::var(k).ok().and_then(|s| s.parse().ok()).unwrap_or(d)
    };
    MineShape {
        m: env_us("AKOYA_MINE_M", 8192),
        n: env_us("AKOYA_MINE_N", 32768),
        k: env_us("AKOYA_MINE_K", 2048),
        noise_rank: env_us("AKOYA_MINE_NOISE_RANK", 128),
        batch: env_us("AKOYA_MINE_BATCH", 8),
    }
}

/// Build a SolveJob from a pool notify + publish it to the miner thread.
fn publish_job(
    slot: &Arc<std::sync::Mutex<Option<(SolveJob, [u8; 32])>>>,
    epoch: &Arc<AtomicU64>,
    j: &akoya_stratum::NotifyParams,
    shape: &MineShape,
    has_gpu: bool,
) {
    tracing::info!(
        "stratum: job job_id={} height={} diff={} cert_version={} target={}…",
        j.job_id, j.height, j.diff, j.cert_version, &j.target[..j.target.len().min(24)]
    );
    if !has_gpu {
        tracing::debug!("stratum: no GPU worker — job {} not solved", j.job_id);
        return;
    }
    let header = match hex_decode(&j.header) {
        Ok(h) => h,
        Err(e) => { tracing::warn!("stratum: bad header hex for job {}: {e}", j.job_id); return; }
    };
    let target_le = match target_be_hex_to_le32(&j.target) {
        Ok(t) => t,
        Err(e) => { tracing::warn!("stratum: bad target for job {}: {e}", j.job_id); return; }
    };
    // sigma_seed: low 8 bytes of the job header prefix act as the σ seed here.
    // (The pool's B-seed is the header-derived opaque seed; for LuckyPool the
    // notify carries the incomplete header — use its first 8 bytes as sigma_seed
    // and the blake3(header) as the 32-byte b_seed stand-in. VERIFY on the T4:
    // if the pool rejects with b_hash mismatch, the b_seed source is wrong and
    // we read it from a dedicated notify field instead.)
    let sigma_seed = {
        let mut s = [0u8; 8];
        let take = header.len().min(8);
        s[..take].copy_from_slice(&header[..take]);
        u64::from_le_bytes(s)
    };
    let b_seed = akoya_crypto::blake3::hash(&header);
    let job = SolveJob {
        job_id: j.job_id.clone(),
        incomplete_header: header,
        target_be: target_le, // stored LE (device wants LE); build_proof doesn't read it
        cert_version: j.cert_version,
        m: shape.m,
        n: shape.n,
        k: shape.k,
        noise_rank: shape.noise_rank,
        b_seed,
        sigma_seed,
    };
    *slot.lock().unwrap() = Some((job, target_le));
    epoch.fetch_add(1, Ordering::SeqCst);
}

/// The dedicated GPU thread: owns the DeviceMiner (raw CUDA pointers stay here),
/// mines the latest published job, aborts on epoch bump, sends solved shares.
fn miner_thread(
    slot: Arc<std::sync::Mutex<Option<(SolveJob, [u8; 32])>>>,
    epoch: Arc<AtomicU64>,
    share_tx: tokio::sync::mpsc::UnboundedSender<crate::worker::SolvedShare>,
    shape: MineShape,
) {
    // Detect the first GPU and build the worker HERE (never sent across threads).
    let gpus = match crate::cuda::detect_gpus() {
        Ok(g) if !g.is_empty() => g,
        _ => { tracing::error!("miner-thread: no CUDA device"); return; }
    };
    let g0 = &gpus[0];
    let worker = match GpuWorker::new(g0.index, g0.cc_major, g0.cc_minor) {
        Ok(w) => w,
        Err(e) => { tracing::error!("miner-thread: worker init failed: {e}"); return; }
    };
    let mut miner = match DeviceMiner::new(worker, shape.batch) {
        Ok(m) => m,
        Err(e) => { tracing::error!("miner-thread: device miner init failed: {e}"); return; }
    };
    tracing::info!("miner-thread: ready (batch={}, {}x{}x{} r={})", shape.batch, shape.m, shape.n, shape.k, shape.noise_rank);

    let mut last_epoch = u64::MAX;
    loop {
        let cur_epoch = epoch.load(Ordering::SeqCst);
        let job_opt = { slot.lock().unwrap().clone() };
        let (job, target_le) = match job_opt {
            Some(j) => j,
            None => {
                // no job yet, or shutdown signalled
                if cur_epoch != last_epoch && last_epoch != u64::MAX {
                    // slot cleared after we had a job -> shutdown
                    tracing::info!("miner-thread: shutdown");
                    return;
                }
                std::thread::sleep(Duration::from_millis(100));
                continue;
            }
        };
        last_epoch = cur_epoch;
        let stop_epoch = cur_epoch;
        let epoch_ref = epoch.clone();
        let should_stop = move || epoch_ref.load(Ordering::SeqCst) != stop_epoch;

        match miner.mine_job(&job, &target_le, should_stop) {
            Ok(Some(share)) => {
                if share_tx.send(share).is_err() {
                    tracing::info!("miner-thread: share channel closed — exiting");
                    return;
                }
            }
            Ok(None) => { /* preempted by a new job; loop picks it up */ }
            Err(e) => {
                tracing::warn!("miner-thread: mine_job error: {e} — retrying on next job");
                std::thread::sleep(Duration::from_millis(200));
            }
        }
    }
}

fn hex_decode(s: &str) -> Result<Vec<u8>, String> {
    let s = s.trim();
    if s.len() % 2 != 0 {
        return Err("odd hex length".into());
    }
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).map_err(|e| e.to_string()))
        .collect()
}
