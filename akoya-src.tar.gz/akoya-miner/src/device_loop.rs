//! Device mining loop — the final piece: set up all pearl-gemm device buffers
//! for a σ (job), run `iter_batch` over nonce ranges, scan the pinned host-signal
//! headers for a winner (status==1), then build + submit the PlainProof.
//!
//! This mirrors the C# `GpuWorker` steady-state loop, condensed to the
//! single-stream path (no ping/pong double-buffering — correctness first; the
//! pong overlap is a throughput optimization we can add once shares are
//! accepted). All device sizing matches `WorkerBuffers.cs`:
//!   A,ApEA   = m*k int8     B,BpEB   = n*k int8
//!   EAL      = m*r          EAL_fp16 = m*r*2
//!   EAR_R/K  = k*r / r*k    EBL_R/K  = k*r / r*k
//!   EBR      = n*r          EBR_fp16 = n*r*2
//!   AxEBL_fp16 = m*r*2      EARxBpEB_fp16 = n*r*2
//!   A_scales = m*4 (fp32 ones)   B_scales = n*4 (fp32 ones)
//!   Roots    = required_scratchpad_bytes(max(m*k,n*k), 128)
//!   Sync     = host_signal_sync_size   Header slot = host_signal_header_size
//!   Key/AHash/BHash/CommitA/CommitB/PowTarget = 32/32/32/32/32/32
//! Const tiling (must match a built kernel instantiation): BM=128 BN=256 BK=128 CM=1 CN=1;
//! tensor-hash threads=128 stages=2 leaves=512.
//!
//! GPU-gated: constructed only via `DeviceMiner::new` which needs a live CUDA
//! device + the built pearl-gemm lib. On GPU-less boxes the caller never reaches
//! here (cuda::detect_gpus returns empty → stratum_runner logs "no GPU").

use std::ffi::c_void;

use akoya_crypto::{commitment, host_signal, MiningConfiguration};
use akoya_gemm_sys::{CudaRt, InstallBParams, PearlGemm, WorkspaceParams};

use crate::worker::{regen_a_host, GpuWorker, SolveJob, SolvedShare};

// Kernel tiling constants (match WorkerBuffers.cs / GpuWorker.cs).
const BM: i32 = 128;
const BN: i32 = 256;
const BK: i32 = 128;
const CM: i32 = 1;
const CN: i32 = 1;
const TH_THREADS: u32 = 128;
const TH_STAGES: u32 = 2;
const TH_LEAVES: u32 = 512;

const CHUNK_LEN: i64 = 1024;

fn num_blocks(matrix_bytes: i64) -> u32 {
    // ceil(matrix_bytes / (threads * 1024))
    let denom = TH_THREADS as i64 * CHUNK_LEN;
    ((matrix_bytes + denom - 1) / denom) as u32
}

/// All device buffers + the pinned host header slots for a single σ, single stream.
struct DeviceBuffers {
    m: i32,
    n: i32,
    k: i32,
    r: i32,
    header_size: usize,
    // A-side (per-iter written)
    a: *mut c_void,
    a_hash: *mut c_void,
    roots: *mut c_void,
    commit_a: *mut c_void,
    commit_b: *mut c_void,
    eal: *mut c_void,
    eal_fp16: *mut c_void,
    ear_r: *mut c_void,
    ear_k: *mut c_void,
    ax_ebl_fp16: *mut c_void,
    ap_ea: *mut c_void,
    a_scales: *mut c_void,
    pow_target: *mut c_void,
    sync: *mut c_void,
    // B-side (installed once per σ)
    b: *mut c_void,
    b_hash: *mut c_void,
    key: *mut c_void,
    ebr: *mut c_void,
    ebr_fp16: *mut c_void,
    ebl_r: *mut c_void,
    ebl_k: *mut c_void,
    ear_x_bpeb_fp16: *mut c_void,
    bpeb: *mut c_void,
    b_scales: *mut c_void,
    // pinned host header slots (one per batch element)
    host_headers: Vec<*mut c_void>,
    // all device allocations for cleanup
    allocs: Vec<*mut c_void>,
}

impl DeviceBuffers {
    fn alloc(cuda: &CudaRt, gemm: &PearlGemm, m: i32, n: i32, k: i32, r: i32, batch: usize)
        -> Result<Self, DeviceError>
    {
        let mut allocs: Vec<*mut c_void> = Vec::new();
        let mut dev = |bytes: i64, allocs: &mut Vec<*mut c_void>| -> Result<*mut c_void, DeviceError> {
            let p = cuda.malloc(bytes.max(1) as usize)?;
            allocs.push(p);
            Ok(p)
        };
        let (mm, nn, kk, rr) = (m as i64, n as i64, k as i64, r as i64);
        let b_a = mm * kk;
        let b_b = nn * kk;
        let roots_bytes = gemm.required_scratchpad_bytes(b_a.max(b_b), TH_THREADS as i32);
        let sync_size = gemm.host_signal_sync_size() as i64;
        let header_size = gemm.host_signal_header_size() as usize;

        // fp32 "ones" scale buffers: allocate then fill 1.0f on host->device.
        let a_scales = dev(mm * 4, &mut allocs)?;
        let b_scales = dev(nn * 4, &mut allocs)?;
        let ones_m: Vec<u8> = (0..mm).flat_map(|_| 1.0f32.to_le_bytes()).collect();
        let ones_n: Vec<u8> = (0..nn).flat_map(|_| 1.0f32.to_le_bytes()).collect();
        unsafe {
            cuda.memcpy_htod(a_scales, &ones_m)?;
            cuda.memcpy_htod(b_scales, &ones_n)?;
        }

        let bufs = DeviceBuffers {
            m, n, k, r,
            header_size,
            a: dev(b_a, &mut allocs)?,
            a_hash: dev(32, &mut allocs)?,
            roots: dev(roots_bytes, &mut allocs)?,
            commit_a: dev(32, &mut allocs)?,
            commit_b: dev(32, &mut allocs)?,
            eal: dev(mm * rr, &mut allocs)?,
            eal_fp16: dev(mm * rr * 2, &mut allocs)?,
            ear_r: dev(kk * rr, &mut allocs)?,
            ear_k: dev(rr * kk, &mut allocs)?,
            ax_ebl_fp16: dev(mm * rr * 2, &mut allocs)?,
            ap_ea: dev(b_a, &mut allocs)?,
            a_scales,
            pow_target: dev(8 * 4, &mut allocs)?,
            sync: dev(sync_size, &mut allocs)?,
            b: dev(b_b, &mut allocs)?,
            b_hash: dev(32, &mut allocs)?,
            key: dev(32, &mut allocs)?,
            ebr: dev(nn * rr, &mut allocs)?,
            ebr_fp16: dev(nn * rr * 2, &mut allocs)?,
            ebl_r: dev(kk * rr, &mut allocs)?,
            ebl_k: dev(rr * kk, &mut allocs)?,
            ear_x_bpeb_fp16: dev(nn * rr * 2, &mut allocs)?,
            bpeb: dev(b_b, &mut allocs)?,
            b_scales,
            host_headers: Vec::new(),
            allocs,
        };
        let mut bufs = bufs;
        for _ in 0..batch {
            let h = cuda.host_alloc(header_size)?;
            // zero it
            let zero = vec![0u8; header_size];
            unsafe { cuda.memcpy_htod(h, &zero)?; }
            bufs.host_headers.push(h);
        }
        Ok(bufs)
    }

    fn free(&mut self, cuda: &CudaRt) {
        for &p in &self.allocs {
            let _ = unsafe { cuda.free(p) };
        }
        for &h in &self.host_headers {
            let _ = unsafe { cuda.free_host(h) };
        }
        self.allocs.clear();
        self.host_headers.clear();
    }
}

#[derive(Debug, thiserror::Error)]
pub enum DeviceError {
    #[error("cuda: {0}")]
    Cuda(#[from] akoya_gemm_sys::CudaError),
    #[error("gemm: {0}")]
    Gemm(#[from] akoya_gemm_sys::GemmError),
    #[error("solve: {0}")]
    Solve(String),
}

/// A device miner bound to one GPU, holding the worker + a CUDA stream.
pub struct DeviceMiner {
    worker: GpuWorker,
    stream: *mut c_void,
    batch: usize,
}

impl DeviceMiner {
    pub fn new(worker: GpuWorker, batch: usize) -> Result<Self, DeviceError> {
        let stream = worker.cuda().stream_create()?;
        Ok(Self { worker, stream, batch })
    }

    /// Install σ (job) and mine until `should_stop()` returns true or a share is
    /// found. On a winner, returns the SolvedShare; on stop with no win, None.
    ///
    /// `pow_target_le` is the pool's 256-bit target as 8×u32 little-endian bytes
    /// (32 bytes). We convert from the notify's big-endian hex before calling.
    pub fn mine_job<F: Fn() -> bool>(
        &mut self,
        job: &SolveJob,
        pow_target_le: &[u8; 32],
        should_stop: F,
    ) -> Result<Option<SolvedShare>, DeviceError> {
        let gemm = self.worker.gemm();
        let cuda = self.worker.cuda();
        let (m, n, k, r) = (job.m as i32, job.n as i32, job.k as i32, job.noise_rank as i32);

        // 1. Allocate buffers for this σ.
        let mut bufs = DeviceBuffers::alloc(cuda, gemm, m, n, k, r, self.batch)?;

        // 2. Upload key + pow_target; install B (expand B-seed + tensor_hash + noise_B).
        let cfg = MiningConfiguration::default_with(job.k as u32, job.noise_rank as u16);
        let job_key = commitment::get_key(&job.incomplete_header, &cfg);

        // FAKE-TARGET validation mode: AKOYA_FAKE_TARGET=1 replaces the pool
        // target with an easy one (top bytes 0xFF) so a "win" fires within a
        // batch or two — exercises build_proof -> submit -> pool response
        // without waiting for a real share. The pool will still reject the
        // (non-consensus) share, but the reject/accept tells us the submit
        // WIRE path works. NEVER leave this on for real mining.
        let mut effective_target = *pow_target_le;
        if std::env::var("AKOYA_FAKE_TARGET").as_deref() == Ok("1") {
            effective_target = [0xFFu8; 32];
            tracing::warn!("miner: AKOYA_FAKE_TARGET=1 — using EASY target (validation only, shares will be rejected by consensus)");
        }
        unsafe {
            cuda.memcpy_htod(bufs.key, &job_key)?;
            cuda.memcpy_htod(bufs.pow_target, &effective_target)?;
        }

        // install_B: expand the pool B-seed on device, tensor-hash it, run noise_B.
        let install = InstallBParams {
            m, n, k, r,
            expand_bseed: 1,
            th_num_blocks: num_blocks((n as i64) * (k as i64)),
            th_threads: TH_THREADS,
            th_stages: TH_STAGES,
            th_leaves: TH_LEAVES,
            device_id: self.worker.device_id(),
            bseed: job.b_seed.as_ptr(),
            b: bufs.b,
            b_hash: bufs.b_hash,
            key: bufs.key,
            roots: bufs.roots,
            a_hash: bufs.a_hash,
            commit_a: bufs.commit_a,
            commit_b: bufs.commit_b,
            ear_k_major: bufs.ear_k,
            ebl_r_major: bufs.ebl_r,
            ebl_k_major: bufs.ebl_k,
            ebr: bufs.ebr,
            ebr_fp16: bufs.ebr_fp16,
            ear_x_bpeb: bufs.ear_x_bpeb_fp16,
            bpeb: bufs.bpeb,
            workspace: std::ptr::null_mut(),
            leaf_cvs: std::ptr::null_mut(),
        };
        unsafe {
            gemm.install_b(&install, self.stream)?;
            cuda.stream_synchronize(self.stream)?;
        }

        // 3. Allocate the per-σ workspace + install constant params.
        let workspace = unsafe {
            gemm.workspace_alloc(m, n, k, r, true, false, self.stream)?
        };
        let wp = WorkspaceParams {
            m, n, k, r,
            bm: BM, bn: BN, bk: BK, cm: CM, cn: CN,
            th_num_blocks: num_blocks((m as i64) * (k as i64)),
            th_threads: TH_THREADS,
            th_stages: TH_STAGES,
            th_leaves: TH_LEAVES,
            sigma_seed: job.sigma_seed,
            a: bufs.a,
            b: bufs.b,
            a_hash: bufs.a_hash,
            b_hash: bufs.b_hash,
            key: bufs.key,
            roots: bufs.roots,
            commit_a: bufs.commit_a,
            commit_b: bufs.commit_b,
            eal: bufs.eal,
            eal_fp16: bufs.eal_fp16,
            ebr: bufs.ebr,
            ebr_fp16: bufs.ebr_fp16,
            ear_r_major: bufs.ear_r,
            ebl_r_major: bufs.ebl_r,
            ear_k_major: bufs.ear_k,
            ebl_k_major: bufs.ebl_k,
            ax_ebl_fp16: bufs.ax_ebl_fp16,
            ear_x_bpeb_fp16: bufs.ear_x_bpeb_fp16,
            ap_ea: bufs.ap_ea,
            bpeb: bufs.bpeb,
            a_scales: bufs.a_scales,
            b_scales: bufs.b_scales,
            c: std::ptr::null_mut(), // headless CAPI path: C = null
            host_signal_sync: bufs.sync,
            pow_target: bufs.pow_target,
            pow_key: bufs.commit_a, // matches C# GpuWorker (PowKey = CommitA)
        };
        unsafe {
            gemm.workspace_install_params(workspace, &wp)?;
        }

        // 4. Steady-state batch loop.
        let header_ptrs: Vec<*mut c_void> = bufs.host_headers.clone();
        let mut seed_lo: u64 = rand_seed_base();
        // Heartbeat: log batches/sec + elapsed every ~30s so a live run reports
        // progress instead of going dark between jobs.
        let loop_start = std::time::Instant::now();
        let mut last_beat = loop_start;
        let mut batches_done: u64 = 0;
        let result = loop {
            if should_stop() {
                break None;
            }
            // clear header slots (stale status==1 = phantom trigger)
            for &h in &header_ptrs {
                let zero = vec![0u8; bufs.header_size];
                unsafe { cuda.memcpy_htod(h, &zero)?; }
            }
            // zero the device sync block before the batch
            // (a fresh HtoD of zeros; the CAPI reads it during iter)
            let sync_zero = vec![0u8; gemm.host_signal_sync_size() as usize];
            unsafe { cuda.memcpy_htod(bufs.sync, &sync_zero)?; }

            // run the batch
            unsafe {
                gemm.iter_batch(
                    workspace,
                    seed_lo,
                    header_ptrs.as_ptr(),
                    self.batch as i32,
                    self.stream,
                )?;
                cuda.stream_synchronize(self.stream)?;
            }
            batches_done += 1;

            // heartbeat
            if last_beat.elapsed().as_secs() >= 30 {
                let elapsed = loop_start.elapsed().as_secs_f64();
                let hashes = batches_done * self.batch as u64;
                tracing::info!(
                    "miner: job={} alive — {} batches, {} hashes, {:.1} H/s, {:.0}s elapsed (no win yet)",
                    job.job_id, batches_done, hashes, hashes as f64 / elapsed, elapsed
                );
                last_beat = std::time::Instant::now();
            }

            // scan headers for a winner
            let mut winner: Option<usize> = None;
            for (k, &h) in header_ptrs.iter().enumerate() {
                let mut hdr = vec![0u8; bufs.header_size];
                unsafe { cuda.memcpy_dtoh(&mut hdr, h)?; }
                if host_signal::is_winner(&hdr) {
                    winner = Some(k);
                    break;
                }
            }

            if let Some(wk) = winner {
                let win_seed = seed_lo + wk as u64;
                let mut hdr = vec![0u8; bufs.header_size];
                unsafe { cuda.memcpy_dtoh(&mut hdr, header_ptrs[wk])?; }
                // Regenerate the winning A on the host (device A was overwritten
                // across the batch — same lcg_int7 the device used).
                let a_bytes = regen_a_host(job.m, job.k, win_seed, job.sigma_seed);
                let mut share = self
                    .worker
                    .build_proof(job, &hdr, &a_bytes)
                    .map_err(|e| DeviceError::Solve(e.to_string()))?;
                share.winning_seed = win_seed;
                break Some(share);
            }

            seed_lo = seed_lo.wrapping_add(self.batch as u64);
        };

        // 5. Cleanup this σ.
        unsafe {
            let _ = gemm.workspace_free(workspace, self.stream);
            cuda.stream_synchronize(self.stream).ok();
        }
        bufs.free(cuda);
        Ok(result)
    }
}

impl Drop for DeviceMiner {
    fn drop(&mut self) {
        if !self.stream.is_null() {
            let _ = unsafe { self.worker.cuda().stream_destroy(self.stream) };
        }
    }
}

/// Convert the pool's big-endian 256-bit target hex into 8×u32 little-endian
/// bytes for `pow_target` (matches the kernel's TargetToUint32LE expectation).
pub fn target_be_hex_to_le32(target_hex: &str) -> Result<[u8; 32], String> {
    let clean = target_hex.trim_start_matches("0x");
    let padded = format!("{:0>64}", clean);
    let mut be = [0u8; 32];
    for i in 0..32 {
        be[i] = u8::from_str_radix(&padded[i * 2..i * 2 + 2], 16)
            .map_err(|e| format!("bad target hex: {e}"))?;
    }
    // BE 256-bit number -> 8 u32 words little-endian, word order least-significant first.
    // The kernel stores target as u32[8] LE; TargetToUint32LE takes the big
    // integer and emits little-endian words. Reverse bytes to LE, then that IS
    // the u32[8] LE array read as bytes.
    let mut le = [0u8; 32];
    for i in 0..32 {
        le[i] = be[31 - i];
    }
    Ok(le)
}

fn rand_seed_base() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let t = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
    // mix nanos + a per-process salt so two workers don't sweep the same range
    (t.as_nanos() as u64) ^ (std::process::id() as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn target_conversion_reverses_be_to_le() {
        // A simple target: BE 00..00FF -> LE byte0 = 0xFF.
        let hex = format!("{:0>64}", "ff");
        let le = target_be_hex_to_le32(&hex).unwrap();
        assert_eq!(le[0], 0xFF);
        assert!(le[1..].iter().all(|&b| b == 0));
    }

    #[test]
    fn target_conversion_full_width() {
        let hex = "0000000000003fffc000000000000000000000000000000000000000000000ff";
        let le = target_be_hex_to_le32(hex).unwrap();
        // lowest byte of BE (0xff) becomes le[0]
        assert_eq!(le[0], 0xff);
    }

    #[test]
    fn num_blocks_ceils() {
        // 8192*2048 bytes / (128*1024) = 128 exactly.
        assert_eq!(num_blocks(8192 * 2048), 128);
        // one extra byte rounds up.
        assert_eq!(num_blocks(8192 * 2048 + 1), 129);
    }
}
