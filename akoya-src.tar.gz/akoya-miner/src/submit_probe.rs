//! `probe-submit` subcommand: discover the LuckyPool Pearl `mining.submit`
//! field schema against a LIVE job, by sending a battery of candidate shapes
//! and logging the pool's exact response to each.
//!
//! WHY: authorize + mining.notify are solved, but submit is not. Observed:
//!   - array params        -> code 20 "params must be an object"
//!   - {job_id}            -> code 21 "job not found / stale"
//!   - {job_id,nonce}      -> code 21 "job not found / stale"
//! meaning the field SET is incomplete (pool can't reconstruct/verify the
//! share). This probe enumerates plausible field combinations so we can read
//! which one changes the error (e.g. 21 "stale" -> 23 "low difficulty" or
//! -> different complaint), which tells us the schema without guessing blind.
//!
//! It does NOT need the GPU: we send deliberately-wrong solution bytes. We are
//! reading the pool's *validation ordering*, not trying to get an accept. The
//! error the pool returns tells us which fields it parsed successfully:
//!   * still "params must be an object" / "unknown field" -> wrong container
//!   * "missing field X"                                  -> X is required
//!   * "stale / job not found"                            -> job_id field name wrong OR needs more
//!   * "low difficulty share" / "invalid share"           -> SCHEMA ACCEPTED, only the value is wrong  <-- WIN
//!
//! Once a probe flips the error from "stale/parse" to "low difficulty/invalid
//! PoW", we've found the field schema; wire that exact shape into SubmitParams.

use std::time::Duration;

use akoya_stratum::{Inbound, StratumClient, StratumConfig, AuthStyle};
use serde_json::json;

pub struct ProbeSettings {
    pub host: String,
    pub port: u16,
    pub wallet: String,
    pub worker: String,
    pub insecure_tls: bool,
}

impl ProbeSettings {
    pub fn from_env() -> Result<Self, String> {
        let host = std::env::var("AKOYA_STRATUM_HOST")
            .or_else(|_| std::env::var("AKOYA_POOL_HOST"))
            .map_err(|_| "AKOYA_STRATUM_HOST (or AKOYA_POOL_HOST) is required".to_string())?;
        let port: u16 = std::env::var("AKOYA_STRATUM_PORT")
            .or_else(|_| std::env::var("AKOYA_POOL_PORT"))
            .ok()
            .and_then(|s| s.parse().ok())
            .unwrap_or(3360);
        let wallet = std::env::var("AKOYA_POOL_WALLET")
            .map_err(|_| "AKOYA_POOL_WALLET is required".to_string())?;
        let worker = std::env::var("AKOYA_POOL_WORKER").unwrap_or_else(|_| "probe01".to_string());
        let insecure_tls = std::env::var("AKOYA_STRATUM_STRICT_TLS")
            .map(|v| v != "1" && !v.eq_ignore_ascii_case("true"))
            .unwrap_or(true);
        Ok(Self { host, port, wallet, worker, insecure_tls })
    }
}

/// Build the candidate submit-param shapes to try against a live job.
///
/// `job_id` / `header` / `target` come from the live `mining.notify`; the
/// solution fields are deliberately bogus (all-zero / dummy) because we only
/// want to learn the pool's field-validation response, not to win a share.
fn candidate_params(job_id: &str, worker: &str, header: &str, target: &str) -> Vec<(String, serde_json::Value)> {
    // A plausible 8-byte nonce and a 32-byte result hash, hex.
    let nonce = "0000000000000000";
    let result = "00".repeat(32);
    let hheader = header;
    let _ = target; // available if a shape needs it

    vec![
        // 1. baseline (already known -> stale): job_id + nonce
        ("job_id+nonce".into(), json!({"job_id": job_id, "nonce": nonce})),
        // 2. + result hash
        ("job_id+nonce+result".into(), json!({"job_id": job_id, "nonce": nonce, "result": result})),
        // 3. + worker
        ("job_id+nonce+result+worker".into(),
            json!({"job_id": job_id, "nonce": nonce, "result": result, "worker": worker})),
        // 4. Ethash-style naming: id/nonce/header/mix
        ("id+nonce+header+mix".into(),
            json!({"id": job_id, "nonce": nonce, "header": hheader, "mix": result})),
        // 5. hash instead of result
        ("job_id+nonce+hash".into(), json!({"job_id": job_id, "nonce": nonce, "hash": result})),
        // 6. Pearl PoUW terms: tile coords + jackpot + commitment
        ("pearl_tile".into(), json!({
            "job_id": job_id, "nonce": nonce,
            "cm": 0, "cn": 0,               // winning tile coordinates
            "sigma": 0,                      // sigma index
            "result": result
        })),
        // 7. Pearl commitment roots (what the job_key is built from)
        ("pearl_commit".into(), json!({
            "job_id": job_id, "nonce": nonce,
            "commit_a": result, "commit_b": result,
            "jackpot": result
        })),
        // 8. Full-header submit (some pools want the completed header back)
        ("job_id+header+nonce".into(),
            json!({"job_id": job_id, "header": hheader, "nonce": nonce})),
        // 9. seed_lo style (Pearl iter takes a u64 seed_lo per nonce)
        ("job_id+seed".into(), json!({"job_id": job_id, "seed": nonce, "result": result})),
        // 10. worker + id + nonce + result (worker required first?)
        ("worker+id+nonce+result".into(),
            json!({"worker": worker, "id": job_id, "nonce": nonce, "result": result})),
    ]
}

pub async fn run(s: &ProbeSettings) -> Result<(), String> {
    let mut cfg = StratumConfig::new(&s.host, s.port, &s.wallet);
    cfg.worker = s.worker.clone();
    cfg.insecure_tls = s.insecure_tls;
    cfg.auth_style = AuthStyle::Object;

    tracing::info!("probe: connecting {}:{} tls_insecure={}", s.host, s.port, s.insecure_tls);
    let mut client = StratumClient::connect(&cfg).await.map_err(|e| e.to_string())?;
    let jobs = client.authorize(&cfg).await.map_err(|e| e.to_string())?;
    tracing::info!("probe: authorized ✓ ({} handshake job(s))", jobs.len());

    // Get a FRESH job to probe against (handshake jobs may already be stale).
    let job = if let Some(j) = jobs.into_iter().next() {
        j
    } else {
        tracing::info!("probe: waiting for first mining.notify...");
        loop {
            match tokio::time::timeout(Duration::from_secs(90), client.next_inbound()).await {
                Ok(Ok(Inbound::Notify(j))) => break j,
                Ok(Ok(_)) => continue,
                Ok(Err(e)) => return Err(e.to_string()),
                Err(_) => return Err("no job within 90s".into()),
            }
        }
    };
    tracing::info!(
        "probe: LIVE job job_id={} height={} diff={} cert_version={} header_len={} target={}…",
        job.job_id, job.height, job.diff, job.cert_version,
        job.header.len(), &job.target[..job.target.len().min(20)]
    );

    let worker = client.worker_label().to_string();
    let candidates = candidate_params(&job.job_id, &worker, &job.header, &job.target);

    // Send each candidate, then wait briefly for its response, tagging by id.
    // We refresh the live job between rounds so job_id never goes stale on us.
    let mut current_job = job;
    for (label, params) in candidates {
        // refresh to the newest job so "stale" can't mask a real schema signal
        while let Ok(Ok(inb)) = tokio::time::timeout(Duration::from_millis(50), client.next_inbound()).await {
            if let Inbound::Notify(j) = inb {
                current_job = j;
            }
        }
        // rewrite job_id/header/target in the params to the freshest job
        let params = refresh_job_fields(params, &current_job);

        tracing::info!("probe[{label}]: -> mining.submit {}", params);
        let id = match client.send_method("mining.submit", params).await {
            Ok(id) => id,
            Err(e) => { tracing::warn!("probe[{label}]: send failed: {e}"); continue; }
        };

        // read frames until we see the response for this id (or timeout)
        let deadline = tokio::time::Instant::now() + Duration::from_secs(6);
        loop {
            let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
            if remaining.is_zero() {
                tracing::warn!("probe[{label}]: no response within 6s");
                break;
            }
            match tokio::time::timeout(remaining, client.next_inbound()).await {
                Ok(Ok(Inbound::Result { id: rid, ok, error })) if rid == id => {
                    match (ok, error) {
                        (_, Some(e)) => tracing::warn!("probe[{label}]: RESULT code={} msg=\"{}\"", e.code, e.msg),
                        (ok, None) => tracing::info!("probe[{label}]: RESULT ok={:?} (NO ERROR — schema accepted!)", ok),
                    }
                    break;
                }
                Ok(Ok(Inbound::Notify(j))) => current_job = j,
                Ok(Ok(_)) => {}
                Ok(Err(e)) => { tracing::warn!("probe[{label}]: stream err {e}"); break; }
                Err(_) => { tracing::warn!("probe[{label}]: no response within 6s"); break; }
            }
        }
    }

    tracing::info!("probe: done. Look for the label whose error changed from \
                    'params must be an object' / 'job not found / stale' to \
                    'low difficulty' / 'invalid share' — that shape is the schema.");
    Ok(())
}

/// Overwrite any job_id/id/header/target fields in a candidate with the values
/// from the freshest live job so the pool can't reject purely as stale.
fn refresh_job_fields(mut params: serde_json::Value, job: &akoya_stratum::NotifyParams) -> serde_json::Value {
    if let Some(obj) = params.as_object_mut() {
        if obj.contains_key("job_id") { obj.insert("job_id".into(), json!(job.job_id)); }
        if obj.contains_key("id") { obj.insert("id".into(), json!(job.job_id)); }
        if obj.contains_key("header") { obj.insert("header".into(), json!(job.header)); }
        if obj.contains_key("target") { obj.insert("target".into(), json!(job.target)); }
    }
    params
}
