//! Environment-variable configuration for the Akoya miner.
//!
//! Port of `Akoya.Miner.Config.MinerOptions` + `EnvVarBindings`. This is the
//! single place env vars are read at startup; the rest of the miner takes an
//! immutable [`MinerOptions`] by reference.

use std::collections::HashMap;

/// Pool / gRPC connection parameters.
#[derive(Clone, Debug)]
pub struct PoolOptions {
    pub host: String,
    pub port: u16,
    pub use_tls: bool,
    pub tls_insecure: bool,
    pub wallet_address: String,
    pub worker_name: String,
    pub ping_interval_sec: i64,
    pub heartbeat_interval_sec: i64,
    pub stream_watchdog_sec: i64,
    pub keepalive_ping_sec: i64,
    pub keepalive_timeout_sec: i64,
    pub pong_timeout_sec: i64,
    pub outbound_depth_trip: i64,
}

/// GEMM / mining-loop parameters. Names + defaults match the C# miner 1:1.
#[derive(Clone, Debug)]
pub struct MineOptions {
    pub m: i64,
    pub n: i64,
    pub k: i64,
    pub noise_rank: i64,
    pub matmuls_per_poll: i64,
    pub max_blocks: i64,
    pub stats_interval_sec: f64,
    pub watchdog_timeout_sec: i64,
    pub trigger_watchdog_sec: i64,
    pub fake_target: bool,
    pub benchmark_duration_sec: i64,
    pub disable_pong: bool,
    pub shape_override_present: bool,
    pub cuda_graph_iter: bool,
    pub cuda_graph_required: bool,
}

/// GPU enumeration / selection.
#[derive(Clone, Debug)]
pub struct GpuOptions {
    pub indices_raw: String,
}

/// Logging + observability.
#[derive(Clone, Debug)]
pub struct ObservabilityOptions {
    pub log_level: String,
    pub log_json: bool,
    pub metrics_port: Option<u16>,
    pub hiveos_stats_path: String,
}

/// Session persistence.
#[derive(Clone, Debug)]
pub struct SessionOptions {
    pub file_path: String,
}

/// Aggregate configuration root.
#[derive(Clone, Debug)]
pub struct MinerOptions {
    pub pool: PoolOptions,
    pub mine: MineOptions,
    pub gpus: GpuOptions,
    pub observability: ObservabilityOptions,
    pub session: SessionOptions,
}

/// v1-era vars that V2 ignores (each produces a startup deprecation warning).
pub const DEPRECATED_VARS: &[(&str, &str)] = &[
    ("AKOYA_GATEWAY_HOST", "no solo/gateway mode in V2"),
    ("AKOYA_GATEWAY_PORT", "no solo/gateway mode in V2"),
    ("AKOYA_POOL_FIRST_JOB_TIMEOUT_SEC", "gRPC server-push delivers job; no race"),
    ("AKOYA_POOL_FIRST_JOB_GIVE_UP_AFTER", "gRPC server-push delivers job; no race"),
    ("AKOYA_POOL_RECONNECT_BASE_SEC", "gRPC channel handles reconnect backoff"),
    ("AKOYA_POOL_RECONNECT_CAP_SEC", "gRPC channel handles reconnect backoff"),
    ("AKOYA_POOL_RECONNECT_INITIAL_JITTER_SEC", "gRPC channel handles reconnect backoff"),
    ("AKOYA_POOL_RECONNECT_MAX_WAIT_SEC", "use ReconnectHint.wait_seconds from server"),
    ("AKOYA_POOL_RECONNECT_MIN_INTERVAL_SEC", "server-side concern in V2"),
    ("AKOYA_POOL_SHARE_STARVATION_SEC", "v1 protocol workaround; not needed in V2"),
    ("AKOYA_POOL_SHARE_STARVATION_COOLDOWN_SEC", "v1 protocol workaround; not needed in V2"),
    ("AKOYA_POOL_SHARE_STARVATION_DISABLE", "v1 protocol workaround; not needed in V2"),
    ("AKOYA_MINE_MAX_ITERS", "per-sigma iteration caps are disabled in V2"),
];

#[derive(Debug, thiserror::Error)]
pub enum ConfigError {
    #[error("AKOYA_POOL_WALLET is required")]
    MissingWallet,
}

impl MinerOptions {
    /// Load configuration from the process environment.
    pub fn load_from_env() -> Result<Self, ConfigError> {
        Self::load(|k| std::env::var(k).ok())
    }

    /// Load configuration using an arbitrary lookup function (testable).
    pub fn load<F>(get: F) -> Result<Self, ConfigError>
    where
        F: Fn(&str) -> Option<String>,
    {
        let env = |name: &str| -> Option<String> {
            match get(name) {
                Some(v) if !v.is_empty() => Some(v),
                _ => None,
            }
        };

        // Emit deprecation warnings.
        for (name, reason) in DEPRECATED_VARS {
            if env(name).is_some() {
                tracing::warn!("[deprecated] {} ignored in v2 ({})", name, reason);
            }
        }

        // ---- Pool ---------------------------------------------------------
        let host = env("AKOYA_POOL_HOST").unwrap_or_else(|| "pool-v2.akoyapool.com".to_string());
        let tls = parse_bool(env("AKOYA_POOL_TLS").or_else(|| env("AKOYA_POOL_USE_TLS")), true);
        let port = parse_int(env("AKOYA_POOL_PORT"), if tls { 443 } else { 50052 }) as u16;

        let wallet = env("AKOYA_POOL_WALLET").ok_or(ConfigError::MissingWallet)?;
        let worker = env("AKOYA_POOL_WORKER").unwrap_or_else(machine_name);

        let pool = PoolOptions {
            host,
            port,
            use_tls: tls,
            tls_insecure: parse_bool(env("AKOYA_POOL_TLS_INSECURE"), false),
            wallet_address: wallet,
            worker_name: worker,
            ping_interval_sec: parse_int(env("AKOYA_POOL_PING_INTERVAL_SEC"), 15),
            heartbeat_interval_sec: parse_int(env("AKOYA_POOL_HEARTBEAT_INTERVAL_SEC"), 30),
            stream_watchdog_sec: parse_int(env("AKOYA_POOL_STREAM_WATCHDOG_SEC"), 90),
            keepalive_ping_sec: parse_int(env("AKOYA_POOL_KEEPALIVE_PING_SEC"), 10).max(1),
            keepalive_timeout_sec: parse_int(env("AKOYA_POOL_KEEPALIVE_TIMEOUT_SEC"), 10).max(1),
            pong_timeout_sec: parse_int(env("AKOYA_POOL_PONG_TIMEOUT_SEC"), 20),
            outbound_depth_trip: parse_int(env("AKOYA_POOL_OUTBOUND_DEPTH_TRIP"), 16),
        };

        // ---- Mining loop --------------------------------------------------
        let shape_override_present = env("AKOYA_MINE_M").is_some()
            || env("AKOYA_MINE_N").is_some()
            || env("AKOYA_MINE_K").is_some()
            || env("AKOYA_MINE_NOISE_RANK").is_some();

        let mine = MineOptions {
            m: parse_int(env("AKOYA_MINE_M"), 8192),
            n: parse_int(env("AKOYA_MINE_N"), 32768),
            k: parse_int(env("AKOYA_MINE_K"), 2048),
            noise_rank: parse_int(env("AKOYA_MINE_NOISE_RANK"), 128),
            matmuls_per_poll: 10, // probe value; overwritten post-benchmark
            max_blocks: parse_int(env("AKOYA_MINE_MAX_BLOCKS"), 0),
            stats_interval_sec: parse_double(env("AKOYA_MINE_STATS_INTERVAL_SEC"), 5.0),
            watchdog_timeout_sec: parse_int(env("AKOYA_MINE_WATCHDOG_TIMEOUT_SEC"), 300),
            trigger_watchdog_sec: parse_int(env("AKOYA_MINE_TRIGGER_WATCHDOG_SEC"), 300),
            fake_target: env("AKOYA_FAKE_TARGET").as_deref() == Some("1"),
            benchmark_duration_sec: parse_int(env("AKOYA_BENCH_DURATION_SEC"), 10),
            disable_pong: parse_bool(env("AKOYA_DISABLE_PONG"), false),
            shape_override_present,
            cuda_graph_iter: parse_bool(env("AKOYA_CUDA_GRAPH_ITER"), false),
            cuda_graph_required: parse_bool(env("AKOYA_CUDA_GRAPH_REQUIRED"), false),
        };

        // ---- GPUs ---------------------------------------------------------
        let gpus = GpuOptions {
            indices_raw: env("AKOYA_GPU_INDICES")
                .or_else(|| env("AKOYA_GPU_INDEX"))
                .unwrap_or_else(|| "all".to_string()),
        };

        // ---- Observability ------------------------------------------------
        let obs = ObservabilityOptions {
            log_level: env("AKOYA_LOG_LEVEL").unwrap_or_else(|| "Information".to_string()),
            log_json: parse_bool(env("AKOYA_LOG_JSON"), false),
            metrics_port: env("AKOYA_METRICS_PORT").and_then(|s| s.parse::<u16>().ok()),
            hiveos_stats_path: env("AKOYA_HIVEOS_STATS_PATH")
                .unwrap_or_else(|| "/run/hive/akoya-miner-stats.json".to_string()),
        };

        // ---- Session ------------------------------------------------------
        let sess = SessionOptions {
            file_path: env("AKOYA_SESSION_FILE").unwrap_or_else(default_session_path),
        };

        Ok(MinerOptions {
            pool,
            mine,
            gpus,
            observability: obs,
            session: sess,
        })
    }
}

/// Parse the GPU-indices spec ("all" or comma-separated) into device indices.
/// Returns `None` for "all" (caller enumerates all devices at runtime).
pub fn parse_gpu_indices(raw: &str) -> Option<Vec<u32>> {
    let t = raw.trim();
    if t.eq_ignore_ascii_case("all") || t.is_empty() {
        return None;
    }
    let mut out = Vec::new();
    for part in t.split(',') {
        let p = part.trim();
        if p.is_empty() {
            continue;
        }
        if let Ok(v) = p.parse::<u32>() {
            out.push(v);
        }
    }
    if out.is_empty() {
        None
    } else {
        Some(out)
    }
}

fn machine_name() -> String {
    std::env::var("COMPUTERNAME")
        .ok()
        .or_else(|| std::env::var("HOSTNAME").ok())
        .unwrap_or_else(|| "unknown-worker".to_string())
}

fn default_session_path() -> String {
    let home = std::env::var("HOME")
        .ok()
        .filter(|s| !s.is_empty())
        .or_else(|| std::env::var("USERPROFILE").ok().filter(|s| !s.is_empty()))
        .unwrap_or_else(|| "/root".to_string());
    format!("{}/.akoya/session.json", home.trim_end_matches(['/', '\\']))
}

fn parse_int(raw: Option<String>, default: i64) -> i64 {
    raw.and_then(|s| s.trim().parse::<i64>().ok()).unwrap_or(default)
}

fn parse_double(raw: Option<String>, default: f64) -> f64 {
    raw.and_then(|s| s.trim().parse::<f64>().ok()).unwrap_or(default)
}

fn parse_bool(raw: Option<String>, default: bool) -> bool {
    match raw.as_deref() {
        None => default,
        Some("1") => true,
        Some("0") => false,
        Some(s) if s.eq_ignore_ascii_case("true") => true,
        Some(s) if s.eq_ignore_ascii_case("false") => false,
        _ => default,
    }
}

/// Build a lookup closure from a fixed map (test helper).
pub fn map_lookup(map: HashMap<String, String>) -> impl Fn(&str) -> Option<String> {
    move |k: &str| map.get(k).cloned()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn opts_from(pairs: &[(&str, &str)]) -> Result<MinerOptions, ConfigError> {
        let map: HashMap<String, String> =
            pairs.iter().map(|(k, v)| (k.to_string(), v.to_string())).collect();
        MinerOptions::load(map_lookup(map))
    }

    #[test]
    fn wallet_is_required() {
        let err = opts_from(&[]).unwrap_err();
        matches!(err, ConfigError::MissingWallet);
    }

    #[test]
    fn defaults_are_applied() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "prl1abc")]).unwrap();
        assert_eq!(o.pool.host, "pool-v2.akoyapool.com");
        assert!(o.pool.use_tls);
        assert_eq!(o.pool.port, 443);
        assert_eq!(o.mine.m, 8192);
        assert_eq!(o.mine.n, 32768);
        assert_eq!(o.mine.k, 2048);
        assert_eq!(o.mine.noise_rank, 128);
        assert_eq!(o.gpus.indices_raw, "all");
        assert!(!o.mine.shape_override_present);
    }

    #[test]
    fn tls_off_switches_default_port() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_POOL_TLS", "0")]).unwrap();
        assert!(!o.pool.use_tls);
        assert_eq!(o.pool.port, 50052);
    }

    #[test]
    fn explicit_port_wins() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_POOL_PORT", "12345")]).unwrap();
        assert_eq!(o.pool.port, 12345);
    }

    #[test]
    fn tls_alias_use_tls_respected() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_POOL_USE_TLS", "false")]).unwrap();
        assert!(!o.pool.use_tls);
    }

    #[test]
    fn shape_override_detected() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_MINE_K", "4096")]).unwrap();
        assert!(o.mine.shape_override_present);
        assert_eq!(o.mine.k, 4096);
    }

    #[test]
    fn keepalive_clamped_to_min_1() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_POOL_KEEPALIVE_PING_SEC", "0")]).unwrap();
        assert_eq!(o.pool.keepalive_ping_sec, 1);
    }

    #[test]
    fn gpu_indices_parse() {
        assert_eq!(parse_gpu_indices("all"), None);
        assert_eq!(parse_gpu_indices(""), None);
        assert_eq!(parse_gpu_indices("0,1,3"), Some(vec![0, 1, 3]));
        assert_eq!(parse_gpu_indices(" 2 , 4 "), Some(vec![2, 4]));
    }

    #[test]
    fn legacy_gpu_index_fallback() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_GPU_INDEX", "0,1")]).unwrap();
        assert_eq!(o.gpus.indices_raw, "0,1");
    }

    #[test]
    fn fake_target_only_on_exact_1() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_FAKE_TARGET", "1")]).unwrap();
        assert!(o.mine.fake_target);
        let o2 = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_FAKE_TARGET", "true")]).unwrap();
        assert!(!o2.mine.fake_target);
    }

    #[test]
    fn metrics_port_optional() {
        let o = opts_from(&[("AKOYA_POOL_WALLET", "w")]).unwrap();
        assert_eq!(o.observability.metrics_port, None);
        let o2 = opts_from(&[("AKOYA_POOL_WALLET", "w"), ("AKOYA_METRICS_PORT", "9100")]).unwrap();
        assert_eq!(o2.observability.metrics_port, Some(9100));
    }
}
