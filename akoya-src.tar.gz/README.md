# akoya-miner-rs

A Rust port of the [Akoya reference miner](https://github.com/akoyapool/akoya-miner)
for **Pearl (PRL)** — the Proof-of-Useful-Work L1 whose proof of work is a
low-rank-noised integer GEMM. This replaces the upstream C#/.NET host
(`Akoya.Miner`) with a Rust host that speaks the same pool V2 gRPC wire
protocol and drives the same native `pearl_gemm_capi` CUDA kernels.

The heavy compute is unchanged: it still runs in the NVIDIA CUDA/CUTLASS
`pearl-gemm` library. What this project reimplements in Rust is everything the
C# host did — the managed crypto, the config, the pool session state machine,
the native-library FFI, and the CLI.

## Workspace layout

| Crate | Replaces (C#) | What it does |
|-------|---------------|--------------|
| `akoya-crypto`   | `Akoya.Crypto` | Pure-Rust BLAKE3 (hash/keyed/XOF/merkle), noise generation, jackpot accumulator, LCG-int7 replay, B-seed expansion, `MiningConfiguration` 52-byte wire format + job-key/commitment/noise-seed derivations. |
| `akoya-config`   | `Akoya.Miner.Config` | `AKOYA_*` environment-variable configuration → `MinerOptions`. |
| `akoya-proto`    | `Akoya.Proto` | tonic/prost client stubs generated from `proto/miner.proto` (pure-Rust `protox`, no system `protoc`). |
| `akoya-pool`     | `Akoya.Pool` | gRPC connection, register/resume session state machine, bidi mining stream with liveness watchdog, atomic session persistence. |
| `akoya-stratum`  | *(new)* | Stratum-style **JSON-over-TLS** client for LuckyPool Pearl pools (`mining.authorize` / `mining.notify` / `mining.submit`). This is a *different wire protocol* from the Akoya gRPC gateway — used by endpoints like `pearl-sg1.lproute.com:3360`. |
| `akoya-gemm-sys` | `Akoya.PearlGemm` | Runtime FFI to `libpearl_gemm_capi` (workspace/iter hot path, `repr(C)` param structs matching the C ABI header). |
| `akoya-miner`    | `Akoya.Miner` | CLI (`mine-blocks` / `stratum` / `selftest` / `version`), CUDA driver GPU detection, worker skeleton, reconnect loop. |

## Status — what is verified vs not

**Verified on this machine (Windows, `cargo test`, 41 tests passing):**

- BLAKE3 (hash, keyed, XOF, random-access XOF) is byte-checked against the
  `blake3` reference crate and the official empty/1024-byte test vectors.
- Mining-config wire format (52-byte layout, reserved-zero, dot-product floor
  rounding), job-key = `BLAKE3(σ ‖ config)`, and the chained noise seeds are
  re-derived independently and matched.
- Noise generator ranges, jackpot determinism + keyed hash, LCG-int7 range and
  determinism, B-seed range-vs-full consistency.
- Config parsing (defaults, TLS/port interplay, deprecation, GPU indices).
- Session store round-trip / validation / wrong-pool discard / token clear.
- The CLI builds (debug + release) and runs: `version` prints, and `selftest`
  correctly reports config/GPU/pool/native-lib probe results as JSON.
- **CUDA driver FFI is real**: `selftest` enumerated the actual GPU on the
  build box via `nvcuda.dll` (`cuInit`/`cuDeviceGet*`).
- **Live pool connectivity (Stratum) is verified**: `akoya-stratum` connected
  over TLS to `pearl-sg1.lproute.com:3360`, authorized the wallet, and
  received live `mining.notify` jobs (e.g. `job_id=4b0ed660_888888`,
  height 103807, cert_version 3). Run it yourself with
  `akoya-miner stratum` or `cargo run -p akoya-stratum --example connect`.

## Two pools, two protocols

Pearl is mined through more than one pool software stack, and they do **not**
share a wire protocol:

- **Akoya gRPC V2** (`pool-v2.akoyapool.com:443`) — HTTP/2 + protobuf,
  register/resume/bidi-stream. Handled by `akoya-pool` + the `mine-blocks`
  subcommand.
- **LuckyPool Stratum** (`pearl-sg1.lproute.com:3360` and similar) — newline
  JSON-RPC over a self-signed TLS socket, `mining.authorize` →
  `mining.notify` → `mining.submit`. Handled by `akoya-stratum` + the
  `stratum` subcommand.

### Connect to a LuckyPool endpoint

```bash
AKOYA_STRATUM_HOST=pearl-sg1.lproute.com \
AKOYA_STRATUM_PORT=3360 \
AKOYA_POOL_WALLET=prl1youraddress… \
AKOYA_POOL_WORKER=t4rig \
./target/release/akoya-miner stratum
```

The pool uses a self-signed `*.luckypool.io` certificate; the client accepts
it by default (set `AKOYA_STRATUM_STRICT_TLS=1` to require a valid chain). The
wallet is the only credential. On a host without a CUDA GPU the client still
connects, authorizes, and logs jobs — it just can't solve/submit shares.

**NOT yet exercised (requires a GPU host with the built native lib):**

- Loading `pearl_gemm_capi` and the per-σ `workspace_alloc → install_params →
  iter` device hot loop. `akoya-gemm-sys` binds the full C ABI and
  `worker::GpuWorker` wires the lifecycle + SM-support guard, but the
  device-buffer allocation and share-trigger polling must be finished and
  tested on hardware. This is called out honestly rather than faked.

## Build (host only, no GPU needed)

```bash
cd akoya-miner-rs
cargo build --release
cargo test
./target/release/akoya-miner version
```

## Build the native CUDA library for a Tesla T4 (Turing / sm_75)

The Rust host loads `libpearl_gemm_capi.so` (Linux) / `pearl_gemm_capi.dll`
(Windows) at runtime. Build it from the upstream repo with the Turing profile:

```bash
git clone --recurse-submodules https://github.com/akoyapool/akoya-miner.git
cd akoya-miner
git submodule update --init --depth 1 native/pearl-gemm/third_party/cutlass
make -C native/pearl-gemm/csrc/capi PEARL_GEMM_ARCH=turing   # T4 = sm_75
```

Requirements: CUDA Toolkit 12.4+ (`nvcc`), a Turing GPU (T4), the NVIDIA
driver, `python3` (kernel codegen), and `make`. See the upstream README for
per-arch notes.

## Run against the pool (on the T4 host)

```bash
export AKOYA_PEARL_GEMM_LIB=/abs/path/to/libpearl_gemm_capi.so
export AKOYA_POOL_WALLET=prl1youraddresshere
export AKOYA_POOL_WORKER=t4-rig01
./target/release/akoya-miner selftest   # 0 = ready; checks config+lib+GPU+pool
./target/release/akoya-miner            # mine-blocks (default)
```

Configuration is entirely via `AKOYA_*` env vars (same names/defaults as the
C# miner): `AKOYA_POOL_HOST`/`PORT`/`TLS`, `AKOYA_GPU_INDICES`,
`AKOYA_MINE_M/N/K/NOISE_RANK`, `AKOYA_LOG_LEVEL`, `AKOYA_SESSION_FILE`, etc.

## Honest note on Pearl + the T4

Pearl's PoW is tuned for datacenter int8 tensor-core throughput (H100-class).
A T4 (sm_75, ~130 int8 TOPS) is supported by the `turing` kernel build and
will mine, but it is an order of magnitude slower than the Hopper/Blackwell
hardware the network is calibrated around — treat T4 mining as functional,
not competitive.
