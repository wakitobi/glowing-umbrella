//! GPU mining worker skeleton.
//!
//! Bridges pool jobs to the native `pearl_gemm_capi` per-σ workspace + iter
//! hot path. This module wires the lifecycle (load lib → verify SM → alloc
//! workspace → install params → iter batches → detect share triggers) but the
//! device-buffer allocation is delegated to the native library's workspace
//! pool, which owns all CUDA memory.
//!
//! The full device-memory dance (allocating A/B/E* buffers, pinned host signal
//! headers, CUDA streams) requires a live CUDA context and is only exercisable
//! on a machine with a supported GPU + the built `pearl_gemm_capi` library.
//! Everything here is structured so that path can be filled in and tested on
//! such hardware (e.g. a Tesla T4 with the `turing` build).

use akoya_gemm_sys::{GemmError, PearlGemm};

/// A GPU worker bound to one device.
pub struct GpuWorker {
    gemm: PearlGemm,
    device_id: i32,
    profile: String,
}

#[derive(Debug, thiserror::Error)]
pub enum WorkerError {
    #[error(transparent)]
    Gemm(#[from] GemmError),
    #[error("loaded pearl-gemm build '{profile}' does not support sm_{major}{minor}")]
    UnsupportedSm {
        profile: String,
        major: i32,
        minor: i32,
    },
}

impl GpuWorker {
    /// Load the native library and verify it can run on the target compute
    /// capability (e.g. `(7, 5)` for a Tesla T4). Fails fast with a clear
    /// message on an arch mismatch — the same guard the C# miner applies at
    /// startup via `pearl_capi_supports_sm`.
    pub fn new(device_id: i32, cc_major: i32, cc_minor: i32) -> Result<Self, WorkerError> {
        let gemm = PearlGemm::load_default()?;
        let profile = gemm.build_profile();
        if !gemm.supports_sm(cc_major, cc_minor) {
            return Err(WorkerError::UnsupportedSm {
                profile,
                major: cc_major,
                minor: cc_minor,
            });
        }
        tracing::info!(
            "worker[{device_id}]: pearl-gemm build '{profile}' supports sm_{cc_major}{cc_minor}"
        );
        Ok(Self {
            gemm,
            device_id,
            profile,
        })
    }

    pub fn device_id(&self) -> i32 {
        self.device_id
    }

    pub fn build_profile(&self) -> &str {
        &self.profile
    }

    /// Report native sizing constants (used to size host-side buffers).
    pub fn host_signal_sizes(&self) -> (i32, i32) {
        (
            self.gemm.host_signal_sync_size(),
            self.gemm.host_signal_header_size(),
        )
    }

    /// Borrow the underlying native library handle for the (device-context
    /// dependent) mining loop, which is implemented against a live CUDA
    /// context on GPU-equipped hosts.
    pub fn gemm(&self) -> &PearlGemm {
        &self.gemm
    }
}
