//! Stratum-style JSON-over-TLS client for LuckyPool Pearl (PRL) pools.
//!
//! This is a separate wire protocol from the Akoya gRPC V2 gateway
//! (`akoya-pool`). LuckyPool endpoints such as `pearl-sg1.lproute.com:3360`
//! speak newline-delimited JSON-RPC over a self-signed TLS socket:
//! `mining.authorize` → `mining.notify` (jobs) → `mining.submit` (shares).

pub mod client;
pub mod protocol;

pub use client::{StratumClient, StratumConfig, StratumError};
pub use protocol::{Inbound, NotifyParams, PoolError};
