//! Async TLS client for the LuckyPool Pearl Stratum-style protocol.
//!
//! Connects over TLS (the pool uses a self-signed `*.luckypool.io` cert, so
//! by default we skip certificate verification — this is a mining pool
//! endpoint, not a browser session, and the wallet is the only credential),
//! authorizes with `mining.authorize`, and exposes an async stream of parsed
//! [`Inbound`] frames plus a `submit`/`send` path.

use std::sync::Arc;

use rustls::client::danger::{HandshakeSignatureValid, ServerCertVerified, ServerCertVerifier};
use rustls::pki_types::{CertificateDer, ServerName, UnixTime};
use rustls::{ClientConfig, SignatureScheme};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tokio::net::TcpStream;
use tokio_rustls::client::TlsStream;
use tokio_rustls::TlsConnector;

use crate::protocol::{parse_line, AuthorizeParams, Inbound, Request, SubmitParams};

#[derive(Debug, thiserror::Error)]
pub enum StratumError {
    #[error("io: {0}")]
    Io(#[from] std::io::Error),
    #[error("tls: {0}")]
    Tls(String),
    #[error("json: {0}")]
    Json(#[from] serde_json::Error),
    #[error("authorize rejected: {0}")]
    AuthRejected(String),
    #[error("connection closed by pool")]
    Closed,
}

/// Certificate verifier that accepts any server cert. The pool uses a
/// self-signed wildcard cert and no ALPN; the wallet is the only credential
/// that matters, and there is no sensitive data to protect on this channel
/// beyond the (public) wallet address. Documented and opt-in via the client.
#[derive(Debug)]
struct AcceptAnyCert;

impl ServerCertVerifier for AcceptAnyCert {
    fn verify_server_cert(
        &self,
        _end_entity: &CertificateDer<'_>,
        _intermediates: &[CertificateDer<'_>],
        _server_name: &ServerName<'_>,
        _ocsp: &[u8],
        _now: UnixTime,
    ) -> Result<ServerCertVerified, rustls::Error> {
        Ok(ServerCertVerified::assertion())
    }

    fn verify_tls12_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &rustls::DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }

    fn verify_tls13_signature(
        &self,
        _message: &[u8],
        _cert: &CertificateDer<'_>,
        _dss: &rustls::DigitallySignedStruct,
    ) -> Result<HandshakeSignatureValid, rustls::Error> {
        Ok(HandshakeSignatureValid::assertion())
    }

    fn supported_verify_schemes(&self) -> Vec<SignatureScheme> {
        vec![
            SignatureScheme::RSA_PKCS1_SHA256,
            SignatureScheme::RSA_PKCS1_SHA384,
            SignatureScheme::RSA_PKCS1_SHA512,
            SignatureScheme::ECDSA_NISTP256_SHA256,
            SignatureScheme::ECDSA_NISTP384_SHA384,
            SignatureScheme::RSA_PSS_SHA256,
            SignatureScheme::RSA_PSS_SHA384,
            SignatureScheme::RSA_PSS_SHA512,
            SignatureScheme::ED25519,
        ]
    }
}

/// Connection parameters.
#[derive(Debug, Clone)]
pub struct StratumConfig {
    pub host: String,
    pub port: u16,
    pub wallet: String,
    pub worker: String,
    pub agent: String,
    /// Accept a self-signed / mismatched cert (default true for LuckyPool).
    pub insecure_tls: bool,
}

impl StratumConfig {
    pub fn new(host: impl Into<String>, port: u16, wallet: impl Into<String>) -> Self {
        Self {
            host: host.into(),
            port,
            wallet: wallet.into(),
            worker: "rig01".into(),
            agent: concat!("akoya-rs/", env!("CARGO_PKG_VERSION")).into(),
            insecure_tls: true,
        }
    }
}

/// A connected, authorized Stratum session.
pub struct StratumClient {
    reader: BufReader<tokio::io::ReadHalf<TlsStream<TcpStream>>>,
    writer: tokio::io::WriteHalf<TlsStream<TcpStream>>,
    next_id: u64,
    worker: String,
    line: String,
}

impl StratumClient {
    /// Dial the pool over TLS and complete the TCP+TLS handshake.
    pub async fn connect(cfg: &StratumConfig) -> Result<Self, StratumError> {
        // Ensure a process-level crypto provider is installed (ring). Safe to
        // call more than once; the first call wins.
        let _ = rustls::crypto::ring::default_provider().install_default();

        let tls_config = if cfg.insecure_tls {
            ClientConfig::builder()
                .dangerous()
                .with_custom_certificate_verifier(Arc::new(AcceptAnyCert))
                .with_no_client_auth()
        } else {
            // Strict TLS with the system/native roots. LuckyPool always uses
            // the insecure path (self-signed cert); this branch exists for
            // completeness / future strict pools.
            let roots = rustls::RootCertStore::empty();
            ClientConfig::builder()
                .with_root_certificates(roots)
                .with_no_client_auth()
        };

        let connector = TlsConnector::from(Arc::new(tls_config));
        let addr = format!("{}:{}", cfg.host, cfg.port);
        let tcp = TcpStream::connect(&addr).await?;
        tcp.set_nodelay(true).ok();

        let server_name = ServerName::try_from(cfg.host.clone())
            .map_err(|e| StratumError::Tls(format!("invalid server name: {e}")))?;
        let tls = connector
            .connect(server_name, tcp)
            .await
            .map_err(|e| StratumError::Tls(e.to_string()))?;

        let (rd, wr) = tokio::io::split(tls);
        Ok(Self {
            reader: BufReader::new(rd),
            writer: wr,
            next_id: 1,
            worker: cfg.worker.clone(),
            line: String::new(),
        })
    }

    fn alloc_id(&mut self) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        id
    }

    async fn write_request(&mut self, req: &Request) -> Result<(), StratumError> {
        let mut buf = serde_json::to_vec(req)?;
        buf.push(b'\n');
        self.writer.write_all(&buf).await?;
        self.writer.flush().await?;
        Ok(())
    }

    /// Send `mining.authorize` and wait for its result frame. Any `mining.notify`
    /// frames that arrive before the result are returned in `pending_jobs`.
    pub async fn authorize(&mut self, cfg: &StratumConfig) -> Result<Vec<crate::protocol::NotifyParams>, StratumError> {
        let id = self.alloc_id();
        let params = serde_json::to_value(AuthorizeParams {
            wallet: cfg.wallet.clone(),
            worker: cfg.worker.clone(),
            agent: Some(cfg.agent.clone()),
        })?;
        self.write_request(&Request::new(id, "mining.authorize", params))
            .await?;

        let mut pending_jobs = Vec::new();
        loop {
            match self.next_inbound().await? {
                Inbound::Result { id: rid, ok, error } if rid == id => {
                    if let Some(err) = error {
                        return Err(StratumError::AuthRejected(err.to_string()));
                    }
                    let accepted = matches!(ok, Some(serde_json::Value::Bool(true)));
                    if !accepted {
                        return Err(StratumError::AuthRejected(format!(
                            "unexpected result: {ok:?}"
                        )));
                    }
                    return Ok(pending_jobs);
                }
                Inbound::Notify(job) => pending_jobs.push(job),
                _ => {}
            }
        }
    }

    /// Read and parse the next inbound frame (blocks until one arrives).
    pub async fn next_inbound(&mut self) -> Result<Inbound, StratumError> {
        self.line.clear();
        let n = self.reader.read_line(&mut self.line).await?;
        if n == 0 {
            return Err(StratumError::Closed);
        }
        let trimmed = self.line.trim_end();
        Ok(parse_line(trimmed)?)
    }

    /// Submit a share for a live job. Returns the request id; callers match
    /// the eventual `Inbound::Result` with that id (accepted = `ok == true`).
    pub async fn submit(
        &mut self,
        job_id: &str,
        nonce_hex: &str,
        result_hex: Option<String>,
    ) -> Result<u64, StratumError> {
        let id = self.alloc_id();
        let params = serde_json::to_value(SubmitParams {
            job_id: job_id.to_string(),
            nonce: nonce_hex.to_string(),
            result: result_hex,
            worker: Some(self.worker.clone()),
        })?;
        self.write_request(&Request::new(id, "mining.submit", params))
            .await?;
        Ok(id)
    }
}
