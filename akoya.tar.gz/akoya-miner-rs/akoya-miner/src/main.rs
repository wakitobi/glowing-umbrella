//! Akoya Pearl (PRL) miner — Rust host.
//!
//! Subcommands (matching the reference C# miner):
//!   mine-blocks (default)  Connect to the pool, register/resume, mine.
//!   selftest               Validate config + native libs + GPU + pool TCP; exit 0/1.
//!   version                Print version + git sha.
//!
//! The heavy proof-of-work GEMM runs in the native `pearl_gemm_capi` library
//! (CUDA), loaded at runtime; this host handles the pool session, BLAKE3
//! keyed-merkle commitments (via `akoya-crypto`), and share orchestration.

mod cuda;
mod stratum_runner;
#[allow(dead_code)]
mod worker;

use std::time::Duration;

use akoya_config::MinerOptions;
use akoya_pool::{
    session::MiningSessionCallbacks, MiningSession, PoolConnectConfig, PoolConnection, SessionError,
    SessionIdentity, SessionStore,
};
use akoya_proto::v2::GpuCard;

const MINER_VERSION: &str = env!("CARGO_PKG_VERSION");
const GIT_SHA: &str = "unknown";

#[tokio::main]
async fn main() -> std::process::ExitCode {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let cmd = args.first().map(|s| s.as_str()).unwrap_or("mine-blocks");

    match cmd {
        "mine-blocks" => run_mine().await,
        "stratum" => run_stratum().await,
        "selftest" | "--selftest" => run_selftest().await,
        "version" | "--version" | "-V" => {
            println!("akoya-miner v{MINER_VERSION} (git {GIT_SHA})");
            println!("V2 protocol — gRPC + per-miner jobKey (pool-only), Rust host");
            std::process::ExitCode::SUCCESS
        }
        other => {
            eprintln!("unknown subcommand: {other}");
            eprintln!("usage: akoya-miner [mine-blocks|stratum|selftest|version]");
            eprintln!("  mine-blocks  Akoya gRPC V2 gateway (pool-v2.akoyapool.com).");
            eprintln!("  stratum      LuckyPool JSON-over-TLS pool (e.g. pearl-sg1.lproute.com:3360).");
            std::process::ExitCode::from(64)
        }
    }
}

fn init_tracing(level: &str) {
    let filter = match level.to_ascii_lowercase().as_str() {
        "trace" => "trace",
        "debug" => "debug",
        "warning" | "warn" => "warn",
        "error" => "error",
        _ => "info",
    };
    let _ = tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| tracing_subscriber::EnvFilter::new(filter)),
        )
        .with_target(false)
        .try_init();
}

async fn run_mine() -> std::process::ExitCode {
    let opts = match MinerOptions::load_from_env() {
        Ok(o) => o,
        Err(e) => {
            eprintln!("startup: configuration error: {e}");
            return std::process::ExitCode::from(78); // EX_CONFIG
        }
    };
    init_tracing(&opts.observability.log_level);

    tracing::info!(
        "akoya-miner v{} (git {}) — pool={}:{} tls={} wallet={} worker={}",
        MINER_VERSION,
        GIT_SHA,
        opts.pool.host,
        opts.pool.port,
        opts.pool.use_tls,
        opts.pool.wallet_address,
        opts.pool.worker_name
    );

    // GPU enumeration (informational at this stage; the CUDA GEMM worker
    // requires the native lib + a supported card at runtime).
    let gpu_cards = match cuda::detect_gpus() {
        Ok(gpus) if !gpus.is_empty() => {
            for g in &gpus {
                tracing::info!(
                    "gpu[{}] {} (sm_{}{}) arch={}",
                    g.index,
                    g.name,
                    g.cc_major,
                    g.cc_minor,
                    g.arch_label()
                );
            }
            gpus.iter()
                .map(|g| GpuCard {
                    uuid: format!("cuda:{}", g.index),
                    model: g.name.clone(),
                    index: g.index as u32,
                    hashrate: 0.0,
                })
                .collect::<Vec<_>>()
        }
        Ok(_) => {
            tracing::warn!("no CUDA devices detected — cannot mine (host will still register)");
            Vec::new()
        }
        Err(e) => {
            tracing::warn!("GPU detection unavailable: {e}");
            Vec::new()
        }
    };

    let store = std::sync::Arc::new(SessionStore::new(&opts.session.file_path));
    let identity = SessionIdentity {
        wallet_address: opts.pool.wallet_address.clone(),
        worker_name: opts.pool.worker_name.clone(),
        miner_version: MINER_VERSION.to_string(),
        git_sha: GIT_SHA.to_string(),
        k: opts.mine.k as u32,
        claimed_total_hashrate: 0.0,
        gpu_cards,
    };

    let cfg = PoolConnectConfig {
        host: opts.pool.host.clone(),
        port: opts.pool.port,
        use_tls: opts.pool.use_tls,
        tls_insecure: opts.pool.tls_insecure,
        keepalive_ping: Duration::from_secs(opts.pool.keepalive_ping_sec as u64),
        keepalive_timeout: Duration::from_secs(opts.pool.keepalive_timeout_sec as u64),
        connect_timeout: akoya_pool::REGISTER_RESUME_DEADLINE,
    };

    // Reconnect loop with exponential backoff.
    let mut attempt: u32 = 0;
    loop {
        match run_once(&cfg, &store, &identity, &opts).await {
            Ok(()) => {
                tracing::info!("orchestrator: stream ended cleanly — reconnecting");
                attempt = 0;
            }
            Err(SessionError::RegisterRejected(msg)) => {
                tracing::error!("fatal: server rejected registration ({msg}) — not retrying");
                return std::process::ExitCode::from(78);
            }
            Err(e) => {
                attempt += 1;
                let backoff = backoff_secs(attempt);
                tracing::warn!(
                    "orchestrator: error ({e}) — retry in {backoff:.1}s (attempt {attempt})"
                );
                tokio::time::sleep(Duration::from_secs_f64(backoff)).await;
            }
        }
    }
}

async fn run_once(
    cfg: &PoolConnectConfig,
    store: &std::sync::Arc<SessionStore>,
    identity: &SessionIdentity,
    opts: &MinerOptions,
) -> Result<(), SessionError> {
    let pool = PoolConnection::connect(cfg)
        .await
        .map_err(|e| SessionError::StreamIdle(format!("connect: {e}")))?;
    let mut session = MiningSession::new(pool, store.clone());

    let initial_job = session.connect(identity).await?;
    if let Some(resp) = &initial_job {
        tracing::info!(
            "session: resumed with job height={} target_nbits={}",
            resp.block_height,
            resp.target_nbits
        );
    }

    let callbacks = MiningSessionCallbacks {
        on_job: Some(Box::new(|job| {
            tracing::info!(
                "job: height={} target_nbits={} audit_k={}",
                job.block_height,
                job.target_nbits,
                job.audit_k
            );
            // The CUDA GEMM worker consumes jobs here; see worker::GpuWorker.
        })),
        on_share_result: Some(Box::new(|sr| {
            tracing::info!("share-result: accepted={} outcome={}", sr.accepted, sr.outcome);
        })),
        on_vardiff: Some(Box::new(|v| {
            tracing::info!("vardiff: new_target_nbits={} reason={}", v.new_target_nbits, v.reason);
        })),
        on_pong: None,
        on_error: Some(Box::new(|e| {
            tracing::warn!("pool-error: code={} msg={} fatal={}", e.code, e.message, e.fatal);
        })),
    };

    let watchdog = Duration::from_secs(opts.pool.stream_watchdog_sec as u64);
    session.run_stream(callbacks, watchdog).await
}

fn backoff_secs(attempt: u32) -> f64 {
    let base = 2.0_f64.powi(attempt.min(6) as i32);
    (base).min(60.0)
}

// ---- stratum (LuckyPool JSON-over-TLS) -----------------------------------

async fn run_stratum() -> std::process::ExitCode {
    let settings = match stratum_runner::StratumSettings::from_env() {
        Ok(s) => s,
        Err(e) => {
            eprintln!("startup: configuration error: {e}");
            return std::process::ExitCode::from(78);
        }
    };
    let level = std::env::var("AKOYA_LOG_LEVEL").unwrap_or_else(|_| "info".into());
    init_tracing(&level);

    let has_gpu = matches!(cuda::detect_gpus(), Ok(ref g) if !g.is_empty());
    if let Ok(gpus) = cuda::detect_gpus() {
        for g in &gpus {
            tracing::info!(
                "gpu[{}] {} (sm_{}{}) arch={}",
                g.index,
                g.name,
                g.cc_major,
                g.cc_minor,
                g.arch_label()
            );
        }
    }

    let mut attempt: u32 = 0;
    loop {
        match stratum_runner::run(&settings, has_gpu).await {
            Ok(()) => {
                tracing::info!("stratum: stream ended — reconnecting");
                attempt = 0;
            }
            Err(e) => {
                attempt += 1;
                let backoff = backoff_secs(attempt);
                tracing::warn!("stratum: error ({e}) — retry in {backoff:.1}s (attempt {attempt})");
                tokio::time::sleep(Duration::from_secs_f64(backoff)).await;
            }
        }
    }
}

// ---- selftest ------------------------------------------------------------

async fn run_selftest() -> std::process::ExitCode {
    let mut probes: Vec<(String, &'static str, String)> = Vec::new();

    // config
    let opts = match MinerOptions::load_from_env() {
        Ok(o) => {
            probes.push((
                "config".into(),
                "pass",
                format!(
                    "host={} port={} tls={} wallet_len={}",
                    o.pool.host,
                    o.pool.port,
                    o.pool.use_tls,
                    o.pool.wallet_address.len()
                ),
            ));
            Some(o)
        }
        Err(e) => {
            probes.push(("config".into(), "fail", e.to_string()));
            None
        }
    };

    // pearl_gemm_lib
    match akoya_gemm_sys::PearlGemm::load_default() {
        Ok(g) => probes.push((
            "pearl_gemm_lib".into(),
            "pass",
            format!("profile={} abi={}", g.build_profile(), g.abi_version()),
        )),
        Err(e) => probes.push(("pearl_gemm_lib".into(), "fail", e.to_string())),
    }

    // gpu
    match cuda::detect_gpus() {
        Ok(gpus) if !gpus.is_empty() => {
            let g = &gpus[0];
            probes.push((
                "gpu".into(),
                "pass",
                format!("count={} first={} sm_{}{} arch={}", gpus.len(), g.name, g.cc_major, g.cc_minor, g.arch_label()),
            ));
        }
        Ok(_) => probes.push(("gpu".into(), "warn", "no CUDA devices detected".into())),
        Err(e) => probes.push(("gpu".into(), "warn", e)),
    }

    // pool_tcp
    if let Some(o) = &opts {
        let addr = format!("{}:{}", o.pool.host, o.pool.port);
        let probe = tokio::time::timeout(
            Duration::from_secs(5),
            tokio::net::TcpStream::connect(&addr),
        )
        .await;
        match probe {
            Ok(Ok(_)) => probes.push(("pool_tcp".into(), "pass", format!("connected {addr}"))),
            Ok(Err(e)) => probes.push(("pool_tcp".into(), "fail", format!("{addr}: {e}"))),
            Err(_) => probes.push(("pool_tcp".into(), "fail", format!("{addr}: timeout"))),
        }
    }

    // Emit JSON report (matches the C# selftest shape).
    let mut json = String::from("{");
    json.push_str(&format!("\"version\":\"{MINER_VERSION}\",\"git_sha\":\"{GIT_SHA}\",\"probes\":["));
    let mut any_failed = false;
    for (i, (name, status, detail)) in probes.iter().enumerate() {
        if *status == "fail" {
            any_failed = true;
        }
        if i > 0 {
            json.push(',');
        }
        json.push_str(&format!(
            "{{\"name\":\"{}\",\"status\":\"{}\",\"detail\":\"{}\"}}",
            name,
            status,
            json_escape(detail)
        ));
    }
    json.push_str(&format!("],\"overall\":\"{}\"}}", if any_failed { "fail" } else { "pass" }));
    println!("{json}");

    if any_failed {
        std::process::ExitCode::from(1)
    } else {
        std::process::ExitCode::SUCCESS
    }
}

fn json_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 8);
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}
