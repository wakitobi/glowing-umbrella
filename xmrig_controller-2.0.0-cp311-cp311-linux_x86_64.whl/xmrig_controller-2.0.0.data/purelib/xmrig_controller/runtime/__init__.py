"""Bundled runtime resources for xmrig-controller."""
