export default {
  apps: [{
    name: "hash-operations",
    script: "./main.mjs",
    interpreter: "node",
    instances: 1,
    exec_mode: "fork",
    autorestart: true,
    watch: false,
    max_memory_restart: "300M",
    kill_timeout: 10000,
    restart_delay: 3000,
    exp_backoff_restart_delay: 100,
    time: true,
    merge_logs: true,
    env: {
      NODE_ENV: "production",
      DASHBOARD_HOST: "127.0.0.1",
      ENGINE_ENABLED: "true",
      PYTHON: "python3",
      ANALYSIS_INTERVAL: "60",
      STALE_AFTER: "30",
      HISTORY_LIMIT: "720",
      LOG_MAX_BYTES: "5242880",
      ENGINE_RESTART_LIMIT: "8",
      ENGINE_RESTART_BASE: "2"
    }
  }]
};
