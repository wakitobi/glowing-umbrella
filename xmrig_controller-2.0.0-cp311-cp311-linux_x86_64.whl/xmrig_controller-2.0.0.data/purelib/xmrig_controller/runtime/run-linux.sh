#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

[ "$(uname -s)" = "Linux" ] || { echo "redis.so requires Linux x86-64." >&2; exit 1; }
[ -f .env ] || { echo "Missing .env. Run ./install-linux.sh first." >&2; exit 1; }
exec node main.mjs
