import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = path.dirname(fileURLToPath(import.meta.url));

function integer(name, fallback, minimum, maximum) {
  const raw = process.env[name];
  const value = raw === undefined || raw === "" ? fallback : Number(raw);
  if (!Number.isInteger(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be an integer between ${minimum} and ${maximum}`);
  }
  return value;
}

function number(name, fallback, minimum, maximum) {
  const raw = process.env[name];
  const value = raw === undefined || raw === "" ? fallback : Number(raw);
  if (!Number.isFinite(value) || value < minimum || value > maximum) {
    throw new Error(`${name} must be between ${minimum} and ${maximum}`);
  }
  return value;
}

function boolean(name, fallback) {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  if (["1", "true", "yes", "on"].includes(raw.toLowerCase())) return true;
  if (["0", "false", "no", "off"].includes(raw.toLowerCase())) return false;
  throw new Error(`${name} must be true or false`);
}

export function loadConfig() {
  return Object.freeze({
    rootDir,
    host: process.env.DASHBOARD_HOST || "127.0.0.1",
    port: process.env.DASHBOARD_PORT ? integer("DASHBOARD_PORT", 0, 10000, 65000) : null,
    engineEnabled: boolean("ENGINE_ENABLED", true),
    python: process.env.PYTHON || "python3",
    analysisIntervalMs: number("ANALYSIS_INTERVAL", 60, 5, 86400) * 1000,
    staleAfterMs: number("STALE_AFTER", 30, 5, 86400) * 1000,
    historyLimit: integer("HISTORY_LIMIT", 720, 20, 10000),
    logMaxBytes: integer("LOG_MAX_BYTES", 5 * 1024 * 1024, 1024, 1024 * 1024 * 1024),
    restartLimit: integer("ENGINE_RESTART_LIMIT", 8, 0, 100),
    restartBaseMs: number("ENGINE_RESTART_BASE", 2, 0.1, 3600) * 1000,
    ollamaUrl: process.env.OLLAMA_URL || "",
    ollamaModel: process.env.OLLAMA_MODEL || "",
    telemetryPath: path.join(rootDir, "data", "telemetry.jsonl"),
    publicDir: path.join(rootDir, "public"),
    bridgePath: path.join(rootDir, "miner_bridge.py"),
    version: process.env.npm_package_version || "2.0.0",
    hostname: os.hostname(),
  });
}
