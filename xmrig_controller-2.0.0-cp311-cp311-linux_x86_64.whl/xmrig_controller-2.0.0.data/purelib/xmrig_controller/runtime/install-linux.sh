#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

command -v node >/dev/null || { echo "Node.js 18 or newer is required." >&2; exit 1; }
command -v npm >/dev/null || { echo "npm is required." >&2; exit 1; }
command -v python3 >/dev/null || { echo "Python 3 is required for the native bridge." >&2; exit 1; }
node_major="$(node -p 'process.versions.node.split(".")[0]')"
[ "$node_major" -ge 18 ] || { echo "Node.js 18+ is required." >&2; exit 1; }
[ "$(uname -s)" = "Linux" ] || { echo "The bundled native engine requires Linux." >&2; exit 1; }
[ -f redis.so ] || { echo "redis.so is missing." >&2; exit 1; }
[ -f .env ] || {
  cp .env.example .env
  chmod 600 .env
  echo "Created .env from .env.example. Fill in the pool settings, then run this installer again." >&2
  exit 2
}

npm test
python3 -m py_compile miner_bridge.py
mkdir -p data logs
chmod 600 .env

if ! command -v pm2 >/dev/null; then
  echo "PM2 is required. Install it once with: sudo npm install --global pm2" >&2
  exit 3
fi

pm2 startOrReload ecosystem.config.mjs --update-env
pm2 save

echo "Service ready. Run 'pm2 logs hash-operations --lines 20' to see the dashboard port."
echo "Enable boot startup with the command printed by: pm2 startup"
