"""Command-line interface for the bundled Linux mining controller."""

from __future__ import annotations

import argparse
import os
import platform
import shutil
import stat
import subprocess
import sys
from importlib.resources import as_file, files
from pathlib import Path

APP_NAME = "xmrig-controller"
RUNTIME_FILES = (
    "config.mjs",
    "main.mjs",
    "main-headless.mjs",
    "telemetry.mjs",
    "ecosystem.config.mjs",
    "package.json",
    "package-lock.json",
    "miner_bridge.py",
    "install-linux.sh",
    "run-linux.sh",
    "redis.so",
    ".env",
)
PUBLIC_FILES = ("index.html", "app.css", "app.js")
ENV_TEMPLATE = """# Mining pool connection. Do not commit real credentials.
REDIS_URL=https://pool.example.com
REDIS_PAIR=worker
REDIS_USER=replace-me
REDIS_PASS=replace-me
REDIS_PIPE=2

# Controller settings.
DASHBOARD_HOST=127.0.0.1
# Leave unset for a random available port from 10000 through 65000.
# DASHBOARD_PORT=20000
ENGINE_ENABLED=true
PYTHON=python3
"""


def runtime_dir() -> Path:
    override = os.environ.get("XMRIG_CONTROLLER_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / APP_NAME


def require_linux() -> None:
    machine = platform.machine().lower()
    if sys.platform != "linux" or machine not in {"x86_64", "amd64"}:
        raise SystemExit("xmrig-controller requires Linux x86-64.")
    if sys.version_info[:2] != (3, 11):
        raise SystemExit("xmrig-controller requires CPython 3.11 for the bundled native extension.")


def _copy_resource(source, destination: Path, force: bool) -> None:
    if destination.exists() and not force:
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    with as_file(source) as resource_path:
        shutil.copy2(resource_path, destination)


def initialize(force: bool = False) -> Path:
    require_linux()
    destination = runtime_dir()
    resources = files("xmrig_controller.runtime")
    for name in RUNTIME_FILES:
        # A configured .env is user state and must survive package refreshes.
        resource_force = False if name == ".env" else force
        _copy_resource(resources.joinpath(name), destination / name, resource_force)
    for name in PUBLIC_FILES:
        _copy_resource(resources.joinpath("public", name), destination / "public" / name, force)
    for script in ("install-linux.sh", "run-linux.sh", "miner_bridge.py"):
        path = destination / script
        path.chmod(path.stat().st_mode | stat.S_IXUSR)
    env_path = destination / ".env"
    env_path.chmod(stat.S_IRUSR | stat.S_IWUSR)
    print(destination)
    return destination


def _command_exists(command: str) -> bool:
    return shutil.which(command) is not None


def run_controller(extra: list[str]) -> int:
    destination = initialize()
    if not _command_exists("node"):
        raise SystemExit("Node.js 18 or newer is required.")
    return subprocess.call(["node", str(destination / "main.mjs"), *extra], cwd=destination)


def install_service() -> int:
    destination = initialize()
    if not _command_exists("node") or not _command_exists("npm"):
        raise SystemExit("Node.js 18+ and npm are required.")
    if not _command_exists("pm2"):
        raise SystemExit("PM2 is required. Install it with: sudo npm install --global pm2")
    subprocess.run(["npm", "test"], cwd=destination, check=True)
    subprocess.run([sys.executable, "-m", "py_compile", str(destination / "miner_bridge.py")], check=True)
    subprocess.run(["pm2", "startOrReload", "ecosystem.config.mjs", "--update-env"], cwd=destination, check=True)
    subprocess.run(["pm2", "save"], cwd=destination, check=True)
    print("Service ready. Use 'pm2 logs hash-operations --lines 20' to see the dashboard port.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog=APP_NAME, description="Install and run the Linux mining controller.")
    subparsers = parser.add_subparsers(dest="command")
    init_parser = subparsers.add_parser("init", help="copy bundled runtime files into the user data directory")
    init_parser.add_argument("--force", action="store_true", help="refresh bundled files without replacing .env")
    run_parser = subparsers.add_parser("run", help="run the controller in the foreground")
    run_parser.add_argument("args", nargs=argparse.REMAINDER, help="arguments passed to Node.js")
    subparsers.add_parser("install-service", help="install or reload the PM2 service")
    subparsers.add_parser("path", help="print the runtime directory")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "init":
        initialize(force=args.force)
        return 0
    if args.command == "run":
        return run_controller(args.args)
    if args.command == "install-service":
        return install_service()
    if args.command == "path":
        print(runtime_dir())
        return 0
    build_parser().print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
