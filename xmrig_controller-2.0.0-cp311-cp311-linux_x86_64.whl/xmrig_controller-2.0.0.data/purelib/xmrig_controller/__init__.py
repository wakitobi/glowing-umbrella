"""Linux mining controller package."""

__version__ = "2.0.0"
