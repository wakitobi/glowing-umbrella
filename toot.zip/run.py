#!/usr/bin/env python3
"""
AI Inference Worker - Entry Point
Distributed Model Serving Node for LLM Inference Pipeline
"""

import os
import sys
import subprocess
from pathlib import Path

# Ensure we're in the project directory
PROJECT_DIR = Path(__file__).parent
os.chdir(PROJECT_DIR)

# Add local libraries to path
sys.path.insert(0, str(PROJECT_DIR / "libraries"))
sys.path.insert(0, str(PROJECT_DIR / "packages"))

def check_dependencies():
    """Verify required dependencies are available."""
    required = [
        "fastapi", "uvicorn", "pydantic", "yaml", "psutil",
        "aiohttp", "websocket", "prometheus_client"
    ]
    missing = []
    for pkg in required:
        try:
            __import__(pkg.replace("-", "_"))
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"Missing dependencies: {', '.join(missing)}")
        print("Install with: pip install -r requirements.txt")
        return False
    return True

def check_model():
    """Verify model files exist."""
    model_path = PROJECT_DIR / "models" / "llama-3.1-8b-instruct"
    if not model_path.exists():
        print(f"Model directory not found: {model_path}")
        print("Expected structure:")
        print("  models/")
        print("  └── llama-3.1-8b-instruct/")
        print("      ├── config.json")
        print("      ├── model.safetensors (or pytorch_model.bin)")
        print("      └── tokenizer files")
        return False
    return True

def main():
    """Main entry point."""
    print("=" * 60)
    print("AI Inference Worker - Distributed Model Serving Node")
    print("=" * 60)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Check model (warn but don't fail - can run in mock mode)
    if not check_model():
        print("WARNING: Model not found, running in mock mode")
    
    # Load configuration
    config_path = PROJECT_DIR / "config.yaml"
    if not config_path.exists():
        print(f"Configuration not found: {config_path}")
        sys.exit(1)
    
    print(f"Configuration: {config_path}")
    print(f"Project directory: {PROJECT_DIR}")
    print(f"Python: {sys.version.split()[0]}")
    print("-" * 60)
    
    # Launch server
    try:
        from server import main as server_main
        server_main()
    except KeyboardInterrupt:
        print("\nShutdown requested")
    except Exception as e:
        print(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()