#!/bin/bash
# ═══════════════════════════════════════════════════════════
# Pearl GPU Pool Miner — T4 Linux Deployment
# ═══════════════════════════════════════════════════════════
# Installs everything needed on a fresh T4 Linux box.
# Builds pearl_mining Rust lib + Python miner.
#
# Usage:
#   curl -sSL <this-url> | bash
#   # or
#   bash setup_t4.sh
# ═══════════════════════════════════════════════════════════
set -e

POOL="pearl-us-ord.lproute.com:3360"
WALLET="prl1p2jan4dvkdfkt5r3pra7z96axrxjyjcgat9w7ldetlcy9wffm569sc9ux2t"
WORKER="t4-$(hostname | cut -c1-8)"

echo "═══════════════════════════════════════════════════════════"
echo " Pearl GPU Miner — T4 Setup"
echo "═══════════════════════════════════════════════════════════"

# 1. Install system deps
echo "[1/5] Installing system dependencies..."
if command -v apt-get &>/dev/null; then
    sudo apt-get update -qq
    sudo apt-get install -y -qq build-essential curl git python3-pip
fi

# 2. Install Rust (for building pearl_mining)
if ! command -v cargo &>/dev/null; then
    echo "[2/5] Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
    source "$HOME/.cargo/env"
else
    echo "[2/5] Rust already installed"
fi

# 3. Clone Pearl repo
PEARL_DIR="$HOME/pearl"
if [ ! -d "$PEARL_DIR" ]; then
    echo "[3/5] Cloning Pearl repo..."
    git clone --depth 1 https://github.com/pearl-research-labs/pearl.git "$PEARL_DIR"
else
    echo "[3/5] Pearl repo already exists"
    cd "$PEARL_DIR" && git pull --ff-only 2>/dev/null || true
fi

# 4. Build pearl_mining Rust library
echo "[4/5] Building pearl_mining..."
cd "$PEARL_DIR/py-pearl-mining"

# Install maturin if needed
pip install maturin 2>/dev/null || pip3 install maturin

# Build and install the wheel
maturin develop --release 2>&1 | tail -5

# Verify
python3 -c "from pearl_mining import PlainProof, MerkleTree; print('[OK] pearl_mining installed')"

# 5. Install Python deps
echo "[5/5] Installing Python deps..."
pip install blake3 torch numpy 2>/dev/null || pip3 install blake3 torch numpy

# Copy miner script
MINER_DIR="$HOME/pearl-miner"
mkdir -p "$MINER_DIR"
# The miner script should be placed here — copy from wherever you got it:
# cp pearl_pool_miner.py "$MINER_DIR/"

echo ""
echo "═══════════════════════════════════════════════════════════"
echo " Setup complete!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo " Run the miner:"
echo "   cd $MINER_DIR"
echo "   python3 pearl_pool_miner.py \\"
echo "     --pool $POOL \\"
echo "     --wallet $WALLET \\"
echo "     --worker $WORKER"
echo ""
echo " Or with custom matrix size (smaller = faster per attempt):"
echo "   python3 pearl_pool_miner.py --m 2048 --n 2048 --k 4096"
echo ""

# Auto-run if flag set
if [ "${AUTORUN:-}" = "1" ]; then
    cd "$MINER_DIR"
    exec python3 pearl_pool_miner.py --pool "$POOL" --wallet "$WALLET" --worker "$WORKER"
fi
