Power2b Go CPU Miner (Linux x86_64)
===================================

This binary contains the canonical MicroBitcoin power2b hasher and Stratum client.
It was built and tested on Ubuntu x86_64.

1. Test before mining:
   ./power2b-go-miner test

Expected:
   edc067dc5d32bf354297b77121dda0c3a98013ca5b6f825ffffee9c8c53208a9
   VERDICT: PASS

2. Mine:
   export POWER2B_USER='YOUR_WALLET.WORKER'
   export POWER2B_PASS='x'
   export POWER2B_POOL='na.rplant.xyz:7022'
   ./power2b-go-miner

The program uses all available CPU cores. Set a distinct worker suffix when running
multiple machines. A real successful connection prints subscribed, authorized/submit
responses, jobs, and share accepted.

Detached:
   nohup ./power2b-go-miner > miner.log 2>&1 &
   tail -f miner.log

Requirements: Linux x86_64 with glibc. No Go installation is needed.
Do not run this on infrastructure where sustained mining violates the provider ToS.
