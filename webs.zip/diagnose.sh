#!/usr/bin/env bash
# Diagnose why the web miner isn't running. Prints all relevant state.
cd "$(dirname "$0")"

# recover the ports this instance used (random per launch); fall back to defaults
WEB_PORT=8765; CDP_PORT=9222
[ -f .miner-ports ] && . ./.miner-ports 2>/dev/null

echo "==== ports (from .miner-ports) ===="
echo "web=$WEB_PORT  cdp=$CDP_PORT"
echo
echo "==== processes ===="
ps aux | grep -E "chrome|server.py" | grep -v grep || echo "(none)"
echo
echo "==== port checks ===="
for p in "$WEB_PORT" "$CDP_PORT"; do
  if curl -s -o /dev/null -m 2 "http://127.0.0.1:$p/"; then echo ":$p UP"; else echo ":$p DOWN"; fi
done
echo
echo "==== chrome.log (last 30) ===="
[ -f chrome.log ] && tail -30 chrome.log || echo "(no chrome.log)"
echo
echo "==== server.log (last 20) ===="
[ -f server.log ] && tail -20 server.log || echo "(no server.log)"
echo
echo "==== page state (via CDP if up) ===="
if curl -s -m 2 "http://127.0.0.1:$CDP_PORT/json" | grep -q websocketDebuggerUrl; then
  echo "CDP is up - open http://127.0.0.1:$WEB_PORT/ in a browser to see the stats page"
else
  echo "CDP down - headless chrome not running"
fi
echo
echo "==== python3 / chrome ===="
command -v python3 && python3 --version
command -v chromium chromium-browser google-chrome 2>/dev/null || echo "(no chrome binary in PATH)"
echo
echo "If ports are DOWN, re-run:  bash setup.sh"
