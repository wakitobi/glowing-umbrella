#!/usr/bin/env bash
# Stop the web miner: kills headless chrome + web server for THIS instance.
cd "$(dirname "$0")"

# recover the ports this instance used (random per launch)
WEB_PORT=""; CDP_PORT=""
[ -f .miner-ports ] && . ./.miner-ports 2>/dev/null

stopped=0
if [ -f chrome.pid ]; then
  kill "$(cat chrome.pid)" 2>/dev/null && echo "chrome stopped (pid $(cat chrome.pid))" && stopped=1
  rm -f chrome.pid
fi
if [ -f server.pid ]; then
  kill "$(cat server.pid)" 2>/dev/null && echo "server stopped (pid $(cat server.pid))" && stopped=1
  rm -f server.pid
fi

# fallback: match by the CDP port flag on the chrome command line
if [ -n "$CDP_PORT" ]; then
  pkill -f "remote-debugging-port=$CDP_PORT" 2>/dev/null && echo "chrome (CDP :$CDP_PORT) stopped" && stopped=1
fi

rm -f .miner-ports
[ "$stopped" -eq 1 ] && echo "done" || echo "nothing running to stop"
