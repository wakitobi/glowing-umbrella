//! redis-miner: native Rust RandomX (rx/0) miner speaking the Monero Stratum
//! protocol over the same Koyeb WebSocket proxy the Python `redis` miner used.
//! Reimplementation of redis.so: builds the RandomX context once per seed hash
//! and hashes across N native threads, submitting shares that beat the target.

mod config;
mod job;
mod randomx;
mod stratum;

use config::Config;
use crossbeam_channel::{bounded, Receiver, Sender};
use job::{difficulty_from_target, meets_target, Job};
use rand::Rng;
use randomx::{new_context, RxHasher};
use rust_randomx::Context;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};
use stratum::{PoolEvent, StratumClient};

/// Shared work snapshot handed to worker threads.
struct Work {
    job: Job,
    ctx: Arc<Context>,
    epoch: u64,
}

/// A found share sent from a worker to the network thread for submit.
struct Share {
    job_id: String,
    nonce_hex: String,
    result_hex: String,
}

/// Use the full 2 GiB dataset (fast mode) only if we likely have the RAM.
/// 8 GB box here → fast mode is fine. Allow override via REDIS_LIGHT=1 env.
fn want_fast_mode() -> bool {
    !matches!(std::env::var("REDIS_LIGHT").as_deref(), Ok("1") | Ok("true"))
}

fn main() {
    let _ = rustls::crypto::ring::default_provider().install_default();

    let mut env_path: Option<String> = None;
    let mut threads_override: Option<usize> = None;
    let args: Vec<String> = std::env::args().collect();
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--env" => {
                i += 1;
                env_path = args.get(i).cloned();
            }
            "--threads" | "-t" => {
                i += 1;
                threads_override = args.get(i).and_then(|s| s.parse().ok());
            }
            "--help" | "-h" => {
                println!(
                    "redis-miner [--env PATH] [--threads N]\n\
                     RandomX (rx/0) Monero-Stratum miner. Reads pool config from .env\n\
                     (REDIS_URL, REDIS_PAIR, REDIS_USER, REDIS_PASS, REDIS_PIPE).\n\
                     Set REDIS_LIGHT=1 for light-mode (low memory, slower)."
                );
                return;
            }
            _ => {}
        }
        i += 1;
    }

    let mut cfg = match Config::load(env_path.as_deref()) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("config error: {e}");
            std::process::exit(1);
        }
    };
    if let Some(t) = threads_override {
        cfg.threads = t;
    }

    println!(
        "redis-miner starting: RandomX rx/0, login={}, threads={}, mode={}",
        cfg.login,
        cfg.threads,
        if want_fast_mode() { "fast(2GiB)" } else { "light(256MiB)" }
    );

    loop {
        if let Err(e) = run_session(&cfg) {
            eprintln!("session ended: {e}; reconnecting in 5s");
            thread::sleep(Duration::from_secs(5));
        }
    }
}

fn run_session(cfg: &Config) -> Result<(), String> {
    let mut client = StratumClient::connect(&cfg.proxy)?;
    client.set_read_timeout(Some(Duration::from_millis(500)));
    println!("connected, logging in…");
    client.login(&cfg.login, &cfg.pass)?;

    let (tx, rx) = std::sync::mpsc::channel::<PoolEvent>();
    let (share_tx, share_rx): (Sender<Share>, Receiver<Share>) = bounded(256);

    let work: Arc<Mutex<Option<Arc<Work>>>> = Arc::new(Mutex::new(None));
    let epoch = Arc::new(AtomicU64::new(0));
    let hashes = Arc::new(AtomicU64::new(0));
    let accepted = Arc::new(AtomicUsize::new(0));
    let rejected = Arc::new(AtomicUsize::new(0));

    // Spawn worker threads.
    let fast = want_fast_mode();
    let mut worker_handles = Vec::new();
    for wid in 0..cfg.threads {
        let work = Arc::clone(&work);
        let epoch = Arc::clone(&epoch);
        let hashes = Arc::clone(&hashes);
        let share_tx = share_tx.clone();
        worker_handles.push(thread::spawn(move || {
            worker_loop(wid, work, epoch, hashes, share_tx);
        }));
    }
    drop(share_tx);

    // Hashrate reporter.
    {
        let hashes = Arc::clone(&hashes);
        let accepted = Arc::clone(&accepted);
        let rejected = Arc::clone(&rejected);
        thread::spawn(move || {
            let mut last = Instant::now();
            let mut last_h = 0u64;
            loop {
                thread::sleep(Duration::from_secs(10));
                let now = Instant::now();
                let h = hashes.load(Ordering::Relaxed);
                let dt = now.duration_since(last).as_secs_f64();
                let hr = if dt > 0.0 { (h - last_h) as f64 / dt } else { 0.0 };
                println!(
                    "[stats] {:.1} H/s | accepted {} | rejected {}",
                    hr,
                    accepted.load(Ordering::Relaxed),
                    rejected.load(Ordering::Relaxed)
                );
                last = now;
                last_h = h;
            }
        });
    }

    // Network-thread state.
    let mut session_id: Option<String> = None;
    // Cache the RandomX context by seed hash so we only rebuild on seed rotation.
    let mut cur_seed: Option<String> = None;
    let mut cur_ctx: Option<Arc<Context>> = None;
    let mut last_keepalive = Instant::now();

    loop {
        client.pump(&tx)?;
        while let Ok(ev) = rx.try_recv() {
            match ev {
                PoolEvent::LoggedIn { session_id: sid } => {
                    println!("logged in, session={sid}");
                    session_id = Some(sid);
                }
                PoolEvent::LoginFailed(detail) => {
                    return Err(format!("login failed: {detail}"));
                }
                PoolEvent::NewJob(job) => {
                    let diff = difficulty_from_target(job.target);
                    println!(
                        "new job {} target={} (~diff {}) seed={}…",
                        job.job_id,
                        job.target_hex,
                        diff,
                        &job.seed_hash.chars().take(12).collect::<String>()
                    );

                    // (Re)build the RandomX context if the seed changed.
                    if cur_seed.as_deref() != Some(job.seed_hash.as_str()) {
                        let seed_bytes = hex::decode(&job.seed_hash)
                            .map_err(|e| format!("bad seed hash: {e}"))?;
                        println!("building RandomX context for new seed (this takes a moment)…");
                        let ctx = new_context(&seed_bytes, fast);
                        cur_ctx = Some(ctx);
                        cur_seed = Some(job.seed_hash.clone());
                        println!("RandomX context ready");
                    }

                    let ctx = cur_ctx.clone().expect("context built above");
                    let new_epoch = epoch.fetch_add(1, Ordering::SeqCst) + 1;
                    let w = Arc::new(Work {
                        job,
                        ctx,
                        epoch: new_epoch,
                    });
                    *work.lock().unwrap() = Some(w);
                }
                PoolEvent::SubmitResult { accepted: ok, detail } => {
                    if ok {
                        accepted.fetch_add(1, Ordering::Relaxed);
                        println!("share ACCEPTED");
                    } else {
                        rejected.fetch_add(1, Ordering::Relaxed);
                        println!("share REJECTED: {detail}");
                    }
                }
            }
        }

        // Submit found shares.
        while let Ok(s) = share_rx.try_recv() {
            if let Some(sid) = &session_id {
                println!("submitting share job={} nonce={}", s.job_id, s.nonce_hex);
                client.submit(sid, &s.job_id, &s.nonce_hex, &s.result_hex)?;
            }
        }

        // Keepalive every 30s.
        if last_keepalive.elapsed() >= Duration::from_secs(30) {
            if let Some(sid) = &session_id {
                let _ = client.keepalived(sid);
            }
            last_keepalive = Instant::now();
        }

        thread::sleep(Duration::from_millis(20));
    }
}

/// A worker: snapshots the current Work, hashes a random nonce sweep with a
/// context-bound RandomX hasher, and restarts when the epoch changes.
fn worker_loop(
    _wid: usize,
    work: Arc<Mutex<Option<Arc<Work>>>>,
    epoch: Arc<AtomicU64>,
    hashes: Arc<AtomicU64>,
    share_tx: Sender<Share>,
) {
    let mut rng = rand::thread_rng();
    let mut hasher: Option<RxHasher> = None;
    let mut bound_epoch: u64 = u64::MAX;

    loop {
        let snapshot = { work.lock().unwrap().clone() };
        let w = match snapshot {
            Some(w) => w,
            None => {
                thread::sleep(Duration::from_millis(100));
                continue;
            }
        };

        // (Re)bind hasher to this work's context when the epoch/context changes.
        if bound_epoch != w.epoch {
            match hasher.as_mut() {
                Some(h) => h.update(Arc::clone(&w.ctx)),
                None => hasher = Some(RxHasher::new(Arc::clone(&w.ctx))),
            }
            bound_epoch = w.epoch;
        }
        let h = hasher.as_ref().unwrap();

        let mut nonce: u32 = rng.gen();
        let mut local_count: u64 = 0;
        loop {
            let blob = w.job.blob_with_nonce(nonce);
            let digest = h.hash(&blob);
            local_count += 1;

            if meets_target(&digest, w.job.target) {
                let _ = share_tx.send(Share {
                    job_id: w.job.job_id.clone(),
                    nonce_hex: w.job.nonce_hex(nonce),
                    result_hex: hex::encode(digest),
                });
            }

            if local_count & 0x3f == 0 {
                hashes.fetch_add(local_count, Ordering::Relaxed);
                local_count = 0;
                if epoch.load(Ordering::SeqCst) != w.epoch {
                    break;
                }
            }
            nonce = nonce.wrapping_add(1);
        }
    }
}
