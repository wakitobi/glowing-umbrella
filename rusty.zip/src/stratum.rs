//! Monero-protocol Stratum client over the Koyeb WebSocket proxy.
//! Messages are newline-terminated JSON-RPC 2.0. Sequence:
//!   login(login,pass,agent,algo) -> result{ id: session, job:{ blob, job_id, target, seed_hash } }
//!   push method "job" -> new job
//!   submit{ id: session, job_id, nonce, result } -> { status: "OK" } or error
//!   keepalived{ id: session } -> keepalive
//! This mirrors the strings found in redis.so (login/agent/blob_hex/
//! seed_hash_hex/job_id/keepalive + randomx-python/1.0.0 agent).

use serde_json::{json, Value};
use std::collections::HashMap;
use std::net::TcpStream;
use std::sync::mpsc::Sender;
use tungstenite::stream::MaybeTlsStream;
use tungstenite::{connect, Message, WebSocket};

use crate::job::Job;

#[derive(Debug, Clone)]
pub enum PoolEvent {
    LoggedIn { session_id: String },
    NewJob(Job),
    SubmitResult { accepted: bool, detail: String },
    LoginFailed(String),
}

type Ws = WebSocket<MaybeTlsStream<TcpStream>>;

pub struct StratumClient {
    ws: Ws,
    next_id: u64,
    /// Maps outgoing request id -> method name, so responses can be routed.
    pending: HashMap<u64, String>,
}

fn as_str(v: &Value) -> String {
    v.as_str().map(|s| s.to_string()).unwrap_or_default()
}

/// Extract a Job from a `params`/`job` object.
fn job_from_obj(o: &Value) -> Option<Job> {
    let blob = o.get("blob")?.as_str()?;
    let job_id = o.get("job_id")?.as_str()?;
    let target = o.get("target")?.as_str()?;
    let seed = o
        .get("seed_hash")
        .and_then(|v| v.as_str())
        .unwrap_or("");
    match Job::from_params(blob, job_id, seed, target) {
        Ok(j) => Some(j),
        Err(e) => {
            eprintln!("bad job: {e}");
            None
        }
    }
}

impl StratumClient {
    pub fn connect(proxy_url: &str) -> Result<Self, String> {
        let (ws, _resp) = connect(proxy_url).map_err(|e| format!("ws connect {proxy_url}: {e}"))?;
        Ok(StratumClient {
            ws,
            next_id: 1,
            pending: HashMap::new(),
        })
    }

    pub fn set_read_timeout(&mut self, dur: Option<std::time::Duration>) {
        match self.ws.get_mut() {
            MaybeTlsStream::Plain(s) => {
                let _ = s.set_read_timeout(dur);
            }
            MaybeTlsStream::Rustls(t) => {
                let _ = t.get_ref().set_read_timeout(dur);
            }
            _ => {}
        }
    }

    fn send(&mut self, v: Value) -> Result<(), String> {
        let line = format!("{}\n", v);
        self.ws
            .send(Message::Text(line))
            .map_err(|e| format!("ws send: {e}"))
    }

    fn take_id(&mut self) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        id
    }

    pub fn login(&mut self, login: &str, pass: &str) -> Result<(), String> {
        let id = self.take_id();
        self.pending.insert(id, "login".into());
        self.send(json!({
            "id": id,
            "jsonrpc": "2.0",
            "method": "login",
            "params": {
                "login": login,
                "pass": pass,
                "agent": "randomx-python/1.0.0",
                "algo": ["rx/0"]
            }
        }))
    }

    pub fn submit(
        &mut self,
        session_id: &str,
        job_id: &str,
        nonce_hex: &str,
        result_hex: &str,
    ) -> Result<(), String> {
        let id = self.take_id();
        self.pending.insert(id, "submit".into());
        self.send(json!({
            "id": id,
            "jsonrpc": "2.0",
            "method": "submit",
            "params": {
                "id": session_id,
                "job_id": job_id,
                "nonce": nonce_hex,
                "result": result_hex
            }
        }))
    }

    pub fn keepalived(&mut self, session_id: &str) -> Result<(), String> {
        let id = self.take_id();
        self.pending.insert(id, "keepalived".into());
        self.send(json!({
            "id": id,
            "jsonrpc": "2.0",
            "method": "keepalived",
            "params": { "id": session_id }
        }))
    }

    /// Read one frame, parse Stratum messages, emit PoolEvents. Ok(true) if a
    /// frame was processed, Ok(false) on read timeout, Err on fatal socket error.
    pub fn pump(&mut self, tx: &Sender<PoolEvent>) -> Result<bool, String> {
        match self.ws.read() {
            Ok(Message::Text(text)) => {
                for line in text.split('\n') {
                    let line = line.trim();
                    if line.is_empty() {
                        continue;
                    }
                    if let Ok(v) = serde_json::from_str::<Value>(line) {
                        handle_message(&v, tx, &mut self.pending);
                    }
                }
                Ok(true)
            }
            Ok(Message::Binary(_)) | Ok(Message::Ping(_)) | Ok(Message::Pong(_)) => Ok(true),
            Ok(Message::Close(_)) => Err("pool closed connection".into()),
            Ok(Message::Frame(_)) => Ok(true),
            Err(tungstenite::Error::Io(e))
                if e.kind() == std::io::ErrorKind::WouldBlock
                    || e.kind() == std::io::ErrorKind::TimedOut =>
            {
                Ok(false)
            }
            Err(e) => Err(format!("ws read: {e}")),
        }
    }
}

fn handle_message(m: &Value, tx: &Sender<PoolEvent>, pending: &mut HashMap<u64, String>) {
    let method = m.get("method").and_then(|v| v.as_str());

    // Async server push: new job.
    if method == Some("job") {
        if let Some(p) = m.get("params") {
            if let Some(job) = job_from_obj(p) {
                let _ = tx.send(PoolEvent::NewJob(job));
            }
        }
        return;
    }

    // Responses: route by the request id we recorded when sending.
    let id = m.get("id").and_then(|v| v.as_u64());
    let req_method = id.and_then(|i| pending.remove(&i));

    match req_method.as_deref() {
        Some("login") => {
            if let Some(result) = m.get("result").filter(|r| !r.is_null()) {
                if let (Some(session), job_obj) = (
                    result.get("id").and_then(|v| v.as_str()),
                    result.get("job"),
                ) {
                    let _ = tx.send(PoolEvent::LoggedIn {
                        session_id: session.to_string(),
                    });
                    if let Some(job_obj) = job_obj {
                        if let Some(job) = job_from_obj(job_obj) {
                            let _ = tx.send(PoolEvent::NewJob(job));
                        }
                    }
                    return;
                }
            }
            let detail = err_detail(m);
            let _ = tx.send(PoolEvent::LoginFailed(detail));
        }
        Some("submit") => {
            let ok = m
                .get("result")
                .and_then(|r| r.get("status"))
                .and_then(|v| v.as_str())
                .map(|s| s.eq_ignore_ascii_case("OK"))
                .unwrap_or(false);
            let detail = if ok { "OK".to_string() } else { err_detail(m) };
            let _ = tx.send(PoolEvent::SubmitResult { accepted: ok, detail });
        }
        Some("keepalived") => {
            // { "result": { "status": "KEEPALIVED" } } — informational, ignore.
        }
        _ => {
            // Unknown/untracked id. If it clearly carries a job, surface it.
            if let Some(result) = m.get("result").filter(|r| !r.is_null()) {
                if let Some(job_obj) = result.get("job") {
                    if let Some(job) = job_from_obj(job_obj) {
                        let _ = tx.send(PoolEvent::NewJob(job));
                    }
                }
            }
        }
    }

    let _ = as_str; // keep helper referenced across cfgs
}

/// Extract a human-readable error message from a JSON-RPC error object.
fn err_detail(m: &Value) -> String {
    m.get("error")
        .filter(|e| !e.is_null())
        .map(|err| {
            err.get("message")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string())
                .unwrap_or_else(|| err.to_string())
        })
        .unwrap_or_else(|| "unknown error".to_string())
}
