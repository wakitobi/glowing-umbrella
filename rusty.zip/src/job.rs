//! Monero-style RandomX job handling: blob nonce insertion, target parsing,
//! and share validation. The pool (xmr.kryptex.network via the Koyeb wss proxy)
//! speaks the standard Monero Stratum `login`/`job`/`submit` protocol.
//!
//! - blob: hex-encoded block-hashing template (typically 76 bytes). The 4-byte
//!   nonce lives at byte offset 39 (little-endian).
//! - target: hex string, little-endian. 4-byte compact form is expanded to a
//!   64-bit target the xmrig way; 8-byte form is read directly.
//! - share check: the last 8 bytes of the RandomX hash, read as a LE u64, must
//!   be strictly less than the 64-bit target.

/// Nonce offset inside a Monero hashing blob.
pub const NONCE_OFFSET: usize = 39;

#[derive(Debug, Clone)]
pub struct Job {
    pub job_id: String,
    pub blob: Vec<u8>,
    pub seed_hash: String,
    pub target: u64,
    /// full target hex as sent (kept for logging)
    pub target_hex: String,
}

/// Parse a Monero target hex string into a 64-bit target (xmrig semantics).
pub fn parse_target(target_hex: &str) -> u64 {
    let bytes = match hex::decode(target_hex) {
        Ok(b) => b,
        Err(_) => return 0,
    };
    match bytes.len() {
        0 => 0,
        1..=4 => {
            let mut buf = [0u8; 4];
            buf[..bytes.len()].copy_from_slice(&bytes);
            let t32 = u32::from_le_bytes(buf) as u64;
            if t32 == 0 {
                return u64::MAX;
            }
            // xmrig: 0xFFFFFFFFFFFFFFFF / (0xFFFFFFFF / t32)
            let denom = 0xFFFF_FFFFu64 / t32;
            if denom == 0 {
                u64::MAX
            } else {
                0xFFFF_FFFF_FFFF_FFFFu64 / denom
            }
        }
        _ => {
            let mut buf = [0u8; 8];
            let n = bytes.len().min(8);
            buf[..n].copy_from_slice(&bytes[..n]);
            u64::from_le_bytes(buf)
        }
    }
}

/// Effective difficulty implied by a 64-bit target.
pub fn difficulty_from_target(target: u64) -> u64 {
    if target == 0 {
        0
    } else {
        0xFFFF_FFFF_FFFF_FFFFu64 / target
    }
}

impl Job {
    pub fn from_params(blob_hex: &str, job_id: &str, seed_hash: &str, target_hex: &str) -> Result<Self, String> {
        let blob = hex::decode(blob_hex).map_err(|e| format!("bad blob hex: {e}"))?;
        if blob.len() < NONCE_OFFSET + 4 {
            return Err(format!(
                "blob too short ({} bytes, need >= {})",
                blob.len(),
                NONCE_OFFSET + 4
            ));
        }
        Ok(Job {
            job_id: job_id.to_string(),
            blob,
            seed_hash: seed_hash.to_string(),
            target: parse_target(target_hex),
            target_hex: target_hex.to_string(),
        })
    }

    /// Return a fresh copy of the blob with the nonce written at offset 39 (LE).
    pub fn blob_with_nonce(&self, nonce: u32) -> Vec<u8> {
        let mut b = self.blob.clone();
        b[NONCE_OFFSET..NONCE_OFFSET + 4].copy_from_slice(&nonce.to_le_bytes());
        b
    }

    /// The 4 nonce bytes as they appear in the blob, hex-encoded (submit format).
    pub fn nonce_hex(&self, nonce: u32) -> String {
        hex::encode(nonce.to_le_bytes())
    }
}

/// A RandomX hash meets the target when its low 64 bits (bytes 24..32, LE) are
/// below the 64-bit target.
pub fn meets_target(hash: &[u8], target: u64) -> bool {
    if hash.len() < 32 {
        return false;
    }
    let mut buf = [0u8; 8];
    buf.copy_from_slice(&hash[24..32]);
    u64::from_le_bytes(buf) < target
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn target_4byte_expands() {
        // xmrig canonical: "f3220000" (LE 0x000022f3 = 8947) is a common testnet-ish value.
        let t = parse_target("f3220000");
        assert!(t > 0);
        // difficulty should be a sane positive number
        assert!(difficulty_from_target(t) > 0);
    }

    #[test]
    fn target_ordering() {
        // Larger compact value => easier => larger 64-bit target => lower difficulty.
        let easy = parse_target("ffff0000"); // 0x0000ffff
        let hard = parse_target("00100000"); // 0x00001000
        assert!(easy > hard);
        assert!(difficulty_from_target(easy) < difficulty_from_target(hard));
    }

    #[test]
    fn nonce_written_at_offset_39() {
        let mut blob = vec![0u8; 76];
        blob[NONCE_OFFSET] = 0xAA; // will be overwritten
        let job = Job {
            job_id: "j".into(),
            blob,
            seed_hash: "s".into(),
            target: 1,
            target_hex: "".into(),
        };
        let b = job.blob_with_nonce(0x11223344);
        assert_eq!(&b[NONCE_OFFSET..NONCE_OFFSET + 4], &[0x44, 0x33, 0x22, 0x11]);
        assert_eq!(job.nonce_hex(0x11223344), "44332211");
    }

    #[test]
    fn share_check_low_bits() {
        let mut hash = [0xffu8; 32];
        // set low 64 bits to 5
        hash[24..32].copy_from_slice(&5u64.to_le_bytes());
        assert!(meets_target(&hash, 10));
        assert!(!meets_target(&hash, 5));
        assert!(!meets_target(&hash, 4));
    }
}
