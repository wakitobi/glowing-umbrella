//! RandomX hashing, wrapping the `rust-randomx` crate (which builds and links
//! the upstream tevador/RandomX C++ core). The pool key ("seed hash") changes
//! only every ~2048 blocks, so the expensive `Context` (dataset/cache init) is
//! built once per seed and shared across all worker threads.

use rust_randomx::{Context, Hasher};
use std::sync::Arc;

/// Build a RandomX context for a given seed hash.
///
/// `fast=true` allocates the full ~2 GiB dataset (fast-mode, best hashrate);
/// `fast=false` uses the ~256 MiB cache (light-mode, slower but low memory).
pub fn new_context(seed: &[u8], fast: bool) -> Arc<Context> {
    Arc::new(Context::new(seed, fast))
}

/// A thread-local hasher bound to a shared context.
pub struct RxHasher {
    inner: Hasher,
}

impl RxHasher {
    pub fn new(ctx: Arc<Context>) -> Self {
        RxHasher {
            inner: Hasher::new(ctx),
        }
    }

    /// Rebind to a new context (called when the pool rotates the seed hash).
    pub fn update(&mut self, ctx: Arc<Context>) {
        self.inner.update(ctx);
    }

    /// Hash an input blob, returning the 32-byte RandomX output.
    pub fn hash(&self, input: &[u8]) -> [u8; 32] {
        let out = self.inner.hash(input);
        let mut h = [0u8; 32];
        h.copy_from_slice(out.as_ref());
        h
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Official RandomX test vector (tevador/RandomX README, key "test key 000").
    #[test]
    fn official_vector() {
        let ctx = new_context(b"test key 000", false);
        let hasher = RxHasher::new(ctx);
        let h = hasher.hash(b"This is a test");
        assert_eq!(
            hex::encode(h),
            "639183aae1bf4c9a35884cb46b09cad9175f04efd7684e7262a0ac1c2f0b4e3f"
        );
    }
}
