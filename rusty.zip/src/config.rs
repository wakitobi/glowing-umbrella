//! Pool configuration, loaded from the same `.env` the Python `redis` miner uses.
//! Keys: REDIS_URL (wss:// koyeb proxy), REDIS_PAIR (base64 url-path of the real
//! pool host:port), REDIS_USER (wallet/login), REDIS_PASS, REDIS_PIPE (threads).
//! The proxy URL is `REDIS_URL + "/" + REDIS_PAIR` (matches main.py: url=_u+'/'+_v).

use std::collections::HashMap;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone)]
pub struct Config {
    /// Full wss:// Koyeb proxy URL including the base64 pool-target path.
    pub proxy: String,
    pub login: String,
    pub pass: String,
    pub threads: usize,
}

fn parse_env(text: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') || !line.contains('=') {
            continue;
        }
        let (k, v) = line.split_once('=').unwrap();
        let mut v = v.trim().to_string();
        if (v.starts_with('"') && v.ends_with('"') && v.len() >= 2)
            || (v.starts_with('\'') && v.ends_with('\'') && v.len() >= 2)
        {
            v = v[1..v.len() - 1].to_string();
        }
        map.insert(k.trim().to_string(), v);
    }
    map
}

impl Config {
    pub fn load(explicit: Option<&str>) -> Result<Self, String> {
        let candidates: Vec<String> = if let Some(p) = explicit {
            vec![p.to_string()]
        } else {
            vec![".env".into(), "../.env".into(), "../../.env".into()]
        };

        let path = candidates
            .iter()
            .find(|c| Path::new(c).is_file())
            .cloned()
            .ok_or_else(|| {
                format!(
                    "no .env found (looked in: {}). Pass --env <path>.",
                    candidates.join(", ")
                )
            })?;

        let text = fs::read_to_string(&path).map_err(|e| format!("read {path}: {e}"))?;
        let m = parse_env(&text);
        let get = |k: &str| m.get(k).cloned().unwrap_or_default();

        let url = get("REDIS_URL");
        let pair = get("REDIS_PAIR");
        if url.is_empty() {
            return Err(format!("`REDIS_URL` missing in {path}"));
        }
        if pair.is_empty() {
            return Err(format!("`REDIS_PAIR` missing in {path}"));
        }
        let login = get("REDIS_USER");
        if login.is_empty() {
            return Err(format!("`REDIS_USER` missing in {path}"));
        }

        // main.py: url=_u+'/'+_v  (avoid a double slash if REDIS_URL ends with '/')
        let proxy = format!("{}/{}", url.trim_end_matches('/'), pair);

        let threads = m
            .get("REDIS_PIPE")
            .and_then(|s| s.parse::<usize>().ok())
            .filter(|&n| n > 0)
            .unwrap_or_else(num_cpus::get);

        Ok(Config {
            proxy,
            login,
            pass: get("REDIS_PASS"),
            threads,
        })
    }
}
