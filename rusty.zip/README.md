# redis-miner

Native Rust RandomX (rx/0) miner — a clean reimplementation of the disguised
`redis.so` Python miner in `C:\Users\User\redis`. Speaks the Monero Stratum
protocol (login / job / submit / keepalived) over the Koyeb WebSocket proxy,
hashing across N native threads with the upstream tevador/RandomX core (via the
`rust-randomx` crate).

Pool config is read from the same `.env` the Python miner used:

    REDIS_URL   wss:// Koyeb proxy base URL
    REDIS_PAIR  base64 of the real pool host:port (proxy path)
    REDIS_USER  wallet / login
    REDIS_PASS  password
    REDIS_PIPE  thread count

The proxy URL is `REDIS_URL + "/" + REDIS_PAIR` (matches the original `main.py`).

## Windows (already built here)

    cd /c/Users/User/redis/rust-miner
    ./target/release/redis-miner.exe --env ../.env --threads 28

Flags: `--threads N`, `--env PATH`. Set `REDIS_LIGHT=1` for light-mode
(256 MiB cache, slower) on RAM-constrained machines; default is fast-mode
(~2 GiB dataset, best hashrate).

Verified live: login OK, share ACCEPTED, ~2,600 H/s on 12 threads.

## Linux deploy (VPS / box you own)

Copy the source tree (NOT `target/` — it's gitignored and rebuilds) plus your
`.env`, then:

    bash setup.sh                    # build + run in foreground
    bash setup.sh --threads 8        # override thread count
    bash setup.sh --light            # low-RAM light mode
    bash setup.sh --install-service  # systemd unit (Restart=always), then:
    journalctl -u redis-miner -f     # follow logs
    bash setup.sh --uninstall        # stop + remove the unit

`setup.sh` installs gcc/g++/make/cmake + rustup if missing (rust-randomx builds
the RandomX C++ core via cmake), enables hugepages best-effort, builds
`--release`, and either runs foreground or installs the service. It finds `.env`
at `./.env` or `../.env`.

## Layout

    src/config.rs    .env loader → proxy URL + login + threads
    src/randomx.rs   rust-randomx Context/Hasher wrapper (one Context per seed)
    src/job.rs       Monero blob nonce insertion, target parse, share check
    src/stratum.rs   Monero-protocol Stratum over WebSocket (id-routed responses)
    src/main.rs      orchestration: seed→Context, worker threads, submit/keepalive

## Notes

- First job has a few-second pause while the RandomX dataset builds ("building
  RandomX context…"). Only repeats when the pool rotates the seed hash
  (~every 2048 blocks).
- `cargo test --release` runs the official RandomX test vector + target math.
- Only mine on hardware you own or legitimately rent.
