#!/usr/bin/env bash
# Build + run the native Rust RandomX (rx/0) miner on a Linux machine (VPS/box).
# Installs Rust + a C/C++ toolchain + cmake if missing (rust-randomx builds the
# upstream tevador/RandomX C++ core via cmake), builds --release, then either
# runs in the foreground or installs a systemd service (--install-service).
#
# Usage:
#   bash setup.sh                    # build + run in foreground
#   bash setup.sh --threads 8        # override thread count
#   bash setup.sh --light            # light-mode (256 MiB, slower, low-RAM boxes)
#   bash setup.sh --install-service  # build + install+start systemd unit
#   bash setup.sh --uninstall        # stop + remove systemd unit
#
# .env: looked up at ./.env first, then ../.env (the redis/ folder layout).
# Copy your .env next to this script for a self-contained deploy.
set -uo pipefail
cd "$(dirname "$0")"
ROOT="$(pwd)"
SVC="redis-miner"

THREADS=""
INSTALL_SERVICE=0
UNINSTALL=0
LIGHT=0
while [ $# -gt 0 ]; do
  case "$1" in
    --threads|-t) THREADS="$2"; shift 2;;
    --light) LIGHT=1; shift;;
    --install-service) INSTALL_SERVICE=1; shift;;
    --uninstall) UNINSTALL=1; shift;;
    *) echo "unknown arg: $1" >&2; exit 2;;
  esac
done

SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

# ---- uninstall path ----
if [ "$UNINSTALL" -eq 1 ]; then
  $SUDO systemctl stop "$SVC" 2>/dev/null || true
  $SUDO systemctl disable "$SVC" 2>/dev/null || true
  $SUDO rm -f "/etc/systemd/system/$SVC.service"
  $SUDO systemctl daemon-reload 2>/dev/null || true
  echo "$SVC service removed."
  exit 0
fi

# ---- locate .env (./ then ../) ----
ENV_FILE=""
if [ -f "$ROOT/.env" ]; then
  ENV_FILE="$ROOT/.env"
elif [ -f "$ROOT/../.env" ]; then
  ENV_FILE="$(cd "$ROOT/.." && pwd)/.env"
fi
if [ -z "$ENV_FILE" ]; then
  echo "ERROR: no .env found (looked in $ROOT/.env and $ROOT/../.env)." >&2
  echo "       It needs REDIS_URL / REDIS_PAIR / REDIS_USER / REDIS_PASS / REDIS_PIPE." >&2
  exit 1
fi
echo "using env: $ENV_FILE"

# ---- C/C++ toolchain + cmake ----
echo "== checking C/C++ toolchain + cmake =="
need_pkgs=0
command -v cc  >/dev/null 2>&1 || command -v gcc >/dev/null 2>&1 || need_pkgs=1
command -v c++ >/dev/null 2>&1 || command -v g++ >/dev/null 2>&1 || need_pkgs=1
command -v cmake >/dev/null 2>&1 || need_pkgs=1
if [ "$need_pkgs" -eq 1 ]; then
  echo "installing build tools (gcc/g++/make/cmake)…"
  if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update -y >/dev/null 2>&1 && $SUDO apt-get install -y build-essential cmake curl >/dev/null 2>&1
  elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf install -y gcc gcc-c++ make cmake curl >/dev/null 2>&1
  elif command -v yum >/dev/null 2>&1; then
    $SUDO yum install -y gcc gcc-c++ make cmake curl >/dev/null 2>&1
  elif command -v pacman >/dev/null 2>&1; then
    $SUDO pacman -Sy --noconfirm base-devel cmake curl >/dev/null 2>&1
  elif command -v apk >/dev/null 2>&1; then
    $SUDO apk add --no-cache build-base cmake curl >/dev/null 2>&1
  elif command -v zypper >/dev/null 2>&1; then
    $SUDO zypper -n install gcc gcc-c++ make cmake curl >/dev/null 2>&1
  else
    echo "ERROR: no known package manager; install gcc, g++, make, cmake manually." >&2
    exit 1
  fi
fi
command -v cmake >/dev/null 2>&1 || { echo "ERROR: cmake still missing (required by rust-randomx)." >&2; exit 1; }
(command -v g++ >/dev/null 2>&1 || command -v c++ >/dev/null 2>&1) || { echo "ERROR: no C++ compiler." >&2; exit 1; }
echo "cc:    $(command -v cc || command -v gcc)"
echo "c++:   $(command -v c++ || command -v g++)"
echo "cmake: $(command -v cmake) ($(cmake --version | head -1))"

# ---- Rust toolchain ----
echo "== checking Rust =="
export PATH="$HOME/.cargo/bin:$PATH"
if ! command -v cargo >/dev/null 2>&1; then
  echo "installing rustup (stable, minimal)…"
  curl -sSfL https://sh.rustup.rs | sh -s -- -y --default-toolchain stable --profile minimal
  export PATH="$HOME/.cargo/bin:$PATH"
fi
command -v cargo >/dev/null 2>&1 || { echo "ERROR: cargo not on PATH after install." >&2; exit 1; }
echo "cargo: $(cargo --version)"

# ---- build ----
echo "== building --release (first build compiles the RandomX C++ core; ~1-3 min) =="
cargo build --release || { echo "ERROR: build failed." >&2; exit 1; }
BIN="$ROOT/target/release/$SVC"
[ -x "$BIN" ] || { echo "ERROR: binary not produced at $BIN" >&2; exit 1; }
echo "built: $BIN"

# ---- optional: enable hugepages for a RandomX speed boost ----
# RandomX likes 1280 x 2 MiB hugepages (dataset + cache). Best-effort; ignore failures.
echo "== enabling transparent/explicit hugepages (best-effort) =="
$SUDO sysctl -w vm.nr_hugepages=1280 >/dev/null 2>&1 || true

RUN_ARGS=""
[ -n "$THREADS" ] && RUN_ARGS="--threads $THREADS"

# ---- systemd install path ----
if [ "$INSTALL_SERVICE" -eq 1 ]; then
  RUN_USER="${SUDO_USER:-$(id -un)}"
  UNIT="/etc/systemd/system/$SVC.service"
  LIGHT_ENV=""
  [ "$LIGHT" -eq 1 ] && LIGHT_ENV="Environment=REDIS_LIGHT=1"
  echo "== installing systemd unit ($UNIT), user=$RUN_USER =="
  $SUDO tee "$UNIT" >/dev/null <<EOF
[Unit]
Description=RandomX rx/0 native Rust miner (redis-miner)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$ROOT
$LIGHT_ENV
ExecStart=$BIN --env $ENV_FILE $RUN_ARGS
Restart=always
RestartSec=5
Nice=10

[Install]
WantedBy=multi-user.target
EOF
  chmod 600 "$ENV_FILE" 2>/dev/null || true
  $SUDO systemctl daemon-reload
  $SUDO systemctl enable "$SVC" >/dev/null 2>&1
  $SUDO systemctl restart "$SVC"
  sleep 3
  echo "== status =="
  $SUDO systemctl --no-pager --full status "$SVC" | head -15 || true
  echo
  echo "logs:   journalctl -u $SVC -f"
  echo "stop:   $SUDO systemctl stop $SVC"
  echo "remove: bash setup.sh --uninstall"
  exit 0
fi

# ---- foreground run ----
echo "== running in foreground (Ctrl-C to stop) =="
[ "$LIGHT" -eq 1 ] && export REDIS_LIGHT=1
exec "$BIN" --env "$ENV_FILE" $RUN_ARGS
