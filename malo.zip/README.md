# power2b web miner (Linux deploy)

Runs the mbc power2b miner inside headless Chrome, driven by a web page that
talks Stratum over WebSocket straight to your Koyeb proxy (same pool config as
the Python miner). No third-party relay, no fee.

## Layout

    .env                 pool config (proxy wss URL, username, password, threads)
    web/index.html       the embedded miner page (JS Stratum client + stats UI)
    web/worker.js        power2b WASM miner worker (works on any OS/arch)
    web/server.py        tiny python3 web server, injects .env config, port 8765
    setup.sh             install chromium if needed, start server + headless chrome
    stop.sh              stop both

## Quick start (on the Linux machine)

    tar xzf web-miner-linux.tar.gz
    cd web-miner-linux
    bash setup.sh

That's it. It auto-installs Chromium when missing (needs sudo for apt/dnf),
then launches headless Chrome mining the page. ~5 seconds later it's hashing.

Check it:
    curl http://127.0.0.1:8765/          # page is served
    tail -f web/server.log chrome.log   # logs
    # open http://127.0.0.1:8765/ in any browser to watch stats live
    # (use --headless=new --remote-debugging-port=9222 for CDP automation)

Stop:   bash stop.sh
Restart: bash setup.sh

## Tuning

    MINER_WEB_PORT=8765 MINER_WORKERS=7 bash setup.sh   # workers + ports
    # note: page caps workers at min(7, CPU cores) via .env threads

## Notes

- .env contains your pool credentials — keep the tarball private.
- server binds 127.0.0.1 only. To view the dashboard from another machine,
  set MINER_WEB_PORT and edit server.py bind to 0.0.0.0 (or ssh -L 8765:localhost:8765).
- Wasm hashrate (~250-400 H/s/7 workers) is much lower than the native Python
  miner. Real valid shares, just slow — fine for monitoring/experiments.
