@echo off
REM Quick start script for CUDA12 Solana Miner (Windows)

REM Configuration - Edit these values
set PROXY=your-pool.example.com:8080
set ADDRESS=prlYourWalletAddressHere
set WORKER=rig-01

REM Run miner
python miner.py --proxy %PROXY% --address %ADDRESS% --worker %WORKER% %*
