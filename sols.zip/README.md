# CUDA12 Solana Miner
# Python wrapper for CUDA-based Solana mining

Python wrapper for the CUDA12 Solana GPU mining application.

## Features

- Clean Python CLI interface with colored output
- Interactive setup wizard
- Environment variable support (PROXY, ADDRESS)
- GPU configuration and tuning options
- Cross-platform (Linux, macOS, Windows)

## Quick Start

### 1. Prerequisites

- Python 3.7 or higher
- NVIDIA GPU with CUDA support
- The `cuda12` miner binary

### 2. Basic Usage

```bash
# Using command line arguments
python miner.py --proxy pool.example.com:8080 --address prlABC123...

# Using environment variables
export PROXY=pool.example.com:8080
export ADDRESS=prlABC123...
python miner.py

# Interactive mode
python miner.py --interactive
```

### 3. Windows

```batch
# Edit start-miner.bat with your values, then run:
start-miner.bat
```

### 4. Linux/macOS

```bash
# Edit start-miner.sh with your values, then run:
chmod +x start-miner.sh
./start-miner.sh
```

## Command Line Options

### Connection Settings
| Flag | Description |
|------|-------------|
| `--proxy, -p` | Stratum proxy address (HOST:PORT) |
| `--address, -a` | Your Solana wallet address |
| `--worker, -w` | Worker/rig name |

### Mining Mode
| Flag | Description |
|------|-------------|
| `--cpu` | Use CPU mining only |
| `--small` | Use small GPU shape (8192x49152) |
| `--startup-bench` | Run GPU autotune at startup |

### GPU Configuration
| Flag | Description |
|------|-------------|
| `--print-gpu-instances` | Show available GPUs and exit |
| `--gpu-instances` | Specify GPU instance config |
| `--gpu-proof-config` | GPU proof configuration |
| `--gpu-hash-config` | GPU hash configuration |

### Performance Tuning
| Flag | Description |
|------|-------------|
| `--build-threads N` | Number of build threads |
| `--stats-interval N` | Stats display interval (seconds) |

### Networking
| Flag | Description |
|------|-------------|
| `--keepalive-interval N` | Keepalive interval (seconds) |
| `--reconnect-delay N` | Reconnect delay (seconds) |
| `--submit-version v3/v4` | Submit protocol version |

## Environment Variables

| Variable | Description |
|----------|-------------|
| `PROXY` | Default stratum proxy |
| `ADDRESS` | Default wallet address |

## Examples

```bash
# Single GPU, standard mode
python miner.py -p pool:8080 -a prlABC123 -w rig-1

# Multi-GPU with autotune
python miner.py -p pool:8080 -a prlABC123 --startup-bench --stats-interval 60

# CPU only mode
python miner.py -p pool:8080 -a prlABC123 --cpu

# Low memory GPU
python miner.py -p pool:8080 -a prlABC123 --small

# Query GPU info
python miner.py --print-gpu-instances
```

## Troubleshooting

### Binary not found
Make sure `cuda12` is in the same directory as `miner.py` or in your PATH.

### Permission denied
```bash
chmod +x cuda12
chmod +x miner.py
```

### GPU not detected
Run `--print-gpu-instances` to check GPU visibility.

## License

MIT
