#!/usr/bin/env python3
"""
Python wrapper for CUDA12 Solana GPU Miner

Usage:
    python miner.py --proxy <HOST:PORT> --address <ADDRESS> [--worker <NAME>]
    python miner.py --address <ADDRESS>                    # Uses default proxy from env
    python miner.py --print-gpu-instances                  # Print GPU info and exit
"""

import argparse
import os
import subprocess
import sys
import shutil
from pathlib import Path
from typing import Optional, List


# ANSI color codes for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'


def colorize(text: str, color: str) -> str:
    """Add color to text if terminal supports it."""
    if hasattr(sys.stderr, 'isatty') and sys.stderr.isatty():
        return f"{color}{text}{Colors.ENDC}"
    return text


def error(msg: str) -> None:
    print(colorize(f"ERROR: {msg}", Colors.RED), file=sys.stderr)


def warning(msg: str) -> None:
    print(colorize(f"WARNING: {msg}", Colors.YELLOW), file=sys.stderr)


def info(msg: str) -> None:
    print(colorize(f"INFO: {msg}", Colors.CYAN))


def success(msg: str) -> None:
    print(colorize(f"SUCCESS: {msg}", Colors.GREEN))


def validate_address(address: str) -> bool:
    """Validate Solana address prefix (prl/rprl/tprl)."""
    valid_prefixes = ('prl', 'rprl', 'tprl')
    if not any(address.startswith(p) for p in valid_prefixes):
        error(f"Address must start with one of: {', '.join(valid_prefixes)}")
        return False
    if len(address) < 32:
        warning(f"Address seems short: '{address}' (expected 32-44 chars)")
    return True


def validate_proxy(proxy: str) -> bool:
    """Validate proxy format (HOST:PORT)."""
    if ':' not in proxy:
        error("Proxy must be in format HOST:PORT")
        return False

    parts = proxy.rsplit(':', 1)
    host = parts[0]
    try:
        port = int(parts[1])
        if port < 1 or port > 65535:
            error(f"Port must be between 1 and 65535, got {port}")
            return False
    except ValueError:
        error(f"Invalid port number: {parts[1]}")
        return False

    return True


def find_miner_binary() -> Optional[Path]:
    """Find the cuda12 miner binary."""
    # Check in the same directory as this script
    script_dir = Path(__file__).parent.resolve()
    local_binary = script_dir / "cuda12"

    if local_binary.exists():
        return local_binary

    # Check in ./sols/ relative to current directory
    sols_binary = Path("sols/cuda12")
    if sols_binary.exists():
        return sols_binary.resolve()

    # Check if it's in PATH
    if shutil.which("cuda12"):
        return Path(shutil.which("cuda12"))

    # Check common locations
    common_paths = [
        Path("/usr/local/bin/cuda12"),
        Path("/usr/bin/cuda12"),
        Path.home() / "cuda12",
    ]

    for path in common_paths:
        if path.exists():
            return path

    return None


def build_arguments(args: argparse.Namespace) -> List[str]:
    """Build the argument list for the miner binary."""
    miner_args: List[str] = []

    # Proxy address
    if args.proxy:
        miner_args.extend(["--proxy", args.proxy])

    # Wallet address
    if args.address:
        miner_args.extend(["--address", args.address])

    # Worker name
    if args.worker:
        miner_args.extend(["--worker", args.worker])

    # CPU mode
    if args.cpu:
        miner_args.append("--cpu")

    # Small mode
    if args.small:
        miner_args.append("--small")

    # Startup benchmark
    if args.startup_bench:
        miner_args.append("--startup-bench")

    # Print GPU instances
    if args.print_gpu_instances:
        miner_args.append("--print-gpu-instances")

    # GPU instances config
    if args.gpu_instances:
        miner_args.extend(["--gpu-instances", args.gpu_instances])

    # GPU proof config
    if args.gpu_proof_config:
        miner_args.extend(["--gpu-proof-config", args.gpu_proof_config])

    # GPU hash config
    if args.gpu_hash_config:
        miner_args.extend(["--gpu-hash-config", args.gpu_hash_config])

    # Build threads
    if args.build_threads:
        miner_args.extend(["--build-threads", str(args.build_threads)])

    # Stats interval
    if args.stats_interval:
        miner_args.extend(["--stats-interval", str(args.stats_interval)])

    # Keepalive interval
    if args.keepalive_interval:
        miner_args.extend(["--keepalive-interval", str(args.keepalive_interval)])

    # Reconnect delay
    if args.reconnect_delay:
        miner_args.extend(["--reconnect-delay", str(args.reconnect_delay)])

    # Submit version
    if args.submit_version:
        miner_args.extend(["--submit-version", args.submit_version])

    return miner_args


def check_dependencies() -> None:
    """Check for required dependencies."""
    # Check if miner binary exists and is executable
    binary = find_miner_binary()
    if not binary:
        error("Could not find 'cuda12' miner binary!")
        print(file=sys.stderr)
        print("Please ensure the cuda12 binary is in one of:", file=sys.stderr)
        print("  - The same directory as this script", file=sys.stderr)
        print("  - ./sols/cuda12", file=sys.stderr)
        print("  - /usr/local/bin/cuda12", file=sys.stderr)
        print("  - In your PATH", file=sys.stderr)
        sys.exit(1)

    if not os.access(binary, os.X_OK):
        warning(f"Binary {binary} is not executable, attempting to fix...")
        try:
            os.chmod(binary, 0o755)
        except Exception as e:
            error(f"Could not make binary executable: {e}")
            sys.exit(1)

    info(f"Using miner binary: {binary}")


def run_miner(args: argparse.Namespace) -> int:
    """Run the miner with the specified arguments."""
    binary = find_miner_binary()
    if not binary:
        error("Miner binary not found!")
        return 1

    miner_args = build_arguments(args)

    info(f"Starting miner with args: {' '.join(miner_args)}")

    try:
        # Run the miner
        process = subprocess.Popen(
            [str(binary)] + miner_args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )

        # Stream output in real-time
        if process.stdout:
            for line in iter(process.stdout.readline, ''):
                if line:
                    print(line, end='')

        return process.wait()

    except KeyboardInterrupt:
        info("Received interrupt signal, shutting down...")
        if process:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        return 130  # Standard exit code for SIGINT
    except Exception as e:
        error(f"Failed to run miner: {e}")
        return 1


def print_gpu_info(args: argparse.Namespace) -> int:
    """Print GPU instances and exit."""
    binary = find_miner_binary()
    if not binary:
        error("Miner binary not found!")
        return 1

    info("Querying GPU instances...")

    try:
        result = subprocess.run(
            [str(binary), "--print-gpu-instances"],
            capture_output=True,
            text=True
        )
        print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        return result.returncode
    except Exception as e:
        error(f"Failed to query GPUs: {e}")
        return 1


def interactive_setup() -> Optional[argparse.Namespace]:
    """Interactive setup wizard if no arguments provided."""
    print(colorize("\n=== CUDA12 Solana Miner Setup ===\n", Colors.HEADER + Colors.BOLD))

    # Get proxy
    proxy = input(f"{Colors.CYAN}Stratum Proxy (HOST:PORT){Colors.ENDC} "
                  f"[{Colors.YELLOW}press Enter for PROXY env var{Colors.ENDC}]: ").strip()
    if not proxy:
        proxy = os.environ.get('PROXY', '')
    if proxy and not validate_proxy(proxy):
        return None

    # Get address
    address = input(f"{Colors.CYAN}Wallet Address{Colors.ENDC} "
                    f"[{Colors.YELLOW}press Enter for ADDRESS env var{Colors.ENDC}]: ").strip()
    if not address:
        address = os.environ.get('ADDRESS', '')
    if address and not validate_address(address):
        return None

    if not address and not proxy:
        error("Either --proxy/ADDRESS or --address/PROXY must be provided!")
        return None

    # Get worker name
    worker = input(f"{Colors.CYAN}Worker Name{Colors.ENDC} "
                   f"[{Colors.YELLOW}optional, press Enter to skip{Colors.ENDC}]: ").strip()

    # Get mode
    print(f"\n{Colors.CYAN}Mining Mode:{Colors.ENDC}")
    print("  1. GPU (default)")
    print("  2. CPU only")
    mode = input(f"{Colors.CYAN}Choice{Colors.ENDC} [1]: ").strip()

    cpu_mode = mode == '2'
    small_mode = input(f"{Colors.CYAN}Use small GPU shape (8192x49152){Colors.ENDC} [y/N]: ").strip().lower() == 'y'
    startup_bench = input(f"{Colors.CYAN}Run GPU autotune at startup{Colors.ENDC} [y/N]: ").strip().lower() == 'y'

    # Build namespace
    class Args:
        proxy = proxy if proxy else None
        address = address if address else None
        worker = worker if worker else None
        cpu = cpu_mode
        small = small_mode
        startup_bench = startup_bench
        print_gpu_instances = False
        gpu_instances = None
        gpu_proof_config = None
        gpu_hash_config = None
        build_threads = None
        stats_interval = None
        keepalive_interval = None
        reconnect_delay = None
        submit_version = None

    return Args()


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        description=colorize("CUDA12 Solana GPU Miner", Colors.CYAN + Colors.BOLD),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --proxy localhost:8080 --address prlABC123...
  %(prog)s --address prlABC123... --worker my-rig-01 --small
  %(prog)s --print-gpu-instances
  PROXY=pool:8080 ADDRESS=prlABC123... %(prog)s

Environment Variables:
  PROXY    Default stratum proxy (HOST:PORT)
  ADDRESS  Default wallet address
"""
    )

    # Connection settings
    conn_group = parser.add_argument_group(colorize('Connection Settings', Colors.BLUE))
    conn_group.add_argument(
        '--proxy', '-p',
        metavar='HOST:PORT',
        help='Stratum bridge address (env: PROXY)'
    )
    conn_group.add_argument(
        '--address', '-a',
        metavar='ADDRESS',
        help='Solana wallet address (env: ADDRESS)'
    )
    conn_group.add_argument(
        '--worker', '-w',
        metavar='NAME',
        help='Worker/rig name (default: hostname)'
    )

    # Mining mode
    mode_group = parser.add_argument_group(colorize('Mining Mode', Colors.BLUE))
    mode_group.add_argument(
        '--cpu',
        action='store_true',
        help='Disable GPU mining and use CPU mode'
    )
    mode_group.add_argument(
        '--small',
        action='store_true',
        help='Force 8192x49152 GPU shape for lower memory GPUs'
    )
    mode_group.add_argument(
        '--startup-bench',
        action='store_true',
        help='Run GPU parameter autotune before mining'
    )

    # GPU configuration
    gpu_group = parser.add_argument_group(colorize('GPU Configuration', Colors.BLUE))
    gpu_group.add_argument(
        '--print-gpu-instances',
        action='store_true',
        help='Print resolved GPU instances and exit'
    )
    gpu_group.add_argument(
        '--gpu-instances',
        metavar='CONFIG',
        help='GPU instance configuration'
    )
    gpu_group.add_argument(
        '--gpu-proof-config',
        metavar='CONFIG',
        help='GPU proof configuration'
    )
    gpu_group.add_argument(
        '--gpu-hash-config',
        metavar='CONFIG',
        help='GPU hash configuration'
    )

    # Performance tuning
    perf_group = parser.add_argument_group(colorize('Performance Tuning', Colors.BLUE))
    perf_group.add_argument(
        '--build-threads',
        metavar='N',
        type=int,
        help='Number of build threads'
    )

    # Networking
    net_group = parser.add_argument_group(colorize('Networking', Colors.BLUE))
    net_group.add_argument(
        '--stats-interval',
        metavar='SECONDS',
        type=int,
        help='Statistics print interval'
    )
    net_group.add_argument(
        '--keepalive-interval',
        metavar='SECONDS',
        type=int,
        help='Keepalive interval in seconds'
    )
    net_group.add_argument(
        '--reconnect-delay',
        metavar='SECONDS',
        type=int,
        help='Delay before reconnecting'
    )

    # Protocol
    proto_group = parser.add_argument_group(colorize('Protocol', Colors.BLUE))
    proto_group.add_argument(
        '--submit-version',
        choices=['v3', 'v4'],
        help='Submit protocol version'
    )

    # Utility
    util_group = parser.add_argument_group(colorize('Utility', Colors.BLUE))
    util_group.add_argument(
        '--interactive', '-i',
        action='store_true',
        help='Run interactive setup wizard'
    )
    util_group.add_argument(
        '--version',
        action='version',
        version='%(prog)s 1.0.0'
    )

    return parser


def main() -> int:
    """Main entry point."""
    parser = create_parser()
    args = parser.parse_args()

    # Interactive mode
    if args.interactive or len(sys.argv) == 1:
        interactive_args = interactive_setup()
        if not interactive_args:
            parser.print_help()
            return 1
        args = interactive_args

    # Check dependencies
    check_dependencies()

    # Print GPU instances and exit
    if args.print_gpu_instances:
        return print_gpu_info(args)

    # Validate required arguments
    if not args.address and not args.proxy:
        # Try environment variables
        env_address = os.environ.get('ADDRESS', '')
        env_proxy = os.environ.get('PROXY', '')

        if not env_address and not env_proxy:
            error("Either --address or --proxy must be provided (or set ADDRESS/PROXY env vars)")
            parser.print_help()
            return 1

        if args.address is None:
            args.address = env_address
        if args.proxy is None:
            args.proxy = env_proxy

    # Validate address format
    if args.address and not validate_address(args.address):
        return 1

    # Validate proxy format
    if args.proxy and not validate_proxy(args.proxy):
        return 1

    # Run the miner
    success("Starting CUDA12 Solana Miner...")
    return run_miner(args)


if __name__ == '__main__':
    sys.exit(main())
