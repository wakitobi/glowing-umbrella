#!/bin/bash
# Quick start script for CUDA12 Solana Miner

# Configuration - Edit these values
PROXY="your-pool.example.com:8080"
ADDRESS="prlYourWalletAddressHere"
WORKER="rig-01"

# Optional settings
# export GPU_INSTANCES="0,1"      # Specify GPU indices
# export BUILD_THREADS="8"         # Build thread count
# export STATS_INTERVAL="30"       # Stats display interval

# Run miner
python3 miner.py --proxy "$PROXY" --address "$ADDRESS" --worker "$WORKER" "$@"
